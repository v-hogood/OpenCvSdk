//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/objdetect.hpp"
#import "opencv2/objdetect/mcc_checker_detector.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>
#import "Algorithm.h"

#import "Objdetect.h"
@class Mat;
@class Point2f;



NS_ASSUME_NONNULL_BEGIN

// C++: class CChecker
/**
 * CChecker
 *
 * checker object
 *
 * This class contains the information about the detected checkers,i.e, their
 * type, the corners of the chart, the color profile, the cost, centers chart,
 * etc.
 *
 * Member of `Objdetect`
 */
CV_EXPORTS @interface CChecker : Algorithm


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::mcc::CChecker> nativePtrCChecker;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::mcc::CChecker>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::mcc::CChecker>)nativePtr;
#endif


#pragma mark - Methods


//
// static Ptr_CChecker cv::mcc::CChecker::create()
//
/**
 * Create a new CChecker object.
 *
 * @return A pointer to the implementation of the CChecker
 */
+ (CChecker*)create NS_SWIFT_NAME(create());


//
//  void cv::mcc::CChecker::setTarget(ColorChart _target)
//
- (void)setTarget:(ColorChart)_target NS_SWIFT_NAME(setTarget(_target:));


//
//  void cv::mcc::CChecker::setBox(vector_Point2f _box)
//
- (void)setBox:(NSArray<Point2f*>*)_box NS_SWIFT_NAME(setBox(_box:));


//
//  void cv::mcc::CChecker::setChartsRGB(Mat _chartsRGB)
//
- (void)setChartsRGB:(Mat*)_chartsRGB NS_SWIFT_NAME(setChartsRGB(_chartsRGB:));


//
//  void cv::mcc::CChecker::setChartsYCbCr(Mat _chartsYCbCr)
//
- (void)setChartsYCbCr:(Mat*)_chartsYCbCr NS_SWIFT_NAME(setChartsYCbCr(_chartsYCbCr:));


//
//  void cv::mcc::CChecker::setCost(float _cost)
//
- (void)setCost:(float)_cost NS_SWIFT_NAME(setCost(_cost:));


//
//  void cv::mcc::CChecker::setCenter(Point2f _center)
//
- (void)setCenter:(Point2f*)_center NS_SWIFT_NAME(setCenter(_center:));


//
//  ColorChart cv::mcc::CChecker::getTarget()
//
- (ColorChart)getTarget NS_SWIFT_NAME(getTarget());


//
//  vector_Point2f cv::mcc::CChecker::getBox()
//
- (NSArray<Point2f*>*)getBox NS_SWIFT_NAME(getBox());


//
//  vector_Point2f cv::mcc::CChecker::getColorCharts()
//
/**
 * Computes and returns the coordinates of the central parts of the charts modules.
 *
 * This method computes transformation matrix from the checkers's coordinates (`CChecker::getBox()`)
 * and find by this the coordinates of the central parts of the charts modules.
 * It is used in `CCheckerDetector::draw()` and in `ChartsRGB` calculation.
 */
- (NSArray<Point2f*>*)getColorCharts NS_SWIFT_NAME(getColorCharts());


//
//  Mat cv::mcc::CChecker::getChartsRGB(bool getStats = true)
//
- (Mat*)getChartsRGB:(BOOL)getStats NS_SWIFT_NAME(getChartsRGB(getStats:));

- (Mat*)getChartsRGB NS_SWIFT_NAME(getChartsRGB());


//
//  Mat cv::mcc::CChecker::getChartsYCbCr()
//
- (Mat*)getChartsYCbCr NS_SWIFT_NAME(getChartsYCbCr());


//
//  float cv::mcc::CChecker::getCost()
//
- (float)getCost NS_SWIFT_NAME(getCost());


//
//  Point2f cv::mcc::CChecker::getCenter()
//
- (Point2f*)getCenter NS_SWIFT_NAME(getCenter());



@end

NS_ASSUME_NONNULL_END


