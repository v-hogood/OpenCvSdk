//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


@class Mat;
@class Point3f;



NS_ASSUME_NONNULL_BEGIN

// C++: class Octree
/**
 * Octree for 3D vision.
 *
 * In 3D vision filed, the Octree is used to process and accelerate the pointcloud data. The class Octree represents
 * the Octree data structure. Each Octree will have a fixed depth. The depth of Octree refers to the distance from
 * the root node to the leaf node.All OctreeNodes will not exceed this depth.Increasing the depth will increase
 * the amount of calculation exponentially. And the small number of depth refers low resolution of Octree.
 * Each node contains 8 children, which are used to divide the space cube into eight parts. Each octree node represents
 * a cube. And these eight children will have a fixed order, the order is described as follows:
 *
 * For illustration, assume,
 *
 * rootNode: origin == (0, 0, 0), size == 2
 *
 * Then,
 *
 * children[0]: origin == (0, 0, 0), size == 1
 *
 * children[1]: origin == (1, 0, 0), size == 1, along X-axis next to child 0
 *
 * children[2]: origin == (0, 1, 0), size == 1, along Y-axis next to child 0
 *
 * children[3]: origin == (1, 1, 0), size == 1, in X-Y plane
 *
 * children[4]: origin == (0, 0, 1), size == 1, along Z-axis next to child 0
 *
 * children[5]: origin == (1, 0, 1), size == 1, in X-Z plane
 *
 * children[6]: origin == (0, 1, 1), size == 1, in Y-Z plane
 *
 * children[7]: origin == (1, 1, 1), size == 1, furthest from child 0
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface Octree : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::Octree> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::Octree>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::Octree>)nativePtr;
#endif


#pragma mark - Methods


//
// static Ptr_Octree cv::Octree::createWithDepth(int maxDepth, double size, Point3f origin = { }, bool withColors = false)
//
/**
 *
 * Creates an empty Octree with given maximum depth
 *
 * @param maxDepth The max depth of the Octree
 * @param size bounding box size for the Octree
 * @param origin Initial center coordinate
 * @param withColors Whether to keep per-point colors or not
 * @return resulting Octree
 */
+ (Octree*)createWithDepth:(int)maxDepth size:(double)size origin:(Point3f*)origin withColors:(BOOL)withColors NS_SWIFT_NAME(createWithDepth(maxDepth:size:origin:withColors:));

/**
 *
 * Creates an empty Octree with given maximum depth
 *
 * @param maxDepth The max depth of the Octree
 * @param size bounding box size for the Octree
 * @param origin Initial center coordinate
 * @return resulting Octree
 */
+ (Octree*)createWithDepth:(int)maxDepth size:(double)size origin:(Point3f*)origin NS_SWIFT_NAME(createWithDepth(maxDepth:size:origin:));

/**
 *
 * Creates an empty Octree with given maximum depth
 *
 * @param maxDepth The max depth of the Octree
 * @param size bounding box size for the Octree
 * @return resulting Octree
 */
+ (Octree*)createWithDepth:(int)maxDepth size:(double)size NS_SWIFT_NAME(createWithDepth(maxDepth:size:));


//
// static Ptr_Octree cv::Octree::createWithDepth(int maxDepth, Mat pointCloud, Mat colors = Mat())
//
/**
 *
 * Create an Octree from the PointCloud data with the specific maxDepth
 *
 * @param maxDepth Max depth of the octree
 * @param pointCloud point cloud data, should be 3-channel float array
 * @param colors color attribute of point cloud in the same 3-channel float format
 * @return resulting Octree
 */
+ (Octree*)createWithDepth:(int)maxDepth pointCloud:(Mat*)pointCloud colors:(Mat*)colors NS_SWIFT_NAME(createWithDepth(maxDepth:pointCloud:colors:));

/**
 *
 * Create an Octree from the PointCloud data with the specific maxDepth
 *
 * @param maxDepth Max depth of the octree
 * @param pointCloud point cloud data, should be 3-channel float array
 * @return resulting Octree
 */
+ (Octree*)createWithDepth:(int)maxDepth pointCloud:(Mat*)pointCloud NS_SWIFT_NAME(createWithDepth(maxDepth:pointCloud:));


//
// static Ptr_Octree cv::Octree::createWithResolution(double resolution, double size, Point3f origin = { }, bool withColors = false)
//
/**
 *
 * Creates an empty Octree with given resolution
 *
 * @param resolution The size of the octree leaf node
 * @param size bounding box size for the Octree
 * @param origin Initial center coordinate
 * @param withColors Whether to keep per-point colors or not
 * @return resulting Octree
 */
+ (Octree*)createWithResolution:(double)resolution size:(double)size origin:(Point3f*)origin withColors:(BOOL)withColors NS_SWIFT_NAME(createWithResolution(resolution:size:origin:withColors:));

/**
 *
 * Creates an empty Octree with given resolution
 *
 * @param resolution The size of the octree leaf node
 * @param size bounding box size for the Octree
 * @param origin Initial center coordinate
 * @return resulting Octree
 */
+ (Octree*)createWithResolution:(double)resolution size:(double)size origin:(Point3f*)origin NS_SWIFT_NAME(createWithResolution(resolution:size:origin:));

/**
 *
 * Creates an empty Octree with given resolution
 *
 * @param resolution The size of the octree leaf node
 * @param size bounding box size for the Octree
 * @return resulting Octree
 */
+ (Octree*)createWithResolution:(double)resolution size:(double)size NS_SWIFT_NAME(createWithResolution(resolution:size:));


//
// static Ptr_Octree cv::Octree::createWithResolution(double resolution, Mat pointCloud, Mat colors = Mat())
//
/**
 *
 * Create an Octree from the PointCloud data with the specific resolution
 *
 * @param resolution The size of the octree leaf node
 * @param pointCloud point cloud data, should be 3-channel float array
 * @param colors color attribute of point cloud in the same 3-channel float format
 * @return resulting octree
 */
+ (Octree*)createWithResolution:(double)resolution pointCloud:(Mat*)pointCloud colors:(Mat*)colors NS_SWIFT_NAME(createWithResolution(resolution:pointCloud:colors:));

/**
 *
 * Create an Octree from the PointCloud data with the specific resolution
 *
 * @param resolution The size of the octree leaf node
 * @param pointCloud point cloud data, should be 3-channel float array
 * @return resulting octree
 */
+ (Octree*)createWithResolution:(double)resolution pointCloud:(Mat*)pointCloud NS_SWIFT_NAME(createWithResolution(resolution:pointCloud:));


//
//  bool cv::Octree::insertPoint(Point3f point, Point3f color = { })
//
/**
 *
 * Insert a point data with color to a OctreeNode.
 *
 * @param point The point data in Point3f format.
 * @param color The color attribute of point in Point3f format.
 * @return Returns whether the insertion is successful.
 */
- (BOOL)insertPoint:(Point3f*)point color:(Point3f*)color NS_SWIFT_NAME(insertPoint(point:color:));

/**
 *
 * Insert a point data with color to a OctreeNode.
 *
 * @param point The point data in Point3f format.
 * @return Returns whether the insertion is successful.
 */
- (BOOL)insertPoint:(Point3f*)point NS_SWIFT_NAME(insertPoint(point:));


//
//  bool cv::Octree::isPointInBound(Point3f point)
//
/**
 * Determine whether the point is within the space range of the specific cube.
 *
 * @param point The point coordinates.
 * @return If point is in bound, return ture. Otherwise, false.
 */
- (BOOL)isPointInBound:(Point3f*)point NS_SWIFT_NAME(isPointInBound(point:));


//
//  bool cv::Octree::empty()
//
- (BOOL)empty NS_SWIFT_NAME(empty());


//
//  void cv::Octree::clear()
//
/**
 * Reset all octree parameter.
 *
 * Clear all the nodes of the octree and initialize the parameters.
 */
- (void)clear NS_SWIFT_NAME(clear());


//
//  bool cv::Octree::deletePoint(Point3f point)
//
/**
 * Delete a given point from the Octree.
 *
 * Delete the corresponding element from the pointList in the corresponding leaf node. If the leaf node
 * does not contain other points after deletion, this node will be deleted. In the same way,
 * its parent node may also be deleted if its last child is deleted.
 * @param point The point coordinates, comparison is epsilon-based
 * @return return ture if the point is deleted successfully.
 */
- (BOOL)deletePoint:(Point3f*)point NS_SWIFT_NAME(deletePoint(point:));


//
//  void cv::Octree::getPointCloudByOctree(Mat& restoredPointCloud, Mat& restoredColor = Mat())
//
/**
 * restore point cloud data from Octree.
 *
 * Restore the point cloud data from existing octree. The points in same leaf node will be seen as the same point.
 * This point is the center of the leaf node. If the resolution is small, it will work as a downSampling function.
 * @param restoredPointCloud The output point cloud data, can be replaced by noArray() if not needed
 * @param restoredColor The color attribute of point cloud data, can be omitted if not needed
 */
- (void)getPointCloudByOctree:(Mat*)restoredPointCloud restoredColor:(Mat*)restoredColor NS_SWIFT_NAME(getPointCloudByOctree(restoredPointCloud:restoredColor:));

/**
 * restore point cloud data from Octree.
 *
 * Restore the point cloud data from existing octree. The points in same leaf node will be seen as the same point.
 * This point is the center of the leaf node. If the resolution is small, it will work as a downSampling function.
 * @param restoredPointCloud The output point cloud data, can be replaced by noArray() if not needed
 */
- (void)getPointCloudByOctree:(Mat*)restoredPointCloud NS_SWIFT_NAME(getPointCloudByOctree(restoredPointCloud:));


//
//  int cv::Octree::radiusNNSearch(Point3f query, float radius, Mat& points, Mat& squareDists = Mat())
//
/**
 * Radius Nearest Neighbor Search in Octree.
 *
 * Search all points that are less than or equal to radius.
 * And return the number of searched points.
 * @param query Query point.
 * @param radius Retrieved radius value.
 * @param points Point output. Contains searched points in 3-float format, and output vector is not in order,
 * can be replaced by noArray() if not needed
 * @param squareDists Dist output. Contains searched squared distance in floats, and output vector is not in order,
 * can be omitted if not needed
 * @return the number of searched points.
 */
- (int)radiusNNSearch:(Point3f*)query radius:(float)radius points:(Mat*)points squareDists:(Mat*)squareDists NS_SWIFT_NAME(radiusNNSearch(query:radius:points:squareDists:));

/**
 * Radius Nearest Neighbor Search in Octree.
 *
 * Search all points that are less than or equal to radius.
 * And return the number of searched points.
 * @param query Query point.
 * @param radius Retrieved radius value.
 * @param points Point output. Contains searched points in 3-float format, and output vector is not in order,
 * can be replaced by noArray() if not needed
 * can be omitted if not needed
 * @return the number of searched points.
 */
- (int)radiusNNSearch:(Point3f*)query radius:(float)radius points:(Mat*)points NS_SWIFT_NAME(radiusNNSearch(query:radius:points:));


//
//  int cv::Octree::radiusNNSearch(Point3f query, float radius, Mat& points, Mat& colors, Mat& squareDists)
//
/**
 *
 * Radius Nearest Neighbor Search in Octree.
 *
 * Search all points that are less than or equal to radius.
 * And return the number of searched points.
 * @param query Query point.
 * @param radius Retrieved radius value.
 * @param points Point output. Contains searched points in 3-float format, and output vector is not in order,
 * can be replaced by noArray() if not needed
 * @param colors Color output. Contains colors corresponding to points in pointSet, can be replaced by noArray() if not needed
 * @param squareDists Dist output. Contains searched squared distance in floats, and output vector is not in order,
 * can be replaced by noArray() if not needed
 * @return the number of searched points.
 */
- (int)radiusNNSearch:(Point3f*)query radius:(float)radius points:(Mat*)points colors:(Mat*)colors squareDists:(Mat*)squareDists NS_SWIFT_NAME(radiusNNSearch(query:radius:points:colors:squareDists:));


//
//  void cv::Octree::KNNSearch(Point3f query, int K, Mat& points, Mat& squareDists = Mat())
//
/**
 * K Nearest Neighbor Search in Octree.
 *
 * Find the K nearest neighbors to the query point.
 * @param query Query point.
 * @param K amount of nearest neighbors to find
 * @param points Point output. Contains K points in 3-float format, arranged in order of distance from near to far,
 * can be replaced by noArray() if not needed
 * @param squareDists Dist output. Contains K squared distance in floats, arranged in order of distance from near to far,
 * can be omitted if not needed
 */
- (void)KNNSearch:(Point3f*)query K:(int)K points:(Mat*)points squareDists:(Mat*)squareDists NS_SWIFT_NAME(KNNSearch(query:K:points:squareDists:));

/**
 * K Nearest Neighbor Search in Octree.
 *
 * Find the K nearest neighbors to the query point.
 * @param query Query point.
 * @param K amount of nearest neighbors to find
 * @param points Point output. Contains K points in 3-float format, arranged in order of distance from near to far,
 * can be replaced by noArray() if not needed
 * can be omitted if not needed
 */
- (void)KNNSearch:(Point3f*)query K:(int)K points:(Mat*)points NS_SWIFT_NAME(KNNSearch(query:K:points:));


//
//  void cv::Octree::KNNSearch(Point3f query, int K, Mat& points, Mat& colors, Mat& squareDists)
//
/**
 *
 * K Nearest Neighbor Search in Octree.
 *
 * Find the K nearest neighbors to the query point.
 * @param query Query point.
 * @param K amount of nearest neighbors to find
 * @param points Point output. Contains K points in 3-float format, arranged in order of distance from near to far,
 * can be replaced by noArray() if not needed
 * @param colors Color output. Contains colors corresponding to points in pointSet, can be replaced by noArray() if not needed
 * @param squareDists Dist output. Contains K squared distance in floats, arranged in order of distance from near to far,
 * can be replaced by noArray() if not needed
 */
- (void)KNNSearch:(Point3f*)query K:(int)K points:(Mat*)points colors:(Mat*)colors squareDists:(Mat*)squareDists NS_SWIFT_NAME(KNNSearch(query:K:points:colors:squareDists:));



@end

NS_ASSUME_NONNULL_END


