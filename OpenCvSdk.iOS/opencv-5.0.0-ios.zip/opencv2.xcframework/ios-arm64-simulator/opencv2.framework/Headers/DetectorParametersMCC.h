//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/objdetect.hpp"
#import "opencv2/objdetect/mcc_checker_detector.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>






NS_ASSUME_NONNULL_BEGIN

// C++: class DetectorParametersMCC
/**
 * struct DetectorParametersMCC is used by CCheckerDetector
 *
 * Member of `Objdetect`
 */
CV_EXPORTS @interface DetectorParametersMCC : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::mcc::DetectorParametersMCC> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::mcc::DetectorParametersMCC>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::mcc::DetectorParametersMCC>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::mcc::DetectorParametersMCC::DetectorParametersMCC()
//
- (instancetype)init;


    //
    // C++: int cv::mcc::DetectorParametersMCC::adaptiveThreshWinSizeMin
    //

@property int adaptiveThreshWinSizeMin;

    //
    // C++: int cv::mcc::DetectorParametersMCC::adaptiveThreshWinSizeMax
    //

@property int adaptiveThreshWinSizeMax;

    //
    // C++: int cv::mcc::DetectorParametersMCC::adaptiveThreshWinSizeStep
    //

@property int adaptiveThreshWinSizeStep;

    //
    // C++: double cv::mcc::DetectorParametersMCC::adaptiveThreshConstant
    //

@property double adaptiveThreshConstant;

    //
    // C++: double cv::mcc::DetectorParametersMCC::minContoursAreaRate
    //

@property double minContoursAreaRate;

    //
    // C++: double cv::mcc::DetectorParametersMCC::minContoursArea
    //

@property double minContoursArea;

    //
    // C++: double cv::mcc::DetectorParametersMCC::confidenceThreshold
    //

@property double confidenceThreshold;

    //
    // C++: double cv::mcc::DetectorParametersMCC::minContourSolidity
    //

@property double minContourSolidity;

    //
    // C++: double cv::mcc::DetectorParametersMCC::findCandidatesApproxPolyDPEpsMultiplier
    //

@property double findCandidatesApproxPolyDPEpsMultiplier;

    //
    // C++: int cv::mcc::DetectorParametersMCC::borderWidth
    //

@property int borderWidth;

    //
    // C++: float cv::mcc::DetectorParametersMCC::B0factor
    //

@property float B0factor;

    //
    // C++: float cv::mcc::DetectorParametersMCC::maxError
    //

@property float maxError;

    //
    // C++: int cv::mcc::DetectorParametersMCC::minContourPointsAllowed
    //

@property int minContourPointsAllowed;

    //
    // C++: int cv::mcc::DetectorParametersMCC::minContourLengthAllowed
    //

@property int minContourLengthAllowed;

    //
    // C++: int cv::mcc::DetectorParametersMCC::minInterContourDistance
    //

@property int minInterContourDistance;

    //
    // C++: int cv::mcc::DetectorParametersMCC::minInterCheckerDistance
    //

@property int minInterCheckerDistance;

    //
    // C++: int cv::mcc::DetectorParametersMCC::minImageSize
    //

@property int minImageSize;

    //
    // C++: int cv::mcc::DetectorParametersMCC::minGroupSize
    //

@property int minGroupSize;


@end

NS_ASSUME_NONNULL_END


