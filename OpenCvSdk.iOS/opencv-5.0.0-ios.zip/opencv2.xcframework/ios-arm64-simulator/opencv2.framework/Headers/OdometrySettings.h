//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/odometry_settings.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "RgbdNormals.h"
@class Mat;



NS_ASSUME_NONNULL_BEGIN

// C++: class OdometrySettings
/**
 * The OdometrySettings module
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface OdometrySettings : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::OdometrySettings> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::OdometrySettings>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::OdometrySettings>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::OdometrySettings::OdometrySettings()
//
- (instancetype)init;


//
//  void cv::OdometrySettings::setCameraMatrix(Mat val)
//
- (void)setCameraMatrix:(Mat*)val NS_SWIFT_NAME(setCameraMatrix(val:));


//
//  void cv::OdometrySettings::getCameraMatrix(Mat& val)
//
- (void)getCameraMatrix:(Mat*)val NS_SWIFT_NAME(getCameraMatrix(val:));


//
//  void cv::OdometrySettings::setIterCounts(Mat val)
//
- (void)setIterCounts:(Mat*)val NS_SWIFT_NAME(setIterCounts(val:));


//
//  void cv::OdometrySettings::getIterCounts(Mat& val)
//
- (void)getIterCounts:(Mat*)val NS_SWIFT_NAME(getIterCounts(val:));


//
//  void cv::OdometrySettings::setMinDepth(float val)
//
- (void)setMinDepth:(float)val NS_SWIFT_NAME(setMinDepth(val:));


//
//  float cv::OdometrySettings::getMinDepth()
//
- (float)getMinDepth NS_SWIFT_NAME(getMinDepth());


//
//  void cv::OdometrySettings::setMaxDepth(float val)
//
- (void)setMaxDepth:(float)val NS_SWIFT_NAME(setMaxDepth(val:));


//
//  float cv::OdometrySettings::getMaxDepth()
//
- (float)getMaxDepth NS_SWIFT_NAME(getMaxDepth());


//
//  void cv::OdometrySettings::setMaxDepthDiff(float val)
//
- (void)setMaxDepthDiff:(float)val NS_SWIFT_NAME(setMaxDepthDiff(val:));


//
//  float cv::OdometrySettings::getMaxDepthDiff()
//
- (float)getMaxDepthDiff NS_SWIFT_NAME(getMaxDepthDiff());


//
//  void cv::OdometrySettings::setMaxPointsPart(float val)
//
- (void)setMaxPointsPart:(float)val NS_SWIFT_NAME(setMaxPointsPart(val:));


//
//  float cv::OdometrySettings::getMaxPointsPart()
//
- (float)getMaxPointsPart NS_SWIFT_NAME(getMaxPointsPart());


//
//  void cv::OdometrySettings::setSobelSize(int val)
//
- (void)setSobelSize:(int)val NS_SWIFT_NAME(setSobelSize(val:));


//
//  int cv::OdometrySettings::getSobelSize()
//
- (int)getSobelSize NS_SWIFT_NAME(getSobelSize());


//
//  void cv::OdometrySettings::setSobelScale(double val)
//
- (void)setSobelScale:(double)val NS_SWIFT_NAME(setSobelScale(val:));


//
//  double cv::OdometrySettings::getSobelScale()
//
- (double)getSobelScale NS_SWIFT_NAME(getSobelScale());


//
//  void cv::OdometrySettings::setNormalWinSize(int val)
//
- (void)setNormalWinSize:(int)val NS_SWIFT_NAME(setNormalWinSize(val:));


//
//  int cv::OdometrySettings::getNormalWinSize()
//
- (int)getNormalWinSize NS_SWIFT_NAME(getNormalWinSize());


//
//  void cv::OdometrySettings::setNormalDiffThreshold(float val)
//
- (void)setNormalDiffThreshold:(float)val NS_SWIFT_NAME(setNormalDiffThreshold(val:));


//
//  float cv::OdometrySettings::getNormalDiffThreshold()
//
- (float)getNormalDiffThreshold NS_SWIFT_NAME(getNormalDiffThreshold());


//
//  void cv::OdometrySettings::setNormalMethod(RgbdNormals_RgbdNormalsMethod nm)
//
- (void)setNormalMethod:(RgbdNormalsMethod)nm NS_SWIFT_NAME(setNormalMethod(nm:));


//
//  RgbdNormals_RgbdNormalsMethod cv::OdometrySettings::getNormalMethod()
//
- (RgbdNormalsMethod)getNormalMethod NS_SWIFT_NAME(getNormalMethod());


//
//  void cv::OdometrySettings::setAngleThreshold(float val)
//
- (void)setAngleThreshold:(float)val NS_SWIFT_NAME(setAngleThreshold(val:));


//
//  float cv::OdometrySettings::getAngleThreshold()
//
- (float)getAngleThreshold NS_SWIFT_NAME(getAngleThreshold());


//
//  void cv::OdometrySettings::setMaxTranslation(float val)
//
- (void)setMaxTranslation:(float)val NS_SWIFT_NAME(setMaxTranslation(val:));


//
//  float cv::OdometrySettings::getMaxTranslation()
//
- (float)getMaxTranslation NS_SWIFT_NAME(getMaxTranslation());


//
//  void cv::OdometrySettings::setMaxRotation(float val)
//
- (void)setMaxRotation:(float)val NS_SWIFT_NAME(setMaxRotation(val:));


//
//  float cv::OdometrySettings::getMaxRotation()
//
- (float)getMaxRotation NS_SWIFT_NAME(getMaxRotation());


//
//  void cv::OdometrySettings::setMinGradientMagnitude(float val)
//
- (void)setMinGradientMagnitude:(float)val NS_SWIFT_NAME(setMinGradientMagnitude(val:));


//
//  float cv::OdometrySettings::getMinGradientMagnitude()
//
- (float)getMinGradientMagnitude NS_SWIFT_NAME(getMinGradientMagnitude());


//
//  void cv::OdometrySettings::setMinGradientMagnitudes(Mat val)
//
- (void)setMinGradientMagnitudes:(Mat*)val NS_SWIFT_NAME(setMinGradientMagnitudes(val:));


//
//  void cv::OdometrySettings::getMinGradientMagnitudes(Mat& val)
//
- (void)getMinGradientMagnitudes:(Mat*)val NS_SWIFT_NAME(getMinGradientMagnitudes(val:));



@end

NS_ASSUME_NONNULL_END


