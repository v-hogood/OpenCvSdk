//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/detail/pose_graph.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>






NS_ASSUME_NONNULL_BEGIN

// C++: class PoseGraph
/**
 * The PoseGraph module
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface PoseGraph : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::detail::PoseGraph> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::detail::PoseGraph>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::detail::PoseGraph>)nativePtr;
#endif


#pragma mark - Methods



@end

NS_ASSUME_NONNULL_END


