//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "Ptcloud.h"



NS_ASSUME_NONNULL_BEGIN

// C++: class TriangleRasterizeSettings
/**
 * Structure to keep settings for rasterization
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface TriangleRasterizeSettings : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::TriangleRasterizeSettings> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::TriangleRasterizeSettings>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::TriangleRasterizeSettings>)nativePtr;
#endif


#pragma mark - Methods


//
//  TriangleRasterizeSettings cv::TriangleRasterizeSettings::setShadingType(TriangleShadingType st)
//
- (TriangleRasterizeSettings*)setShadingType:(TriangleShadingType)st NS_SWIFT_NAME(setShadingType(st:));


//
//  TriangleRasterizeSettings cv::TriangleRasterizeSettings::setCullingMode(TriangleCullingMode cm)
//
- (TriangleRasterizeSettings*)setCullingMode:(TriangleCullingMode)cm NS_SWIFT_NAME(setCullingMode(cm:));


//
//  TriangleRasterizeSettings cv::TriangleRasterizeSettings::setGlCompatibleMode(TriangleGlCompatibleMode gm)
//
- (TriangleRasterizeSettings*)setGlCompatibleMode:(TriangleGlCompatibleMode)gm NS_SWIFT_NAME(setGlCompatibleMode(gm:));



@end

NS_ASSUME_NONNULL_END


