//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>

@class Mat;
@class Size2i;
@class TriangleRasterizeSettings;


// C++: enum OdometryAlgoType (cv.OdometryAlgoType)
typedef NS_ENUM(int, OdometryAlgoType) {
    OdometryAlgoType_COMMON NS_SWIFT_NAME(COMMON) = 0,
    OdometryAlgoType_FAST NS_SWIFT_NAME(FAST) = 1
};


// C++: enum OdometryFramePyramidType (cv.OdometryFramePyramidType)
typedef NS_ENUM(int, OdometryFramePyramidType) {
    PYR_IMAGE = 0,
    PYR_DEPTH = 1,
    PYR_MASK = 2,
    PYR_CLOUD = 3,
    PYR_DIX = 4,
    PYR_DIY = 5,
    PYR_TEXMASK = 6,
    PYR_NORM = 7,
    PYR_NORMMASK = 8,
    N_PYRAMIDS = 8+1
};


// C++: enum OdometryType (cv.OdometryType)
typedef NS_ENUM(int, OdometryType) {
    OdometryType_DEPTH NS_SWIFT_NAME(DEPTH) = 0,
    OdometryType_RGB NS_SWIFT_NAME(RGB) = 1,
    OdometryType_RGB_DEPTH NS_SWIFT_NAME(RGB_DEPTH) = 2
};


// C++: enum RgbdPlaneMethod (cv.RgbdPlaneMethod)
typedef NS_ENUM(int, RgbdPlaneMethod) {
    RGBD_PLANE_METHOD_DEFAULT = 0
};


// C++: enum TriangleCullingMode (cv.TriangleCullingMode)
typedef NS_ENUM(int, TriangleCullingMode) {
    RASTERIZE_CULLING_NONE = 0,
    RASTERIZE_CULLING_CW = 1,
    RASTERIZE_CULLING_CCW = 2
};


// C++: enum TriangleGlCompatibleMode (cv.TriangleGlCompatibleMode)
typedef NS_ENUM(int, TriangleGlCompatibleMode) {
    RASTERIZE_COMPAT_DISABLED = 0,
    RASTERIZE_COMPAT_INVDEPTH = 1
};


// C++: enum TriangleShadingType (cv.TriangleShadingType)
typedef NS_ENUM(int, TriangleShadingType) {
    RASTERIZE_SHADING_WHITE = 0,
    RASTERIZE_SHADING_FLAT = 1,
    RASTERIZE_SHADING_SHADED = 2
};


// C++: enum VolumeType (cv.VolumeType)
typedef NS_ENUM(int, VolumeType) {
    VolumeType_TSDF NS_SWIFT_NAME(TSDF) = 0,
    VolumeType_HashTSDF NS_SWIFT_NAME(HashTSDF) = 1,
    VolumeType_ColorTSDF NS_SWIFT_NAME(ColorTSDF) = 2
};



NS_ASSUME_NONNULL_BEGIN

// C++: class Ptcloud
/**
 * The Ptcloud module
 *
 * Member classes: `TriangleRasterizeSettings`, `Octree`, `VolumeSettings`, `OdometryFrame`, `RgbdNormals`, `Volume`, `Odometry`, `OdometrySettings`, `PoseGraph`
 *
 * Member enums: `TriangleShadingType`, `TriangleCullingMode`, `TriangleGlCompatibleMode`, `VolumeType`, `OdometryFramePyramidType`, `RgbdNormalsMethod`, `RgbdPlaneMethod`, `BoundingBoxPrecision`, `OdometryType`, `OdometryAlgoType`
 */
CV_EXPORTS @interface Ptcloud : NSObject

#pragma mark - Methods


//
//  void cv::loadPointCloud(String filename, Mat& vertices, Mat& normals = Mat(), Mat& rgb = Mat())
//
/**
 * Loads a point cloud from a file.
 *
 * The function loads point cloud from the specified file and returns it.
 * If the cloud cannot be read, throws an error.
 * Vertex coordinates, normals and colors are returned as they are saved in the file
 * even if these arrays have different sizes and their elements do not correspond to each other
 * (which is typical for OBJ files for example)
 *
 * Currently, the following file formats are supported:
 * -  [Wavefront obj file *.obj](https://en.wikipedia.org/wiki/Wavefront_.obj_file)
 * -  [Polygon File Format *.ply](https://en.wikipedia.org/wiki/PLY_(file_format))
 *
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param normals per-vertex normals, each value contains 3 floats
 * @param rgb per-vertex colors, each value contains 3 floats
 */
+ (void)loadPointCloud:(NSString*)filename vertices:(Mat*)vertices normals:(Mat*)normals rgb:(Mat*)rgb NS_SWIFT_NAME(loadPointCloud(filename:vertices:normals:rgb:));

/**
 * Loads a point cloud from a file.
 *
 * The function loads point cloud from the specified file and returns it.
 * If the cloud cannot be read, throws an error.
 * Vertex coordinates, normals and colors are returned as they are saved in the file
 * even if these arrays have different sizes and their elements do not correspond to each other
 * (which is typical for OBJ files for example)
 *
 * Currently, the following file formats are supported:
 * -  [Wavefront obj file *.obj](https://en.wikipedia.org/wiki/Wavefront_.obj_file)
 * -  [Polygon File Format *.ply](https://en.wikipedia.org/wiki/PLY_(file_format))
 *
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param normals per-vertex normals, each value contains 3 floats
 */
+ (void)loadPointCloud:(NSString*)filename vertices:(Mat*)vertices normals:(Mat*)normals NS_SWIFT_NAME(loadPointCloud(filename:vertices:normals:));

/**
 * Loads a point cloud from a file.
 *
 * The function loads point cloud from the specified file and returns it.
 * If the cloud cannot be read, throws an error.
 * Vertex coordinates, normals and colors are returned as they are saved in the file
 * even if these arrays have different sizes and their elements do not correspond to each other
 * (which is typical for OBJ files for example)
 *
 * Currently, the following file formats are supported:
 * -  [Wavefront obj file *.obj](https://en.wikipedia.org/wiki/Wavefront_.obj_file)
 * -  [Polygon File Format *.ply](https://en.wikipedia.org/wiki/PLY_(file_format))
 *
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 */
+ (void)loadPointCloud:(NSString*)filename vertices:(Mat*)vertices NS_SWIFT_NAME(loadPointCloud(filename:vertices:));


//
//  void cv::savePointCloud(String filename, Mat vertices, Mat normals = Mat(), Mat rgb = Mat())
//
/**
 * Saves a point cloud to a specified file.
 *
 * The function saves point cloud to the specified file.
 * File format is chosen based on the filename extension.
 *
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param normals per-vertex normals, each value contains 3 floats
 * @param rgb per-vertex colors, each value contains 3 floats
 */
+ (void)savePointCloud:(NSString*)filename vertices:(Mat*)vertices normals:(Mat*)normals rgb:(Mat*)rgb NS_SWIFT_NAME(savePointCloud(filename:vertices:normals:rgb:));

/**
 * Saves a point cloud to a specified file.
 *
 * The function saves point cloud to the specified file.
 * File format is chosen based on the filename extension.
 *
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param normals per-vertex normals, each value contains 3 floats
 */
+ (void)savePointCloud:(NSString*)filename vertices:(Mat*)vertices normals:(Mat*)normals NS_SWIFT_NAME(savePointCloud(filename:vertices:normals:));

/**
 * Saves a point cloud to a specified file.
 *
 * The function saves point cloud to the specified file.
 * File format is chosen based on the filename extension.
 *
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 */
+ (void)savePointCloud:(NSString*)filename vertices:(Mat*)vertices NS_SWIFT_NAME(savePointCloud(filename:vertices:));


//
//  void cv::loadMesh(String filename, Mat& vertices, vector_Mat& indices, Mat& normals = Mat(), Mat& colors = Mat(), Mat& texCoords = Mat())
//
/**
 * Loads a mesh from a file.
 *
 * The function loads mesh from the specified file and returns it.
 * If the mesh cannot be read, throws an error
 * Vertex attributes (i.e. space and texture coodinates, normals and colors) are returned in same-sized
 * arrays with corresponding elements having the same indices.
 * This means that if a face uses a vertex with a normal or a texture coordinate with different indices
 * (which is typical for OBJ files for example), this vertex will be duplicated for each face it uses.
 *
 * Currently, the following file formats are supported:
 * -  [Wavefront obj file *.obj](https://en.wikipedia.org/wiki/Wavefront_.obj_file) (ONLY TRIANGULATED FACES)
 * -  [Polygon File Format *.ply](https://en.wikipedia.org/wiki/PLY_(file_format))
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param indices per-face list of vertices, each value is a vector of ints
 * @param normals per-vertex normals, each value contains 3 floats
 * @param colors per-vertex colors, each value contains 3 floats
 * @param texCoords per-vertex texture coordinates, each value contains 2 or 3 floats
 */
+ (void)loadMesh:(NSString*)filename vertices:(Mat*)vertices indices:(NSMutableArray<Mat*>*)indices normals:(Mat*)normals colors:(Mat*)colors texCoords:(Mat*)texCoords NS_SWIFT_NAME(loadMesh(filename:vertices:indices:normals:colors:texCoords:));

/**
 * Loads a mesh from a file.
 *
 * The function loads mesh from the specified file and returns it.
 * If the mesh cannot be read, throws an error
 * Vertex attributes (i.e. space and texture coodinates, normals and colors) are returned in same-sized
 * arrays with corresponding elements having the same indices.
 * This means that if a face uses a vertex with a normal or a texture coordinate with different indices
 * (which is typical for OBJ files for example), this vertex will be duplicated for each face it uses.
 *
 * Currently, the following file formats are supported:
 * -  [Wavefront obj file *.obj](https://en.wikipedia.org/wiki/Wavefront_.obj_file) (ONLY TRIANGULATED FACES)
 * -  [Polygon File Format *.ply](https://en.wikipedia.org/wiki/PLY_(file_format))
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param indices per-face list of vertices, each value is a vector of ints
 * @param normals per-vertex normals, each value contains 3 floats
 * @param colors per-vertex colors, each value contains 3 floats
 */
+ (void)loadMesh:(NSString*)filename vertices:(Mat*)vertices indices:(NSMutableArray<Mat*>*)indices normals:(Mat*)normals colors:(Mat*)colors NS_SWIFT_NAME(loadMesh(filename:vertices:indices:normals:colors:));

/**
 * Loads a mesh from a file.
 *
 * The function loads mesh from the specified file and returns it.
 * If the mesh cannot be read, throws an error
 * Vertex attributes (i.e. space and texture coodinates, normals and colors) are returned in same-sized
 * arrays with corresponding elements having the same indices.
 * This means that if a face uses a vertex with a normal or a texture coordinate with different indices
 * (which is typical for OBJ files for example), this vertex will be duplicated for each face it uses.
 *
 * Currently, the following file formats are supported:
 * -  [Wavefront obj file *.obj](https://en.wikipedia.org/wiki/Wavefront_.obj_file) (ONLY TRIANGULATED FACES)
 * -  [Polygon File Format *.ply](https://en.wikipedia.org/wiki/PLY_(file_format))
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param indices per-face list of vertices, each value is a vector of ints
 * @param normals per-vertex normals, each value contains 3 floats
 */
+ (void)loadMesh:(NSString*)filename vertices:(Mat*)vertices indices:(NSMutableArray<Mat*>*)indices normals:(Mat*)normals NS_SWIFT_NAME(loadMesh(filename:vertices:indices:normals:));

/**
 * Loads a mesh from a file.
 *
 * The function loads mesh from the specified file and returns it.
 * If the mesh cannot be read, throws an error
 * Vertex attributes (i.e. space and texture coodinates, normals and colors) are returned in same-sized
 * arrays with corresponding elements having the same indices.
 * This means that if a face uses a vertex with a normal or a texture coordinate with different indices
 * (which is typical for OBJ files for example), this vertex will be duplicated for each face it uses.
 *
 * Currently, the following file formats are supported:
 * -  [Wavefront obj file *.obj](https://en.wikipedia.org/wiki/Wavefront_.obj_file) (ONLY TRIANGULATED FACES)
 * -  [Polygon File Format *.ply](https://en.wikipedia.org/wiki/PLY_(file_format))
 * @param filename Name of the file
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param indices per-face list of vertices, each value is a vector of ints
 */
+ (void)loadMesh:(NSString*)filename vertices:(Mat*)vertices indices:(NSMutableArray<Mat*>*)indices NS_SWIFT_NAME(loadMesh(filename:vertices:indices:));


//
//  void cv::saveMesh(String filename, Mat vertices, vector_Mat indices, Mat normals = Mat(), Mat colors = Mat(), Mat texCoords = Mat())
//
/**
 * Saves a mesh to a specified file.
 *
 * The function saves mesh to the specified file.
 * File format is chosen based on the filename extension.
 *
 * @param filename Name of the file.
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param indices per-face list of vertices, each value is a vector of ints
 * @param normals per-vertex normals, each value contains 3 floats
 * @param colors per-vertex colors, each value contains 3 floats
 * @param texCoords per-vertex texture coordinates, each value contains 2 or 3 floats
 */
+ (void)saveMesh:(NSString*)filename vertices:(Mat*)vertices indices:(NSArray<Mat*>*)indices normals:(Mat*)normals colors:(Mat*)colors texCoords:(Mat*)texCoords NS_SWIFT_NAME(saveMesh(filename:vertices:indices:normals:colors:texCoords:));

/**
 * Saves a mesh to a specified file.
 *
 * The function saves mesh to the specified file.
 * File format is chosen based on the filename extension.
 *
 * @param filename Name of the file.
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param indices per-face list of vertices, each value is a vector of ints
 * @param normals per-vertex normals, each value contains 3 floats
 * @param colors per-vertex colors, each value contains 3 floats
 */
+ (void)saveMesh:(NSString*)filename vertices:(Mat*)vertices indices:(NSArray<Mat*>*)indices normals:(Mat*)normals colors:(Mat*)colors NS_SWIFT_NAME(saveMesh(filename:vertices:indices:normals:colors:));

/**
 * Saves a mesh to a specified file.
 *
 * The function saves mesh to the specified file.
 * File format is chosen based on the filename extension.
 *
 * @param filename Name of the file.
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param indices per-face list of vertices, each value is a vector of ints
 * @param normals per-vertex normals, each value contains 3 floats
 */
+ (void)saveMesh:(NSString*)filename vertices:(Mat*)vertices indices:(NSArray<Mat*>*)indices normals:(Mat*)normals NS_SWIFT_NAME(saveMesh(filename:vertices:indices:normals:));

/**
 * Saves a mesh to a specified file.
 *
 * The function saves mesh to the specified file.
 * File format is chosen based on the filename extension.
 *
 * @param filename Name of the file.
 * @param vertices vertex coordinates, each value contains 3 floats
 * @param indices per-face list of vertices, each value is a vector of ints
 */
+ (void)saveMesh:(NSString*)filename vertices:(Mat*)vertices indices:(NSArray<Mat*>*)indices NS_SWIFT_NAME(saveMesh(filename:vertices:indices:));


//
//  void cv::triangleRasterize(Mat vertices, Mat indices, Mat colors, Mat& colorBuf, Mat& depthBuf, Mat world2cam, double fovY, double zNear, double zFar, TriangleRasterizeSettings settings = TriangleRasterizeSettings())
//
/**
 * Renders a set of triangles on a depth and color image
 *
 * Triangles can be drawn white (1.0, 1.0, 1.0), flat-shaded or with a color interpolation between vertices.
 * In flat-shaded mode the 1st vertex color of each triangle is used to fill the whole triangle.
 *
 * The world2cam is an inverted camera pose matrix in fact. It transforms vertices from world to
 * camera coordinate system.
 *
 * The camera coordinate system emulates the OpenGL's coordinate system having coordinate origin in a screen center,
 * X axis pointing right, Y axis pointing up and Z axis pointing towards the viewer
 * except that image is vertically flipped after the render.
 * This means that all visible objects are placed in z-negative area, or exactly in -zNear > z > -zFar since
 * zNear and zFar are positive.
 * For example, at fovY = PI/2 the point (0, 1, -1) will be projected to (width/2, 0) screen point,
 * (1, 0, -1) to (width/2 + height/2, height/2). Increasing fovY makes projection smaller and vice versa.
 *
 * The function does not create or clear output images before the rendering. This means that it can be used
 * for drawing over an existing image or for rendering a model into a 3D scene using pre-filled Z-buffer.
 *
 * Empty scene results in a depth buffer filled by the maximum value since every pixel is infinitely far from the camera.
 * Therefore, before rendering anything from scratch the depthBuf should be filled by zFar values (or by ones in INVDEPTH mode).
 *
 * There are special versions of this function named triangleRasterizeDepth and triangleRasterizeColor
 * for cases if a user needs a color image or a depth image alone; they may run slightly faster.
 *
 * @param vertices vertices coordinates array. Should contain values of CV_32FC3 type or a compatible one (e.g. cv::Vec3f, etc.)
 * @param indices triangle vertices index array, 3 per triangle. Each index indicates a vertex in a vertices array.
 * Should contain CV_32SC3 values or compatible
 * @param colors per-vertex colors of CV_32FC3 type or compatible. Can be empty or the same size as vertices array.
 * If the values are out of [0; 1] range, the result correctness is not guaranteed
 * @param colorBuf an array representing the final rendered image. Should containt CV_32FC3 values and be the same size as depthBuf.
 * Not cleared before rendering, i.e. the content is reused as there is some pre-rendered scene.
 * @param depthBuf an array of floats containing resulting Z buffer. Should contain float values and be the same size as colorBuf.
 * Not cleared before rendering, i.e. the content is reused as there is some pre-rendered scene.
 * Empty scene corresponds to all values set to zFar (or to 1.0 in INVDEPTH mode)
 * @param world2cam a 4x3 or 4x4 float or double matrix containing inverted (sic!) camera pose
 * @param fovY field of view in vertical direction, given in radians
 * @param zNear minimum Z value to render, everything closer is clipped
 * @param zFar maximum Z value to render, everything farther is clipped
 * @param settings see TriangleRasterizeSettings. By default the smooth shading is on,
 * with CW culling and with disabled GL compatibility
 */
+ (void)triangleRasterize:(Mat*)vertices indices:(Mat*)indices colors:(Mat*)colors colorBuf:(Mat*)colorBuf depthBuf:(Mat*)depthBuf world2cam:(Mat*)world2cam fovY:(double)fovY zNear:(double)zNear zFar:(double)zFar settings:(TriangleRasterizeSettings*)settings NS_SWIFT_NAME(triangleRasterize(vertices:indices:colors:colorBuf:depthBuf:world2cam:fovY:zNear:zFar:settings:));

/**
 * Renders a set of triangles on a depth and color image
 *
 * Triangles can be drawn white (1.0, 1.0, 1.0), flat-shaded or with a color interpolation between vertices.
 * In flat-shaded mode the 1st vertex color of each triangle is used to fill the whole triangle.
 *
 * The world2cam is an inverted camera pose matrix in fact. It transforms vertices from world to
 * camera coordinate system.
 *
 * The camera coordinate system emulates the OpenGL's coordinate system having coordinate origin in a screen center,
 * X axis pointing right, Y axis pointing up and Z axis pointing towards the viewer
 * except that image is vertically flipped after the render.
 * This means that all visible objects are placed in z-negative area, or exactly in -zNear > z > -zFar since
 * zNear and zFar are positive.
 * For example, at fovY = PI/2 the point (0, 1, -1) will be projected to (width/2, 0) screen point,
 * (1, 0, -1) to (width/2 + height/2, height/2). Increasing fovY makes projection smaller and vice versa.
 *
 * The function does not create or clear output images before the rendering. This means that it can be used
 * for drawing over an existing image or for rendering a model into a 3D scene using pre-filled Z-buffer.
 *
 * Empty scene results in a depth buffer filled by the maximum value since every pixel is infinitely far from the camera.
 * Therefore, before rendering anything from scratch the depthBuf should be filled by zFar values (or by ones in INVDEPTH mode).
 *
 * There are special versions of this function named triangleRasterizeDepth and triangleRasterizeColor
 * for cases if a user needs a color image or a depth image alone; they may run slightly faster.
 *
 * @param vertices vertices coordinates array. Should contain values of CV_32FC3 type or a compatible one (e.g. cv::Vec3f, etc.)
 * @param indices triangle vertices index array, 3 per triangle. Each index indicates a vertex in a vertices array.
 * Should contain CV_32SC3 values or compatible
 * @param colors per-vertex colors of CV_32FC3 type or compatible. Can be empty or the same size as vertices array.
 * If the values are out of [0; 1] range, the result correctness is not guaranteed
 * @param colorBuf an array representing the final rendered image. Should containt CV_32FC3 values and be the same size as depthBuf.
 * Not cleared before rendering, i.e. the content is reused as there is some pre-rendered scene.
 * @param depthBuf an array of floats containing resulting Z buffer. Should contain float values and be the same size as colorBuf.
 * Not cleared before rendering, i.e. the content is reused as there is some pre-rendered scene.
 * Empty scene corresponds to all values set to zFar (or to 1.0 in INVDEPTH mode)
 * @param world2cam a 4x3 or 4x4 float or double matrix containing inverted (sic!) camera pose
 * @param fovY field of view in vertical direction, given in radians
 * @param zNear minimum Z value to render, everything closer is clipped
 * @param zFar maximum Z value to render, everything farther is clipped
 * with CW culling and with disabled GL compatibility
 */
+ (void)triangleRasterize:(Mat*)vertices indices:(Mat*)indices colors:(Mat*)colors colorBuf:(Mat*)colorBuf depthBuf:(Mat*)depthBuf world2cam:(Mat*)world2cam fovY:(double)fovY zNear:(double)zNear zFar:(double)zFar NS_SWIFT_NAME(triangleRasterize(vertices:indices:colors:colorBuf:depthBuf:world2cam:fovY:zNear:zFar:));


//
//  void cv::triangleRasterizeDepth(Mat vertices, Mat indices, Mat& depthBuf, Mat world2cam, double fovY, double zNear, double zFar, TriangleRasterizeSettings settings = TriangleRasterizeSettings())
//
/**
 * Overloaded version of triangleRasterize() with depth-only rendering
 *
 * @param vertices vertices coordinates array. Should contain values of CV_32FC3 type or a compatible one (e.g. cv::Vec3f, etc.)
 * @param indices triangle vertices index array, 3 per triangle. Each index indicates a vertex in a vertices array.
 * Should contain CV_32SC3 values or compatible
 * @param depthBuf an array of floats containing resulting Z buffer. Should contain float values and be the same size as colorBuf.
 * Not cleared before rendering, i.e. the content is reused as there is some pre-rendered scene.
 * Empty scene corresponds to all values set to zFar (or to 1.0 in INVDEPTH mode)
 * @param world2cam a 4x3 or 4x4 float or double matrix containing inverted (sic!) camera pose
 * @param fovY field of view in vertical direction, given in radians
 * @param zNear minimum Z value to render, everything closer is clipped
 * @param zFar maximum Z value to render, everything farther is clipped
 * @param settings see TriangleRasterizeSettings. By default the smooth shading is on,
 * with CW culling and with disabled GL compatibility
 */
+ (void)triangleRasterizeDepth:(Mat*)vertices indices:(Mat*)indices depthBuf:(Mat*)depthBuf world2cam:(Mat*)world2cam fovY:(double)fovY zNear:(double)zNear zFar:(double)zFar settings:(TriangleRasterizeSettings*)settings NS_SWIFT_NAME(triangleRasterizeDepth(vertices:indices:depthBuf:world2cam:fovY:zNear:zFar:settings:));

/**
 * Overloaded version of triangleRasterize() with depth-only rendering
 *
 * @param vertices vertices coordinates array. Should contain values of CV_32FC3 type or a compatible one (e.g. cv::Vec3f, etc.)
 * @param indices triangle vertices index array, 3 per triangle. Each index indicates a vertex in a vertices array.
 * Should contain CV_32SC3 values or compatible
 * @param depthBuf an array of floats containing resulting Z buffer. Should contain float values and be the same size as colorBuf.
 * Not cleared before rendering, i.e. the content is reused as there is some pre-rendered scene.
 * Empty scene corresponds to all values set to zFar (or to 1.0 in INVDEPTH mode)
 * @param world2cam a 4x3 or 4x4 float or double matrix containing inverted (sic!) camera pose
 * @param fovY field of view in vertical direction, given in radians
 * @param zNear minimum Z value to render, everything closer is clipped
 * @param zFar maximum Z value to render, everything farther is clipped
 * with CW culling and with disabled GL compatibility
 */
+ (void)triangleRasterizeDepth:(Mat*)vertices indices:(Mat*)indices depthBuf:(Mat*)depthBuf world2cam:(Mat*)world2cam fovY:(double)fovY zNear:(double)zNear zFar:(double)zFar NS_SWIFT_NAME(triangleRasterizeDepth(vertices:indices:depthBuf:world2cam:fovY:zNear:zFar:));


//
//  void cv::triangleRasterizeColor(Mat vertices, Mat indices, Mat colors, Mat& colorBuf, Mat world2cam, double fovY, double zNear, double zFar, TriangleRasterizeSettings settings = TriangleRasterizeSettings())
//
/**
 * Overloaded version of triangleRasterize() with color-only rendering
 *
 * @param vertices vertices coordinates array. Should contain values of CV_32FC3 type or a compatible one (e.g. cv::Vec3f, etc.)
 * @param indices triangle vertices index array, 3 per triangle. Each index indicates a vertex in a vertices array.
 * Should contain CV_32SC3 values or compatible
 * @param colors per-vertex colors of CV_32FC3 type or compatible. Can be empty or the same size as vertices array.
 * If the values are out of [0; 1] range, the result correctness is not guaranteed
 * @param colorBuf an array representing the final rendered image. Should containt CV_32FC3 values and be the same size as depthBuf.
 * Not cleared before rendering, i.e. the content is reused as there is some pre-rendered scene.
 * @param world2cam a 4x3 or 4x4 float or double matrix containing inverted (sic!) camera pose
 * @param fovY field of view in vertical direction, given in radians
 * @param zNear minimum Z value to render, everything closer is clipped
 * @param zFar maximum Z value to render, everything farther is clipped
 * @param settings see TriangleRasterizeSettings. By default the smooth shading is on,
 * with CW culling and with disabled GL compatibility
 */
+ (void)triangleRasterizeColor:(Mat*)vertices indices:(Mat*)indices colors:(Mat*)colors colorBuf:(Mat*)colorBuf world2cam:(Mat*)world2cam fovY:(double)fovY zNear:(double)zNear zFar:(double)zFar settings:(TriangleRasterizeSettings*)settings NS_SWIFT_NAME(triangleRasterizeColor(vertices:indices:colors:colorBuf:world2cam:fovY:zNear:zFar:settings:));

/**
 * Overloaded version of triangleRasterize() with color-only rendering
 *
 * @param vertices vertices coordinates array. Should contain values of CV_32FC3 type or a compatible one (e.g. cv::Vec3f, etc.)
 * @param indices triangle vertices index array, 3 per triangle. Each index indicates a vertex in a vertices array.
 * Should contain CV_32SC3 values or compatible
 * @param colors per-vertex colors of CV_32FC3 type or compatible. Can be empty or the same size as vertices array.
 * If the values are out of [0; 1] range, the result correctness is not guaranteed
 * @param colorBuf an array representing the final rendered image. Should containt CV_32FC3 values and be the same size as depthBuf.
 * Not cleared before rendering, i.e. the content is reused as there is some pre-rendered scene.
 * @param world2cam a 4x3 or 4x4 float or double matrix containing inverted (sic!) camera pose
 * @param fovY field of view in vertical direction, given in radians
 * @param zNear minimum Z value to render, everything closer is clipped
 * @param zFar maximum Z value to render, everything farther is clipped
 * with CW culling and with disabled GL compatibility
 */
+ (void)triangleRasterizeColor:(Mat*)vertices indices:(Mat*)indices colors:(Mat*)colors colorBuf:(Mat*)colorBuf world2cam:(Mat*)world2cam fovY:(double)fovY zNear:(double)zNear zFar:(double)zFar NS_SWIFT_NAME(triangleRasterizeColor(vertices:indices:colors:colorBuf:world2cam:fovY:zNear:zFar:));


//
//  void cv::registerDepth(Mat unregisteredCameraMatrix, Mat registeredCameraMatrix, Mat registeredDistCoeffs, Mat Rt, Mat unregisteredDepth, Size outputImagePlaneSize, Mat& registeredDepth, bool depthDilation = false)
//
/**
 * Registers depth data to an external camera
 * Registration is performed by creating a depth cloud, transforming the cloud by
 * the rigid body transformation between the cameras, and then projecting the
 * transformed points into the RGB camera.
 *
 * uv_rgb = K_rgb * [R | t] * z * inv(K_ir) * uv_ir
 *
 * Currently does not check for negative depth values.
 *
 * @param unregisteredCameraMatrix the camera matrix of the depth camera
 * @param registeredCameraMatrix the camera matrix of the external camera
 * @param registeredDistCoeffs the distortion coefficients of the external camera
 * @param Rt the rigid body transform between the cameras. Transforms points from depth camera frame to external camera frame.
 * @param unregisteredDepth the input depth data
 * @param outputImagePlaneSize the image plane dimensions of the external camera (width, height)
 * @param registeredDepth the result of transforming the depth into the external camera
 * @param depthDilation whether or not the depth is dilated to avoid holes and occlusion errors (optional)
 */
+ (void)registerDepth:(Mat*)unregisteredCameraMatrix registeredCameraMatrix:(Mat*)registeredCameraMatrix registeredDistCoeffs:(Mat*)registeredDistCoeffs Rt:(Mat*)Rt unregisteredDepth:(Mat*)unregisteredDepth outputImagePlaneSize:(Size2i*)outputImagePlaneSize registeredDepth:(Mat*)registeredDepth depthDilation:(BOOL)depthDilation NS_SWIFT_NAME(registerDepth(unregisteredCameraMatrix:registeredCameraMatrix:registeredDistCoeffs:Rt:unregisteredDepth:outputImagePlaneSize:registeredDepth:depthDilation:));

/**
 * Registers depth data to an external camera
 * Registration is performed by creating a depth cloud, transforming the cloud by
 * the rigid body transformation between the cameras, and then projecting the
 * transformed points into the RGB camera.
 *
 * uv_rgb = K_rgb * [R | t] * z * inv(K_ir) * uv_ir
 *
 * Currently does not check for negative depth values.
 *
 * @param unregisteredCameraMatrix the camera matrix of the depth camera
 * @param registeredCameraMatrix the camera matrix of the external camera
 * @param registeredDistCoeffs the distortion coefficients of the external camera
 * @param Rt the rigid body transform between the cameras. Transforms points from depth camera frame to external camera frame.
 * @param unregisteredDepth the input depth data
 * @param outputImagePlaneSize the image plane dimensions of the external camera (width, height)
 * @param registeredDepth the result of transforming the depth into the external camera
 */
+ (void)registerDepth:(Mat*)unregisteredCameraMatrix registeredCameraMatrix:(Mat*)registeredCameraMatrix registeredDistCoeffs:(Mat*)registeredDistCoeffs Rt:(Mat*)Rt unregisteredDepth:(Mat*)unregisteredDepth outputImagePlaneSize:(Size2i*)outputImagePlaneSize registeredDepth:(Mat*)registeredDepth NS_SWIFT_NAME(registerDepth(unregisteredCameraMatrix:registeredCameraMatrix:registeredDistCoeffs:Rt:unregisteredDepth:outputImagePlaneSize:registeredDepth:));


//
//  void cv::depthTo3dSparse(Mat depth, Mat in_K, Mat in_points, Mat& points3d)
//
/**
 * @param depth the depth image
 * @param in_K
 * @param in_points the list of xy coordinates
 * @param points3d the resulting 3d points (point is represented by 4 chanels value [x, y, z, 0])
 */
+ (void)depthTo3dSparse:(Mat*)depth in_K:(Mat*)in_K in_points:(Mat*)in_points points3d:(Mat*)points3d NS_SWIFT_NAME(depthTo3dSparse(depth:in_K:in_points:points3d:));


//
//  void cv::depthTo3d(Mat depth, Mat K, Mat& points3d, Mat mask = Mat())
//
/**
 * Converts a depth image to 3d points. If the mask is empty then the resulting array has the same dimensions as `depth`,
 * otherwise it is 1d vector containing mask-enabled values only.
 * The coordinate system is x pointing left, y down and z away from the camera
 * @param depth the depth image (if given as short int CV_U, it is assumed to be the depth in millimeters
 * (as done with the Microsoft Kinect), otherwise, if given as CV_32F or CV_64F, it is assumed in meters)
 * @param K The calibration matrix
 * @param points3d the resulting 3d points (point is represented by 4 channels value [x, y, z, 0]). They are of the same depth as `depth` if it is CV_32F or CV_64F, and the
 * depth of `K` if `depth` is of depth CV_16U or CV_16S
 * @param mask the mask of the points to consider (can be empty)
 */
+ (void)depthTo3d:(Mat*)depth K:(Mat*)K points3d:(Mat*)points3d mask:(Mat*)mask NS_SWIFT_NAME(depthTo3d(depth:K:points3d:mask:));

/**
 * Converts a depth image to 3d points. If the mask is empty then the resulting array has the same dimensions as `depth`,
 * otherwise it is 1d vector containing mask-enabled values only.
 * The coordinate system is x pointing left, y down and z away from the camera
 * @param depth the depth image (if given as short int CV_U, it is assumed to be the depth in millimeters
 * (as done with the Microsoft Kinect), otherwise, if given as CV_32F or CV_64F, it is assumed in meters)
 * @param K The calibration matrix
 * @param points3d the resulting 3d points (point is represented by 4 channels value [x, y, z, 0]). They are of the same depth as `depth` if it is CV_32F or CV_64F, and the
 * depth of `K` if `depth` is of depth CV_16U or CV_16S
 */
+ (void)depthTo3d:(Mat*)depth K:(Mat*)K points3d:(Mat*)points3d NS_SWIFT_NAME(depthTo3d(depth:K:points3d:));


//
//  void cv::rescaleDepth(Mat in, int type, Mat& out, double depth_factor = 1000.0)
//
/**
 * If the input image is of type CV_16UC1 (like the Kinect one), the image is converted to floats, divided
 * by depth_factor to get a depth in meters, and the values 0 are converted to std::numeric_limits<float>::quiet_NaN()
 * Otherwise, the image is simply converted to floats
 * @param in the depth image (if given as short int CV_U, it is assumed to be the depth in millimeters
 * (as done with the Microsoft Kinect), it is assumed in meters)
 * @param type the desired output depth (CV_32F or CV_64F)
 * @param out The rescaled float depth image
 * @param depth_factor (optional) factor by which depth is converted to distance (by default = 1000.0 for Kinect sensor)
 */
+ (void)rescaleDepth:(Mat*)in type:(int)type out:(Mat*)out depth_factor:(double)depth_factor NS_SWIFT_NAME(rescaleDepth(in:type:out:depth_factor:));

/**
 * If the input image is of type CV_16UC1 (like the Kinect one), the image is converted to floats, divided
 * by depth_factor to get a depth in meters, and the values 0 are converted to std::numeric_limits<float>::quiet_NaN()
 * Otherwise, the image is simply converted to floats
 * @param in the depth image (if given as short int CV_U, it is assumed to be the depth in millimeters
 * (as done with the Microsoft Kinect), it is assumed in meters)
 * @param type the desired output depth (CV_32F or CV_64F)
 * @param out The rescaled float depth image
 */
+ (void)rescaleDepth:(Mat*)in type:(int)type out:(Mat*)out NS_SWIFT_NAME(rescaleDepth(in:type:out:));


//
//  void cv::warpFrame(Mat depth, Mat image, Mat mask, Mat Rt, Mat cameraMatrix, Mat& warpedDepth = Mat(), Mat& warpedImage = Mat(), Mat& warpedMask = Mat())
//
/**
 * Warps depth or RGB-D image by reprojecting it in 3d, applying Rt transformation
 * and then projecting it back onto the image plane.
 * This function can be used to visualize the results of the Odometry algorithm.
 * @param depth Depth data, should be 1-channel CV_16U, CV_16S, CV_32F or CV_64F
 * @param image RGB image (optional), should be 1-, 3- or 4-channel CV_8U
 * @param mask Mask of used pixels (optional), should be CV_8UC1, CV_8SC1 or CV_BoolC1
 * @param Rt Rotation+translation matrix (3x4 or 4x4) to be applied to depth points
 * @param cameraMatrix Camera intrinsics matrix (3x3)
 * @param warpedDepth The warped depth data (optional)
 * @param warpedImage The warped RGB image (optional)
 * @param warpedMask The mask of valid pixels in warped image (optional)
 */
+ (void)warpFrame:(Mat*)depth image:(Mat*)image mask:(Mat*)mask Rt:(Mat*)Rt cameraMatrix:(Mat*)cameraMatrix warpedDepth:(Mat*)warpedDepth warpedImage:(Mat*)warpedImage warpedMask:(Mat*)warpedMask NS_SWIFT_NAME(warpFrame(depth:image:mask:Rt:cameraMatrix:warpedDepth:warpedImage:warpedMask:));

/**
 * Warps depth or RGB-D image by reprojecting it in 3d, applying Rt transformation
 * and then projecting it back onto the image plane.
 * This function can be used to visualize the results of the Odometry algorithm.
 * @param depth Depth data, should be 1-channel CV_16U, CV_16S, CV_32F or CV_64F
 * @param image RGB image (optional), should be 1-, 3- or 4-channel CV_8U
 * @param mask Mask of used pixels (optional), should be CV_8UC1, CV_8SC1 or CV_BoolC1
 * @param Rt Rotation+translation matrix (3x4 or 4x4) to be applied to depth points
 * @param cameraMatrix Camera intrinsics matrix (3x3)
 * @param warpedDepth The warped depth data (optional)
 * @param warpedImage The warped RGB image (optional)
 */
+ (void)warpFrame:(Mat*)depth image:(Mat*)image mask:(Mat*)mask Rt:(Mat*)Rt cameraMatrix:(Mat*)cameraMatrix warpedDepth:(Mat*)warpedDepth warpedImage:(Mat*)warpedImage NS_SWIFT_NAME(warpFrame(depth:image:mask:Rt:cameraMatrix:warpedDepth:warpedImage:));

/**
 * Warps depth or RGB-D image by reprojecting it in 3d, applying Rt transformation
 * and then projecting it back onto the image plane.
 * This function can be used to visualize the results of the Odometry algorithm.
 * @param depth Depth data, should be 1-channel CV_16U, CV_16S, CV_32F or CV_64F
 * @param image RGB image (optional), should be 1-, 3- or 4-channel CV_8U
 * @param mask Mask of used pixels (optional), should be CV_8UC1, CV_8SC1 or CV_BoolC1
 * @param Rt Rotation+translation matrix (3x4 or 4x4) to be applied to depth points
 * @param cameraMatrix Camera intrinsics matrix (3x3)
 * @param warpedDepth The warped depth data (optional)
 */
+ (void)warpFrame:(Mat*)depth image:(Mat*)image mask:(Mat*)mask Rt:(Mat*)Rt cameraMatrix:(Mat*)cameraMatrix warpedDepth:(Mat*)warpedDepth NS_SWIFT_NAME(warpFrame(depth:image:mask:Rt:cameraMatrix:warpedDepth:));

/**
 * Warps depth or RGB-D image by reprojecting it in 3d, applying Rt transformation
 * and then projecting it back onto the image plane.
 * This function can be used to visualize the results of the Odometry algorithm.
 * @param depth Depth data, should be 1-channel CV_16U, CV_16S, CV_32F or CV_64F
 * @param image RGB image (optional), should be 1-, 3- or 4-channel CV_8U
 * @param mask Mask of used pixels (optional), should be CV_8UC1, CV_8SC1 or CV_BoolC1
 * @param Rt Rotation+translation matrix (3x4 or 4x4) to be applied to depth points
 * @param cameraMatrix Camera intrinsics matrix (3x3)
 */
+ (void)warpFrame:(Mat*)depth image:(Mat*)image mask:(Mat*)mask Rt:(Mat*)Rt cameraMatrix:(Mat*)cameraMatrix NS_SWIFT_NAME(warpFrame(depth:image:mask:Rt:cameraMatrix:));


//
//  void cv::findPlanes(Mat points3d, Mat normals, Mat& mask, Mat& plane_coefficients, int block_size = 40, int min_size = 40*40, double threshold = 0.01, double sensor_error_a = 0, double sensor_error_b = 0, double sensor_error_c = 0, RgbdPlaneMethod method = RGBD_PLANE_METHOD_DEFAULT)
//
/**
 * Find the planes in a depth image
 * @param points3d the 3d points organized like the depth image: rows x cols with 3 channels
 * @param normals the normals for every point in the depth image; optional, can be empty
 * @param mask An image where each pixel is labeled with the plane it belongs to
 * and 255 if it does not belong to any plane
 * @param plane_coefficients the coefficients of the corresponding planes (a,b,c,d) such that ax+by+cz+d=0, norm(a,b,c)=1
 * and c < 0 (so that the normal points towards the camera)
 * @param block_size The size of the blocks to look at for a stable MSE
 * @param min_size The minimum size of a cluster to be considered a plane
 * @param threshold The maximum distance of a point from a plane to belong to it (in meters)
 * @param sensor_error_a coefficient of the sensor error. 0 by default, use 0.0075 for a Kinect
 * @param sensor_error_b coefficient of the sensor error. 0 by default
 * @param sensor_error_c coefficient of the sensor error. 0 by default
 * @param method The method to use to compute the planes.
 */
+ (void)findPlanes:(Mat*)points3d normals:(Mat*)normals mask:(Mat*)mask plane_coefficients:(Mat*)plane_coefficients block_size:(int)block_size min_size:(int)min_size threshold:(double)threshold sensor_error_a:(double)sensor_error_a sensor_error_b:(double)sensor_error_b sensor_error_c:(double)sensor_error_c method:(RgbdPlaneMethod)method NS_SWIFT_NAME(findPlanes(points3d:normals:mask:plane_coefficients:block_size:min_size:threshold:sensor_error_a:sensor_error_b:sensor_error_c:method:));

/**
 * Find the planes in a depth image
 * @param points3d the 3d points organized like the depth image: rows x cols with 3 channels
 * @param normals the normals for every point in the depth image; optional, can be empty
 * @param mask An image where each pixel is labeled with the plane it belongs to
 * and 255 if it does not belong to any plane
 * @param plane_coefficients the coefficients of the corresponding planes (a,b,c,d) such that ax+by+cz+d=0, norm(a,b,c)=1
 * and c < 0 (so that the normal points towards the camera)
 * @param block_size The size of the blocks to look at for a stable MSE
 * @param min_size The minimum size of a cluster to be considered a plane
 * @param threshold The maximum distance of a point from a plane to belong to it (in meters)
 * @param sensor_error_a coefficient of the sensor error. 0 by default, use 0.0075 for a Kinect
 * @param sensor_error_b coefficient of the sensor error. 0 by default
 * @param sensor_error_c coefficient of the sensor error. 0 by default
 */
+ (void)findPlanes:(Mat*)points3d normals:(Mat*)normals mask:(Mat*)mask plane_coefficients:(Mat*)plane_coefficients block_size:(int)block_size min_size:(int)min_size threshold:(double)threshold sensor_error_a:(double)sensor_error_a sensor_error_b:(double)sensor_error_b sensor_error_c:(double)sensor_error_c NS_SWIFT_NAME(findPlanes(points3d:normals:mask:plane_coefficients:block_size:min_size:threshold:sensor_error_a:sensor_error_b:sensor_error_c:));

/**
 * Find the planes in a depth image
 * @param points3d the 3d points organized like the depth image: rows x cols with 3 channels
 * @param normals the normals for every point in the depth image; optional, can be empty
 * @param mask An image where each pixel is labeled with the plane it belongs to
 * and 255 if it does not belong to any plane
 * @param plane_coefficients the coefficients of the corresponding planes (a,b,c,d) such that ax+by+cz+d=0, norm(a,b,c)=1
 * and c < 0 (so that the normal points towards the camera)
 * @param block_size The size of the blocks to look at for a stable MSE
 * @param min_size The minimum size of a cluster to be considered a plane
 * @param threshold The maximum distance of a point from a plane to belong to it (in meters)
 * @param sensor_error_a coefficient of the sensor error. 0 by default, use 0.0075 for a Kinect
 * @param sensor_error_b coefficient of the sensor error. 0 by default
 */
+ (void)findPlanes:(Mat*)points3d normals:(Mat*)normals mask:(Mat*)mask plane_coefficients:(Mat*)plane_coefficients block_size:(int)block_size min_size:(int)min_size threshold:(double)threshold sensor_error_a:(double)sensor_error_a sensor_error_b:(double)sensor_error_b NS_SWIFT_NAME(findPlanes(points3d:normals:mask:plane_coefficients:block_size:min_size:threshold:sensor_error_a:sensor_error_b:));

/**
 * Find the planes in a depth image
 * @param points3d the 3d points organized like the depth image: rows x cols with 3 channels
 * @param normals the normals for every point in the depth image; optional, can be empty
 * @param mask An image where each pixel is labeled with the plane it belongs to
 * and 255 if it does not belong to any plane
 * @param plane_coefficients the coefficients of the corresponding planes (a,b,c,d) such that ax+by+cz+d=0, norm(a,b,c)=1
 * and c < 0 (so that the normal points towards the camera)
 * @param block_size The size of the blocks to look at for a stable MSE
 * @param min_size The minimum size of a cluster to be considered a plane
 * @param threshold The maximum distance of a point from a plane to belong to it (in meters)
 * @param sensor_error_a coefficient of the sensor error. 0 by default, use 0.0075 for a Kinect
 */
+ (void)findPlanes:(Mat*)points3d normals:(Mat*)normals mask:(Mat*)mask plane_coefficients:(Mat*)plane_coefficients block_size:(int)block_size min_size:(int)min_size threshold:(double)threshold sensor_error_a:(double)sensor_error_a NS_SWIFT_NAME(findPlanes(points3d:normals:mask:plane_coefficients:block_size:min_size:threshold:sensor_error_a:));

/**
 * Find the planes in a depth image
 * @param points3d the 3d points organized like the depth image: rows x cols with 3 channels
 * @param normals the normals for every point in the depth image; optional, can be empty
 * @param mask An image where each pixel is labeled with the plane it belongs to
 * and 255 if it does not belong to any plane
 * @param plane_coefficients the coefficients of the corresponding planes (a,b,c,d) such that ax+by+cz+d=0, norm(a,b,c)=1
 * and c < 0 (so that the normal points towards the camera)
 * @param block_size The size of the blocks to look at for a stable MSE
 * @param min_size The minimum size of a cluster to be considered a plane
 * @param threshold The maximum distance of a point from a plane to belong to it (in meters)
 */
+ (void)findPlanes:(Mat*)points3d normals:(Mat*)normals mask:(Mat*)mask plane_coefficients:(Mat*)plane_coefficients block_size:(int)block_size min_size:(int)min_size threshold:(double)threshold NS_SWIFT_NAME(findPlanes(points3d:normals:mask:plane_coefficients:block_size:min_size:threshold:));

/**
 * Find the planes in a depth image
 * @param points3d the 3d points organized like the depth image: rows x cols with 3 channels
 * @param normals the normals for every point in the depth image; optional, can be empty
 * @param mask An image where each pixel is labeled with the plane it belongs to
 * and 255 if it does not belong to any plane
 * @param plane_coefficients the coefficients of the corresponding planes (a,b,c,d) such that ax+by+cz+d=0, norm(a,b,c)=1
 * and c < 0 (so that the normal points towards the camera)
 * @param block_size The size of the blocks to look at for a stable MSE
 * @param min_size The minimum size of a cluster to be considered a plane
 */
+ (void)findPlanes:(Mat*)points3d normals:(Mat*)normals mask:(Mat*)mask plane_coefficients:(Mat*)plane_coefficients block_size:(int)block_size min_size:(int)min_size NS_SWIFT_NAME(findPlanes(points3d:normals:mask:plane_coefficients:block_size:min_size:));

/**
 * Find the planes in a depth image
 * @param points3d the 3d points organized like the depth image: rows x cols with 3 channels
 * @param normals the normals for every point in the depth image; optional, can be empty
 * @param mask An image where each pixel is labeled with the plane it belongs to
 * and 255 if it does not belong to any plane
 * @param plane_coefficients the coefficients of the corresponding planes (a,b,c,d) such that ax+by+cz+d=0, norm(a,b,c)=1
 * and c < 0 (so that the normal points towards the camera)
 * @param block_size The size of the blocks to look at for a stable MSE
 */
+ (void)findPlanes:(Mat*)points3d normals:(Mat*)normals mask:(Mat*)mask plane_coefficients:(Mat*)plane_coefficients block_size:(int)block_size NS_SWIFT_NAME(findPlanes(points3d:normals:mask:plane_coefficients:block_size:));

/**
 * Find the planes in a depth image
 * @param points3d the 3d points organized like the depth image: rows x cols with 3 channels
 * @param normals the normals for every point in the depth image; optional, can be empty
 * @param mask An image where each pixel is labeled with the plane it belongs to
 * and 255 if it does not belong to any plane
 * @param plane_coefficients the coefficients of the corresponding planes (a,b,c,d) such that ax+by+cz+d=0, norm(a,b,c)=1
 * and c < 0 (so that the normal points towards the camera)
 */
+ (void)findPlanes:(Mat*)points3d normals:(Mat*)normals mask:(Mat*)mask plane_coefficients:(Mat*)plane_coefficients NS_SWIFT_NAME(findPlanes(points3d:normals:mask:plane_coefficients:));



@end

NS_ASSUME_NONNULL_END


