//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/features.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>
#import "Feature2D.h"

@class ByteVector;
@class Size2i;



NS_ASSUME_NONNULL_BEGIN

// C++: class DISK
/**
 * DISK feature detector and descriptor, based on a DNN model.
 *
 * DISK (Deep Image Structure and Keypoints) is a learned local-feature pipeline that produces
 * keypoints and 128-D L2-normalized descriptors via a single forward pass through a fully
 * convolutional network. This class wraps an ONNX export of the pre-trained DISK model through
 * cv::dnn::Net and exposes it under the standard cv::Feature2D interface so it can be used as
 * a drop-in alternative to SIFT/ORB.
 *
 * The class assumes the ONNX model has a single input named `image` taking an N×3×H×W float32
 * tensor in [0, 1] (RGB channel order) and three outputs named `keypoints` (N×2), `scores` (N)
 * and `descriptors` (N×128).
 *
 * Member of `Features`
 */
CV_EXPORTS @interface DISK : Feature2D


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::DISK> nativePtrDISK;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::DISK>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::DISK>)nativePtr;
#endif


#pragma mark - Methods


//
// static Ptr_DISK cv::DISK::create(String modelPath, int maxKeypoints = -1, float scoreThreshold = 0.0f, Size imageSize = Size(), int backendId = 0, int targetId = 0)
//
/**
 * Creates a DISK detector.
 * @param modelPath Path to the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score strictly below this value.
 * @param imageSize Target input size (width, height) fed to the network. Use Size()
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 * @param backendId DNN backend identifier (see cv::dnn::Backend); 0 = DNN_BACKEND_DEFAULT.
 * @param targetId  DNN target identifier (see cv::dnn::Target);  0 = DNN_TARGET_CPU.
 */
+ (DISK*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold imageSize:(Size2i*)imageSize backendId:(int)backendId targetId:(int)targetId NS_SWIFT_NAME(create(modelPath:maxKeypoints:scoreThreshold:imageSize:backendId:targetId:));

/**
 * Creates a DISK detector.
 * @param modelPath Path to the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score strictly below this value.
 * @param imageSize Target input size (width, height) fed to the network. Use Size()
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 * @param backendId DNN backend identifier (see cv::dnn::Backend); 0 = DNN_BACKEND_DEFAULT.
 */
+ (DISK*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold imageSize:(Size2i*)imageSize backendId:(int)backendId NS_SWIFT_NAME(create(modelPath:maxKeypoints:scoreThreshold:imageSize:backendId:));

/**
 * Creates a DISK detector.
 * @param modelPath Path to the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score strictly below this value.
 * @param imageSize Target input size (width, height) fed to the network. Use Size()
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 */
+ (DISK*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold imageSize:(Size2i*)imageSize NS_SWIFT_NAME(create(modelPath:maxKeypoints:scoreThreshold:imageSize:));

/**
 * Creates a DISK detector.
 * @param modelPath Path to the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score strictly below this value.
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 */
+ (DISK*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold NS_SWIFT_NAME(create(modelPath:maxKeypoints:scoreThreshold:));

/**
 * Creates a DISK detector.
 * @param modelPath Path to the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 */
+ (DISK*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints NS_SWIFT_NAME(create(modelPath:maxKeypoints:));

/**
 * Creates a DISK detector.
 * @param modelPath Path to the DISK ONNX model.
 *                         responses (by network score) are kept; -1 keeps all detections.
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 */
+ (DISK*)create:(NSString*)modelPath NS_SWIFT_NAME(create(modelPath:));


//
// static Ptr_DISK cv::DISK::create(vector_uchar bufferModel, int maxKeypoints = -1, float scoreThreshold = 0.0f, Size imageSize = Size(), int backendId = 0, int targetId = 0)
//
/**
 * Creates a DISK detector from an in-memory model buffer.
 *
 *     This overload loads the DISK ONNX model from a buffer instead of a file on disk. It is
 *     intended for cases where the model is read from application resources (for example Android
 *     assets) and is not available as a path on the filesystem.
 *
 * @param bufferModel A buffer containing the contents of the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score strictly below this value.
 * @param imageSize Target input size (width, height) fed to the network. Use Size()
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 * @param backendId DNN backend identifier (see cv::dnn::Backend); 0 = DNN_BACKEND_DEFAULT.
 * @param targetId  DNN target identifier (see cv::dnn::Target);  0 = DNN_TARGET_CPU.
 *
 * Note:* In C++ this is an overload of *Ref:* create. The Python/Java/Objective-C bindings expose
 *           it as `createFromMemory`, because Objective-C selectors are not disambiguated by argument
 *           type and would otherwise clash with the file-path *Ref:* create.
 */
+ (DISK*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold imageSize:(Size2i*)imageSize backendId:(int)backendId targetId:(int)targetId NS_SWIFT_NAME(create(bufferModel:maxKeypoints:scoreThreshold:imageSize:backendId:targetId:));

/**
 * Creates a DISK detector from an in-memory model buffer.
 *
 *     This overload loads the DISK ONNX model from a buffer instead of a file on disk. It is
 *     intended for cases where the model is read from application resources (for example Android
 *     assets) and is not available as a path on the filesystem.
 *
 * @param bufferModel A buffer containing the contents of the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score strictly below this value.
 * @param imageSize Target input size (width, height) fed to the network. Use Size()
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 * @param backendId DNN backend identifier (see cv::dnn::Backend); 0 = DNN_BACKEND_DEFAULT.
 *
 * Note:* In C++ this is an overload of *Ref:* create. The Python/Java/Objective-C bindings expose
 *           it as `createFromMemory`, because Objective-C selectors are not disambiguated by argument
 *           type and would otherwise clash with the file-path *Ref:* create.
 */
+ (DISK*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold imageSize:(Size2i*)imageSize backendId:(int)backendId NS_SWIFT_NAME(create(bufferModel:maxKeypoints:scoreThreshold:imageSize:backendId:));

/**
 * Creates a DISK detector from an in-memory model buffer.
 *
 *     This overload loads the DISK ONNX model from a buffer instead of a file on disk. It is
 *     intended for cases where the model is read from application resources (for example Android
 *     assets) and is not available as a path on the filesystem.
 *
 * @param bufferModel A buffer containing the contents of the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score strictly below this value.
 * @param imageSize Target input size (width, height) fed to the network. Use Size()
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 *
 * Note:* In C++ this is an overload of *Ref:* create. The Python/Java/Objective-C bindings expose
 *           it as `createFromMemory`, because Objective-C selectors are not disambiguated by argument
 *           type and would otherwise clash with the file-path *Ref:* create.
 */
+ (DISK*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold imageSize:(Size2i*)imageSize NS_SWIFT_NAME(create(bufferModel:maxKeypoints:scoreThreshold:imageSize:));

/**
 * Creates a DISK detector from an in-memory model buffer.
 *
 *     This overload loads the DISK ONNX model from a buffer instead of a file on disk. It is
 *     intended for cases where the model is read from application resources (for example Android
 *     assets) and is not available as a path on the filesystem.
 *
 * @param bufferModel A buffer containing the contents of the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score strictly below this value.
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 *
 * Note:* In C++ this is an overload of *Ref:* create. The Python/Java/Objective-C bindings expose
 *           it as `createFromMemory`, because Objective-C selectors are not disambiguated by argument
 *           type and would otherwise clash with the file-path *Ref:* create.
 */
+ (DISK*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold NS_SWIFT_NAME(create(bufferModel:maxKeypoints:scoreThreshold:));

/**
 * Creates a DISK detector from an in-memory model buffer.
 *
 *     This overload loads the DISK ONNX model from a buffer instead of a file on disk. It is
 *     intended for cases where the model is read from application resources (for example Android
 *     assets) and is not available as a path on the filesystem.
 *
 * @param bufferModel A buffer containing the contents of the DISK ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses (by network score) are kept; -1 keeps all detections.
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 *
 * Note:* In C++ this is an overload of *Ref:* create. The Python/Java/Objective-C bindings expose
 *           it as `createFromMemory`, because Objective-C selectors are not disambiguated by argument
 *           type and would otherwise clash with the file-path *Ref:* create.
 */
+ (DISK*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints NS_SWIFT_NAME(create(bufferModel:maxKeypoints:));

/**
 * Creates a DISK detector from an in-memory model buffer.
 *
 *     This overload loads the DISK ONNX model from a buffer instead of a file on disk. It is
 *     intended for cases where the model is read from application resources (for example Android
 *     assets) and is not available as a path on the filesystem.
 *
 * @param bufferModel A buffer containing the contents of the DISK ONNX model.
 *                         responses (by network score) are kept; -1 keeps all detections.
 *                      (the default) to fall back to the network's expected fixed input
 *                      shape of 1024x1024. When overriding, both dimensions must be
 *                      positive multiples of 16, since DISK downsamples by a factor of 16.
 *
 * Note:* In C++ this is an overload of *Ref:* create. The Python/Java/Objective-C bindings expose
 *           it as `createFromMemory`, because Objective-C selectors are not disambiguated by argument
 *           type and would otherwise clash with the file-path *Ref:* create.
 */
+ (DISK*)createFromMemory:(ByteVector*)bufferModel NS_SWIFT_NAME(create(bufferModel:));


//
//  void cv::DISK::setMaxKeypoints(int maxKeypoints)
//
- (void)setMaxKeypoints:(int)maxKeypoints NS_SWIFT_NAME(setMaxKeypoints(maxKeypoints:));


//
//  int cv::DISK::getMaxKeypoints()
//
- (int)getMaxKeypoints NS_SWIFT_NAME(getMaxKeypoints());


//
//  void cv::DISK::setScoreThreshold(float threshold)
//
- (void)setScoreThreshold:(float)threshold NS_SWIFT_NAME(setScoreThreshold(threshold:));


//
//  float cv::DISK::getScoreThreshold()
//
- (float)getScoreThreshold NS_SWIFT_NAME(getScoreThreshold());


//
//  void cv::DISK::setImageSize(Size size)
//
- (void)setImageSize:(Size2i*)size NS_SWIFT_NAME(setImageSize(size:));


//
//  Size cv::DISK::getImageSize()
//
- (Size2i*)getImageSize NS_SWIFT_NAME(getImageSize());


//
//  String cv::DISK::getDefaultName()
//
- (NSString*)getDefaultName NS_SWIFT_NAME(getDefaultName());



@end

NS_ASSUME_NONNULL_END


