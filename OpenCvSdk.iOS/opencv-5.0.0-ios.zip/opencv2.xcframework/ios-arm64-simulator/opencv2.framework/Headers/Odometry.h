//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/odometry.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "Ptcloud.h"
@class Mat;
@class OdometryFrame;
@class OdometrySettings;
@class RgbdNormals;



NS_ASSUME_NONNULL_BEGIN

// C++: class Odometry
/**
 * The Odometry module
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface Odometry : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::Odometry> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::Odometry>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::Odometry>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::Odometry::Odometry()
//
- (instancetype)init;


//
//   cv::Odometry::Odometry(OdometryType otype)
//
- (instancetype)initWithOtype:(OdometryType)otype;


//
//   cv::Odometry::Odometry(OdometryType otype, OdometrySettings settings, OdometryAlgoType algtype)
//
- (instancetype)initWithOtype:(OdometryType)otype settings:(OdometrySettings*)settings algtype:(OdometryAlgoType)algtype;


//
//  void cv::Odometry::prepareFrame(OdometryFrame frame)
//
/**
 * Prepare frame for odometry calculation
 * @param frame odometry prepare this frame as src frame and dst frame simultaneously
 */
- (void)prepareFrame:(OdometryFrame*)frame NS_SWIFT_NAME(prepareFrame(frame:));


//
//  void cv::Odometry::prepareFrames(OdometryFrame srcFrame, OdometryFrame dstFrame)
//
/**
 * Prepare frame for odometry calculation
 * @param srcFrame frame will be prepared as src frame ("original" image)
 * @param dstFrame frame will be prepared as dsr frame ("rotated" image)
 */
- (void)prepareFrames:(OdometryFrame*)srcFrame dstFrame:(OdometryFrame*)dstFrame NS_SWIFT_NAME(prepareFrames(srcFrame:dstFrame:));


//
//  bool cv::Odometry::compute(OdometryFrame srcFrame, OdometryFrame dstFrame, Mat& Rt)
//
/**
 * Compute Rigid Transformation between two frames so that Rt * src = dst
 * Both frames, source and destination, should have been prepared by calling prepareFrame() first
 *
 * @param srcFrame src frame ("original" image)
 * @param dstFrame dst frame ("rotated" image)
 * @param Rt Rigid transformation, which will be calculated, in form:
 * { R_11 R_12 R_13 t_1
 * R_21 R_22 R_23 t_2
 * R_31 R_32 R_33 t_3
 * 0    0    0    1  }
 * @return true on success, false if failed to find the transformation
 */
- (BOOL)compute:(OdometryFrame*)srcFrame dstFrame:(OdometryFrame*)dstFrame Rt:(Mat*)Rt NS_SWIFT_NAME(compute(srcFrame:dstFrame:Rt:));


//
//  bool cv::Odometry::compute(Mat srcDepth, Mat dstDepth, Mat& Rt)
//
/**
 * Compute Rigid Transformation between two frames so that Rt * src = dst
 *
 * @param srcDepth source depth ("original" image)
 * @param dstDepth destination depth ("rotated" image)
 * @param Rt Rigid transformation, which will be calculated, in form:
 * { R_11 R_12 R_13 t_1
 * R_21 R_22 R_23 t_2
 * R_31 R_32 R_33 t_3
 * 0    0    0    1  }
 * @return true on success, false if failed to find the transformation
 */
- (BOOL)compute:(Mat*)srcDepth dstDepth:(Mat*)dstDepth Rt:(Mat*)Rt NS_SWIFT_NAME(compute(srcDepth:dstDepth:Rt:));


//
//  bool cv::Odometry::compute(Mat srcDepth, Mat srcRGB, Mat dstDepth, Mat dstRGB, Mat& Rt)
//
/**
 * Compute Rigid Transformation between two frames so that Rt * src = dst
 *
 * @param srcDepth source depth ("original" image)
 * @param srcRGB source RGB
 * @param dstDepth destination depth ("rotated" image)
 * @param dstRGB destination RGB
 * @param Rt Rigid transformation, which will be calculated, in form:
 * { R_11 R_12 R_13 t_1
 * R_21 R_22 R_23 t_2
 * R_31 R_32 R_33 t_3
 * 0    0    0    1  }
 * @return true on success, false if failed to find the transformation
 */
- (BOOL)compute:(Mat*)srcDepth srcRGB:(Mat*)srcRGB dstDepth:(Mat*)dstDepth dstRGB:(Mat*)dstRGB Rt:(Mat*)Rt NS_SWIFT_NAME(compute(srcDepth:srcRGB:dstDepth:dstRGB:Rt:));


//
//  Ptr_RgbdNormals cv::Odometry::getNormalsComputer()
//
/**
 * Get the normals computer object used for normals calculation (if presented).
 * The normals computer is generated at first need during prepareFrame when normals are required for the ICP algorithm
 * but not presented by a user. Re-generated each time the related settings change or a new frame arrives with the different size.
 */
- (RgbdNormals*)getNormalsComputer NS_SWIFT_NAME(getNormalsComputer());



@end

NS_ASSUME_NONNULL_END


