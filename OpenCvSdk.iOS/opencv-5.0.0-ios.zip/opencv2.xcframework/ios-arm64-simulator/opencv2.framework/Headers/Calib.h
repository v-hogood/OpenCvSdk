//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/calib.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>

@class Mat;
@class Size2i;
@class TermCriteria;


// C++: enum CameraModel (cv.CameraModel)
typedef NS_ENUM(int, CameraModel) {
    CALIB_MODEL_PINHOLE = 0,
    CALIB_MODEL_FISHEYE = 1
};


// C++: enum HandEyeCalibrationMethod (cv.HandEyeCalibrationMethod)
typedef NS_ENUM(int, HandEyeCalibrationMethod) {
    CALIB_HAND_EYE_TSAI = 0,
    CALIB_HAND_EYE_PARK = 1,
    CALIB_HAND_EYE_HORAUD = 2,
    CALIB_HAND_EYE_ANDREFF = 3,
    CALIB_HAND_EYE_DANIILIDIS = 4
};


// C++: enum RobotWorldHandEyeCalibrationMethod (cv.RobotWorldHandEyeCalibrationMethod)
typedef NS_ENUM(int, RobotWorldHandEyeCalibrationMethod) {
    CALIB_ROBOT_WORLD_HAND_EYE_SHAH = 0,
    CALIB_ROBOT_WORLD_HAND_EYE_LI = 1
};



NS_ASSUME_NONNULL_BEGIN

// C++: class Calib
/**
 * The Calib module
 *
 * Member of `Calib`
 * Member enums: `CameraModel`, `HandEyeCalibrationMethod`, `RobotWorldHandEyeCalibrationMethod`
 */
CV_EXPORTS @interface Calib : NSObject

#pragma mark - Class Constants


@property (class, readonly) int CALIB_USE_INTRINSIC_GUESS NS_SWIFT_NAME(CALIB_USE_INTRINSIC_GUESS);
@property (class, readonly) int CALIB_FIX_ASPECT_RATIO NS_SWIFT_NAME(CALIB_FIX_ASPECT_RATIO);
@property (class, readonly) int CALIB_FIX_PRINCIPAL_POINT NS_SWIFT_NAME(CALIB_FIX_PRINCIPAL_POINT);
@property (class, readonly) int CALIB_ZERO_TANGENT_DIST NS_SWIFT_NAME(CALIB_ZERO_TANGENT_DIST);
@property (class, readonly) int CALIB_FIX_FOCAL_LENGTH NS_SWIFT_NAME(CALIB_FIX_FOCAL_LENGTH);
@property (class, readonly) int CALIB_FIX_K1 NS_SWIFT_NAME(CALIB_FIX_K1);
@property (class, readonly) int CALIB_FIX_K2 NS_SWIFT_NAME(CALIB_FIX_K2);
@property (class, readonly) int CALIB_FIX_K3 NS_SWIFT_NAME(CALIB_FIX_K3);
@property (class, readonly) int CALIB_FIX_K4 NS_SWIFT_NAME(CALIB_FIX_K4);
@property (class, readonly) int CALIB_FIX_K5 NS_SWIFT_NAME(CALIB_FIX_K5);
@property (class, readonly) int CALIB_FIX_K6 NS_SWIFT_NAME(CALIB_FIX_K6);
@property (class, readonly) int CALIB_RATIONAL_MODEL NS_SWIFT_NAME(CALIB_RATIONAL_MODEL);
@property (class, readonly) int CALIB_THIN_PRISM_MODEL NS_SWIFT_NAME(CALIB_THIN_PRISM_MODEL);
@property (class, readonly) int CALIB_FIX_S1_S2_S3_S4 NS_SWIFT_NAME(CALIB_FIX_S1_S2_S3_S4);
@property (class, readonly) int CALIB_TILTED_MODEL NS_SWIFT_NAME(CALIB_TILTED_MODEL);
@property (class, readonly) int CALIB_FIX_TAUX_TAUY NS_SWIFT_NAME(CALIB_FIX_TAUX_TAUY);
@property (class, readonly) int CALIB_USE_QR NS_SWIFT_NAME(CALIB_USE_QR);
@property (class, readonly) int CALIB_FIX_TANGENT_DIST NS_SWIFT_NAME(CALIB_FIX_TANGENT_DIST);
@property (class, readonly) int CALIB_FIX_INTRINSIC NS_SWIFT_NAME(CALIB_FIX_INTRINSIC);
@property (class, readonly) int CALIB_SAME_FOCAL_LENGTH NS_SWIFT_NAME(CALIB_SAME_FOCAL_LENGTH);
@property (class, readonly) int CALIB_ZERO_DISPARITY NS_SWIFT_NAME(CALIB_ZERO_DISPARITY);
@property (class, readonly) int CALIB_USE_LU NS_SWIFT_NAME(CALIB_USE_LU);
@property (class, readonly) int CALIB_DISABLE_SCHUR_COMPLEMENT NS_SWIFT_NAME(CALIB_DISABLE_SCHUR_COMPLEMENT);
@property (class, readonly) int CALIB_USE_EXTRINSIC_GUESS NS_SWIFT_NAME(CALIB_USE_EXTRINSIC_GUESS);
@property (class, readonly) int CALIB_RECOMPUTE_EXTRINSIC NS_SWIFT_NAME(CALIB_RECOMPUTE_EXTRINSIC);
@property (class, readonly) int CALIB_CHECK_COND NS_SWIFT_NAME(CALIB_CHECK_COND);
@property (class, readonly) int CALIB_FIX_SKEW NS_SWIFT_NAME(CALIB_FIX_SKEW);
@property (class, readonly) int CALIB_STEREO_REGISTRATION NS_SWIFT_NAME(CALIB_STEREO_REGISTRATION);

#pragma mark - Methods


//
//  Mat cv::initCameraMatrix2D(vector_Mat objectPoints, vector_Mat imagePoints, Size imageSize, double aspectRatio = 1.0)
//
/**
 * Finds an initial camera intrinsic matrix from 3D-2D point correspondences.
 *
 * @param objectPoints Vector of vectors of the calibration pattern points in the calibration pattern
 * coordinate space. In the old interface all the per-view vectors are concatenated. See
 * ``Calib/calibrateCamera`` for details.
 * @param imagePoints Vector of vectors of the projections of the calibration pattern points. In the
 * old interface all the per-view vectors are concatenated.
 * @param imageSize Image size in pixels used to initialize the principal point.
 * @param aspectRatio If it is zero or negative, both `$$f_x$$` and `$$f_y$$` are estimated independently.
 * Otherwise, `$$f_x = f_y \cdot \texttt{aspectRatio}$$` .
 *
 * The function estimates and returns an initial camera intrinsic matrix for the camera calibration process.
 * Currently, the function only supports planar calibration patterns, which are patterns where each
 * object point has z-coordinate =0.
 */
+ (Mat*)initCameraMatrix2D:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize aspectRatio:(double)aspectRatio NS_SWIFT_NAME(initCameraMatrix2D(objectPoints:imagePoints:imageSize:aspectRatio:));

/**
 * Finds an initial camera intrinsic matrix from 3D-2D point correspondences.
 *
 * @param objectPoints Vector of vectors of the calibration pattern points in the calibration pattern
 * coordinate space. In the old interface all the per-view vectors are concatenated. See
 * ``Calib/calibrateCamera`` for details.
 * @param imagePoints Vector of vectors of the projections of the calibration pattern points. In the
 * old interface all the per-view vectors are concatenated.
 * @param imageSize Image size in pixels used to initialize the principal point.
 * Otherwise, `$$f_x = f_y \cdot \texttt{aspectRatio}$$` .
 *
 * The function estimates and returns an initial camera intrinsic matrix for the camera calibration process.
 * Currently, the function only supports planar calibration patterns, which are patterns where each
 * object point has z-coordinate =0.
 */
+ (Mat*)initCameraMatrix2D:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize NS_SWIFT_NAME(initCameraMatrix2D(objectPoints:imagePoints:imageSize:));


//
//  double cv::calibrateCamera(vector_Mat objectPoints, vector_Mat imagePoints, Size imageSize, Mat& cameraMatrix, Mat& distCoeffs, vector_Mat& rvecs, vector_Mat& tvecs, Mat& stdDeviationsIntrinsics, Mat& stdDeviationsExtrinsics, Mat& perViewErrors, int flags = 0, TermCriteria criteria = TermCriteria( TermCriteria::COUNT + TermCriteria::EPS, 500, DBL_EPSILON))
//
/**
 * Finds the camera intrinsic and extrinsic parameters from several views of a calibration
 * pattern.
 *
 * @param objectPoints In the new interface it is a vector of vectors of calibration pattern points in
 * the calibration pattern coordinate space (e.g. std::vector<std::vector<cv::Vec3f>>). The outer
 * vector contains as many elements as the number of pattern views. If the same calibration pattern
 * is shown in each view and it is fully visible, all the vectors will be the same. Although, it is
 * possible to use partially occluded patterns or even different patterns in different views. Then,
 * the vectors will be different. Although the points are 3D, they all lie in the calibration pattern's
 * XY coordinate plane (thus 0 in the Z-coordinate), if the used calibration pattern is a planar rig.
 * In the old interface all the vectors of object points from different views are concatenated
 * together.
 * @param imagePoints In the new interface it is a vector of vectors of the projections of calibration
 * pattern points (e.g. std::vector<std::vector<cv::Vec2f>>). imagePoints.size() and
 * objectPoints.size(), and imagePoints[i].size() and objectPoints[i].size() for each i, must be equal,
 * respectively. In the old interface all the vectors of object points from different views are
 * concatenated together.
 * @param imageSize Size of the image used only to initialize the camera intrinsic matrix.
 * @param cameraMatrix Input/output 3x3 floating-point camera intrinsic matrix
 * `$$\cameramatrix{A}$$` . If *Ref:* CALIB_USE_INTRINSIC_GUESS
 * and/or *Ref:* CALIB_FIX_ASPECT_RATIO, *Ref:* CALIB_FIX_PRINCIPAL_POINT or *Ref:* CALIB_FIX_FOCAL_LENGTH
 * are specified, some or all of fx, fy, cx, cy must be initialized before calling the function.
 * @param distCoeffs Input/output vector of distortion coefficients
 * `$$\distcoeffs$$`.
 * @param rvecs Output vector of rotation vectors (*Ref:* Rodrigues ) estimated for each pattern view
 * (e.g. std::vector<cv::Mat>>). That is, each i-th rotation vector together with the corresponding
 * i-th translation vector (see the next output parameter description) brings the calibration pattern
 * from the object coordinate space (in which object points are specified) to the camera coordinate
 * space. In more technical terms, the tuple of the i-th rotation and translation vector performs
 * a change of basis from object coordinate space to camera coordinate space. Due to its duality, this
 * tuple is equivalent to the position of the calibration pattern with respect to the camera coordinate
 * space.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter
 * description above.
 * @param stdDeviationsIntrinsics Output vector of standard deviations estimated for intrinsic
 * parameters. Order of deviations values:
 * `$$(f_x, f_y, c_x, c_y, k_1, k_2, p_1, p_2, k_3, k_4, k_5, k_6 , s_1, s_2, s_3,
 *  s_4, \tau_x, \tau_y)$$` If one of parameters is not estimated, it's deviation is equals to zero.
 * @param stdDeviationsExtrinsics Output vector of standard deviations estimated for extrinsic
 * parameters. Order of deviations values: `$$(R_0, T_0, \dotsc , R_{M - 1}, T_{M - 1})$$` where M is
 * the number of pattern views. `$$R_i, T_i$$` are concatenated 1x3 vectors.
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* CALIB_USE_INTRINSIC_GUESS cameraMatrix contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center ( imageSize is used), and focal distances are computed in a least-squares fashion.
 * Note, that if intrinsic parameters are known, there is no need to use this function just to
 * estimate extrinsic parameters. Use *Ref:* solvePnP instead.
 * -   *Ref:* CALIB_DISABLE_SCHUR_COMPLEMENT Disable Schur complement and use the Bouguet calibration engine (*Cite:* Zhang2000, *Cite:* BouguetMCT).
 * -   *Ref:* CALIB_FIX_PRINCIPAL_POINT The principal point is not changed during the global
 * optimization. It stays at the center or at a different location specified when
 * Ref:* CALIB_USE_INTRINSIC_GUESS is set too.
 * -   *Ref:* CALIB_FIX_ASPECT_RATIO The functions consider only fy as a free parameter. The
 * ratio fx/fy stays the same as in the input cameraMatrix . When
 * Ref:* CALIB_USE_INTRINSIC_GUESS is not set, the actual input values of fx and fy are
 * ignored, only their ratio is computed and used further.
 * -   *Ref:* CALIB_ZERO_TANGENT_DIST Tangential distortion coefficients `$$(p_1, p_2)$$` are set
 * to zeros and stay zero.
 * -   *Ref:* CALIB_FIX_FOCAL_LENGTH The focal length is not changed during the global optimization if
 * Ref:* CALIB_USE_INTRINSIC_GUESS is set.
 * -   *Ref:* CALIB_FIX_K1,..., *Ref:* CALIB_FIX_K6 The corresponding radial distortion
 * coefficient is not changed during the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is
 * set, the coefficient from the supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_RATIONAL_MODEL Coefficients k4, k5, and k6 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the rational model and return 8 coefficients or more.
 * -   *Ref:* CALIB_THIN_PRISM_MODEL Coefficients s1, s2, s3 and s4 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the thin prism model and return 12 coefficients or more.
 * -   *Ref:* CALIB_FIX_S1_S2_S3_S4 The thin prism distortion coefficients are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_TILTED_MODEL Coefficients tauX and tauY are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the tilted sensor model and return 14 coefficients.
 * -   *Ref:* CALIB_FIX_TAUX_TAUY The coefficients of the tilted sensor model are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * @param criteria Termination criteria for the iterative optimization algorithm.
 *
 * @return the overall RMS re-projection error.
 *
 * The function estimates the intrinsic camera parameters and extrinsic parameters for each of the
 * views. By default, the optimization follows a sparse bundle adjustment formulation with Schur
 * complement; see *Cite:* Triggs2000_bundle_adjustment and *Cite:* Lourakis2009_sba for background. Use
 * Ref:* CALIB_DISABLE_SCHUR_COMPLEMENT to switch to the Bouguet calibration engine. The coordinates of 3D object
 * points and their corresponding 2D projections in each view must be specified. That may be achieved
 * by using an object with known geometry and easily detectable feature points. Such an object is
 * called a calibration rig or calibration pattern, and OpenCV has built-in support for a chessboard as
 * a calibration rig (see *Ref:* findChessboardCorners). Currently, initialization of intrinsic
 * parameters (when *Ref:* CALIB_USE_INTRINSIC_GUESS is not set) is only implemented for planar calibration
 * patterns (where Z-coordinates of the object points must be all zeros). 3D calibration rigs can also
 * be used as long as initial cameraMatrix is provided.
 *
 * The algorithm performs the following steps:
 *
 * -   Compute the initial intrinsic parameters (the option only available for planar calibration
 *     patterns) or read them from the input parameters. The distortion coefficients are all set to
 *     zeros initially unless some of CALIB_FIX_K? are specified.
 *
 * -   Estimate the initial camera pose as if the intrinsic parameters have been already known. This is
 *     done using *Ref:* solvePnP .
 *
 * -   Run the global Levenberg-Marquardt optimization algorithm to minimize the reprojection error,
 *     that is, the total sum of squared distances between the observed feature points imagePoints and
 *     the projected (using the current estimates for camera parameters and the poses) object points
 *     objectPoints. See *Ref:* projectPoints for details.
 *
 * -   In practice, robust acquisition is essential for stable results: use multiple board poses with
 *     significant tilt, avoid collecting all views at a single working distance, span the expected
 *     working-distance range (a larger board with larger squares can help for longer distances).
 *
 * Note:*
 *     If you use a non-square (i.e. non-N-by-N) grid and *Ref:* findChessboardCorners for calibration,
 *     and *Ref:* calibrateCamera returns bad values (zero distortion coefficients, `$$c_x$$` and
 *     `$$c_y$$` very far from the image center, and/or large differences between `$$f_x$$` and
 *     `$$f_y$$` (ratios of 10:1 or more)), then you are probably using patternSize=cvSize(rows,cols)
 *     instead of using patternSize=cvSize(cols,rows) in *Ref:* findChessboardCorners.
 *
 * Note:*
 *     The function may throw exceptions, if unsupported combination of parameters is provided or
 *     the system is underconstrained.
 *
 * @sa
 *    calibrateCameraRO, findChessboardCorners, solvePnP, initCameraMatrix2D, stereoCalibrate,
 *    undistort
 */
+ (double)calibrateCameraExtended:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs stdDeviationsIntrinsics:(Mat*)stdDeviationsIntrinsics stdDeviationsExtrinsics:(Mat*)stdDeviationsExtrinsics perViewErrors:(Mat*)perViewErrors flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(calibrateCamera(objectPoints:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:stdDeviationsIntrinsics:stdDeviationsExtrinsics:perViewErrors:flags:criteria:));

/**
 * Finds the camera intrinsic and extrinsic parameters from several views of a calibration
 * pattern.
 *
 * @param objectPoints In the new interface it is a vector of vectors of calibration pattern points in
 * the calibration pattern coordinate space (e.g. std::vector<std::vector<cv::Vec3f>>). The outer
 * vector contains as many elements as the number of pattern views. If the same calibration pattern
 * is shown in each view and it is fully visible, all the vectors will be the same. Although, it is
 * possible to use partially occluded patterns or even different patterns in different views. Then,
 * the vectors will be different. Although the points are 3D, they all lie in the calibration pattern's
 * XY coordinate plane (thus 0 in the Z-coordinate), if the used calibration pattern is a planar rig.
 * In the old interface all the vectors of object points from different views are concatenated
 * together.
 * @param imagePoints In the new interface it is a vector of vectors of the projections of calibration
 * pattern points (e.g. std::vector<std::vector<cv::Vec2f>>). imagePoints.size() and
 * objectPoints.size(), and imagePoints[i].size() and objectPoints[i].size() for each i, must be equal,
 * respectively. In the old interface all the vectors of object points from different views are
 * concatenated together.
 * @param imageSize Size of the image used only to initialize the camera intrinsic matrix.
 * @param cameraMatrix Input/output 3x3 floating-point camera intrinsic matrix
 * `$$\cameramatrix{A}$$` . If *Ref:* CALIB_USE_INTRINSIC_GUESS
 * and/or *Ref:* CALIB_FIX_ASPECT_RATIO, *Ref:* CALIB_FIX_PRINCIPAL_POINT or *Ref:* CALIB_FIX_FOCAL_LENGTH
 * are specified, some or all of fx, fy, cx, cy must be initialized before calling the function.
 * @param distCoeffs Input/output vector of distortion coefficients
 * `$$\distcoeffs$$`.
 * @param rvecs Output vector of rotation vectors (*Ref:* Rodrigues ) estimated for each pattern view
 * (e.g. std::vector<cv::Mat>>). That is, each i-th rotation vector together with the corresponding
 * i-th translation vector (see the next output parameter description) brings the calibration pattern
 * from the object coordinate space (in which object points are specified) to the camera coordinate
 * space. In more technical terms, the tuple of the i-th rotation and translation vector performs
 * a change of basis from object coordinate space to camera coordinate space. Due to its duality, this
 * tuple is equivalent to the position of the calibration pattern with respect to the camera coordinate
 * space.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter
 * description above.
 * @param stdDeviationsIntrinsics Output vector of standard deviations estimated for intrinsic
 * parameters. Order of deviations values:
 * `$$(f_x, f_y, c_x, c_y, k_1, k_2, p_1, p_2, k_3, k_4, k_5, k_6 , s_1, s_2, s_3,
 *  s_4, \tau_x, \tau_y)$$` If one of parameters is not estimated, it's deviation is equals to zero.
 * @param stdDeviationsExtrinsics Output vector of standard deviations estimated for extrinsic
 * parameters. Order of deviations values: `$$(R_0, T_0, \dotsc , R_{M - 1}, T_{M - 1})$$` where M is
 * the number of pattern views. `$$R_i, T_i$$` are concatenated 1x3 vectors.
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* CALIB_USE_INTRINSIC_GUESS cameraMatrix contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center ( imageSize is used), and focal distances are computed in a least-squares fashion.
 * Note, that if intrinsic parameters are known, there is no need to use this function just to
 * estimate extrinsic parameters. Use *Ref:* solvePnP instead.
 * -   *Ref:* CALIB_DISABLE_SCHUR_COMPLEMENT Disable Schur complement and use the Bouguet calibration engine (*Cite:* Zhang2000, *Cite:* BouguetMCT).
 * -   *Ref:* CALIB_FIX_PRINCIPAL_POINT The principal point is not changed during the global
 * optimization. It stays at the center or at a different location specified when
 * Ref:* CALIB_USE_INTRINSIC_GUESS is set too.
 * -   *Ref:* CALIB_FIX_ASPECT_RATIO The functions consider only fy as a free parameter. The
 * ratio fx/fy stays the same as in the input cameraMatrix . When
 * Ref:* CALIB_USE_INTRINSIC_GUESS is not set, the actual input values of fx and fy are
 * ignored, only their ratio is computed and used further.
 * -   *Ref:* CALIB_ZERO_TANGENT_DIST Tangential distortion coefficients `$$(p_1, p_2)$$` are set
 * to zeros and stay zero.
 * -   *Ref:* CALIB_FIX_FOCAL_LENGTH The focal length is not changed during the global optimization if
 * Ref:* CALIB_USE_INTRINSIC_GUESS is set.
 * -   *Ref:* CALIB_FIX_K1,..., *Ref:* CALIB_FIX_K6 The corresponding radial distortion
 * coefficient is not changed during the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is
 * set, the coefficient from the supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_RATIONAL_MODEL Coefficients k4, k5, and k6 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the rational model and return 8 coefficients or more.
 * -   *Ref:* CALIB_THIN_PRISM_MODEL Coefficients s1, s2, s3 and s4 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the thin prism model and return 12 coefficients or more.
 * -   *Ref:* CALIB_FIX_S1_S2_S3_S4 The thin prism distortion coefficients are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_TILTED_MODEL Coefficients tauX and tauY are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the tilted sensor model and return 14 coefficients.
 * -   *Ref:* CALIB_FIX_TAUX_TAUY The coefficients of the tilted sensor model are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 *
 * @return the overall RMS re-projection error.
 *
 * The function estimates the intrinsic camera parameters and extrinsic parameters for each of the
 * views. By default, the optimization follows a sparse bundle adjustment formulation with Schur
 * complement; see *Cite:* Triggs2000_bundle_adjustment and *Cite:* Lourakis2009_sba for background. Use
 * Ref:* CALIB_DISABLE_SCHUR_COMPLEMENT to switch to the Bouguet calibration engine. The coordinates of 3D object
 * points and their corresponding 2D projections in each view must be specified. That may be achieved
 * by using an object with known geometry and easily detectable feature points. Such an object is
 * called a calibration rig or calibration pattern, and OpenCV has built-in support for a chessboard as
 * a calibration rig (see *Ref:* findChessboardCorners). Currently, initialization of intrinsic
 * parameters (when *Ref:* CALIB_USE_INTRINSIC_GUESS is not set) is only implemented for planar calibration
 * patterns (where Z-coordinates of the object points must be all zeros). 3D calibration rigs can also
 * be used as long as initial cameraMatrix is provided.
 *
 * The algorithm performs the following steps:
 *
 * -   Compute the initial intrinsic parameters (the option only available for planar calibration
 *     patterns) or read them from the input parameters. The distortion coefficients are all set to
 *     zeros initially unless some of CALIB_FIX_K? are specified.
 *
 * -   Estimate the initial camera pose as if the intrinsic parameters have been already known. This is
 *     done using *Ref:* solvePnP .
 *
 * -   Run the global Levenberg-Marquardt optimization algorithm to minimize the reprojection error,
 *     that is, the total sum of squared distances between the observed feature points imagePoints and
 *     the projected (using the current estimates for camera parameters and the poses) object points
 *     objectPoints. See *Ref:* projectPoints for details.
 *
 * -   In practice, robust acquisition is essential for stable results: use multiple board poses with
 *     significant tilt, avoid collecting all views at a single working distance, span the expected
 *     working-distance range (a larger board with larger squares can help for longer distances).
 *
 * Note:*
 *     If you use a non-square (i.e. non-N-by-N) grid and *Ref:* findChessboardCorners for calibration,
 *     and *Ref:* calibrateCamera returns bad values (zero distortion coefficients, `$$c_x$$` and
 *     `$$c_y$$` very far from the image center, and/or large differences between `$$f_x$$` and
 *     `$$f_y$$` (ratios of 10:1 or more)), then you are probably using patternSize=cvSize(rows,cols)
 *     instead of using patternSize=cvSize(cols,rows) in *Ref:* findChessboardCorners.
 *
 * Note:*
 *     The function may throw exceptions, if unsupported combination of parameters is provided or
 *     the system is underconstrained.
 *
 * @sa
 *    calibrateCameraRO, findChessboardCorners, solvePnP, initCameraMatrix2D, stereoCalibrate,
 *    undistort
 */
+ (double)calibrateCameraExtended:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs stdDeviationsIntrinsics:(Mat*)stdDeviationsIntrinsics stdDeviationsExtrinsics:(Mat*)stdDeviationsExtrinsics perViewErrors:(Mat*)perViewErrors flags:(int)flags NS_SWIFT_NAME(calibrateCamera(objectPoints:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:stdDeviationsIntrinsics:stdDeviationsExtrinsics:perViewErrors:flags:));

/**
 * Finds the camera intrinsic and extrinsic parameters from several views of a calibration
 * pattern.
 *
 * @param objectPoints In the new interface it is a vector of vectors of calibration pattern points in
 * the calibration pattern coordinate space (e.g. std::vector<std::vector<cv::Vec3f>>). The outer
 * vector contains as many elements as the number of pattern views. If the same calibration pattern
 * is shown in each view and it is fully visible, all the vectors will be the same. Although, it is
 * possible to use partially occluded patterns or even different patterns in different views. Then,
 * the vectors will be different. Although the points are 3D, they all lie in the calibration pattern's
 * XY coordinate plane (thus 0 in the Z-coordinate), if the used calibration pattern is a planar rig.
 * In the old interface all the vectors of object points from different views are concatenated
 * together.
 * @param imagePoints In the new interface it is a vector of vectors of the projections of calibration
 * pattern points (e.g. std::vector<std::vector<cv::Vec2f>>). imagePoints.size() and
 * objectPoints.size(), and imagePoints[i].size() and objectPoints[i].size() for each i, must be equal,
 * respectively. In the old interface all the vectors of object points from different views are
 * concatenated together.
 * @param imageSize Size of the image used only to initialize the camera intrinsic matrix.
 * @param cameraMatrix Input/output 3x3 floating-point camera intrinsic matrix
 * `$$\cameramatrix{A}$$` . If *Ref:* CALIB_USE_INTRINSIC_GUESS
 * and/or *Ref:* CALIB_FIX_ASPECT_RATIO, *Ref:* CALIB_FIX_PRINCIPAL_POINT or *Ref:* CALIB_FIX_FOCAL_LENGTH
 * are specified, some or all of fx, fy, cx, cy must be initialized before calling the function.
 * @param distCoeffs Input/output vector of distortion coefficients
 * `$$\distcoeffs$$`.
 * @param rvecs Output vector of rotation vectors (*Ref:* Rodrigues ) estimated for each pattern view
 * (e.g. std::vector<cv::Mat>>). That is, each i-th rotation vector together with the corresponding
 * i-th translation vector (see the next output parameter description) brings the calibration pattern
 * from the object coordinate space (in which object points are specified) to the camera coordinate
 * space. In more technical terms, the tuple of the i-th rotation and translation vector performs
 * a change of basis from object coordinate space to camera coordinate space. Due to its duality, this
 * tuple is equivalent to the position of the calibration pattern with respect to the camera coordinate
 * space.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter
 * description above.
 * @param stdDeviationsIntrinsics Output vector of standard deviations estimated for intrinsic
 * parameters. Order of deviations values:
 * `$$(f_x, f_y, c_x, c_y, k_1, k_2, p_1, p_2, k_3, k_4, k_5, k_6 , s_1, s_2, s_3,
 *  s_4, \tau_x, \tau_y)$$` If one of parameters is not estimated, it's deviation is equals to zero.
 * @param stdDeviationsExtrinsics Output vector of standard deviations estimated for extrinsic
 * parameters. Order of deviations values: `$$(R_0, T_0, \dotsc , R_{M - 1}, T_{M - 1})$$` where M is
 * the number of pattern views. `$$R_i, T_i$$` are concatenated 1x3 vectors.
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * -   *Ref:* CALIB_USE_INTRINSIC_GUESS cameraMatrix contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center ( imageSize is used), and focal distances are computed in a least-squares fashion.
 * Note, that if intrinsic parameters are known, there is no need to use this function just to
 * estimate extrinsic parameters. Use *Ref:* solvePnP instead.
 * -   *Ref:* CALIB_DISABLE_SCHUR_COMPLEMENT Disable Schur complement and use the Bouguet calibration engine (*Cite:* Zhang2000, *Cite:* BouguetMCT).
 * -   *Ref:* CALIB_FIX_PRINCIPAL_POINT The principal point is not changed during the global
 * optimization. It stays at the center or at a different location specified when
 * Ref:* CALIB_USE_INTRINSIC_GUESS is set too.
 * -   *Ref:* CALIB_FIX_ASPECT_RATIO The functions consider only fy as a free parameter. The
 * ratio fx/fy stays the same as in the input cameraMatrix . When
 * Ref:* CALIB_USE_INTRINSIC_GUESS is not set, the actual input values of fx and fy are
 * ignored, only their ratio is computed and used further.
 * -   *Ref:* CALIB_ZERO_TANGENT_DIST Tangential distortion coefficients `$$(p_1, p_2)$$` are set
 * to zeros and stay zero.
 * -   *Ref:* CALIB_FIX_FOCAL_LENGTH The focal length is not changed during the global optimization if
 * Ref:* CALIB_USE_INTRINSIC_GUESS is set.
 * -   *Ref:* CALIB_FIX_K1,..., *Ref:* CALIB_FIX_K6 The corresponding radial distortion
 * coefficient is not changed during the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is
 * set, the coefficient from the supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_RATIONAL_MODEL Coefficients k4, k5, and k6 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the rational model and return 8 coefficients or more.
 * -   *Ref:* CALIB_THIN_PRISM_MODEL Coefficients s1, s2, s3 and s4 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the thin prism model and return 12 coefficients or more.
 * -   *Ref:* CALIB_FIX_S1_S2_S3_S4 The thin prism distortion coefficients are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_TILTED_MODEL Coefficients tauX and tauY are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the tilted sensor model and return 14 coefficients.
 * -   *Ref:* CALIB_FIX_TAUX_TAUY The coefficients of the tilted sensor model are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 *
 * @return the overall RMS re-projection error.
 *
 * The function estimates the intrinsic camera parameters and extrinsic parameters for each of the
 * views. By default, the optimization follows a sparse bundle adjustment formulation with Schur
 * complement; see *Cite:* Triggs2000_bundle_adjustment and *Cite:* Lourakis2009_sba for background. Use
 * Ref:* CALIB_DISABLE_SCHUR_COMPLEMENT to switch to the Bouguet calibration engine. The coordinates of 3D object
 * points and their corresponding 2D projections in each view must be specified. That may be achieved
 * by using an object with known geometry and easily detectable feature points. Such an object is
 * called a calibration rig or calibration pattern, and OpenCV has built-in support for a chessboard as
 * a calibration rig (see *Ref:* findChessboardCorners). Currently, initialization of intrinsic
 * parameters (when *Ref:* CALIB_USE_INTRINSIC_GUESS is not set) is only implemented for planar calibration
 * patterns (where Z-coordinates of the object points must be all zeros). 3D calibration rigs can also
 * be used as long as initial cameraMatrix is provided.
 *
 * The algorithm performs the following steps:
 *
 * -   Compute the initial intrinsic parameters (the option only available for planar calibration
 *     patterns) or read them from the input parameters. The distortion coefficients are all set to
 *     zeros initially unless some of CALIB_FIX_K? are specified.
 *
 * -   Estimate the initial camera pose as if the intrinsic parameters have been already known. This is
 *     done using *Ref:* solvePnP .
 *
 * -   Run the global Levenberg-Marquardt optimization algorithm to minimize the reprojection error,
 *     that is, the total sum of squared distances between the observed feature points imagePoints and
 *     the projected (using the current estimates for camera parameters and the poses) object points
 *     objectPoints. See *Ref:* projectPoints for details.
 *
 * -   In practice, robust acquisition is essential for stable results: use multiple board poses with
 *     significant tilt, avoid collecting all views at a single working distance, span the expected
 *     working-distance range (a larger board with larger squares can help for longer distances).
 *
 * Note:*
 *     If you use a non-square (i.e. non-N-by-N) grid and *Ref:* findChessboardCorners for calibration,
 *     and *Ref:* calibrateCamera returns bad values (zero distortion coefficients, `$$c_x$$` and
 *     `$$c_y$$` very far from the image center, and/or large differences between `$$f_x$$` and
 *     `$$f_y$$` (ratios of 10:1 or more)), then you are probably using patternSize=cvSize(rows,cols)
 *     instead of using patternSize=cvSize(cols,rows) in *Ref:* findChessboardCorners.
 *
 * Note:*
 *     The function may throw exceptions, if unsupported combination of parameters is provided or
 *     the system is underconstrained.
 *
 * @sa
 *    calibrateCameraRO, findChessboardCorners, solvePnP, initCameraMatrix2D, stereoCalibrate,
 *    undistort
 */
+ (double)calibrateCameraExtended:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs stdDeviationsIntrinsics:(Mat*)stdDeviationsIntrinsics stdDeviationsExtrinsics:(Mat*)stdDeviationsExtrinsics perViewErrors:(Mat*)perViewErrors NS_SWIFT_NAME(calibrateCamera(objectPoints:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:stdDeviationsIntrinsics:stdDeviationsExtrinsics:perViewErrors:));


//
//  double cv::calibrateCamera(vector_Mat objectPoints, vector_Mat imagePoints, Size imageSize, Mat& cameraMatrix, Mat& distCoeffs, vector_Mat& rvecs, vector_Mat& tvecs, int flags = 0, TermCriteria criteria = TermCriteria( TermCriteria::COUNT + TermCriteria::EPS, 500, DBL_EPSILON))
//
+ (double)calibrateCamera:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(calibrateCamera(objectPoints:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:flags:criteria:));

+ (double)calibrateCamera:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs flags:(int)flags NS_SWIFT_NAME(calibrateCamera(objectPoints:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:flags:));

+ (double)calibrateCamera:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs NS_SWIFT_NAME(calibrateCamera(objectPoints:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:));


//
//  double cv::calibrateCameraRO(vector_Mat objectPoints, vector_Mat imagePoints, Size imageSize, int iFixedPoint, Mat& cameraMatrix, Mat& distCoeffs, vector_Mat& rvecs, vector_Mat& tvecs, Mat& newObjPoints, Mat& stdDeviationsIntrinsics, Mat& stdDeviationsExtrinsics, Mat& stdDeviationsObjPoints, Mat& perViewErrors, int flags = 0, TermCriteria criteria = TermCriteria( TermCriteria::COUNT + TermCriteria::EPS, 500, DBL_EPSILON))
//
/**
 * Finds the camera intrinsic and extrinsic parameters from several views of a calibration pattern.
 *
 * This function is an extension of ``Calib/calibrateCamera`` with the method of releasing object which was
 * proposed in *Cite:* strobl2011iccv. In many common cases with inaccurate, unmeasured, roughly planar
 * targets (calibration plates), this method can dramatically improve the precision of the estimated
 * camera parameters. Both the object-releasing method and standard method are supported by this
 * function. Use the parameter **iFixedPoint** for method selection. In the internal implementation,
 * ``Calib/calibrateCamera`` is a wrapper for this function.
 *
 * @param objectPoints Vector of vectors of calibration pattern points in the calibration pattern
 * coordinate space. See ``Calib/calibrateCamera`` for details. If the method of releasing object to be used,
 * the identical calibration board must be used in each view and it must be fully visible, and all
 * objectPoints[i] must be the same and all points should be roughly close to a plane. **The calibration
 * target has to be rigid, or at least static if the camera (rather than the calibration target) is
 * shifted for grabbing images.**
 * @param imagePoints Vector of vectors of the projections of calibration pattern points. See
 * ``Calib/calibrateCamera`` for details.
 * @param imageSize Size of the image used only to initialize the intrinsic camera matrix.
 * @param iFixedPoint The index of the 3D object point in objectPoints[0] to be fixed. It also acts as
 * a switch for calibration method selection. If object-releasing method to be used, pass in the
 * parameter in the range of [1, objectPoints[0].size()-2], otherwise a value out of this range will
 * make standard calibration method selected. Usually the top-right corner point of the calibration
 * board grid is recommended to be fixed when object-releasing method being utilized. According to
 * \cite strobl2011iccv, two other points are also fixed. In this implementation, objectPoints[0].front
 * and objectPoints[0].back.z are used. With object-releasing method, accurate rvecs, tvecs and
 * newObjPoints are only possible if coordinates of these three fixed points are accurate enough.
 * @param cameraMatrix Output 3x3 floating-point camera matrix. See ``Calib/calibrateCamera`` for details.
 * @param distCoeffs Output vector of distortion coefficients. See ``Calib/calibrateCamera`` for details.
 * @param rvecs Output vector of rotation vectors estimated for each pattern view. See ``Calib/calibrateCamera``
 * for details.
 * @param tvecs Output vector of translation vectors estimated for each pattern view.
 * @param newObjPoints The updated output vector of calibration pattern points. The coordinates might
 * be scaled based on three fixed points. The returned coordinates are accurate only if the above
 * mentioned three fixed points are accurate. If not needed, noArray() can be passed in. This parameter
 * is ignored with standard calibration method.
 * @param stdDeviationsIntrinsics Output vector of standard deviations estimated for intrinsic parameters.
 * See ``Calib/calibrateCamera`` for details.
 * @param stdDeviationsExtrinsics Output vector of standard deviations estimated for extrinsic parameters.
 * See ``Calib/calibrateCamera`` for details.
 * @param stdDeviationsObjPoints Output vector of standard deviations estimated for refined coordinates
 * of calibration pattern points. It has the same size and order as objectPoints[0] vector. This
 * parameter is ignored with standard calibration method.
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of some predefined values. See
 * ``Calib/calibrateCamera`` for details. If the method of releasing object is used, the calibration time may
 * be much longer. CALIB_USE_QR or CALIB_USE_LU could be used for faster calibration with potentially
 * less precise and less stable in some rare cases.
 * @param criteria Termination criteria for the iterative optimization algorithm.
 *
 * @return the overall RMS re-projection error.
 *
 * The function estimates the intrinsic camera parameters and extrinsic parameters for each of the
 * views. The object-releasing extension follows *Cite:* strobl2011iccv and uses the same optimization
 * core as ``Calib/calibrateCamera``. See ``Calib/calibrateCamera`` for other detailed explanations.
 * @sa
 *    calibrateCamera, findChessboardCorners, solvePnP, initCameraMatrix2D, stereoCalibrate, undistort
 */
+ (double)calibrateCameraROExtended:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize iFixedPoint:(int)iFixedPoint cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs newObjPoints:(Mat*)newObjPoints stdDeviationsIntrinsics:(Mat*)stdDeviationsIntrinsics stdDeviationsExtrinsics:(Mat*)stdDeviationsExtrinsics stdDeviationsObjPoints:(Mat*)stdDeviationsObjPoints perViewErrors:(Mat*)perViewErrors flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(calibrateCameraRO(objectPoints:imagePoints:imageSize:iFixedPoint:cameraMatrix:distCoeffs:rvecs:tvecs:newObjPoints:stdDeviationsIntrinsics:stdDeviationsExtrinsics:stdDeviationsObjPoints:perViewErrors:flags:criteria:));

/**
 * Finds the camera intrinsic and extrinsic parameters from several views of a calibration pattern.
 *
 * This function is an extension of ``Calib/calibrateCamera`` with the method of releasing object which was
 * proposed in *Cite:* strobl2011iccv. In many common cases with inaccurate, unmeasured, roughly planar
 * targets (calibration plates), this method can dramatically improve the precision of the estimated
 * camera parameters. Both the object-releasing method and standard method are supported by this
 * function. Use the parameter **iFixedPoint** for method selection. In the internal implementation,
 * ``Calib/calibrateCamera`` is a wrapper for this function.
 *
 * @param objectPoints Vector of vectors of calibration pattern points in the calibration pattern
 * coordinate space. See ``Calib/calibrateCamera`` for details. If the method of releasing object to be used,
 * the identical calibration board must be used in each view and it must be fully visible, and all
 * objectPoints[i] must be the same and all points should be roughly close to a plane. **The calibration
 * target has to be rigid, or at least static if the camera (rather than the calibration target) is
 * shifted for grabbing images.**
 * @param imagePoints Vector of vectors of the projections of calibration pattern points. See
 * ``Calib/calibrateCamera`` for details.
 * @param imageSize Size of the image used only to initialize the intrinsic camera matrix.
 * @param iFixedPoint The index of the 3D object point in objectPoints[0] to be fixed. It also acts as
 * a switch for calibration method selection. If object-releasing method to be used, pass in the
 * parameter in the range of [1, objectPoints[0].size()-2], otherwise a value out of this range will
 * make standard calibration method selected. Usually the top-right corner point of the calibration
 * board grid is recommended to be fixed when object-releasing method being utilized. According to
 * \cite strobl2011iccv, two other points are also fixed. In this implementation, objectPoints[0].front
 * and objectPoints[0].back.z are used. With object-releasing method, accurate rvecs, tvecs and
 * newObjPoints are only possible if coordinates of these three fixed points are accurate enough.
 * @param cameraMatrix Output 3x3 floating-point camera matrix. See ``Calib/calibrateCamera`` for details.
 * @param distCoeffs Output vector of distortion coefficients. See ``Calib/calibrateCamera`` for details.
 * @param rvecs Output vector of rotation vectors estimated for each pattern view. See ``Calib/calibrateCamera``
 * for details.
 * @param tvecs Output vector of translation vectors estimated for each pattern view.
 * @param newObjPoints The updated output vector of calibration pattern points. The coordinates might
 * be scaled based on three fixed points. The returned coordinates are accurate only if the above
 * mentioned three fixed points are accurate. If not needed, noArray() can be passed in. This parameter
 * is ignored with standard calibration method.
 * @param stdDeviationsIntrinsics Output vector of standard deviations estimated for intrinsic parameters.
 * See ``Calib/calibrateCamera`` for details.
 * @param stdDeviationsExtrinsics Output vector of standard deviations estimated for extrinsic parameters.
 * See ``Calib/calibrateCamera`` for details.
 * @param stdDeviationsObjPoints Output vector of standard deviations estimated for refined coordinates
 * of calibration pattern points. It has the same size and order as objectPoints[0] vector. This
 * parameter is ignored with standard calibration method.
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of some predefined values. See
 * ``Calib/calibrateCamera`` for details. If the method of releasing object is used, the calibration time may
 * be much longer. CALIB_USE_QR or CALIB_USE_LU could be used for faster calibration with potentially
 * less precise and less stable in some rare cases.
 *
 * @return the overall RMS re-projection error.
 *
 * The function estimates the intrinsic camera parameters and extrinsic parameters for each of the
 * views. The object-releasing extension follows *Cite:* strobl2011iccv and uses the same optimization
 * core as ``Calib/calibrateCamera``. See ``Calib/calibrateCamera`` for other detailed explanations.
 * @sa
 *    calibrateCamera, findChessboardCorners, solvePnP, initCameraMatrix2D, stereoCalibrate, undistort
 */
+ (double)calibrateCameraROExtended:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize iFixedPoint:(int)iFixedPoint cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs newObjPoints:(Mat*)newObjPoints stdDeviationsIntrinsics:(Mat*)stdDeviationsIntrinsics stdDeviationsExtrinsics:(Mat*)stdDeviationsExtrinsics stdDeviationsObjPoints:(Mat*)stdDeviationsObjPoints perViewErrors:(Mat*)perViewErrors flags:(int)flags NS_SWIFT_NAME(calibrateCameraRO(objectPoints:imagePoints:imageSize:iFixedPoint:cameraMatrix:distCoeffs:rvecs:tvecs:newObjPoints:stdDeviationsIntrinsics:stdDeviationsExtrinsics:stdDeviationsObjPoints:perViewErrors:flags:));

/**
 * Finds the camera intrinsic and extrinsic parameters from several views of a calibration pattern.
 *
 * This function is an extension of ``Calib/calibrateCamera`` with the method of releasing object which was
 * proposed in *Cite:* strobl2011iccv. In many common cases with inaccurate, unmeasured, roughly planar
 * targets (calibration plates), this method can dramatically improve the precision of the estimated
 * camera parameters. Both the object-releasing method and standard method are supported by this
 * function. Use the parameter **iFixedPoint** for method selection. In the internal implementation,
 * ``Calib/calibrateCamera`` is a wrapper for this function.
 *
 * @param objectPoints Vector of vectors of calibration pattern points in the calibration pattern
 * coordinate space. See ``Calib/calibrateCamera`` for details. If the method of releasing object to be used,
 * the identical calibration board must be used in each view and it must be fully visible, and all
 * objectPoints[i] must be the same and all points should be roughly close to a plane. **The calibration
 * target has to be rigid, or at least static if the camera (rather than the calibration target) is
 * shifted for grabbing images.**
 * @param imagePoints Vector of vectors of the projections of calibration pattern points. See
 * ``Calib/calibrateCamera`` for details.
 * @param imageSize Size of the image used only to initialize the intrinsic camera matrix.
 * @param iFixedPoint The index of the 3D object point in objectPoints[0] to be fixed. It also acts as
 * a switch for calibration method selection. If object-releasing method to be used, pass in the
 * parameter in the range of [1, objectPoints[0].size()-2], otherwise a value out of this range will
 * make standard calibration method selected. Usually the top-right corner point of the calibration
 * board grid is recommended to be fixed when object-releasing method being utilized. According to
 * \cite strobl2011iccv, two other points are also fixed. In this implementation, objectPoints[0].front
 * and objectPoints[0].back.z are used. With object-releasing method, accurate rvecs, tvecs and
 * newObjPoints are only possible if coordinates of these three fixed points are accurate enough.
 * @param cameraMatrix Output 3x3 floating-point camera matrix. See ``Calib/calibrateCamera`` for details.
 * @param distCoeffs Output vector of distortion coefficients. See ``Calib/calibrateCamera`` for details.
 * @param rvecs Output vector of rotation vectors estimated for each pattern view. See ``Calib/calibrateCamera``
 * for details.
 * @param tvecs Output vector of translation vectors estimated for each pattern view.
 * @param newObjPoints The updated output vector of calibration pattern points. The coordinates might
 * be scaled based on three fixed points. The returned coordinates are accurate only if the above
 * mentioned three fixed points are accurate. If not needed, noArray() can be passed in. This parameter
 * is ignored with standard calibration method.
 * @param stdDeviationsIntrinsics Output vector of standard deviations estimated for intrinsic parameters.
 * See ``Calib/calibrateCamera`` for details.
 * @param stdDeviationsExtrinsics Output vector of standard deviations estimated for extrinsic parameters.
 * See ``Calib/calibrateCamera`` for details.
 * @param stdDeviationsObjPoints Output vector of standard deviations estimated for refined coordinates
 * of calibration pattern points. It has the same size and order as objectPoints[0] vector. This
 * parameter is ignored with standard calibration method.
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * ``Calib/calibrateCamera`` for details. If the method of releasing object is used, the calibration time may
 * be much longer. CALIB_USE_QR or CALIB_USE_LU could be used for faster calibration with potentially
 * less precise and less stable in some rare cases.
 *
 * @return the overall RMS re-projection error.
 *
 * The function estimates the intrinsic camera parameters and extrinsic parameters for each of the
 * views. The object-releasing extension follows *Cite:* strobl2011iccv and uses the same optimization
 * core as ``Calib/calibrateCamera``. See ``Calib/calibrateCamera`` for other detailed explanations.
 * @sa
 *    calibrateCamera, findChessboardCorners, solvePnP, initCameraMatrix2D, stereoCalibrate, undistort
 */
+ (double)calibrateCameraROExtended:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize iFixedPoint:(int)iFixedPoint cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs newObjPoints:(Mat*)newObjPoints stdDeviationsIntrinsics:(Mat*)stdDeviationsIntrinsics stdDeviationsExtrinsics:(Mat*)stdDeviationsExtrinsics stdDeviationsObjPoints:(Mat*)stdDeviationsObjPoints perViewErrors:(Mat*)perViewErrors NS_SWIFT_NAME(calibrateCameraRO(objectPoints:imagePoints:imageSize:iFixedPoint:cameraMatrix:distCoeffs:rvecs:tvecs:newObjPoints:stdDeviationsIntrinsics:stdDeviationsExtrinsics:stdDeviationsObjPoints:perViewErrors:));


//
//  double cv::calibrateCameraRO(vector_Mat objectPoints, vector_Mat imagePoints, Size imageSize, int iFixedPoint, Mat& cameraMatrix, Mat& distCoeffs, vector_Mat& rvecs, vector_Mat& tvecs, Mat& newObjPoints, int flags = 0, TermCriteria criteria = TermCriteria( TermCriteria::COUNT + TermCriteria::EPS, 500, DBL_EPSILON))
//
+ (double)calibrateCameraRO:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize iFixedPoint:(int)iFixedPoint cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs newObjPoints:(Mat*)newObjPoints flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(calibrateCameraRO(objectPoints:imagePoints:imageSize:iFixedPoint:cameraMatrix:distCoeffs:rvecs:tvecs:newObjPoints:flags:criteria:));

+ (double)calibrateCameraRO:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize iFixedPoint:(int)iFixedPoint cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs newObjPoints:(Mat*)newObjPoints flags:(int)flags NS_SWIFT_NAME(calibrateCameraRO(objectPoints:imagePoints:imageSize:iFixedPoint:cameraMatrix:distCoeffs:rvecs:tvecs:newObjPoints:flags:));

+ (double)calibrateCameraRO:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints imageSize:(Size2i*)imageSize iFixedPoint:(int)iFixedPoint cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs newObjPoints:(Mat*)newObjPoints NS_SWIFT_NAME(calibrateCameraRO(objectPoints:imagePoints:imageSize:iFixedPoint:cameraMatrix:distCoeffs:rvecs:tvecs:newObjPoints:));


//
//  double cv::stereoCalibrate(vector_Mat objectPoints, vector_Mat imagePoints1, vector_Mat imagePoints2, Mat& cameraMatrix1, Mat& distCoeffs1, Mat& cameraMatrix2, Mat& distCoeffs2, Size imageSize, Mat& R, Mat& T, Mat& E, Mat& F, vector_Mat& rvecs, vector_Mat& tvecs, Mat& perViewErrors, int flags = CALIB_FIX_INTRINSIC, TermCriteria criteria = TermCriteria(TermCriteria::COUNT+TermCriteria::EPS, 100, 1e-6))
//
/**
 * Calibrates a stereo camera set up. This function finds the intrinsic parameters
 * for each of the two cameras and the extrinsic parameters between the two cameras.
 *
 * @param objectPoints Vector of vectors of the calibration pattern points. The same structure as
 * in *Ref:* calibrateCamera. For each pattern view, both cameras need to see the same object
 * points. Therefore, objectPoints.size(), imagePoints1.size(), and imagePoints2.size() need to be
 * equal as well as objectPoints[i].size(), imagePoints1[i].size(), and imagePoints2[i].size() need to
 * be equal for each i.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera. The same structure as in *Ref:* calibrateCamera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera. The same structure as in *Ref:* calibrateCamera.
 * @param cameraMatrix1 Input/output camera intrinsic matrix for the first camera, the same as in
 * Ref:* calibrateCamera. Furthermore, for the stereo case, additional flags may be used, see below.
 * @param distCoeffs1 Input/output vector of distortion coefficients, the same as in
 * Ref:* calibrateCamera.
 * @param cameraMatrix2 Input/output second camera intrinsic matrix for the second camera. See description for
 * cameraMatrix1.
 * @param distCoeffs2 Input/output lens distortion coefficients for the second camera. See
 * description for distCoeffs1.
 * @param imageSize Size of the image used only to initialize the camera intrinsic matrices.
 * @param R Output rotation matrix. Together with the translation vector T, this matrix brings
 * points given in the first camera's coordinate system to points in the second camera's
 * coordinate system. In more technical terms, the tuple of R and T performs a change of basis
 * from the first camera's coordinate system to the second camera's coordinate system. Due to its
 * duality, this tuple is equivalent to the position of the first camera with respect to the
 * second camera coordinate system.
 * @param T Output translation vector, see description above.
 * @param E Output essential matrix.
 * @param F Output fundamental matrix.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* CALIB_FIX_INTRINSIC Fix cameraMatrix? and distCoeffs? so that only R, T, E, and F
 * matrices are estimated.
 * -   *Ref:* CALIB_USE_INTRINSIC_GUESS Optimize some or all of the intrinsic parameters
 * according to the specified flags. Initial values are provided by the user.
 * -   *Ref:* CALIB_USE_EXTRINSIC_GUESS R and T contain valid initial values that are optimized further.
 * Otherwise R and T are initialized to the median value of the pattern views (each dimension separately).
 * -   *Ref:* CALIB_FIX_PRINCIPAL_POINT Fix the principal points during the optimization.
 * -   *Ref:* CALIB_FIX_FOCAL_LENGTH Fix `$$f^{(j)}_x$$` and `$$f^{(j)}_y$$` .
 * -   *Ref:* CALIB_FIX_ASPECT_RATIO Optimize `$$f^{(j)}_y$$` . Fix the ratio `$$f^{(j)}_x/f^{(j)}_y$$`
 * .
 * -   *Ref:* CALIB_SAME_FOCAL_LENGTH Enforce `$$f^{(0)}_x=f^{(1)}_x$$` and `$$f^{(0)}_y=f^{(1)}_y$$` .
 * -   *Ref:* CALIB_ZERO_TANGENT_DIST Set tangential distortion coefficients for each camera to
 * zeros and fix there.
 * -   *Ref:* CALIB_FIX_K1,..., *Ref:* CALIB_FIX_K6 Do not change the corresponding radial
 * distortion coefficient during the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set,
 * the coefficient from the supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_RATIONAL_MODEL Enable coefficients k4, k5, and k6. To provide the backward
 * compatibility, this extra flag should be explicitly specified to make the calibration
 * function use the rational model and return 8 coefficients. If the flag is not set, the
 * function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_THIN_PRISM_MODEL Coefficients s1, s2, s3 and s4 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the thin prism model and return 12 coefficients. If the flag is not
 * set, the function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_FIX_S1_S2_S3_S4 The thin prism distortion coefficients are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_TILTED_MODEL Coefficients tauX and tauY are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the tilted sensor model and return 14 coefficients. If the flag is not
 * set, the function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_FIX_TAUX_TAUY The coefficients of the tilted sensor model are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * @param criteria Termination criteria for the iterative optimization algorithm.
 *
 * The function estimates the transformation between two cameras making a stereo pair. If one computes
 * the poses of an object relative to the first camera and to the second camera,
 * ( `$$R_1$$`,`$$T_1$$` ) and (`$$R_2$$`,`$$T_2$$`), respectively, for a stereo camera where the
 * relative position and orientation between the two cameras are fixed, then those poses definitely
 * relate to each other. This means, if the relative position and orientation (`$$R$$`,`$$T$$`) of the
 * two cameras is known, it is possible to compute (`$$R_2$$`,`$$T_2$$`) when (`$$R_1$$`,`$$T_1$$`) is
 * given. This is what the described function does. It computes (`$$R$$`,`$$T$$`) such that:
 *
 * `$$R_2=R R_1$$`
 * `$$T_2=R T_1 + T.$$`
 *
 * Therefore, one can compute the coordinate representation of a 3D point for the second camera's
 * coordinate system when given the point's coordinate representation in the first camera's coordinate
 * system:
 *
 * `$$\begin{bmatrix}
 * X_2 \\
 * Y_2 \\
 * Z_2 \\
 * 1
 * \end{bmatrix} = \begin{bmatrix}
 * R & T \\
 * 0 & 1
 * \end{bmatrix} \begin{bmatrix}
 * X_1 \\
 * Y_1 \\
 * Z_1 \\
 * 1
 * \end{bmatrix}.$$`
 *
 *
 * Optionally, it computes the essential matrix E:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } E= \vecthreethree{0}{-T_2}{T_1}{T_2}{0}{-T_0}{-T_1}{T_0}{0} R$$`
 *
 * where `$$T_i$$` are components of the translation vector `$$T$$` : `$$T=[T_0, T_1, T_2]^T$$` .
 * And the function can also compute the fundamental matrix F:
 *
 * `$$F = cameraMatrix2^{-T}\cdot E \cdot cameraMatrix1^{-1}$$`
 *
 * Besides the stereo-related information, the function can also perform a full calibration of each of
 * the two cameras. However, due to the high dimensionality of the parameter space and noise in the
 * input data, the function can diverge from the correct solution. If the intrinsic parameters can be
 * estimated with high accuracy for each of the cameras individually (for example, using
 * ``Calib/calibrateCamera`` ), you are recommended to do so and then pass *Ref:* CALIB_FIX_INTRINSIC flag to the
 * function along with the computed intrinsic parameters. Otherwise, if all the parameters are
 * estimated at once, it makes sense to restrict some parameters, for example, pass
 * Ref:* CALIB_SAME_FOCAL_LENGTH and *Ref:* CALIB_ZERO_TANGENT_DIST flags, which is usually a
 * reasonable assumption.
 *
 * Similarly to ``Calib/calibrateCamera``, the function minimizes the total re-projection error for all the
 * points in all the available views from both cameras. The function returns the final value of the
 * re-projection error.
 */
+ (double)stereoCalibrateExtended:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs perViewErrors:(Mat*)perViewErrors flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:rvecs:tvecs:perViewErrors:flags:criteria:));

/**
 * Calibrates a stereo camera set up. This function finds the intrinsic parameters
 * for each of the two cameras and the extrinsic parameters between the two cameras.
 *
 * @param objectPoints Vector of vectors of the calibration pattern points. The same structure as
 * in *Ref:* calibrateCamera. For each pattern view, both cameras need to see the same object
 * points. Therefore, objectPoints.size(), imagePoints1.size(), and imagePoints2.size() need to be
 * equal as well as objectPoints[i].size(), imagePoints1[i].size(), and imagePoints2[i].size() need to
 * be equal for each i.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera. The same structure as in *Ref:* calibrateCamera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera. The same structure as in *Ref:* calibrateCamera.
 * @param cameraMatrix1 Input/output camera intrinsic matrix for the first camera, the same as in
 * Ref:* calibrateCamera. Furthermore, for the stereo case, additional flags may be used, see below.
 * @param distCoeffs1 Input/output vector of distortion coefficients, the same as in
 * Ref:* calibrateCamera.
 * @param cameraMatrix2 Input/output second camera intrinsic matrix for the second camera. See description for
 * cameraMatrix1.
 * @param distCoeffs2 Input/output lens distortion coefficients for the second camera. See
 * description for distCoeffs1.
 * @param imageSize Size of the image used only to initialize the camera intrinsic matrices.
 * @param R Output rotation matrix. Together with the translation vector T, this matrix brings
 * points given in the first camera's coordinate system to points in the second camera's
 * coordinate system. In more technical terms, the tuple of R and T performs a change of basis
 * from the first camera's coordinate system to the second camera's coordinate system. Due to its
 * duality, this tuple is equivalent to the position of the first camera with respect to the
 * second camera coordinate system.
 * @param T Output translation vector, see description above.
 * @param E Output essential matrix.
 * @param F Output fundamental matrix.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* CALIB_FIX_INTRINSIC Fix cameraMatrix? and distCoeffs? so that only R, T, E, and F
 * matrices are estimated.
 * -   *Ref:* CALIB_USE_INTRINSIC_GUESS Optimize some or all of the intrinsic parameters
 * according to the specified flags. Initial values are provided by the user.
 * -   *Ref:* CALIB_USE_EXTRINSIC_GUESS R and T contain valid initial values that are optimized further.
 * Otherwise R and T are initialized to the median value of the pattern views (each dimension separately).
 * -   *Ref:* CALIB_FIX_PRINCIPAL_POINT Fix the principal points during the optimization.
 * -   *Ref:* CALIB_FIX_FOCAL_LENGTH Fix `$$f^{(j)}_x$$` and `$$f^{(j)}_y$$` .
 * -   *Ref:* CALIB_FIX_ASPECT_RATIO Optimize `$$f^{(j)}_y$$` . Fix the ratio `$$f^{(j)}_x/f^{(j)}_y$$`
 * .
 * -   *Ref:* CALIB_SAME_FOCAL_LENGTH Enforce `$$f^{(0)}_x=f^{(1)}_x$$` and `$$f^{(0)}_y=f^{(1)}_y$$` .
 * -   *Ref:* CALIB_ZERO_TANGENT_DIST Set tangential distortion coefficients for each camera to
 * zeros and fix there.
 * -   *Ref:* CALIB_FIX_K1,..., *Ref:* CALIB_FIX_K6 Do not change the corresponding radial
 * distortion coefficient during the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set,
 * the coefficient from the supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_RATIONAL_MODEL Enable coefficients k4, k5, and k6. To provide the backward
 * compatibility, this extra flag should be explicitly specified to make the calibration
 * function use the rational model and return 8 coefficients. If the flag is not set, the
 * function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_THIN_PRISM_MODEL Coefficients s1, s2, s3 and s4 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the thin prism model and return 12 coefficients. If the flag is not
 * set, the function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_FIX_S1_S2_S3_S4 The thin prism distortion coefficients are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_TILTED_MODEL Coefficients tauX and tauY are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the tilted sensor model and return 14 coefficients. If the flag is not
 * set, the function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_FIX_TAUX_TAUY The coefficients of the tilted sensor model are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 *
 * The function estimates the transformation between two cameras making a stereo pair. If one computes
 * the poses of an object relative to the first camera and to the second camera,
 * ( `$$R_1$$`,`$$T_1$$` ) and (`$$R_2$$`,`$$T_2$$`), respectively, for a stereo camera where the
 * relative position and orientation between the two cameras are fixed, then those poses definitely
 * relate to each other. This means, if the relative position and orientation (`$$R$$`,`$$T$$`) of the
 * two cameras is known, it is possible to compute (`$$R_2$$`,`$$T_2$$`) when (`$$R_1$$`,`$$T_1$$`) is
 * given. This is what the described function does. It computes (`$$R$$`,`$$T$$`) such that:
 *
 * `$$R_2=R R_1$$`
 * `$$T_2=R T_1 + T.$$`
 *
 * Therefore, one can compute the coordinate representation of a 3D point for the second camera's
 * coordinate system when given the point's coordinate representation in the first camera's coordinate
 * system:
 *
 * `$$\begin{bmatrix}
 * X_2 \\
 * Y_2 \\
 * Z_2 \\
 * 1
 * \end{bmatrix} = \begin{bmatrix}
 * R & T \\
 * 0 & 1
 * \end{bmatrix} \begin{bmatrix}
 * X_1 \\
 * Y_1 \\
 * Z_1 \\
 * 1
 * \end{bmatrix}.$$`
 *
 *
 * Optionally, it computes the essential matrix E:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } E= \vecthreethree{0}{-T_2}{T_1}{T_2}{0}{-T_0}{-T_1}{T_0}{0} R$$`
 *
 * where `$$T_i$$` are components of the translation vector `$$T$$` : `$$T=[T_0, T_1, T_2]^T$$` .
 * And the function can also compute the fundamental matrix F:
 *
 * `$$F = cameraMatrix2^{-T}\cdot E \cdot cameraMatrix1^{-1}$$`
 *
 * Besides the stereo-related information, the function can also perform a full calibration of each of
 * the two cameras. However, due to the high dimensionality of the parameter space and noise in the
 * input data, the function can diverge from the correct solution. If the intrinsic parameters can be
 * estimated with high accuracy for each of the cameras individually (for example, using
 * ``Calib/calibrateCamera`` ), you are recommended to do so and then pass *Ref:* CALIB_FIX_INTRINSIC flag to the
 * function along with the computed intrinsic parameters. Otherwise, if all the parameters are
 * estimated at once, it makes sense to restrict some parameters, for example, pass
 * Ref:* CALIB_SAME_FOCAL_LENGTH and *Ref:* CALIB_ZERO_TANGENT_DIST flags, which is usually a
 * reasonable assumption.
 *
 * Similarly to ``Calib/calibrateCamera``, the function minimizes the total re-projection error for all the
 * points in all the available views from both cameras. The function returns the final value of the
 * re-projection error.
 */
+ (double)stereoCalibrateExtended:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs perViewErrors:(Mat*)perViewErrors flags:(int)flags NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:rvecs:tvecs:perViewErrors:flags:));

/**
 * Calibrates a stereo camera set up. This function finds the intrinsic parameters
 * for each of the two cameras and the extrinsic parameters between the two cameras.
 *
 * @param objectPoints Vector of vectors of the calibration pattern points. The same structure as
 * in *Ref:* calibrateCamera. For each pattern view, both cameras need to see the same object
 * points. Therefore, objectPoints.size(), imagePoints1.size(), and imagePoints2.size() need to be
 * equal as well as objectPoints[i].size(), imagePoints1[i].size(), and imagePoints2[i].size() need to
 * be equal for each i.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera. The same structure as in *Ref:* calibrateCamera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera. The same structure as in *Ref:* calibrateCamera.
 * @param cameraMatrix1 Input/output camera intrinsic matrix for the first camera, the same as in
 * Ref:* calibrateCamera. Furthermore, for the stereo case, additional flags may be used, see below.
 * @param distCoeffs1 Input/output vector of distortion coefficients, the same as in
 * Ref:* calibrateCamera.
 * @param cameraMatrix2 Input/output second camera intrinsic matrix for the second camera. See description for
 * cameraMatrix1.
 * @param distCoeffs2 Input/output lens distortion coefficients for the second camera. See
 * description for distCoeffs1.
 * @param imageSize Size of the image used only to initialize the camera intrinsic matrices.
 * @param R Output rotation matrix. Together with the translation vector T, this matrix brings
 * points given in the first camera's coordinate system to points in the second camera's
 * coordinate system. In more technical terms, the tuple of R and T performs a change of basis
 * from the first camera's coordinate system to the second camera's coordinate system. Due to its
 * duality, this tuple is equivalent to the position of the first camera with respect to the
 * second camera coordinate system.
 * @param T Output translation vector, see description above.
 * @param E Output essential matrix.
 * @param F Output fundamental matrix.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * -   *Ref:* CALIB_FIX_INTRINSIC Fix cameraMatrix? and distCoeffs? so that only R, T, E, and F
 * matrices are estimated.
 * -   *Ref:* CALIB_USE_INTRINSIC_GUESS Optimize some or all of the intrinsic parameters
 * according to the specified flags. Initial values are provided by the user.
 * -   *Ref:* CALIB_USE_EXTRINSIC_GUESS R and T contain valid initial values that are optimized further.
 * Otherwise R and T are initialized to the median value of the pattern views (each dimension separately).
 * -   *Ref:* CALIB_FIX_PRINCIPAL_POINT Fix the principal points during the optimization.
 * -   *Ref:* CALIB_FIX_FOCAL_LENGTH Fix `$$f^{(j)}_x$$` and `$$f^{(j)}_y$$` .
 * -   *Ref:* CALIB_FIX_ASPECT_RATIO Optimize `$$f^{(j)}_y$$` . Fix the ratio `$$f^{(j)}_x/f^{(j)}_y$$`
 * .
 * -   *Ref:* CALIB_SAME_FOCAL_LENGTH Enforce `$$f^{(0)}_x=f^{(1)}_x$$` and `$$f^{(0)}_y=f^{(1)}_y$$` .
 * -   *Ref:* CALIB_ZERO_TANGENT_DIST Set tangential distortion coefficients for each camera to
 * zeros and fix there.
 * -   *Ref:* CALIB_FIX_K1,..., *Ref:* CALIB_FIX_K6 Do not change the corresponding radial
 * distortion coefficient during the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set,
 * the coefficient from the supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_RATIONAL_MODEL Enable coefficients k4, k5, and k6. To provide the backward
 * compatibility, this extra flag should be explicitly specified to make the calibration
 * function use the rational model and return 8 coefficients. If the flag is not set, the
 * function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_THIN_PRISM_MODEL Coefficients s1, s2, s3 and s4 are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the thin prism model and return 12 coefficients. If the flag is not
 * set, the function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_FIX_S1_S2_S3_S4 The thin prism distortion coefficients are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 * -   *Ref:* CALIB_TILTED_MODEL Coefficients tauX and tauY are enabled. To provide the
 * backward compatibility, this extra flag should be explicitly specified to make the
 * calibration function use the tilted sensor model and return 14 coefficients. If the flag is not
 * set, the function computes and returns only 5 distortion coefficients.
 * -   *Ref:* CALIB_FIX_TAUX_TAUY The coefficients of the tilted sensor model are not changed during
 * the optimization. If *Ref:* CALIB_USE_INTRINSIC_GUESS is set, the coefficient from the
 * supplied distCoeffs matrix is used. Otherwise, it is set to 0.
 *
 * The function estimates the transformation between two cameras making a stereo pair. If one computes
 * the poses of an object relative to the first camera and to the second camera,
 * ( `$$R_1$$`,`$$T_1$$` ) and (`$$R_2$$`,`$$T_2$$`), respectively, for a stereo camera where the
 * relative position and orientation between the two cameras are fixed, then those poses definitely
 * relate to each other. This means, if the relative position and orientation (`$$R$$`,`$$T$$`) of the
 * two cameras is known, it is possible to compute (`$$R_2$$`,`$$T_2$$`) when (`$$R_1$$`,`$$T_1$$`) is
 * given. This is what the described function does. It computes (`$$R$$`,`$$T$$`) such that:
 *
 * `$$R_2=R R_1$$`
 * `$$T_2=R T_1 + T.$$`
 *
 * Therefore, one can compute the coordinate representation of a 3D point for the second camera's
 * coordinate system when given the point's coordinate representation in the first camera's coordinate
 * system:
 *
 * `$$\begin{bmatrix}
 * X_2 \\
 * Y_2 \\
 * Z_2 \\
 * 1
 * \end{bmatrix} = \begin{bmatrix}
 * R & T \\
 * 0 & 1
 * \end{bmatrix} \begin{bmatrix}
 * X_1 \\
 * Y_1 \\
 * Z_1 \\
 * 1
 * \end{bmatrix}.$$`
 *
 *
 * Optionally, it computes the essential matrix E:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } E= \vecthreethree{0}{-T_2}{T_1}{T_2}{0}{-T_0}{-T_1}{T_0}{0} R$$`
 *
 * where `$$T_i$$` are components of the translation vector `$$T$$` : `$$T=[T_0, T_1, T_2]^T$$` .
 * And the function can also compute the fundamental matrix F:
 *
 * `$$F = cameraMatrix2^{-T}\cdot E \cdot cameraMatrix1^{-1}$$`
 *
 * Besides the stereo-related information, the function can also perform a full calibration of each of
 * the two cameras. However, due to the high dimensionality of the parameter space and noise in the
 * input data, the function can diverge from the correct solution. If the intrinsic parameters can be
 * estimated with high accuracy for each of the cameras individually (for example, using
 * ``Calib/calibrateCamera`` ), you are recommended to do so and then pass *Ref:* CALIB_FIX_INTRINSIC flag to the
 * function along with the computed intrinsic parameters. Otherwise, if all the parameters are
 * estimated at once, it makes sense to restrict some parameters, for example, pass
 * Ref:* CALIB_SAME_FOCAL_LENGTH and *Ref:* CALIB_ZERO_TANGENT_DIST flags, which is usually a
 * reasonable assumption.
 *
 * Similarly to ``Calib/calibrateCamera``, the function minimizes the total re-projection error for all the
 * points in all the available views from both cameras. The function returns the final value of the
 * re-projection error.
 */
+ (double)stereoCalibrateExtended:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs perViewErrors:(Mat*)perViewErrors NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:rvecs:tvecs:perViewErrors:));


//
//  double cv::stereoCalibrate(vector_Mat objectPoints, vector_Mat imagePoints1, vector_Mat imagePoints2, Mat& cameraMatrix1, Mat& distCoeffs1, Mat& cameraMatrix2, Mat& distCoeffs2, Size imageSize, Mat& R, Mat& T, Mat& E, Mat& F, int flags = CALIB_FIX_INTRINSIC, TermCriteria criteria = TermCriteria(TermCriteria::COUNT+TermCriteria::EPS, 100, 1e-6))
//
+ (double)stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:flags:criteria:));

+ (double)stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F flags:(int)flags NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:flags:));

+ (double)stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:));


//
//  double cv::stereoCalibrate(vector_Mat objectPoints, vector_Mat imagePoints1, vector_Mat imagePoints2, Mat& cameraMatrix1, Mat& distCoeffs1, Mat& cameraMatrix2, Mat& distCoeffs2, Size imageSize, Mat& R, Mat& T, Mat& E, Mat& F, Mat& perViewErrors, int flags = CALIB_FIX_INTRINSIC, TermCriteria criteria = TermCriteria(TermCriteria::COUNT+TermCriteria::EPS, 30, 1e-6))
//
+ (double)stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F perViewErrors:(Mat*)perViewErrors flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:perViewErrors:flags:criteria:));

+ (double)stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F perViewErrors:(Mat*)perViewErrors flags:(int)flags NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:perViewErrors:flags:));

+ (double)stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F perViewErrors:(Mat*)perViewErrors NS_SWIFT_NAME(stereoCalibrate(objectPoints:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:perViewErrors:));


//
//  double cv::registerCameras(vector_Mat objectPoints1, vector_Mat objectPoints2, vector_Mat imagePoints1, vector_Mat imagePoints2, Mat cameraMatrix1, Mat distCoeffs1, CameraModel cameraModel1, Mat cameraMatrix2, Mat distCoeffs2, CameraModel cameraModel2, Mat& R, Mat& T, Mat& E, Mat& F, vector_Mat& rvecs, vector_Mat& tvecs, Mat& perViewErrors, int flags = 0, TermCriteria criteria = TermCriteria(TermCriteria::COUNT+TermCriteria::EPS, 100, 1e-6))
//
/**
 * Calibrates a camera pair set up. This function finds the extrinsic parameters between the two cameras.
 *
 * @param objectPoints1 Vector of vectors of the calibration pattern points for camera 1.
 * A similar structure as objectPoints in *Ref:* calibrateCamera and for each pattern view,
 * both cameras do not need to see the same object points. objectPoints1.size(), imagePoints1.size()
 * nees to be equal,as well as objectPoints1[i].size(), imagePoints1[i].size() need to be equal for each i.
 * @param objectPoints2 Vector of vectors of the calibration pattern points for camera 2.
 * A similar structure as objectPoints1. objectPoints2.size(), and imagePoints2.size() nees to be equal,
 * as well as objectPoints2[i].size(), imagePoints2[i].size() need to be equal for each i.
 * However, objectPoints1[i].size() and objectPoints2[i].size() are not required to be equal.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera. The same structure as in *Ref:* calibrateCamera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera. The same structure as in *Ref:* calibrateCamera.
 * @param cameraMatrix1 Input/output camera intrinsic matrix for the first camera, the same as in
 * Ref:* calibrateCamera. Furthermore, for the stereo case, additional flags may be used, see below.
 * @param distCoeffs1 Input/output vector of distortion coefficients, the same as in
 * Ref:* calibrateCamera.
 * @param cameraModel1 Flag reflecting the type of model for camera 1 (pinhole / fisheye):
 * - *Ref:* CALIB_MODEL_PINHOLE pinhole camera model
 * - *Ref:* CALIB_MODEL_FISHEYE fisheye camera model
 * @param cameraMatrix2 Input/output second camera intrinsic matrix for the second camera.
 * See description for cameraMatrix1.
 * @param distCoeffs2 Input/output lens distortion coefficients for the second camera. See
 * description for distCoeffs1.
 * @param cameraModel2 Flag reflecting the type of model for camera 2 (pinhole / fisheye).
 * See description for cameraModel1.
 * @param R Output rotation matrix. Together with the translation vector T, this matrix brings
 * points given in the first camera's coordinate system to points in the second camera's
 * coordinate system. In more technical terms, the tuple of R and T performs a change of basis
 * from the first camera's coordinate system to the second camera's coordinate system. Due to its
 * duality, this tuple is equivalent to the position of the first camera with respect to the
 * second camera coordinate system.
 * @param T Output translation vector, see description above.
 * @param E Output essential matrix.
 * @param F Output fundamental matrix.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to the camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* CALIB_USE_EXTRINSIC_GUESS R and T contain valid initial values that are optimized further.
 * @param criteria Termination criteria for the iterative optimization algorithm.
 *
 * The function estimates the transformation between two cameras similar to stereo pair calibration.
 * The principle follows closely to *Ref:* stereoCalibrate. To understand the problem of estimating the
 * relative pose between a camera pair, please refer to the description there. The difference for
 * this function is that, camera intrinsics are not optimized and two cameras are not required
 * to have overlapping fields of view as long as they are observing the same calibration target
 * and the absolute positions of each object point are known.
 * ![](register_pair)
 * The above illustration shows an example where such a case may become relevant.
 * Additionally, it supports a camera pair with the mixed model (pinhole / fisheye).
 * Similarly to ``Calib/calibrateCamera``, the function minimizes the total re-projection error for all the
 * points in all the available views from both cameras.
 * @return the final value of the re-projection error.
 *
 * - SeeAlso ``calibrateCamera:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:flags:criteria:``, ``stereoCalibrate:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:flags:criteria:``
 */
+ (double)registerCamerasExtended:(NSArray<Mat*>*)objectPoints1 objectPoints2:(NSArray<Mat*>*)objectPoints2 imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraModel1:(CameraModel)cameraModel1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 cameraModel2:(CameraModel)cameraModel2 R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs perViewErrors:(Mat*)perViewErrors flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(registerCameras(objectPoints1:objectPoints2:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraModel1:cameraMatrix2:distCoeffs2:cameraModel2:R:T:E:F:rvecs:tvecs:perViewErrors:flags:criteria:));

/**
 * Calibrates a camera pair set up. This function finds the extrinsic parameters between the two cameras.
 *
 * @param objectPoints1 Vector of vectors of the calibration pattern points for camera 1.
 * A similar structure as objectPoints in *Ref:* calibrateCamera and for each pattern view,
 * both cameras do not need to see the same object points. objectPoints1.size(), imagePoints1.size()
 * nees to be equal,as well as objectPoints1[i].size(), imagePoints1[i].size() need to be equal for each i.
 * @param objectPoints2 Vector of vectors of the calibration pattern points for camera 2.
 * A similar structure as objectPoints1. objectPoints2.size(), and imagePoints2.size() nees to be equal,
 * as well as objectPoints2[i].size(), imagePoints2[i].size() need to be equal for each i.
 * However, objectPoints1[i].size() and objectPoints2[i].size() are not required to be equal.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera. The same structure as in *Ref:* calibrateCamera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera. The same structure as in *Ref:* calibrateCamera.
 * @param cameraMatrix1 Input/output camera intrinsic matrix for the first camera, the same as in
 * Ref:* calibrateCamera. Furthermore, for the stereo case, additional flags may be used, see below.
 * @param distCoeffs1 Input/output vector of distortion coefficients, the same as in
 * Ref:* calibrateCamera.
 * @param cameraModel1 Flag reflecting the type of model for camera 1 (pinhole / fisheye):
 * - *Ref:* CALIB_MODEL_PINHOLE pinhole camera model
 * - *Ref:* CALIB_MODEL_FISHEYE fisheye camera model
 * @param cameraMatrix2 Input/output second camera intrinsic matrix for the second camera.
 * See description for cameraMatrix1.
 * @param distCoeffs2 Input/output lens distortion coefficients for the second camera. See
 * description for distCoeffs1.
 * @param cameraModel2 Flag reflecting the type of model for camera 2 (pinhole / fisheye).
 * See description for cameraModel1.
 * @param R Output rotation matrix. Together with the translation vector T, this matrix brings
 * points given in the first camera's coordinate system to points in the second camera's
 * coordinate system. In more technical terms, the tuple of R and T performs a change of basis
 * from the first camera's coordinate system to the second camera's coordinate system. Due to its
 * duality, this tuple is equivalent to the position of the first camera with respect to the
 * second camera coordinate system.
 * @param T Output translation vector, see description above.
 * @param E Output essential matrix.
 * @param F Output fundamental matrix.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to the camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* CALIB_USE_EXTRINSIC_GUESS R and T contain valid initial values that are optimized further.
 *
 * The function estimates the transformation between two cameras similar to stereo pair calibration.
 * The principle follows closely to *Ref:* stereoCalibrate. To understand the problem of estimating the
 * relative pose between a camera pair, please refer to the description there. The difference for
 * this function is that, camera intrinsics are not optimized and two cameras are not required
 * to have overlapping fields of view as long as they are observing the same calibration target
 * and the absolute positions of each object point are known.
 * ![](register_pair)
 * The above illustration shows an example where such a case may become relevant.
 * Additionally, it supports a camera pair with the mixed model (pinhole / fisheye).
 * Similarly to ``Calib/calibrateCamera``, the function minimizes the total re-projection error for all the
 * points in all the available views from both cameras.
 * @return the final value of the re-projection error.
 *
 * - SeeAlso ``calibrateCamera:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:flags:criteria:``, ``stereoCalibrate:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:flags:criteria:``
 */
+ (double)registerCamerasExtended:(NSArray<Mat*>*)objectPoints1 objectPoints2:(NSArray<Mat*>*)objectPoints2 imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraModel1:(CameraModel)cameraModel1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 cameraModel2:(CameraModel)cameraModel2 R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs perViewErrors:(Mat*)perViewErrors flags:(int)flags NS_SWIFT_NAME(registerCameras(objectPoints1:objectPoints2:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraModel1:cameraMatrix2:distCoeffs2:cameraModel2:R:T:E:F:rvecs:tvecs:perViewErrors:flags:));

/**
 * Calibrates a camera pair set up. This function finds the extrinsic parameters between the two cameras.
 *
 * @param objectPoints1 Vector of vectors of the calibration pattern points for camera 1.
 * A similar structure as objectPoints in *Ref:* calibrateCamera and for each pattern view,
 * both cameras do not need to see the same object points. objectPoints1.size(), imagePoints1.size()
 * nees to be equal,as well as objectPoints1[i].size(), imagePoints1[i].size() need to be equal for each i.
 * @param objectPoints2 Vector of vectors of the calibration pattern points for camera 2.
 * A similar structure as objectPoints1. objectPoints2.size(), and imagePoints2.size() nees to be equal,
 * as well as objectPoints2[i].size(), imagePoints2[i].size() need to be equal for each i.
 * However, objectPoints1[i].size() and objectPoints2[i].size() are not required to be equal.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera. The same structure as in *Ref:* calibrateCamera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera. The same structure as in *Ref:* calibrateCamera.
 * @param cameraMatrix1 Input/output camera intrinsic matrix for the first camera, the same as in
 * Ref:* calibrateCamera. Furthermore, for the stereo case, additional flags may be used, see below.
 * @param distCoeffs1 Input/output vector of distortion coefficients, the same as in
 * Ref:* calibrateCamera.
 * @param cameraModel1 Flag reflecting the type of model for camera 1 (pinhole / fisheye):
 * - *Ref:* CALIB_MODEL_PINHOLE pinhole camera model
 * - *Ref:* CALIB_MODEL_FISHEYE fisheye camera model
 * @param cameraMatrix2 Input/output second camera intrinsic matrix for the second camera.
 * See description for cameraMatrix1.
 * @param distCoeffs2 Input/output lens distortion coefficients for the second camera. See
 * description for distCoeffs1.
 * @param cameraModel2 Flag reflecting the type of model for camera 2 (pinhole / fisheye).
 * See description for cameraModel1.
 * @param R Output rotation matrix. Together with the translation vector T, this matrix brings
 * points given in the first camera's coordinate system to points in the second camera's
 * coordinate system. In more technical terms, the tuple of R and T performs a change of basis
 * from the first camera's coordinate system to the second camera's coordinate system. Due to its
 * duality, this tuple is equivalent to the position of the first camera with respect to the
 * second camera coordinate system.
 * @param T Output translation vector, see description above.
 * @param E Output essential matrix.
 * @param F Output fundamental matrix.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to the camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * @param perViewErrors Output vector of the RMS re-projection error estimated for each pattern view.
 * -   *Ref:* CALIB_USE_EXTRINSIC_GUESS R and T contain valid initial values that are optimized further.
 *
 * The function estimates the transformation between two cameras similar to stereo pair calibration.
 * The principle follows closely to *Ref:* stereoCalibrate. To understand the problem of estimating the
 * relative pose between a camera pair, please refer to the description there. The difference for
 * this function is that, camera intrinsics are not optimized and two cameras are not required
 * to have overlapping fields of view as long as they are observing the same calibration target
 * and the absolute positions of each object point are known.
 * ![](register_pair)
 * The above illustration shows an example where such a case may become relevant.
 * Additionally, it supports a camera pair with the mixed model (pinhole / fisheye).
 * Similarly to ``Calib/calibrateCamera``, the function minimizes the total re-projection error for all the
 * points in all the available views from both cameras.
 * @return the final value of the re-projection error.
 *
 * - SeeAlso ``calibrateCamera:imagePoints:imageSize:cameraMatrix:distCoeffs:rvecs:tvecs:flags:criteria:``, ``stereoCalibrate:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraMatrix2:distCoeffs2:imageSize:R:T:E:F:flags:criteria:``
 */
+ (double)registerCamerasExtended:(NSArray<Mat*>*)objectPoints1 objectPoints2:(NSArray<Mat*>*)objectPoints2 imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraModel1:(CameraModel)cameraModel1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 cameraModel2:(CameraModel)cameraModel2 R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs perViewErrors:(Mat*)perViewErrors NS_SWIFT_NAME(registerCameras(objectPoints1:objectPoints2:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraModel1:cameraMatrix2:distCoeffs2:cameraModel2:R:T:E:F:rvecs:tvecs:perViewErrors:));


//
//  double cv::registerCameras(vector_Mat objectPoints1, vector_Mat objectPoints2, vector_Mat imagePoints1, vector_Mat imagePoints2, Mat cameraMatrix1, Mat distCoeffs1, CameraModel cameraModel1, Mat cameraMatrix2, Mat distCoeffs2, CameraModel cameraModel2, Mat& R, Mat& T, Mat& E, Mat& F, Mat& perViewErrors, int flags = 0, TermCriteria criteria = TermCriteria(TermCriteria::COUNT+TermCriteria::EPS, 100, 1e-6))
//
+ (double)registerCameras:(NSArray<Mat*>*)objectPoints1 objectPoints2:(NSArray<Mat*>*)objectPoints2 imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraModel1:(CameraModel)cameraModel1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 cameraModel2:(CameraModel)cameraModel2 R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F perViewErrors:(Mat*)perViewErrors flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(registerCameras(objectPoints1:objectPoints2:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraModel1:cameraMatrix2:distCoeffs2:cameraModel2:R:T:E:F:perViewErrors:flags:criteria:));

+ (double)registerCameras:(NSArray<Mat*>*)objectPoints1 objectPoints2:(NSArray<Mat*>*)objectPoints2 imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraModel1:(CameraModel)cameraModel1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 cameraModel2:(CameraModel)cameraModel2 R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F perViewErrors:(Mat*)perViewErrors flags:(int)flags NS_SWIFT_NAME(registerCameras(objectPoints1:objectPoints2:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraModel1:cameraMatrix2:distCoeffs2:cameraModel2:R:T:E:F:perViewErrors:flags:));

+ (double)registerCameras:(NSArray<Mat*>*)objectPoints1 objectPoints2:(NSArray<Mat*>*)objectPoints2 imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 cameraMatrix1:(Mat*)cameraMatrix1 distCoeffs1:(Mat*)distCoeffs1 cameraModel1:(CameraModel)cameraModel1 cameraMatrix2:(Mat*)cameraMatrix2 distCoeffs2:(Mat*)distCoeffs2 cameraModel2:(CameraModel)cameraModel2 R:(Mat*)R T:(Mat*)T E:(Mat*)E F:(Mat*)F perViewErrors:(Mat*)perViewErrors NS_SWIFT_NAME(registerCameras(objectPoints1:objectPoints2:imagePoints1:imagePoints2:cameraMatrix1:distCoeffs1:cameraModel1:cameraMatrix2:distCoeffs2:cameraModel2:R:T:E:F:perViewErrors:));


//
//  double cv::calibrateMultiview(vector_Mat objPoints, vector_vector_Mat imagePoints, vector_Size imageSize, Mat detectionMask, Mat models, vector_Mat& Ks, vector_Mat& distortions, vector_Mat& Rs, vector_Mat& Ts, Mat& initializationPairs, vector_Mat& rvecs0, vector_Mat& tvecs0, Mat& perFrameErrors, Mat flagsForIntrinsics = Mat(), int flags = 0, TermCriteria criteria = TermCriteria(TermCriteria::COUNT + TermCriteria::EPS, 100, DBL_EPSILON))
//
// Unknown type 'vector_Size' (I), skipping the function


//
//  double cv::calibrateMultiview(vector_Mat objPoints, vector_vector_Mat imagePoints, vector_Size imageSize, Mat detectionMask, Mat models, vector_Mat& Ks, vector_Mat& distortions, vector_Mat& Rs, vector_Mat& Ts, Mat flagsForIntrinsics = Mat(), int flags = 0, TermCriteria criteria = TermCriteria(TermCriteria::COUNT + TermCriteria::EPS, 100, DBL_EPSILON))
//
// Unknown type 'vector_Size' (I), skipping the function


//
//  double cv::fisheye::calibrate(vector_Mat objectPoints, vector_Mat imagePoints, Size image_size, Mat& K, Mat& D, vector_Mat& rvecs, vector_Mat& tvecs, int flags = 0, TermCriteria criteria = TermCriteria(TermCriteria::COUNT + TermCriteria::EPS, 100, DBL_EPSILON))
//
/**
 * Performs camera calibration
 *
 * @param objectPoints vector of vectors of calibration pattern points in the calibration pattern
 * coordinate space.
 * @param imagePoints vector of vectors of the projections of calibration pattern points.
 * imagePoints.size() and objectPoints.size() and imagePoints[i].size() must be equal to
 * objectPoints[i].size() for each i.
 * @param image_size Size of the image used only to initialize the camera intrinsic matrix.
 * @param K Output 3x3 floating-point camera intrinsic matrix
 * `$$\cameramatrix{A}$$` . If
 * Ref:* cv::CALIB_USE_INTRINSIC_GUESS is specified, some or all of fx, fy, cx, cy must be
 * initialized before calling the function.
 * @param D Output vector of distortion coefficients `$$\distcoeffsfisheye$$`.
 * @param rvecs Output vector of rotation vectors (see Rodrigues ) estimated for each pattern view.
 * That is, each k-th rotation vector together with the corresponding k-th translation vector (see
 * the next output parameter description) brings the calibration pattern from the model coordinate
 * space (in which object points are specified) to the world coordinate space, that is, a real
 * position of the calibration pattern in the k-th pattern view (k=0.. *M* -1).
 * @param tvecs Output vector of translation vectors estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* cv::CALIB_USE_INTRINSIC_GUESS  cameraMatrix contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center ( imageSize is used), and focal distances are computed in a least-squares fashion.
 * -   *Ref:* cv::CALIB_RECOMPUTE_EXTRINSIC  Extrinsic will be recomputed after each iteration
 * of intrinsic optimization.
 * -   *Ref:* cv::CALIB_CHECK_COND  The functions will check validity of condition number.
 * -   *Ref:* cv::CALIB_FIX_SKEW  Skew coefficient (alpha) is set to zero and stay zero.
 * -   *Ref:* cv::CALIB_FIX_K1,..., *Ref:* cv::CALIB_FIX_K4 Selected distortion coefficients
 * are set to zeros and stay zero.
 * -   *Ref:* cv::CALIB_FIX_PRINCIPAL_POINT  The principal point is not changed during the global
 * optimization. It stays at the center or at a different location specified when *Ref:* cv::CALIB_USE_INTRINSIC_GUESS is set too.
 * -   *Ref:* cv::CALIB_FIX_FOCAL_LENGTH The focal length is not changed during the global
 * optimization. It is the `$$max(width,height)/\pi$$` or the provided `$$f_x$$`, `$$f_y$$` when *Ref:* cv::CALIB_USE_INTRINSIC_GUESS is set too.
 * @param criteria Termination criteria for the iterative optimization algorithm.
 */
+ (double)fisheye_calibrate:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints image_size:(Size2i*)image_size K:(Mat*)K D:(Mat*)D rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(fisheye_calibrate(objectPoints:imagePoints:image_size:K:D:rvecs:tvecs:flags:criteria:));

/**
 * Performs camera calibration
 *
 * @param objectPoints vector of vectors of calibration pattern points in the calibration pattern
 * coordinate space.
 * @param imagePoints vector of vectors of the projections of calibration pattern points.
 * imagePoints.size() and objectPoints.size() and imagePoints[i].size() must be equal to
 * objectPoints[i].size() for each i.
 * @param image_size Size of the image used only to initialize the camera intrinsic matrix.
 * @param K Output 3x3 floating-point camera intrinsic matrix
 * `$$\cameramatrix{A}$$` . If
 * Ref:* cv::CALIB_USE_INTRINSIC_GUESS is specified, some or all of fx, fy, cx, cy must be
 * initialized before calling the function.
 * @param D Output vector of distortion coefficients `$$\distcoeffsfisheye$$`.
 * @param rvecs Output vector of rotation vectors (see Rodrigues ) estimated for each pattern view.
 * That is, each k-th rotation vector together with the corresponding k-th translation vector (see
 * the next output parameter description) brings the calibration pattern from the model coordinate
 * space (in which object points are specified) to the world coordinate space, that is, a real
 * position of the calibration pattern in the k-th pattern view (k=0.. *M* -1).
 * @param tvecs Output vector of translation vectors estimated for each pattern view.
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* cv::CALIB_USE_INTRINSIC_GUESS  cameraMatrix contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center ( imageSize is used), and focal distances are computed in a least-squares fashion.
 * -   *Ref:* cv::CALIB_RECOMPUTE_EXTRINSIC  Extrinsic will be recomputed after each iteration
 * of intrinsic optimization.
 * -   *Ref:* cv::CALIB_CHECK_COND  The functions will check validity of condition number.
 * -   *Ref:* cv::CALIB_FIX_SKEW  Skew coefficient (alpha) is set to zero and stay zero.
 * -   *Ref:* cv::CALIB_FIX_K1,..., *Ref:* cv::CALIB_FIX_K4 Selected distortion coefficients
 * are set to zeros and stay zero.
 * -   *Ref:* cv::CALIB_FIX_PRINCIPAL_POINT  The principal point is not changed during the global
 * optimization. It stays at the center or at a different location specified when *Ref:* cv::CALIB_USE_INTRINSIC_GUESS is set too.
 * -   *Ref:* cv::CALIB_FIX_FOCAL_LENGTH The focal length is not changed during the global
 * optimization. It is the `$$max(width,height)/\pi$$` or the provided `$$f_x$$`, `$$f_y$$` when *Ref:* cv::CALIB_USE_INTRINSIC_GUESS is set too.
 */
+ (double)fisheye_calibrate:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints image_size:(Size2i*)image_size K:(Mat*)K D:(Mat*)D rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs flags:(int)flags NS_SWIFT_NAME(fisheye_calibrate(objectPoints:imagePoints:image_size:K:D:rvecs:tvecs:flags:));

/**
 * Performs camera calibration
 *
 * @param objectPoints vector of vectors of calibration pattern points in the calibration pattern
 * coordinate space.
 * @param imagePoints vector of vectors of the projections of calibration pattern points.
 * imagePoints.size() and objectPoints.size() and imagePoints[i].size() must be equal to
 * objectPoints[i].size() for each i.
 * @param image_size Size of the image used only to initialize the camera intrinsic matrix.
 * @param K Output 3x3 floating-point camera intrinsic matrix
 * `$$\cameramatrix{A}$$` . If
 * Ref:* cv::CALIB_USE_INTRINSIC_GUESS is specified, some or all of fx, fy, cx, cy must be
 * initialized before calling the function.
 * @param D Output vector of distortion coefficients `$$\distcoeffsfisheye$$`.
 * @param rvecs Output vector of rotation vectors (see Rodrigues ) estimated for each pattern view.
 * That is, each k-th rotation vector together with the corresponding k-th translation vector (see
 * the next output parameter description) brings the calibration pattern from the model coordinate
 * space (in which object points are specified) to the world coordinate space, that is, a real
 * position of the calibration pattern in the k-th pattern view (k=0.. *M* -1).
 * @param tvecs Output vector of translation vectors estimated for each pattern view.
 * -   *Ref:* cv::CALIB_USE_INTRINSIC_GUESS  cameraMatrix contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center ( imageSize is used), and focal distances are computed in a least-squares fashion.
 * -   *Ref:* cv::CALIB_RECOMPUTE_EXTRINSIC  Extrinsic will be recomputed after each iteration
 * of intrinsic optimization.
 * -   *Ref:* cv::CALIB_CHECK_COND  The functions will check validity of condition number.
 * -   *Ref:* cv::CALIB_FIX_SKEW  Skew coefficient (alpha) is set to zero and stay zero.
 * -   *Ref:* cv::CALIB_FIX_K1,..., *Ref:* cv::CALIB_FIX_K4 Selected distortion coefficients
 * are set to zeros and stay zero.
 * -   *Ref:* cv::CALIB_FIX_PRINCIPAL_POINT  The principal point is not changed during the global
 * optimization. It stays at the center or at a different location specified when *Ref:* cv::CALIB_USE_INTRINSIC_GUESS is set too.
 * -   *Ref:* cv::CALIB_FIX_FOCAL_LENGTH The focal length is not changed during the global
 * optimization. It is the `$$max(width,height)/\pi$$` or the provided `$$f_x$$`, `$$f_y$$` when *Ref:* cv::CALIB_USE_INTRINSIC_GUESS is set too.
 */
+ (double)fisheye_calibrate:(NSArray<Mat*>*)objectPoints imagePoints:(NSArray<Mat*>*)imagePoints image_size:(Size2i*)image_size K:(Mat*)K D:(Mat*)D rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs NS_SWIFT_NAME(fisheye_calibrate(objectPoints:imagePoints:image_size:K:D:rvecs:tvecs:));


//
//  double cv::fisheye::stereoCalibrate(vector_Mat objectPoints, vector_Mat imagePoints1, vector_Mat imagePoints2, Mat& K1, Mat& D1, Mat& K2, Mat& D2, Size imageSize, Mat& R, Mat& T, vector_Mat& rvecs, vector_Mat& tvecs, int flags = CALIB_FIX_INTRINSIC, TermCriteria criteria = TermCriteria(TermCriteria::COUNT + TermCriteria::EPS, 100, DBL_EPSILON))
//
/**
 * Performs stereo calibration
 *
 * @param objectPoints Vector of vectors of the calibration pattern points.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera.
 * @param K1 Input/output first camera intrinsic matrix:
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{f_x^{(j)}}{0}{c_x^{(j)}}{0}{f_y^{(j)}}{c_y^{(j)}}{0}{0}{1}$$` , `$$j = 0,\, 1$$` . If
 * any of *Ref:* cv::CALIB_USE_INTRINSIC_GUESS , *Ref:* cv::CALIB_FIX_INTRINSIC are specified,
 * some or all of the matrix components must be initialized.
 * @param D1 Input/output vector of distortion coefficients `$$\distcoeffsfisheye$$` of 4 elements.
 * @param K2 Input/output second camera intrinsic matrix. The parameter is similar to K1 .
 * @param D2 Input/output lens distortion coefficients for the second camera. The parameter is
 * similar to D1 .
 * @param imageSize Size of the image used only to initialize camera intrinsic matrix.
 * @param R Output rotation matrix between the 1st and the 2nd camera coordinate systems.
 * @param T Output translation vector between the coordinate systems of the cameras.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* cv::CALIB_FIX_INTRINSIC  Fix K1, K2? and D1, D2? so that only R, T matrices
 * are estimated.
 * -   *Ref:* cv::CALIB_USE_INTRINSIC_GUESS  K1, K2 contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center (imageSize is used), and focal distances are computed in a least-squares fashion.
 * -   *Ref:* cv::CALIB_RECOMPUTE_EXTRINSIC  Extrinsic will be recomputed after each iteration
 * of intrinsic optimization.
 * -   *Ref:* cv::CALIB_CHECK_COND  The functions will check validity of condition number.
 * -   *Ref:* cv::CALIB_FIX_SKEW  Skew coefficient (alpha) is set to zero and stay zero.
 * -   *Ref:* cv::CALIB_FIX_K1,..., *Ref:* cv::CALIB_FIX_K4 Selected distortion coefficients are set to zeros and stay
 * zero.
 * @param criteria Termination criteria for the iterative optimization algorithm.
 */
+ (double)fisheye_stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 K1:(Mat*)K1 D1:(Mat*)D1 K2:(Mat*)K2 D2:(Mat*)D2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(fisheye_stereoCalibrate(objectPoints:imagePoints1:imagePoints2:K1:D1:K2:D2:imageSize:R:T:rvecs:tvecs:flags:criteria:));

/**
 * Performs stereo calibration
 *
 * @param objectPoints Vector of vectors of the calibration pattern points.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera.
 * @param K1 Input/output first camera intrinsic matrix:
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{f_x^{(j)}}{0}{c_x^{(j)}}{0}{f_y^{(j)}}{c_y^{(j)}}{0}{0}{1}$$` , `$$j = 0,\, 1$$` . If
 * any of *Ref:* cv::CALIB_USE_INTRINSIC_GUESS , *Ref:* cv::CALIB_FIX_INTRINSIC are specified,
 * some or all of the matrix components must be initialized.
 * @param D1 Input/output vector of distortion coefficients `$$\distcoeffsfisheye$$` of 4 elements.
 * @param K2 Input/output second camera intrinsic matrix. The parameter is similar to K1 .
 * @param D2 Input/output lens distortion coefficients for the second camera. The parameter is
 * similar to D1 .
 * @param imageSize Size of the image used only to initialize camera intrinsic matrix.
 * @param R Output rotation matrix between the 1st and the 2nd camera coordinate systems.
 * @param T Output translation vector between the coordinate systems of the cameras.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * @param flags Different flags that may be zero or a combination of the following values:
 * -   *Ref:* cv::CALIB_FIX_INTRINSIC  Fix K1, K2? and D1, D2? so that only R, T matrices
 * are estimated.
 * -   *Ref:* cv::CALIB_USE_INTRINSIC_GUESS  K1, K2 contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center (imageSize is used), and focal distances are computed in a least-squares fashion.
 * -   *Ref:* cv::CALIB_RECOMPUTE_EXTRINSIC  Extrinsic will be recomputed after each iteration
 * of intrinsic optimization.
 * -   *Ref:* cv::CALIB_CHECK_COND  The functions will check validity of condition number.
 * -   *Ref:* cv::CALIB_FIX_SKEW  Skew coefficient (alpha) is set to zero and stay zero.
 * -   *Ref:* cv::CALIB_FIX_K1,..., *Ref:* cv::CALIB_FIX_K4 Selected distortion coefficients are set to zeros and stay
 * zero.
 */
+ (double)fisheye_stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 K1:(Mat*)K1 D1:(Mat*)D1 K2:(Mat*)K2 D2:(Mat*)D2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs flags:(int)flags NS_SWIFT_NAME(fisheye_stereoCalibrate(objectPoints:imagePoints1:imagePoints2:K1:D1:K2:D2:imageSize:R:T:rvecs:tvecs:flags:));

/**
 * Performs stereo calibration
 *
 * @param objectPoints Vector of vectors of the calibration pattern points.
 * @param imagePoints1 Vector of vectors of the projections of the calibration pattern points,
 * observed by the first camera.
 * @param imagePoints2 Vector of vectors of the projections of the calibration pattern points,
 * observed by the second camera.
 * @param K1 Input/output first camera intrinsic matrix:
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{f_x^{(j)}}{0}{c_x^{(j)}}{0}{f_y^{(j)}}{c_y^{(j)}}{0}{0}{1}$$` , `$$j = 0,\, 1$$` . If
 * any of *Ref:* cv::CALIB_USE_INTRINSIC_GUESS , *Ref:* cv::CALIB_FIX_INTRINSIC are specified,
 * some or all of the matrix components must be initialized.
 * @param D1 Input/output vector of distortion coefficients `$$\distcoeffsfisheye$$` of 4 elements.
 * @param K2 Input/output second camera intrinsic matrix. The parameter is similar to K1 .
 * @param D2 Input/output lens distortion coefficients for the second camera. The parameter is
 * similar to D1 .
 * @param imageSize Size of the image used only to initialize camera intrinsic matrix.
 * @param R Output rotation matrix between the 1st and the 2nd camera coordinate systems.
 * @param T Output translation vector between the coordinate systems of the cameras.
 * @param rvecs Output vector of rotation vectors ( *Ref:* Rodrigues ) estimated for each pattern view in the
 * coordinate system of the first camera of the stereo pair (e.g. std::vector<cv::Mat>). More in detail, each
 * i-th rotation vector together with the corresponding i-th translation vector (see the next output parameter
 * description) brings the calibration pattern from the object coordinate space (in which object points are
 * specified) to the camera coordinate space of the first camera of the stereo pair. In more technical terms,
 * the tuple of the i-th rotation and translation vector performs a change of basis from object coordinate space
 * to camera coordinate space of the first camera of the stereo pair.
 * @param tvecs Output vector of translation vectors estimated for each pattern view, see parameter description
 * of previous output parameter ( rvecs ).
 * -   *Ref:* cv::CALIB_FIX_INTRINSIC  Fix K1, K2? and D1, D2? so that only R, T matrices
 * are estimated.
 * -   *Ref:* cv::CALIB_USE_INTRINSIC_GUESS  K1, K2 contains valid initial values of
 * fx, fy, cx, cy that are optimized further. Otherwise, (cx, cy) is initially set to the image
 * center (imageSize is used), and focal distances are computed in a least-squares fashion.
 * -   *Ref:* cv::CALIB_RECOMPUTE_EXTRINSIC  Extrinsic will be recomputed after each iteration
 * of intrinsic optimization.
 * -   *Ref:* cv::CALIB_CHECK_COND  The functions will check validity of condition number.
 * -   *Ref:* cv::CALIB_FIX_SKEW  Skew coefficient (alpha) is set to zero and stay zero.
 * -   *Ref:* cv::CALIB_FIX_K1,..., *Ref:* cv::CALIB_FIX_K4 Selected distortion coefficients are set to zeros and stay
 * zero.
 */
+ (double)fisheye_stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 K1:(Mat*)K1 D1:(Mat*)D1 K2:(Mat*)K2 D2:(Mat*)D2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T rvecs:(NSMutableArray<Mat*>*)rvecs tvecs:(NSMutableArray<Mat*>*)tvecs NS_SWIFT_NAME(fisheye_stereoCalibrate(objectPoints:imagePoints1:imagePoints2:K1:D1:K2:D2:imageSize:R:T:rvecs:tvecs:));


//
//  double cv::fisheye::stereoCalibrate(vector_Mat objectPoints, vector_Mat imagePoints1, vector_Mat imagePoints2, Mat& K1, Mat& D1, Mat& K2, Mat& D2, Size imageSize, Mat& R, Mat& T, int flags = CALIB_FIX_INTRINSIC, TermCriteria criteria = TermCriteria(TermCriteria::COUNT + TermCriteria::EPS, 100, DBL_EPSILON))
//
+ (double)fisheye_stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 K1:(Mat*)K1 D1:(Mat*)D1 K2:(Mat*)K2 D2:(Mat*)D2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T flags:(int)flags criteria:(TermCriteria*)criteria NS_SWIFT_NAME(fisheye_stereoCalibrate(objectPoints:imagePoints1:imagePoints2:K1:D1:K2:D2:imageSize:R:T:flags:criteria:));

+ (double)fisheye_stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 K1:(Mat*)K1 D1:(Mat*)D1 K2:(Mat*)K2 D2:(Mat*)D2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T flags:(int)flags NS_SWIFT_NAME(fisheye_stereoCalibrate(objectPoints:imagePoints1:imagePoints2:K1:D1:K2:D2:imageSize:R:T:flags:));

+ (double)fisheye_stereoCalibrate:(NSArray<Mat*>*)objectPoints imagePoints1:(NSArray<Mat*>*)imagePoints1 imagePoints2:(NSArray<Mat*>*)imagePoints2 K1:(Mat*)K1 D1:(Mat*)D1 K2:(Mat*)K2 D2:(Mat*)D2 imageSize:(Size2i*)imageSize R:(Mat*)R T:(Mat*)T NS_SWIFT_NAME(fisheye_stereoCalibrate(objectPoints:imagePoints1:imagePoints2:K1:D1:K2:D2:imageSize:R:T:));



@end

NS_ASSUME_NONNULL_END


