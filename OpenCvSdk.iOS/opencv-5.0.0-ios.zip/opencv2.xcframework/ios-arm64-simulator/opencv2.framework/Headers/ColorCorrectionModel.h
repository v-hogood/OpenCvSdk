//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/photo.hpp"
#import "opencv2/photo/ccm.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "Photo.h"
@class Mat;



NS_ASSUME_NONNULL_BEGIN

// C++: class ColorCorrectionModel
/**
 * Core class of ccm model
 *
 * Produce a ColorCorrectionModel instance for inference
 *
 * Member of `Photo`
 */
CV_EXPORTS @interface ColorCorrectionModel : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::ccm::ColorCorrectionModel> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::ccm::ColorCorrectionModel>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::ccm::ColorCorrectionModel>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::ccm::ColorCorrectionModel::ColorCorrectionModel()
//
- (instancetype)init;


//
//   cv::ccm::ColorCorrectionModel::ColorCorrectionModel(Mat src, int constColor)
//
/**
 * Color Correction Model
 *
 *         Supported list of color cards:
 *         - *Ref:* COLORCHECKER_MACBETH, the Macbeth ColorChecker
 *         - *Ref:* COLORCHECKER_VINYL, the DKK ColorChecker
 *         - *Ref:* COLORCHECKER_DIGITAL_SG, the DigitalSG ColorChecker with 140 squares
 *
 * @param src detected colors of ColorChecker patches;
 *                     the color type is RGB not BGR, and the color values are in [0, 1];
 * @param constColor the Built-in color card
 */
- (instancetype)initWithSrc:(Mat*)src constColor:(int)constColor;


//
//   cv::ccm::ColorCorrectionModel::ColorCorrectionModel(Mat src, Mat colors, ColorSpace refColorSpace)
//
/**
 * Color Correction Model
 * @param src detected colors of ColorChecker patches;
 *                 the color type is RGB not BGR, and the color values are in [0, 1];
 * @param colors the reference color values, the color values are in [0, 1].
 * @param refColorSpace the corresponding color space
 *                 If the color type is some RGB, the format is RGB not BGR;
 */
- (instancetype)initWithSrc:(Mat*)src colors:(Mat*)colors refColorSpace:(ColorSpace)refColorSpace;


//
//   cv::ccm::ColorCorrectionModel::ColorCorrectionModel(Mat src, Mat colors, ColorSpace refColorSpace, Mat coloredPatchesMask)
//
/**
 * Color Correction Model
 * @param src detected colors of ColorChecker patches;
 *                     the color type is RGB not BGR, and the color values are in [0, 1];
 * @param colors the reference color values, the color values are in [0, 1].
 * @param refColorSpace the corresponding color space
 *                     If the color type is some RGB, the format is RGB not BGR;
 * @param coloredPatchesMask binary mask indicating which patches are colored (non-gray) patches
 */
- (instancetype)initWithSrc:(Mat*)src colors:(Mat*)colors refColorSpace:(ColorSpace)refColorSpace coloredPatchesMask:(Mat*)coloredPatchesMask;


//
//  void cv::ccm::ColorCorrectionModel::setColorSpace(ColorSpace cs)
//
/**
 * set ColorSpace
 * Note:* It should be some RGB color space;
 *         Supported list of color cards:
 *         - *Ref:* COLOR_SPACE_SRGB
 *         - *Ref:* COLOR_SPACE_ADOBE_RGB
 *         - *Ref:* COLOR_SPACE_WIDE_GAMUT_RGB
 *         - *Ref:* COLOR_SPACE_PRO_PHOTO_RGB
 *         - *Ref:* COLOR_SPACE_DCI_P3_RGB
 *         - *Ref:* COLOR_SPACE_APPLE_RGB
 *         - *Ref:* COLOR_SPACE_REC_709_RGB
 *         - *Ref:* COLOR_SPACE_REC_2020_RGB
 * @param cs the absolute color space that detected colors convert to;
 *               default: *Ref:* COLOR_SPACE_SRGB
 */
- (void)setColorSpace:(ColorSpace)cs NS_SWIFT_NAME(setColorSpace(cs:));


//
//  void cv::ccm::ColorCorrectionModel::setCcmType(CcmType ccmType)
//
/**
 * set ccmType
 * @param ccmType the shape of color correction matrix(CCM);
 *                     default: *Ref:* CCM_LINEAR
 */
- (void)setCcmType:(CcmType)ccmType NS_SWIFT_NAME(setCcmType(ccmType:));


//
//  void cv::ccm::ColorCorrectionModel::setDistance(DistanceType distance)
//
/**
 * set Distance
 * @param distance the type of color distance;
 *                     default: *Ref:* DISTANCE_CIE2000
 */
- (void)setDistance:(DistanceType)distance NS_SWIFT_NAME(setDistance(distance:));


//
//  void cv::ccm::ColorCorrectionModel::setLinearization(LinearizationType linearizationType)
//
/**
 * set Linear
 * @param linearizationType the method of linearization;
 *                        default: *Ref:* LINEARIZATION_GAMMA
 */
- (void)setLinearization:(LinearizationType)linearizationType NS_SWIFT_NAME(setLinearization(linearizationType:));


//
//  void cv::ccm::ColorCorrectionModel::setLinearizationGamma(double gamma)
//
/**
 * set Gamma
 *
 * Note:* only valid when linear is set to "gamma";
 *
 * @param gamma the gamma value of gamma correction;
 *                  default: 2.2;
 */
- (void)setLinearizationGamma:(double)gamma NS_SWIFT_NAME(setLinearizationGamma(gamma:));


//
//  void cv::ccm::ColorCorrectionModel::setLinearizationDegree(int deg)
//
/**
 * set degree
 * Note:* only valid when linear is set to
 *         - *Ref:* LINEARIZATION_COLORPOLYFIT
 *         - *Ref:* LINEARIZATION_GRAYPOLYFIT
 *         - *Ref:* LINEARIZATION_COLORLOGPOLYFIT
 *         - *Ref:* LINEARIZATION_GRAYLOGPOLYFIT
 *
 * @param deg the degree of linearization polynomial
 *             default: 3
 */
- (void)setLinearizationDegree:(int)deg NS_SWIFT_NAME(setLinearizationDegree(deg:));


//
//  void cv::ccm::ColorCorrectionModel::setSaturatedThreshold(double lower, double upper)
//
/**
 * set SaturatedThreshold.
 *                 The colors in the closed interval [lower, upper] are reserved to participate
 *                 in the calculation of the loss function and initialization parameters
 * @param lower the lower threshold to determine saturation;
 *                 default: 0;
 * @param upper the upper threshold to determine saturation;
 *                 default: 0
 */
- (void)setSaturatedThreshold:(double)lower upper:(double)upper NS_SWIFT_NAME(setSaturatedThreshold(lower:upper:));


//
//  void cv::ccm::ColorCorrectionModel::setWeightsList(Mat weightsList)
//
/**
 * set WeightsList
 * @param weightsList the list of weight of each color;
 *                         default: empty array
 */
- (void)setWeightsList:(Mat*)weightsList NS_SWIFT_NAME(setWeightsList(weightsList:));


//
//  void cv::ccm::ColorCorrectionModel::setWeightCoeff(double weightsCoeff)
//
/**
 * set WeightCoeff
 * @param weightsCoeff the exponent number of L* component of the reference color in CIE Lab color space;
 *                          default: 0
 */
- (void)setWeightCoeff:(double)weightsCoeff NS_SWIFT_NAME(setWeightCoeff(weightsCoeff:));


//
//  void cv::ccm::ColorCorrectionModel::setInitialMethod(InitialMethodType initialMethodType)
//
/**
 * set InitialMethod
 * @param initialMethodType the method of calculating CCM initial value;
 *             default: INITIAL_METHOD_LEAST_SQUARE
 */
- (void)setInitialMethod:(InitialMethodType)initialMethodType NS_SWIFT_NAME(setInitialMethod(initialMethodType:));


//
//  void cv::ccm::ColorCorrectionModel::setMaxCount(int maxCount)
//
/**
 * set MaxCount
 * @param maxCount used in MinProblemSolver-DownhillSolver;
 *         Terminal criteria to the algorithm;
 *                      default: 5000;
 */
- (void)setMaxCount:(int)maxCount NS_SWIFT_NAME(setMaxCount(maxCount:));


//
//  void cv::ccm::ColorCorrectionModel::setEpsilon(double epsilon)
//
/**
 * set Epsilon
 * @param epsilon used in MinProblemSolver-DownhillSolver;
 *         Terminal criteria to the algorithm;
 *                    default: 1e-4;
 */
- (void)setEpsilon:(double)epsilon NS_SWIFT_NAME(setEpsilon(epsilon:));


//
//  void cv::ccm::ColorCorrectionModel::setRGB(bool rgb)
//
/**
 * Set whether the input image is in RGB color space
 * @param rgb If true, the model expects input images in RGB format.
 *                  If false, input is assumed to be in BGR (default).
 */
- (void)setRGB:(BOOL)rgb NS_SWIFT_NAME(setRGB(rgb:));


//
//  Mat cv::ccm::ColorCorrectionModel::compute()
//
/**
 * make color correction
 */
- (Mat*)compute NS_SWIFT_NAME(compute());


//
//  Mat cv::ccm::ColorCorrectionModel::getColorCorrectionMatrix()
//
- (Mat*)getColorCorrectionMatrix NS_SWIFT_NAME(getColorCorrectionMatrix());


//
//  double cv::ccm::ColorCorrectionModel::getLoss()
//
- (double)getLoss NS_SWIFT_NAME(getLoss());


//
//  Mat cv::ccm::ColorCorrectionModel::getSrcLinearRGB()
//
- (Mat*)getSrcLinearRGB NS_SWIFT_NAME(getSrcLinearRGB());


//
//  Mat cv::ccm::ColorCorrectionModel::getRefLinearRGB()
//
- (Mat*)getRefLinearRGB NS_SWIFT_NAME(getRefLinearRGB());


//
//  Mat cv::ccm::ColorCorrectionModel::getMask()
//
- (Mat*)getMask NS_SWIFT_NAME(getMask());


//
//  Mat cv::ccm::ColorCorrectionModel::getWeights()
//
- (Mat*)getWeights NS_SWIFT_NAME(getWeights());


//
//  void cv::ccm::ColorCorrectionModel::correctImage(Mat src, Mat& dst, bool islinear = false)
//
/**
 * Applies color correction to the input image using a fitted color correction matrix.
 *
 * The conventional ranges for R, G, and B channel values are:
 *      -   0 to 255 for CV_8U images
 *      -   0 to 65535 for CV_16U images
 *      -   0 to 1 for CV_32F images
 * @param src Input 8-bit, 16-bit unsigned or 32-bit float 3-channel image..
 * @param dst Output image of the same size and datatype as src.
 * @param islinear default false.
 */
- (void)correctImage:(Mat*)src dst:(Mat*)dst islinear:(BOOL)islinear NS_SWIFT_NAME(correctImage(src:dst:islinear:));

/**
 * Applies color correction to the input image using a fitted color correction matrix.
 *
 * The conventional ranges for R, G, and B channel values are:
 *      -   0 to 255 for CV_8U images
 *      -   0 to 65535 for CV_16U images
 *      -   0 to 1 for CV_32F images
 * @param src Input 8-bit, 16-bit unsigned or 32-bit float 3-channel image..
 * @param dst Output image of the same size and datatype as src.
 */
- (void)correctImage:(Mat*)src dst:(Mat*)dst NS_SWIFT_NAME(correctImage(src:dst:));


//
//  void cv::ccm::ColorCorrectionModel::write(FileStorage fs)
//
// Unknown type 'FileStorage' (I), skipping the function


//
//  void cv::ccm::ColorCorrectionModel::read(FileNode node)
//
// Unknown type 'FileNode' (I), skipping the function



@end

NS_ASSUME_NONNULL_END


