//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/depth.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


@class Mat;


// C++: enum RgbdNormalsMethod (cv.RgbdNormals.RgbdNormalsMethod)
typedef NS_ENUM(int, RgbdNormalsMethod) {
    RgbdNormals_RGBD_NORMALS_METHOD_FALS NS_SWIFT_NAME(RGBD_NORMALS_METHOD_FALS) = 0,
    RgbdNormals_RGBD_NORMALS_METHOD_LINEMOD NS_SWIFT_NAME(RGBD_NORMALS_METHOD_LINEMOD) = 1,
    RgbdNormals_RGBD_NORMALS_METHOD_SRI NS_SWIFT_NAME(RGBD_NORMALS_METHOD_SRI) = 2,
    RgbdNormals_RGBD_NORMALS_METHOD_CROSS_PRODUCT NS_SWIFT_NAME(RGBD_NORMALS_METHOD_CROSS_PRODUCT) = 3
};



NS_ASSUME_NONNULL_BEGIN

// C++: class RgbdNormals
/**
 * Object that can compute the normals in an image.
 * It is an object as it can cache data for speed efficiency
 * The implemented methods are either:
 * - FALS (the fastest) and SRI from
 * ``Fast and Accurate Computation of Surface Normals from Range Images``
 * by H. Badino, D. Huber, Y. Park and T. Kanade
 * - the normals with bilateral filtering on a depth image from
 * ``Gradient Response Maps for Real-Time Detection of Texture-Less Objects``
 * by S. Hinterstoisser, C. Cagniart, S. Ilic, P. Sturm, N. Navab, P. Fua, and V. Lepetit
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface RgbdNormals : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::RgbdNormals> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::RgbdNormals>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::RgbdNormals>)nativePtr;
#endif


#pragma mark - Methods


//
// static Ptr_RgbdNormals cv::RgbdNormals::create(int rows = 0, int cols = 0, int depth = 0, Mat K = Mat(), int window_size = 5, float diff_threshold = 50.f, RgbdNormals_RgbdNormalsMethod method = RgbdNormals::RgbdNormalsMethod::RGBD_NORMALS_METHOD_FALS)
//
/**
 * Creates new RgbdNormals object
 * @param rows the number of rows of the depth image normals will be computed on
 * @param cols the number of cols of the depth image normals will be computed on
 * @param depth the depth of the normals (only CV_32F or CV_64F)
 * @param K the calibration matrix to use
 * @param window_size the window size to compute the normals: can only be 1,3,5 or 7
 * @param diff_threshold threshold in depth difference, used in LINEMOD algirithm
 * @param method one of the methods to use: RGBD_NORMALS_METHOD_SRI, RGBD_NORMALS_METHOD_FALS
 */
+ (RgbdNormals*)create:(int)rows cols:(int)cols depth:(int)depth K:(Mat*)K window_size:(int)window_size diff_threshold:(float)diff_threshold method:(RgbdNormalsMethod)method NS_SWIFT_NAME(create(rows:cols:depth:K:window_size:diff_threshold:method:));

/**
 * Creates new RgbdNormals object
 * @param rows the number of rows of the depth image normals will be computed on
 * @param cols the number of cols of the depth image normals will be computed on
 * @param depth the depth of the normals (only CV_32F or CV_64F)
 * @param K the calibration matrix to use
 * @param window_size the window size to compute the normals: can only be 1,3,5 or 7
 * @param diff_threshold threshold in depth difference, used in LINEMOD algirithm
 */
+ (RgbdNormals*)create:(int)rows cols:(int)cols depth:(int)depth K:(Mat*)K window_size:(int)window_size diff_threshold:(float)diff_threshold NS_SWIFT_NAME(create(rows:cols:depth:K:window_size:diff_threshold:));

/**
 * Creates new RgbdNormals object
 * @param rows the number of rows of the depth image normals will be computed on
 * @param cols the number of cols of the depth image normals will be computed on
 * @param depth the depth of the normals (only CV_32F or CV_64F)
 * @param K the calibration matrix to use
 * @param window_size the window size to compute the normals: can only be 1,3,5 or 7
 */
+ (RgbdNormals*)create:(int)rows cols:(int)cols depth:(int)depth K:(Mat*)K window_size:(int)window_size NS_SWIFT_NAME(create(rows:cols:depth:K:window_size:));

/**
 * Creates new RgbdNormals object
 * @param rows the number of rows of the depth image normals will be computed on
 * @param cols the number of cols of the depth image normals will be computed on
 * @param depth the depth of the normals (only CV_32F or CV_64F)
 * @param K the calibration matrix to use
 */
+ (RgbdNormals*)create:(int)rows cols:(int)cols depth:(int)depth K:(Mat*)K NS_SWIFT_NAME(create(rows:cols:depth:K:));

/**
 * Creates new RgbdNormals object
 * @param rows the number of rows of the depth image normals will be computed on
 * @param cols the number of cols of the depth image normals will be computed on
 * @param depth the depth of the normals (only CV_32F or CV_64F)
 */
+ (RgbdNormals*)create:(int)rows cols:(int)cols depth:(int)depth NS_SWIFT_NAME(create(rows:cols:depth:));

/**
 * Creates new RgbdNormals object
 * @param rows the number of rows of the depth image normals will be computed on
 * @param cols the number of cols of the depth image normals will be computed on
 */
+ (RgbdNormals*)create:(int)rows cols:(int)cols NS_SWIFT_NAME(create(rows:cols:));

/**
 * Creates new RgbdNormals object
 * @param rows the number of rows of the depth image normals will be computed on
 */
+ (RgbdNormals*)create:(int)rows NS_SWIFT_NAME(create(rows:));

/**
 * Creates new RgbdNormals object
 */
+ (RgbdNormals*)create NS_SWIFT_NAME(create());


//
//  void cv::RgbdNormals::apply(Mat points, Mat& normals)
//
/**
 * Given a set of 3d points in a depth image, compute the normals at each point.
 * @param points a rows x cols x 3 matrix of CV_32F/CV64F or a rows x cols x 1 CV_U16S
 * @param normals a rows x cols x 3 matrix
 */
- (void)apply:(Mat*)points normals:(Mat*)normals NS_SWIFT_NAME(apply(points:normals:));


//
//  void cv::RgbdNormals::cache()
//
/**
 * Prepares cached data required for calculation
 * If not called by user, called automatically at first calculation
 */
- (void)cache NS_SWIFT_NAME(cache());


//
//  int cv::RgbdNormals::getRows()
//
- (int)getRows NS_SWIFT_NAME(getRows());


//
//  void cv::RgbdNormals::setRows(int val)
//
- (void)setRows:(int)val NS_SWIFT_NAME(setRows(val:));


//
//  int cv::RgbdNormals::getCols()
//
- (int)getCols NS_SWIFT_NAME(getCols());


//
//  void cv::RgbdNormals::setCols(int val)
//
- (void)setCols:(int)val NS_SWIFT_NAME(setCols(val:));


//
//  int cv::RgbdNormals::getWindowSize()
//
- (int)getWindowSize NS_SWIFT_NAME(getWindowSize());


//
//  void cv::RgbdNormals::setWindowSize(int val)
//
- (void)setWindowSize:(int)val NS_SWIFT_NAME(setWindowSize(val:));


//
//  int cv::RgbdNormals::getDepth()
//
- (int)getDepth NS_SWIFT_NAME(getDepth());


//
//  void cv::RgbdNormals::getK(Mat& val)
//
- (void)getK:(Mat*)val NS_SWIFT_NAME(getK(val:));


//
//  void cv::RgbdNormals::setK(Mat val)
//
- (void)setK:(Mat*)val NS_SWIFT_NAME(setK(val:));


//
//  RgbdNormals_RgbdNormalsMethod cv::RgbdNormals::getMethod()
//
- (RgbdNormalsMethod)getMethod NS_SWIFT_NAME(getMethod());



@end

NS_ASSUME_NONNULL_END


