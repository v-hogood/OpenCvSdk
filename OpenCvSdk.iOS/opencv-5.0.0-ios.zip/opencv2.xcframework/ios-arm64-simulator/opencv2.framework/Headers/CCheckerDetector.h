//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/objdetect.hpp"
#import "opencv2/objdetect/mcc_checker_detector.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>
#import "Algorithm.h"

#import "Objdetect.h"
@class DetectorParametersMCC;
@class Mat;
@class Rect2i;



NS_ASSUME_NONNULL_BEGIN

// C++: class CCheckerDetector
/**
 * A class to find the positions of the ColorCharts in the image.
 *
 * Member of `Objdetect`
 */
CV_EXPORTS @interface CCheckerDetector : Algorithm


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::mcc::CCheckerDetector> nativePtrCCheckerDetector;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::mcc::CCheckerDetector>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::mcc::CCheckerDetector>)nativePtr;
#endif


#pragma mark - Methods


//
//  bool cv::mcc::CCheckerDetector::process(Mat image, vector_Rect regionsOfInterest, int nc = 1)
//
/**
 * Find the ColorCharts in the given image.
 *
 * The found charts are not returned but instead stored in the
 * detector, these can be accessed later on using getBestColorChecker()
 * and getListColorChecker()
 * @param image image in color space BGR
 * @param regionsOfInterest regions of image to look for the chart, if
 * it is empty, charts are looked for in the
 * entire image
 * @param nc number of charts in the image, if you don't know the exact
 * then keeping this number high helps.
 * @return true if atleast one chart is detected otherwise false
 */
- (BOOL)processWithROI:(Mat*)image regionsOfInterest:(NSArray<Rect2i*>*)regionsOfInterest nc:(int)nc NS_SWIFT_NAME(process(image:regionsOfInterest:nc:));

/**
 * Find the ColorCharts in the given image.
 *
 * The found charts are not returned but instead stored in the
 * detector, these can be accessed later on using getBestColorChecker()
 * and getListColorChecker()
 * @param image image in color space BGR
 * @param regionsOfInterest regions of image to look for the chart, if
 * it is empty, charts are looked for in the
 * entire image
 * then keeping this number high helps.
 * @return true if atleast one chart is detected otherwise false
 */
- (BOOL)processWithROI:(Mat*)image regionsOfInterest:(NSArray<Rect2i*>*)regionsOfInterest NS_SWIFT_NAME(process(image:regionsOfInterest:));


//
//  bool cv::mcc::CCheckerDetector::process(Mat image, int nc = 1)
//
/**
 * Find the ColorCharts in the given image.
 *
 * Differs from the above one only in the arguments.
 *
 * This version searches for the chart in the full image.
 *
 * The found charts are not returned but instead stored in the
 * detector, these can be accessed later on using getBestColorChecker()
 * and getListColorChecker()
 * @param image image in color space BGR
 * @param nc number of charts in the image, if you don't know the exact
 * then keeping this number high helps.
 * @return true if atleast one chart is detected otherwise false
 */
- (BOOL)process:(Mat*)image nc:(int)nc NS_SWIFT_NAME(process(image:nc:));

/**
 * Find the ColorCharts in the given image.
 *
 * Differs from the above one only in the arguments.
 *
 * This version searches for the chart in the full image.
 *
 * The found charts are not returned but instead stored in the
 * detector, these can be accessed later on using getBestColorChecker()
 * and getListColorChecker()
 * @param image image in color space BGR
 * then keeping this number high helps.
 * @return true if atleast one chart is detected otherwise false
 */
- (BOOL)process:(Mat*)image NS_SWIFT_NAME(process(image:));


//
//  Ptr_mcc_CChecker cv::mcc::CCheckerDetector::getBestColorChecker()
//
    // Return type 'Ptr_mcc_CChecker' is not supported, skipping the function


//
//  vector_Ptr_CChecker cv::mcc::CCheckerDetector::getListColorChecker()
//
    // Return type 'vector_Ptr_CChecker' is not supported, skipping the function


//
// static Ptr_CCheckerDetector cv::mcc::CCheckerDetector::create()
//
/**
 * Returns the implementation of the CCheckerDetector.
 *
 */
+ (CCheckerDetector*)create NS_SWIFT_NAME(create());


//
// static Ptr_CCheckerDetector cv::mcc::CCheckerDetector::create(dnn_Net net)
//
// Unknown type 'dnn_Net' (I), skipping the function


//
//  void cv::mcc::CCheckerDetector::draw(vector_Ptr_CChecker checkers, Mat& img, Scalar color = CV_RGB(0,250,0), int thickness = 2)
//
// Unknown type 'vector_Ptr_CChecker' (I), skipping the function


//
//  Mat cv::mcc::CCheckerDetector::getRefColors()
//
/**
 * Gets the reference color for chart.
 */
- (Mat*)getRefColors NS_SWIFT_NAME(getRefColors());


//
//  void cv::mcc::CCheckerDetector::setDetectionParams(DetectorParametersMCC params)
//
/**
 * Sets the detection paramaters for mcc.
 * @param params DetectorParametersMCC structure containing detection configuration parameters.
 */
- (void)setDetectionParams:(DetectorParametersMCC*)params NS_SWIFT_NAME(setDetectionParams(params:));


//
//  void cv::mcc::CCheckerDetector::setColorChartType(ColorChart chartType)
//
/**
 * Sets the color chart type for MCC detection.
 * @param chartType ColorChart enum specifying the type of color chart to detect.
 */
- (void)setColorChartType:(ColorChart)chartType NS_SWIFT_NAME(setColorChartType(chartType:));


//
//  void cv::mcc::CCheckerDetector::setUseDnnModel(bool useDnn)
//
/**
 * Enables or disables the use of the neural network for detection.
 * @param useDnn Boolean flag to indicate whether to use neural network (true) or not (false).
 */
- (void)setUseDnnModel:(BOOL)useDnn NS_SWIFT_NAME(setUseDnnModel(useDnn:));


//
//  bool cv::mcc::CCheckerDetector::getUseDnnModel()
//
- (BOOL)getUseDnnModel NS_SWIFT_NAME(getUseDnnModel());


//
//  DetectorParametersMCC cv::mcc::CCheckerDetector::getDetectionParams()
//
- (DetectorParametersMCC*)getDetectionParams NS_SWIFT_NAME(getDetectionParams());


//
//  ColorChart cv::mcc::CCheckerDetector::getColorChartType()
//
- (ColorChart)getColorChartType NS_SWIFT_NAME(getColorChartType());



@end

NS_ASSUME_NONNULL_END


