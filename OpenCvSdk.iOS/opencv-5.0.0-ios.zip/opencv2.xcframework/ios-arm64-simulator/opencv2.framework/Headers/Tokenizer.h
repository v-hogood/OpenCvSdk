//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/dnn.hpp"
#import "opencv2/dnn/dnn.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


@class IntVector;



NS_ASSUME_NONNULL_BEGIN

// C++: class Tokenizer
/**
 * High-level tokenizer wrapper for DNN usage.
 *
 * Provides a simple API to encode and decode tokens for LLMs.
 * Models are loaded via Tokenizer::load().
 *
 *
 * using namespace cv::dnn;
 * Tokenizer tok = Tokenizer::load("/path/to/model/");
 * std::vector<int> ids = tok.encode("hello world");
 * std::string text = tok.decode(ids);
 *
 *
 * Member of `Dnn`
 */
CV_EXPORTS @interface Tokenizer : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::dnn::Tokenizer> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::dnn::Tokenizer>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::dnn::Tokenizer>)nativePtr;
#endif


#pragma mark - Methods


//
// static Tokenizer cv::dnn::Tokenizer::load(string model_config)
//
/**
 * Load a tokenizer from a model directory.
 *
 * Expects the directory to contain:
 * - `config.json` with field `model_type` with value "gpt2" or "gpt4".
 * - `tokenizer.json` produced by the corresponding model family.
 *
 * The argument is a path prefix; this function concatenates file
 * names directly (e.g. `model_dir` + "config.json"), so `model_dir` must
 * end with an appropriate path separator.
 *
 * @param model_config  Path to config.json for model.
 * @return A Tokenizer ready for use. Throws cv::Exception if files are missing or `model_type` is unsupported.
 */
+ (Tokenizer*)load:(NSString*)model_config NS_SWIFT_NAME(load(model_config:));


//
//  vector_int cv::dnn::Tokenizer::encode(string text)
//
/**
 * Encode UTF-8 text to token ids (special tokens currently disabled).
 *
 * Calls the underlying `CoreBPE::encode` with an empty allowed-special set.
 *
 * @param text  UTF-8 input string.
 * @return Vector of token ids (32-bit ids narrowed to int for convenience).
 */
- (IntVector*)encode:(NSString*)text NS_SWIFT_NAME(encode(text:));


//
//  string cv::dnn::Tokenizer::decode(vector_int tokens)
//
- (NSString*)decode:(IntVector*)tokens NS_SWIFT_NAME(decode(tokens:));



@end

NS_ASSUME_NONNULL_END


