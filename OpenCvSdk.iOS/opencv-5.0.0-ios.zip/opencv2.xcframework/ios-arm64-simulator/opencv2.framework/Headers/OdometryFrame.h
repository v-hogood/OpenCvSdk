//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/odometry_frame.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "Ptcloud.h"
@class Mat;



NS_ASSUME_NONNULL_BEGIN

// C++: class OdometryFrame
/**
 * An object that keeps per-frame data for Odometry algorithms from user-provided images to algorithm-specific precalculated data.
 * When not empty, it contains a depth image, a mask of valid pixels and a set of pyramids generated from that data.
 * A BGR/Gray image and normals are optional.
 * OdometryFrame is made to be used together with Odometry class to reuse precalculated data between Rt data calculations.
 * A correct way to do that is to call Odometry::prepareFrames() on prev and next frames and then pass them to Odometry::compute() method.
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface OdometryFrame : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::OdometryFrame> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::OdometryFrame>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::OdometryFrame>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::OdometryFrame::OdometryFrame(Mat depth = Mat(), Mat image = Mat(), Mat mask = Mat(), Mat normals = Mat())
//
/**
 * Construct a new OdometryFrame object. All non-empty images should have the same size.
 *
 * @param depth A depth image, should be CV_8UC1
 * @param image An BGR or grayscale image (or noArray() if it's not required for used ICP algorithm).
 * Should be CV_8UC3 or CV_8C4 if it's BGR image or CV_8UC1 if it's grayscale. If it's BGR then it's converted to grayscale
 * image automatically.
 * @param mask A user-provided mask of valid pixels, should be CV_8UC1
 * @param normals A user-provided normals to the depth surface, should be CV_32FC4
 */
- (instancetype)initWithDepth:(Mat*)depth image:(Mat*)image mask:(Mat*)mask normals:(Mat*)normals;

/**
 * Construct a new OdometryFrame object. All non-empty images should have the same size.
 *
 * @param depth A depth image, should be CV_8UC1
 * @param image An BGR or grayscale image (or noArray() if it's not required for used ICP algorithm).
 * Should be CV_8UC3 or CV_8C4 if it's BGR image or CV_8UC1 if it's grayscale. If it's BGR then it's converted to grayscale
 * image automatically.
 * @param mask A user-provided mask of valid pixels, should be CV_8UC1
 */
- (instancetype)initWithDepth:(Mat*)depth image:(Mat*)image mask:(Mat*)mask;

/**
 * Construct a new OdometryFrame object. All non-empty images should have the same size.
 *
 * @param depth A depth image, should be CV_8UC1
 * @param image An BGR or grayscale image (or noArray() if it's not required for used ICP algorithm).
 * Should be CV_8UC3 or CV_8C4 if it's BGR image or CV_8UC1 if it's grayscale. If it's BGR then it's converted to grayscale
 * image automatically.
 */
- (instancetype)initWithDepth:(Mat*)depth image:(Mat*)image;

/**
 * Construct a new OdometryFrame object. All non-empty images should have the same size.
 *
 * @param depth A depth image, should be CV_8UC1
 * Should be CV_8UC3 or CV_8C4 if it's BGR image or CV_8UC1 if it's grayscale. If it's BGR then it's converted to grayscale
 * image automatically.
 */
- (instancetype)initWithDepth:(Mat*)depth;

/**
 * Construct a new OdometryFrame object. All non-empty images should have the same size.
 *
 * Should be CV_8UC3 or CV_8C4 if it's BGR image or CV_8UC1 if it's grayscale. If it's BGR then it's converted to grayscale
 * image automatically.
 */
- (instancetype)init;


//
//  void cv::OdometryFrame::getImage(Mat& image)
//
/**
 * Get the original user-provided BGR/Gray image
 *
 * @param image Output image
 */
- (void)getImage:(Mat*)image NS_SWIFT_NAME(getImage(image:));


//
//  void cv::OdometryFrame::getGrayImage(Mat& image)
//
/**
 * Get the gray image generated from the user-provided BGR/Gray image
 *
 * @param image Output image
 */
- (void)getGrayImage:(Mat*)image NS_SWIFT_NAME(getGrayImage(image:));


//
//  void cv::OdometryFrame::getDepth(Mat& depth)
//
/**
 * Get the original user-provided depth image
 *
 * @param depth Output image
 */
- (void)getDepth:(Mat*)depth NS_SWIFT_NAME(getDepth(depth:));


//
//  void cv::OdometryFrame::getProcessedDepth(Mat& depth)
//
/**
 * Get the depth image generated from the user-provided one after conversion, rescale or filtering for ICP algorithm needs
 *
 * @param depth Output image
 */
- (void)getProcessedDepth:(Mat*)depth NS_SWIFT_NAME(getProcessedDepth(depth:));


//
//  void cv::OdometryFrame::getMask(Mat& mask)
//
/**
 * Get the valid pixels mask generated for the ICP calculations intersected with the user-provided mask
 *
 * @param mask Output image
 */
- (void)getMask:(Mat*)mask NS_SWIFT_NAME(getMask(mask:));


//
//  void cv::OdometryFrame::getNormals(Mat& normals)
//
/**
 * Get the normals image either generated for the ICP calculations or user-provided
 *
 * @param normals Output image
 */
- (void)getNormals:(Mat*)normals NS_SWIFT_NAME(getNormals(normals:));


//
//  int cv::OdometryFrame::getPyramidLevels()
//
/**
 * Get the amount of levels in pyramids (all of them if not empty should have the same number of levels)
 * or 0 if no pyramids were prepared yet
 */
- (int)getPyramidLevels NS_SWIFT_NAME(getPyramidLevels());


//
//  void cv::OdometryFrame::getPyramidAt(Mat& img, OdometryFramePyramidType pyrType, size_t level)
//
/**
 * Get the image generated for the ICP calculations from one of the pyramids specified by pyrType. Returns empty image if
 * the pyramid is empty or there's no such pyramid level
 *
 * @param img Output image
 * @param pyrType Type of pyramid
 * @param level Level in the pyramid
 */
- (void)getPyramidAt:(Mat*)img pyrType:(OdometryFramePyramidType)pyrType level:(size_t)level NS_SWIFT_NAME(getPyramidAt(img:pyrType:level:));



@end

NS_ASSUME_NONNULL_END


