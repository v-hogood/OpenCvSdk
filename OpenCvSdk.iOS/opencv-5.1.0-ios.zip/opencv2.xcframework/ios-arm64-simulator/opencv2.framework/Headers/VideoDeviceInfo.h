//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/videoio.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "Videoio.h"



NS_ASSUME_NONNULL_BEGIN

// C++: class VideoDeviceInfo
/**
 * Camera device reported by a videoio backend
 *
 * Member of `Videoio`
 */
CV_EXPORTS @interface VideoDeviceInfo : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::VideoDeviceInfo> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::VideoDeviceInfo>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::VideoDeviceInfo>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::VideoDeviceInfo::VideoDeviceInfo()
//
- (instancetype)init;


    //
    // C++: int cv::VideoDeviceInfo::cam_idx
    //

@property int cam_idx;

    //
    // C++: string cv::VideoDeviceInfo::cam_name
    //

@property NSString* cam_name;

    //
    // C++: VideoCaptureAPIs cv::VideoDeviceInfo::backend
    //

@property VideoCaptureAPIs backend;


@end

NS_ASSUME_NONNULL_END


