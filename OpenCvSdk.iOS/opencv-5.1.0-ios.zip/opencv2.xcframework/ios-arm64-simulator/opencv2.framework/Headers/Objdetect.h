//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/objdetect.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>

@class Dictionary;
@class Mat;
@class Scalar;
@class Size2i;


// C++: enum CornerRefineMethod (cv.aruco.CornerRefineMethod)
typedef NS_ENUM(int, CornerRefineMethod) {
    CORNER_REFINE_NONE = 0,
    CORNER_REFINE_SUBPIX = 1,
    CORNER_REFINE_CONTOUR = 2,
    CORNER_REFINE_APRILTAG = 3
};


// C++: enum PredefinedDictionaryType (cv.aruco.PredefinedDictionaryType)
typedef NS_ENUM(int, PredefinedDictionaryType) {
    DICT_4X4_50 = 0,
    DICT_4X4_100 = 0+1,
    DICT_4X4_250 = 0+2,
    DICT_4X4_1000 = 0+3,
    DICT_5X5_50 = 0+4,
    DICT_5X5_100 = 0+5,
    DICT_5X5_250 = 0+6,
    DICT_5X5_1000 = 0+7,
    DICT_6X6_50 = 0+8,
    DICT_6X6_100 = 0+9,
    DICT_6X6_250 = 0+10,
    DICT_6X6_1000 = 0+11,
    DICT_7X7_50 = 0+12,
    DICT_7X7_100 = 0+13,
    DICT_7X7_250 = 0+14,
    DICT_7X7_1000 = 0+15,
    DICT_ARUCO_ORIGINAL = 0+16,
    DICT_APRILTAG_16h5 = 0+17,
    DICT_APRILTAG_25h9 = 0+18,
    DICT_APRILTAG_36h10 = 0+19,
    DICT_APRILTAG_36h11 = 0+20,
    DICT_ARUCO_MIP_36h12 = 0+21
};


// C++: enum ColorChart (cv.mcc.ColorChart)
typedef NS_ENUM(int, ColorChart) {
    MCC24 = 0,
    SG140 = 0+1,
    VINYL18 = 0+2
};



NS_ASSUME_NONNULL_BEGIN

// C++: class Objdetect
/**
 * The Objdetect module
 *
 * Member classes: `QRCodeEncoder`, `QRCodeEncoderParams`, `QRCodeDetector`, `QRCodeDetectorAruco`, `QRCodeDetectorArucoParams`, `CirclesGridFinderParameters`, `Board`, `GridBoard`, `CharucoBoard`, `DetectorParameters`, `RefineParameters`, `ArucoDetector`, `Dictionary`, `CChecker`, `DetectorParametersMCC`, `CCheckerDetector`, `GraphicalCodeDetector`, `FaceDetectorYN`, `FaceRecognizerSF`, `CharucoParameters`, `CharucoDetector`, `BarcodeDetector`
 *
 * Member enums: `EncodeMode`, `CorrectionLevel`, `ECIEncodings`, `GridType`, `CornerRefineMethod`, `PredefinedDictionaryType`, `ColorChart`, `DisType`
 */
CV_EXPORTS @interface Objdetect : NSObject

#pragma mark - Class Constants


@property (class, readonly) int CALIB_CB_ADAPTIVE_THRESH NS_SWIFT_NAME(CALIB_CB_ADAPTIVE_THRESH);
@property (class, readonly) int CALIB_CB_NORMALIZE_IMAGE NS_SWIFT_NAME(CALIB_CB_NORMALIZE_IMAGE);
@property (class, readonly) int CALIB_CB_FILTER_QUADS NS_SWIFT_NAME(CALIB_CB_FILTER_QUADS);
@property (class, readonly) int CALIB_CB_FAST_CHECK NS_SWIFT_NAME(CALIB_CB_FAST_CHECK);
@property (class, readonly) int CALIB_CB_EXHAUSTIVE NS_SWIFT_NAME(CALIB_CB_EXHAUSTIVE);
@property (class, readonly) int CALIB_CB_ACCURACY NS_SWIFT_NAME(CALIB_CB_ACCURACY);
@property (class, readonly) int CALIB_CB_LARGER NS_SWIFT_NAME(CALIB_CB_LARGER);
@property (class, readonly) int CALIB_CB_MARKER NS_SWIFT_NAME(CALIB_CB_MARKER);
@property (class, readonly) int CALIB_CB_PLAIN NS_SWIFT_NAME(CALIB_CB_PLAIN);
@property (class, readonly) int CALIB_CB_SYMMETRIC_GRID NS_SWIFT_NAME(CALIB_CB_SYMMETRIC_GRID);
@property (class, readonly) int CALIB_CB_ASYMMETRIC_GRID NS_SWIFT_NAME(CALIB_CB_ASYMMETRIC_GRID);
@property (class, readonly) int CALIB_CB_CLUSTERING NS_SWIFT_NAME(CALIB_CB_CLUSTERING);

#pragma mark - Methods


//
//  bool cv::findChessboardCorners(Mat image, Size patternSize, Mat& corners, int flags = CALIB_CB_ADAPTIVE_THRESH + CALIB_CB_NORMALIZE_IMAGE)
//
/**
 * Finds the positions of internal corners of the chessboard.
 *
 * @param image Source chessboard view. It must be an 8-bit grayscale or color image.
 * @param patternSize Number of inner corners per a chessboard row and column
 * ( patternSize = cv::Size(points_per_row,points_per_column) = cv::Size(columns,rows) ).
 * @param corners Output array of detected corners.
 * @param flags Various operation flags that can be zero or a combination of the following values:
 * -   *Ref:* CALIB_CB_ADAPTIVE_THRESH Use adaptive thresholding to convert the image to black
 * and white, rather than a fixed threshold level (computed from the average image brightness).
 * -   *Ref:* CALIB_CB_NORMALIZE_IMAGE Normalize the image gamma with equalizeHist before
 * applying fixed or adaptive thresholding.
 * -   *Ref:* CALIB_CB_FILTER_QUADS Use additional criteria (like contour area, perimeter,
 * square-like shape) to filter out false quads extracted at the contour retrieval stage.
 * -   *Ref:* CALIB_CB_FAST_CHECK Run a fast check on the image that looks for chessboard corners,
 * and shortcut the call if none is found. This can drastically speed up the call in the
 * degenerate condition when no chessboard is observed.
 * -   *Ref:* CALIB_CB_PLAIN All other flags are ignored. The input image is taken as is.
 * No image processing is done to improve to find the checkerboard. This has the effect of speeding up the
 * execution of the function but could lead to not recognizing the checkerboard if the image
 * is not previously binarized in the appropriate manner.
 *
 * @return True if all of the corners are found and placed in a certain order (row by row,
 * left to right in every row). Otherwise, if the function fails to find all the corners or reorder them,
 * it returns false.
 *
 * The function attempts to determine whether the input image is a view of the chessboard pattern and
 * locate the internal chessboard corners. For example, a regular chessboard has 8 x 8 squares and
 * 7 x 7 internal corners, that is, points where the black squares touch each other. The detected
 * coordinates are approximate, and to determine their positions more accurately, the function
 * calls #cornerSubPix. You also may use the function #cornerSubPix with different parameters if
 * returned coordinates are not accurate enough.
 *
 * Sample usage of detecting and drawing chessboard corners: :
 *
 *     Size patternsize(8,6); //interior number of corners
 *     Mat gray = ....; //source image
 *     vector<Point2f> corners; //this will be filled by the detected corners
 *
 *     //CALIB_CB_FAST_CHECK saves a lot of time on images
 *     //that do not contain any chessboard corners
 *     bool patternfound = findChessboardCorners(gray, patternsize, corners,
 *             CALIB_CB_ADAPTIVE_THRESH + CALIB_CB_NORMALIZE_IMAGE
 *             + CALIB_CB_FAST_CHECK);
 *
 *     if(patternfound)
 *       cornerSubPix(gray, corners, Size(11, 11), Size(-1, -1),
 *         TermCriteria(CV_TERMCRIT_EPS + CV_TERMCRIT_ITER, 30, 0.1));
 *
 *     drawChessboardCorners(img, patternsize, Mat(corners), patternfound);
 *
 * Note:* The function requires white space (like a square-thick border, the wider the better) around
 * the board to make the detection more robust in various environments. Otherwise, if there is no
 * border and the background is dark, the outer black squares cannot be segmented properly and so the
 * square grouping and ordering algorithm fails.
 *
 * Note:* The corners are returned row by row and left to right within each row, but whether that order
 * pins down a unique physical corner of the board depends on `patternSize`. The detector builds its
 * grid from the dark squares only, so it recognises a rotated board only when the rotation maps dark
 * squares onto dark squares. For a `patternSize` of w x h interior corners the squares form a
 * (w+1) x (h+1) grid, and a rotation by 180 degrees preserves that colouring exactly when w and h have
 * the same parity. Three cases follow. If w and h have different parity, as on the common 9x6 board,
 * the origin is unique and the ordering is repeatable across views. If w and h have the same parity
 * but differ, as on the 8x6 board used in the example above, the order is fixed only up to a rotation
 * by 180 degrees. If w equals h, the detector cannot tell rows from columns either, and the order is
 * fixed only up to a rotation by 90 degrees. Where the order is ambiguous, which one you get depends
 * on how the board happens to lie in the image. That does not affect camera calibration, since each
 * view absorbs the rotation into its own pose and the intrinsics come out the same, but it breaks
 * anything that assumes a fixed board coordinate frame across views, hand-eye calibration being the
 * usual case, where a flipped view silently corrupts the estimated transform. A plain chessboard image
 * does not carry the information needed to resolve the rotation, so it has to come from the pattern:
 * choose a board whose two dimensions have different parity, or use ``Objdetect/findChessboardCornersSB`` with
 * Ref:* CALIB_CB_MARKER, whose `meta` output identifies the origin, or a ChArUco board, where the
 * markers make the orientation unambiguous.
 *
 * Use the `generate_pattern.py` Python script (*Ref:* tutorial_camera_calibration_pattern)
 * to create the desired checkerboard pattern.
 */
+ (BOOL)findChessboardCorners:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners flags:(int)flags NS_SWIFT_NAME(findChessboardCorners(image:patternSize:corners:flags:));

/**
 * Finds the positions of internal corners of the chessboard.
 *
 * @param image Source chessboard view. It must be an 8-bit grayscale or color image.
 * @param patternSize Number of inner corners per a chessboard row and column
 * ( patternSize = cv::Size(points_per_row,points_per_column) = cv::Size(columns,rows) ).
 * @param corners Output array of detected corners.
 * -   *Ref:* CALIB_CB_ADAPTIVE_THRESH Use adaptive thresholding to convert the image to black
 * and white, rather than a fixed threshold level (computed from the average image brightness).
 * -   *Ref:* CALIB_CB_NORMALIZE_IMAGE Normalize the image gamma with equalizeHist before
 * applying fixed or adaptive thresholding.
 * -   *Ref:* CALIB_CB_FILTER_QUADS Use additional criteria (like contour area, perimeter,
 * square-like shape) to filter out false quads extracted at the contour retrieval stage.
 * -   *Ref:* CALIB_CB_FAST_CHECK Run a fast check on the image that looks for chessboard corners,
 * and shortcut the call if none is found. This can drastically speed up the call in the
 * degenerate condition when no chessboard is observed.
 * -   *Ref:* CALIB_CB_PLAIN All other flags are ignored. The input image is taken as is.
 * No image processing is done to improve to find the checkerboard. This has the effect of speeding up the
 * execution of the function but could lead to not recognizing the checkerboard if the image
 * is not previously binarized in the appropriate manner.
 *
 * @return True if all of the corners are found and placed in a certain order (row by row,
 * left to right in every row). Otherwise, if the function fails to find all the corners or reorder them,
 * it returns false.
 *
 * The function attempts to determine whether the input image is a view of the chessboard pattern and
 * locate the internal chessboard corners. For example, a regular chessboard has 8 x 8 squares and
 * 7 x 7 internal corners, that is, points where the black squares touch each other. The detected
 * coordinates are approximate, and to determine their positions more accurately, the function
 * calls #cornerSubPix. You also may use the function #cornerSubPix with different parameters if
 * returned coordinates are not accurate enough.
 *
 * Sample usage of detecting and drawing chessboard corners: :
 *
 *     Size patternsize(8,6); //interior number of corners
 *     Mat gray = ....; //source image
 *     vector<Point2f> corners; //this will be filled by the detected corners
 *
 *     //CALIB_CB_FAST_CHECK saves a lot of time on images
 *     //that do not contain any chessboard corners
 *     bool patternfound = findChessboardCorners(gray, patternsize, corners,
 *             CALIB_CB_ADAPTIVE_THRESH + CALIB_CB_NORMALIZE_IMAGE
 *             + CALIB_CB_FAST_CHECK);
 *
 *     if(patternfound)
 *       cornerSubPix(gray, corners, Size(11, 11), Size(-1, -1),
 *         TermCriteria(CV_TERMCRIT_EPS + CV_TERMCRIT_ITER, 30, 0.1));
 *
 *     drawChessboardCorners(img, patternsize, Mat(corners), patternfound);
 *
 * Note:* The function requires white space (like a square-thick border, the wider the better) around
 * the board to make the detection more robust in various environments. Otherwise, if there is no
 * border and the background is dark, the outer black squares cannot be segmented properly and so the
 * square grouping and ordering algorithm fails.
 *
 * Note:* The corners are returned row by row and left to right within each row, but whether that order
 * pins down a unique physical corner of the board depends on `patternSize`. The detector builds its
 * grid from the dark squares only, so it recognises a rotated board only when the rotation maps dark
 * squares onto dark squares. For a `patternSize` of w x h interior corners the squares form a
 * (w+1) x (h+1) grid, and a rotation by 180 degrees preserves that colouring exactly when w and h have
 * the same parity. Three cases follow. If w and h have different parity, as on the common 9x6 board,
 * the origin is unique and the ordering is repeatable across views. If w and h have the same parity
 * but differ, as on the 8x6 board used in the example above, the order is fixed only up to a rotation
 * by 180 degrees. If w equals h, the detector cannot tell rows from columns either, and the order is
 * fixed only up to a rotation by 90 degrees. Where the order is ambiguous, which one you get depends
 * on how the board happens to lie in the image. That does not affect camera calibration, since each
 * view absorbs the rotation into its own pose and the intrinsics come out the same, but it breaks
 * anything that assumes a fixed board coordinate frame across views, hand-eye calibration being the
 * usual case, where a flipped view silently corrupts the estimated transform. A plain chessboard image
 * does not carry the information needed to resolve the rotation, so it has to come from the pattern:
 * choose a board whose two dimensions have different parity, or use ``Objdetect/findChessboardCornersSB`` with
 * Ref:* CALIB_CB_MARKER, whose `meta` output identifies the origin, or a ChArUco board, where the
 * markers make the orientation unambiguous.
 *
 * Use the `generate_pattern.py` Python script (*Ref:* tutorial_camera_calibration_pattern)
 * to create the desired checkerboard pattern.
 */
+ (BOOL)findChessboardCorners:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners NS_SWIFT_NAME(findChessboardCorners(image:patternSize:corners:));


//
//  bool cv::checkChessboard(Mat img, Size size)
//
/**
 * Checks whether the image contains chessboard of the specific size or not.
 *
 * @param img Source chessboard view.
 * @param size Size of the chessboard.
 *
 * @return Whether a chessboard was found.
 */
+ (BOOL)checkChessboard:(Mat*)img size:(Size2i*)size NS_SWIFT_NAME(checkChessboard(img:size:));


//
//  bool cv::findChessboardCornersSB(Mat image, Size patternSize, Mat& corners, int flags, Mat& meta)
//
/**
 * Finds the positions of internal corners of the chessboard using a sector based approach.
 *
 * @param image Source chessboard view. It must be an 8-bit grayscale or color image.
 * @param patternSize Number of inner corners per a chessboard row and column
 * ( patternSize = cv::Size(points_per_row,points_per_column) = cv::Size(columns,rows) ).
 * @param corners Output array of detected corners.
 * @param flags Various operation flags that can be zero or a combination of the following values:
 * -   *Ref:* CALIB_CB_NORMALIZE_IMAGE Normalize the image gamma with equalizeHist before detection.
 * -   *Ref:* CALIB_CB_EXHAUSTIVE Run an exhaustive search to improve detection rate.
 * -   *Ref:* CALIB_CB_ACCURACY Up sample input image to improve sub-pixel accuracy due to aliasing effects.
 * -   *Ref:* CALIB_CB_LARGER The detected pattern is allowed to be larger than patternSize (see description).
 * -   *Ref:* CALIB_CB_MARKER The detected pattern must have a marker (see description).
 * This should be used if an accurate camera calibration is required.
 * @param meta Optional output array of detected corners (CV_8UC1 and size = cv::Size(columns,rows)).
 * Each entry stands for one corner of the pattern and can have one of the following values:
 * -   0 = no meta data attached
 * -   1 = left-top corner of a black cell
 * -   2 = left-top corner of a white cell
 * -   3 = left-top corner of a black cell with a white marker dot
 * -   4 = left-top corner of a white cell with a black marker dot (pattern origin in case of markers otherwise first corner)
 *
 * The function is analog to ``Objdetect/findChessboardCorners`` but uses a localized radon
 * transformation approximated by box filters being more robust to all sort of
 * noise, faster on larger images and is able to directly return the sub-pixel
 * position of the internal chessboard corners. The Method is based on the paper
 * Cite:* duda2018 "Accurate Detection and Localization of Checkerboard Corners for
 * Calibration" demonstrating that the returned sub-pixel positions are more
 * accurate than the one returned by cornerSubPix allowing a precise camera
 * calibration for demanding applications.
 *
 * In the case, the flags *Ref:* CALIB_CB_LARGER or *Ref:* CALIB_CB_MARKER are given,
 * the result can be recovered from the optional meta array. Both flags are
 * helpful to use calibration patterns exceeding the field of view of the camera.
 * These oversized patterns allow more accurate calibrations as corners can be
 * utilized, which are as close as possible to the image borders.  For a
 * consistent coordinate system across all images, the optional marker (see image
 * below) can be used to move the origin of the board to the location where the
 * black circle is located.
 *
 * Note:* The function requires a white boarder with roughly the same width as one
 * of the checkerboard fields around the whole board to improve the detection in
 * various environments. In addition, because of the localized radon
 * transformation it is beneficial to use round corners for the field corners
 * which are located on the outside of the board. The following figure illustrates
 * a sample checkerboard optimized for the detection. However, any other checkerboard
 * can be used as well.
 *
 * Use the `generate_pattern.py` Python script (*Ref:* tutorial_camera_calibration_pattern)
 * to create the corresponding checkerboard pattern:
 * \image html pics/checkerboard_radon.png width=60%
 */
+ (BOOL)findChessboardCornersSBWithMeta:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners flags:(int)flags meta:(Mat*)meta NS_SWIFT_NAME(findChessboardCornersSB(image:patternSize:corners:flags:meta:));


//
//  bool cv::findChessboardCornersSB(Mat image, Size patternSize, Mat& corners, int flags = 0)
//
+ (BOOL)findChessboardCornersSB:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners flags:(int)flags NS_SWIFT_NAME(findChessboardCornersSB(image:patternSize:corners:flags:));

+ (BOOL)findChessboardCornersSB:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners NS_SWIFT_NAME(findChessboardCornersSB(image:patternSize:corners:));


//
//  Scalar cv::estimateChessboardSharpness(Mat image, Size patternSize, Mat corners, float rise_distance = 0.8F, bool vertical = false, Mat& sharpness = Mat())
//
/**
 * Estimates the sharpness of a detected chessboard.
 *
 * Image sharpness, as well as brightness, are a critical parameter for accuracte
 * camera calibration. For accessing these parameters for filtering out
 * problematic calibraiton images, this method calculates edge profiles by traveling from
 * black to white chessboard cell centers. Based on this, the number of pixels is
 * calculated required to transit from black to white. This width of the
 * transition area is a good indication of how sharp the chessboard is imaged
 * and should be below ~3.0 pixels.
 *
 * @param image Gray image used to find chessboard corners
 * @param patternSize Size of a found chessboard pattern
 * @param corners Corners found by ``Objdetect/findChessboardCornersSB``
 * @param rise_distance Rise distance 0.8 means 10% ... 90% of the final signal strength
 * @param vertical By default edge responses for horizontal lines are calculated
 * @param sharpness Optional output array with a sharpness value for calculated edge responses (see description)
 *
 * The optional sharpness array is of type CV_32FC1 and has for each calculated
 * profile one row with the following five entries:
 * 0 = x coordinate of the underlying edge in the image
 * 1 = y coordinate of the underlying edge in the image
 * 2 = width of the transition area (sharpness)
 * 3 = signal strength in the black cell (min brightness)
 * 4 = signal strength in the white cell (max brightness)
 *
 * @return Scalar(average sharpness, average min brightness, average max brightness,0)
 */
+ (Scalar*)estimateChessboardSharpness:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners rise_distance:(float)rise_distance vertical:(BOOL)vertical sharpness:(Mat*)sharpness NS_SWIFT_NAME(estimateChessboardSharpness(image:patternSize:corners:rise_distance:vertical:sharpness:));

/**
 * Estimates the sharpness of a detected chessboard.
 *
 * Image sharpness, as well as brightness, are a critical parameter for accuracte
 * camera calibration. For accessing these parameters for filtering out
 * problematic calibraiton images, this method calculates edge profiles by traveling from
 * black to white chessboard cell centers. Based on this, the number of pixels is
 * calculated required to transit from black to white. This width of the
 * transition area is a good indication of how sharp the chessboard is imaged
 * and should be below ~3.0 pixels.
 *
 * @param image Gray image used to find chessboard corners
 * @param patternSize Size of a found chessboard pattern
 * @param corners Corners found by ``Objdetect/findChessboardCornersSB``
 * @param rise_distance Rise distance 0.8 means 10% ... 90% of the final signal strength
 * @param vertical By default edge responses for horizontal lines are calculated
 *
 * The optional sharpness array is of type CV_32FC1 and has for each calculated
 * profile one row with the following five entries:
 * 0 = x coordinate of the underlying edge in the image
 * 1 = y coordinate of the underlying edge in the image
 * 2 = width of the transition area (sharpness)
 * 3 = signal strength in the black cell (min brightness)
 * 4 = signal strength in the white cell (max brightness)
 *
 * @return Scalar(average sharpness, average min brightness, average max brightness,0)
 */
+ (Scalar*)estimateChessboardSharpness:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners rise_distance:(float)rise_distance vertical:(BOOL)vertical NS_SWIFT_NAME(estimateChessboardSharpness(image:patternSize:corners:rise_distance:vertical:));

/**
 * Estimates the sharpness of a detected chessboard.
 *
 * Image sharpness, as well as brightness, are a critical parameter for accuracte
 * camera calibration. For accessing these parameters for filtering out
 * problematic calibraiton images, this method calculates edge profiles by traveling from
 * black to white chessboard cell centers. Based on this, the number of pixels is
 * calculated required to transit from black to white. This width of the
 * transition area is a good indication of how sharp the chessboard is imaged
 * and should be below ~3.0 pixels.
 *
 * @param image Gray image used to find chessboard corners
 * @param patternSize Size of a found chessboard pattern
 * @param corners Corners found by ``Objdetect/findChessboardCornersSB``
 * @param rise_distance Rise distance 0.8 means 10% ... 90% of the final signal strength
 *
 * The optional sharpness array is of type CV_32FC1 and has for each calculated
 * profile one row with the following five entries:
 * 0 = x coordinate of the underlying edge in the image
 * 1 = y coordinate of the underlying edge in the image
 * 2 = width of the transition area (sharpness)
 * 3 = signal strength in the black cell (min brightness)
 * 4 = signal strength in the white cell (max brightness)
 *
 * @return Scalar(average sharpness, average min brightness, average max brightness,0)
 */
+ (Scalar*)estimateChessboardSharpness:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners rise_distance:(float)rise_distance NS_SWIFT_NAME(estimateChessboardSharpness(image:patternSize:corners:rise_distance:));

/**
 * Estimates the sharpness of a detected chessboard.
 *
 * Image sharpness, as well as brightness, are a critical parameter for accuracte
 * camera calibration. For accessing these parameters for filtering out
 * problematic calibraiton images, this method calculates edge profiles by traveling from
 * black to white chessboard cell centers. Based on this, the number of pixels is
 * calculated required to transit from black to white. This width of the
 * transition area is a good indication of how sharp the chessboard is imaged
 * and should be below ~3.0 pixels.
 *
 * @param image Gray image used to find chessboard corners
 * @param patternSize Size of a found chessboard pattern
 * @param corners Corners found by ``Objdetect/findChessboardCornersSB``
 *
 * The optional sharpness array is of type CV_32FC1 and has for each calculated
 * profile one row with the following five entries:
 * 0 = x coordinate of the underlying edge in the image
 * 1 = y coordinate of the underlying edge in the image
 * 2 = width of the transition area (sharpness)
 * 3 = signal strength in the black cell (min brightness)
 * 4 = signal strength in the white cell (max brightness)
 *
 * @return Scalar(average sharpness, average min brightness, average max brightness,0)
 */
+ (Scalar*)estimateChessboardSharpness:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners NS_SWIFT_NAME(estimateChessboardSharpness(image:patternSize:corners:));


//
//  bool cv::find4QuadCornerSubpix(Mat img, Mat& corners, Size region_size)
//
+ (BOOL)find4QuadCornerSubpix:(Mat*)img corners:(Mat*)corners region_size:(Size2i*)region_size NS_SWIFT_NAME(find4QuadCornerSubpix(img:corners:region_size:));


//
//  void cv::drawChessboardCorners(Mat& image, Size patternSize, Mat corners, bool patternWasFound)
//
/**
 * Renders the detected chessboard corners.
 *
 * @param image Destination image. It must be an 8-bit color image.
 * @param patternSize Number of inner corners per a chessboard row and column
 * (patternSize = cv::Size(points_per_row,points_per_column)).
 * @param corners Array of detected corners, the output of ``Objdetect/findChessboardCorners``.
 * @param patternWasFound Parameter indicating whether the complete board was found or not. The
 * return value of ``Objdetect/findChessboardCorners`` should be passed here.
 *
 * The function draws individual chessboard corners detected either as red circles if the board was not
 * found, or as colored corners connected with lines if the board was found.
 */
+ (void)drawChessboardCorners:(Mat*)image patternSize:(Size2i*)patternSize corners:(Mat*)corners patternWasFound:(BOOL)patternWasFound NS_SWIFT_NAME(drawChessboardCorners(image:patternSize:corners:patternWasFound:));


//
//  bool cv::findCirclesGrid(Mat image, Size patternSize, Mat& centers, int flags, Ptr_FeatureDetector blobDetector, CirclesGridFinderParameters parameters)
//
// Unknown type 'Ptr_FeatureDetector' (I), skipping the function


//
//  bool cv::findCirclesGrid(Mat image, Size patternSize, Mat& centers, int flags = CALIB_CB_SYMMETRIC_GRID,  _hidden_  blobDetector = cv::SimpleBlobDetector::create())
//
+ (BOOL)findCirclesGrid:(Mat*)image patternSize:(Size2i*)patternSize centers:(Mat*)centers flags:(int)flags NS_SWIFT_NAME(findCirclesGrid(image:patternSize:centers:flags:));

+ (BOOL)findCirclesGrid:(Mat*)image patternSize:(Size2i*)patternSize centers:(Mat*)centers NS_SWIFT_NAME(findCirclesGrid(image:patternSize:centers:));


//
//  void cv::aruco::drawDetectedMarkers(Mat& image, vector_Mat corners, Mat ids = Mat(), Scalar borderColor = Scalar(0, 255, 0))
//
/**
 * Draw detected markers in image
 *
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not altered.
 * @param corners positions of marker corners on input image.
 * (e.g std::vector<std::vector<cv::Point2f> > ). For N detected markers, the dimensions of
 * this array should be Nx4. The order of the corners should be clockwise.
 * @param ids vector of identifiers for markers in markersCorners .
 * Optional, if not provided, ids are not painted.
 * @param borderColor color of marker borders. Rest of colors (text color and first corner color)
 * are calculated based on this one to improve visualization.
 *
 * Given an array of detected marker corners and its corresponding ids, this functions draws
 * the markers in the image. The marker borders are painted and the markers identifiers if provided.
 * Useful for debugging purposes.
 */
+ (void)drawDetectedMarkers:(Mat*)image corners:(NSArray<Mat*>*)corners ids:(Mat*)ids borderColor:(Scalar*)borderColor NS_SWIFT_NAME(drawDetectedMarkers(image:corners:ids:borderColor:));

/**
 * Draw detected markers in image
 *
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not altered.
 * @param corners positions of marker corners on input image.
 * (e.g std::vector<std::vector<cv::Point2f> > ). For N detected markers, the dimensions of
 * this array should be Nx4. The order of the corners should be clockwise.
 * @param ids vector of identifiers for markers in markersCorners .
 * Optional, if not provided, ids are not painted.
 * are calculated based on this one to improve visualization.
 *
 * Given an array of detected marker corners and its corresponding ids, this functions draws
 * the markers in the image. The marker borders are painted and the markers identifiers if provided.
 * Useful for debugging purposes.
 */
+ (void)drawDetectedMarkers:(Mat*)image corners:(NSArray<Mat*>*)corners ids:(Mat*)ids NS_SWIFT_NAME(drawDetectedMarkers(image:corners:ids:));

/**
 * Draw detected markers in image
 *
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not altered.
 * @param corners positions of marker corners on input image.
 * (e.g std::vector<std::vector<cv::Point2f> > ). For N detected markers, the dimensions of
 * this array should be Nx4. The order of the corners should be clockwise.
 * Optional, if not provided, ids are not painted.
 * are calculated based on this one to improve visualization.
 *
 * Given an array of detected marker corners and its corresponding ids, this functions draws
 * the markers in the image. The marker borders are painted and the markers identifiers if provided.
 * Useful for debugging purposes.
 */
+ (void)drawDetectedMarkers:(Mat*)image corners:(NSArray<Mat*>*)corners NS_SWIFT_NAME(drawDetectedMarkers(image:corners:));


//
//  void cv::aruco::generateImageMarker(Dictionary dictionary, int id, int sidePixels, Mat& img, int borderBits = 1)
//
/**
 * Generate a canonical marker image
 *
 * @param dictionary dictionary of markers indicating the type of markers
 * @param id identifier of the marker that will be returned. It has to be a valid id in the specified dictionary.
 * @param sidePixels size of the image in pixels
 * @param img output image with the marker
 * @param borderBits width of the marker border.
 *
 * This function returns a marker image in its canonical form (i.e. ready to be printed)
 */
+ (void)generateImageMarker:(Dictionary*)dictionary id:(int)id sidePixels:(int)sidePixels img:(Mat*)img borderBits:(int)borderBits NS_SWIFT_NAME(generateImageMarker(dictionary:id:sidePixels:img:borderBits:));

/**
 * Generate a canonical marker image
 *
 * @param dictionary dictionary of markers indicating the type of markers
 * @param id identifier of the marker that will be returned. It has to be a valid id in the specified dictionary.
 * @param sidePixels size of the image in pixels
 * @param img output image with the marker
 *
 * This function returns a marker image in its canonical form (i.e. ready to be printed)
 */
+ (void)generateImageMarker:(Dictionary*)dictionary id:(int)id sidePixels:(int)sidePixels img:(Mat*)img NS_SWIFT_NAME(generateImageMarker(dictionary:id:sidePixels:img:));


//
//  Dictionary cv::aruco::getPredefinedDictionary(int dict)
//
/**
 * Returns one of the predefined dictionaries referenced by DICT_*.
 */
+ (Dictionary*)getPredefinedDictionary:(int)dict NS_SWIFT_NAME(getPredefinedDictionary(dict:));


//
//  Dictionary cv::aruco::extendDictionary(int nMarkers, int markerSize, Dictionary baseDictionary = Dictionary(), int randomSeed = 0)
//
/**
 * Extend base dictionary by new nMarkers
 *
 * @param nMarkers number of markers in the dictionary
 * @param markerSize number of bits per dimension of each markers
 * @param baseDictionary Include the markers in this dictionary at the beginning (optional)
 * @param randomSeed a user supplied seed for theRNG()
 *
 * This function creates a new dictionary composed by nMarkers markers and each markers composed
 * by markerSize x markerSize bits. If baseDictionary is provided, its markers are directly
 * included and the rest are generated based on them. If the size of baseDictionary is higher
 * than nMarkers, only the first nMarkers in baseDictionary are taken and no new marker is added.
 */
+ (Dictionary*)extendDictionary:(int)nMarkers markerSize:(int)markerSize baseDictionary:(Dictionary*)baseDictionary randomSeed:(int)randomSeed NS_SWIFT_NAME(extendDictionary(nMarkers:markerSize:baseDictionary:randomSeed:));

/**
 * Extend base dictionary by new nMarkers
 *
 * @param nMarkers number of markers in the dictionary
 * @param markerSize number of bits per dimension of each markers
 * @param baseDictionary Include the markers in this dictionary at the beginning (optional)
 *
 * This function creates a new dictionary composed by nMarkers markers and each markers composed
 * by markerSize x markerSize bits. If baseDictionary is provided, its markers are directly
 * included and the rest are generated based on them. If the size of baseDictionary is higher
 * than nMarkers, only the first nMarkers in baseDictionary are taken and no new marker is added.
 */
+ (Dictionary*)extendDictionary:(int)nMarkers markerSize:(int)markerSize baseDictionary:(Dictionary*)baseDictionary NS_SWIFT_NAME(extendDictionary(nMarkers:markerSize:baseDictionary:));

/**
 * Extend base dictionary by new nMarkers
 *
 * @param nMarkers number of markers in the dictionary
 * @param markerSize number of bits per dimension of each markers
 *
 * This function creates a new dictionary composed by nMarkers markers and each markers composed
 * by markerSize x markerSize bits. If baseDictionary is provided, its markers are directly
 * included and the rest are generated based on them. If the size of baseDictionary is higher
 * than nMarkers, only the first nMarkers in baseDictionary are taken and no new marker is added.
 */
+ (Dictionary*)extendDictionary:(int)nMarkers markerSize:(int)markerSize NS_SWIFT_NAME(extendDictionary(nMarkers:markerSize:));


//
//  void cv::aruco::drawDetectedCornersCharuco(Mat& image, Mat charucoCorners, Mat charucoIds = Mat(), Scalar cornerColor = Scalar(255, 0, 0))
//
/**
 * Draws a set of Charuco corners
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not
 * altered.
 * @param charucoCorners vector of detected charuco corners
 * @param charucoIds list of identifiers for each corner in charucoCorners
 * @param cornerColor color of the square surrounding each corner
 *
 * This function draws a set of detected Charuco corners. If identifiers vector is provided, it also
 * draws the id of each corner.
 */
+ (void)drawDetectedCornersCharuco:(Mat*)image charucoCorners:(Mat*)charucoCorners charucoIds:(Mat*)charucoIds cornerColor:(Scalar*)cornerColor NS_SWIFT_NAME(drawDetectedCornersCharuco(image:charucoCorners:charucoIds:cornerColor:));

/**
 * Draws a set of Charuco corners
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not
 * altered.
 * @param charucoCorners vector of detected charuco corners
 * @param charucoIds list of identifiers for each corner in charucoCorners
 *
 * This function draws a set of detected Charuco corners. If identifiers vector is provided, it also
 * draws the id of each corner.
 */
+ (void)drawDetectedCornersCharuco:(Mat*)image charucoCorners:(Mat*)charucoCorners charucoIds:(Mat*)charucoIds NS_SWIFT_NAME(drawDetectedCornersCharuco(image:charucoCorners:charucoIds:));

/**
 * Draws a set of Charuco corners
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not
 * altered.
 * @param charucoCorners vector of detected charuco corners
 *
 * This function draws a set of detected Charuco corners. If identifiers vector is provided, it also
 * draws the id of each corner.
 */
+ (void)drawDetectedCornersCharuco:(Mat*)image charucoCorners:(Mat*)charucoCorners NS_SWIFT_NAME(drawDetectedCornersCharuco(image:charucoCorners:));


//
//  void cv::aruco::drawDetectedDiamonds(Mat& image, vector_Mat diamondCorners, Mat diamondIds = Mat(), Scalar borderColor = Scalar(0, 0, 255))
//
/**
 * Draw a set of detected ChArUco Diamond markers
 *
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not
 * altered.
 * @param diamondCorners positions of diamond corners in the same format returned by
 * detectCharucoDiamond(). (e.g std::vector<std::vector<cv::Point2f> > ). For N detected markers,
 * the dimensions of this array should be Nx4. The order of the corners should be clockwise.
 * @param diamondIds vector of identifiers for diamonds in diamondCorners, in the same format
 * returned by detectCharucoDiamond() (e.g. std::vector<Vec4i>).
 * Optional, if not provided, ids are not painted.
 * @param borderColor color of marker borders. Rest of colors (text color and first corner color)
 * are calculated based on this one.
 *
 * Given an array of detected diamonds, this functions draws them in the image. The marker borders
 * are painted and the markers identifiers if provided.
 * Useful for debugging purposes.
 */
+ (void)drawDetectedDiamonds:(Mat*)image diamondCorners:(NSArray<Mat*>*)diamondCorners diamondIds:(Mat*)diamondIds borderColor:(Scalar*)borderColor NS_SWIFT_NAME(drawDetectedDiamonds(image:diamondCorners:diamondIds:borderColor:));

/**
 * Draw a set of detected ChArUco Diamond markers
 *
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not
 * altered.
 * @param diamondCorners positions of diamond corners in the same format returned by
 * detectCharucoDiamond(). (e.g std::vector<std::vector<cv::Point2f> > ). For N detected markers,
 * the dimensions of this array should be Nx4. The order of the corners should be clockwise.
 * @param diamondIds vector of identifiers for diamonds in diamondCorners, in the same format
 * returned by detectCharucoDiamond() (e.g. std::vector<Vec4i>).
 * Optional, if not provided, ids are not painted.
 * are calculated based on this one.
 *
 * Given an array of detected diamonds, this functions draws them in the image. The marker borders
 * are painted and the markers identifiers if provided.
 * Useful for debugging purposes.
 */
+ (void)drawDetectedDiamonds:(Mat*)image diamondCorners:(NSArray<Mat*>*)diamondCorners diamondIds:(Mat*)diamondIds NS_SWIFT_NAME(drawDetectedDiamonds(image:diamondCorners:diamondIds:));

/**
 * Draw a set of detected ChArUco Diamond markers
 *
 * @param image input/output image. It must have 1 or 3 channels. The number of channels is not
 * altered.
 * @param diamondCorners positions of diamond corners in the same format returned by
 * detectCharucoDiamond(). (e.g std::vector<std::vector<cv::Point2f> > ). For N detected markers,
 * the dimensions of this array should be Nx4. The order of the corners should be clockwise.
 * returned by detectCharucoDiamond() (e.g. std::vector<Vec4i>).
 * Optional, if not provided, ids are not painted.
 * are calculated based on this one.
 *
 * Given an array of detected diamonds, this functions draws them in the image. The marker borders
 * are painted and the markers identifiers if provided.
 * Useful for debugging purposes.
 */
+ (void)drawDetectedDiamonds:(Mat*)image diamondCorners:(NSArray<Mat*>*)diamondCorners NS_SWIFT_NAME(drawDetectedDiamonds(image:diamondCorners:));



@end

NS_ASSUME_NONNULL_END


