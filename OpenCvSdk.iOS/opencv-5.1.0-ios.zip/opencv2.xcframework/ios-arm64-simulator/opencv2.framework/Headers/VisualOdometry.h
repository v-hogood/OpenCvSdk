//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/slam/visual_odometry.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "Ptcloud.h"
@class DescriptorMatcher;
@class Feature2D;
@class Mat;
@class OdometryParams;



NS_ASSUME_NONNULL_BEGIN

// C++: class VisualOdometry
/**
 * Monocular visual odometry pipeline.
 *
 * State machine: NOT_INITIALIZED → INITIALIZING (H/F two-view bootstrap) → TRACKING
 * (per-frame PnP + local-map refinement). Tracking failure rewinds to INITIALIZING.
 *
 * Purely in-memory: feed images with *Ref:* processFrame and read back the trajectory
 * and map with *Ref:* getTrajectory / *Ref:* getMap. See samples/slam for driving this
 * from a directory of images and writing the result to disk (e.g. COLMAP format).
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface VisualOdometry : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::slam::VisualOdometry> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::slam::VisualOdometry>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::slam::VisualOdometry>)nativePtr;
#endif


#pragma mark - Methods


//
// static Ptr_VisualOdometry cv::slam::VisualOdometry::create(Ptr_Feature2D detector, Ptr_DescriptorMatcher matcher, Mat cameraMatrix, Mat distCoeffs = Mat(), OdometryParams params = OdometryParams())
//
+ (VisualOdometry*)create:(Feature2D*)detector matcher:(DescriptorMatcher*)matcher cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs params:(OdometryParams*)params NS_SWIFT_NAME(create(detector:matcher:cameraMatrix:distCoeffs:params:));

+ (VisualOdometry*)create:(Feature2D*)detector matcher:(DescriptorMatcher*)matcher cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs NS_SWIFT_NAME(create(detector:matcher:cameraMatrix:distCoeffs:));

+ (VisualOdometry*)create:(Feature2D*)detector matcher:(DescriptorMatcher*)matcher cameraMatrix:(Mat*)cameraMatrix NS_SWIFT_NAME(create(detector:matcher:cameraMatrix:));


//
//  bool cv::slam::VisualOdometry::processFrame(Mat image)
//
/**
 * Feed one image. Returns true if a pose was emitted.
 */
- (BOOL)processFrame:(Mat*)image NS_SWIFT_NAME(processFrame(image:));


//
//  void cv::slam::VisualOdometry::reset()
//
/**
 * Reset to NOT_INITIALIZED, clearing map and trajectory.
 */
- (void)reset NS_SWIFT_NAME(reset());


//
//  OdometryState cv::slam::VisualOdometry::getState()
//
- (OdometryState)getState NS_SWIFT_NAME(getState());


//
//  Matx44d cv::slam::VisualOdometry::getLastPose()
//
    // Return type 'Matx44d' is not supported, skipping the function


//
//  int cv::slam::VisualOdometry::getNumKeyframes()
//
- (int)getNumKeyframes NS_SWIFT_NAME(getNumKeyframes());


//
//  int cv::slam::VisualOdometry::getNumMapPoints()
//
- (int)getNumMapPoints NS_SWIFT_NAME(getNumMapPoints());


//
//  vector_Matx44d cv::slam::VisualOdometry::getTrajectory()
//
    // Return type 'vector_Matx44d' is not supported, skipping the function


//
//  OdometryParams cv::slam::VisualOdometry::getParams()
//
- (OdometryParams*)getParams NS_SWIFT_NAME(getParams());


//
//  void cv::slam::VisualOdometry::setParams(OdometryParams params)
//
- (void)setParams:(OdometryParams*)params NS_SWIFT_NAME(setParams(params:));



@end

NS_ASSUME_NONNULL_END


