//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/slam/odometry_params.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>






NS_ASSUME_NONNULL_BEGIN

// C++: class OdometryParams
/**
 * Tunable parameters for visual odometry: initialization, tracking, keyframe selection, and local-map refinement.
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface OdometryParams : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::slam::OdometryParams> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::slam::OdometryParams>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::slam::OdometryParams>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::slam::OdometryParams::OdometryParams()
//
- (instancetype)init;


    //
    // C++: int cv::slam::OdometryParams::minInitInliers
    //

@property int minInitInliers;

    //
    // C++: double cv::slam::OdometryParams::minInitParallaxDeg
    //

@property double minInitParallaxDeg;

    //
    // C++: int cv::slam::OdometryParams::minInitPoints
    //

@property int minInitPoints;

    //
    // C++: double cv::slam::OdometryParams::hfRatioThresh
    //

@property double hfRatioThresh;

    //
    // C++: double cv::slam::OdometryParams::minGrowthParallaxDeg
    //

@property double minGrowthParallaxDeg;

    //
    // C++: double cv::slam::OdometryParams::essentialRansacThresh
    //

@property double essentialRansacThresh;

    //
    // C++: double cv::slam::OdometryParams::essentialRansacConfidence
    //

@property double essentialRansacConfidence;

    //
    // C++: double cv::slam::OdometryParams::pnpReprojThresh
    //

@property double pnpReprojThresh;

    //
    // C++: int cv::slam::OdometryParams::pnpMinInliers
    //

@property int pnpMinInliers;

    //
    // C++: int cv::slam::OdometryParams::pnpRansacIters
    //

@property int pnpRansacIters;

    //
    // C++: double cv::slam::OdometryParams::pnpConfidence
    //

@property double pnpConfidence;

    //
    // C++: double cv::slam::OdometryParams::motionModelRadius
    //

@property double motionModelRadius;

    //
    // C++: double cv::slam::OdometryParams::motionModelRadiusWide
    //

@property double motionModelRadiusWide;

    //
    // C++: int cv::slam::OdometryParams::motionModelMinMatches
    //

@property int motionModelMinMatches;

    //
    // C++: double cv::slam::OdometryParams::descProjThresh
    //

@property double descProjThresh;

    //
    // C++: int cv::slam::OdometryParams::opticalFlowMinInliers
    //

@property int opticalFlowMinInliers;

    //
    // C++: int cv::slam::OdometryParams::kfMinFrames
    //

@property int kfMinFrames;

    //
    // C++: int cv::slam::OdometryParams::kfMaxFrames
    //

@property int kfMaxFrames;

    //
    // C++: double cv::slam::OdometryParams::kfInlierRatio
    //

@property double kfInlierRatio;

    //
    // C++: int cv::slam::OdometryParams::kfMinInliers
    //

@property int kfMinInliers;

    //
    // C++: double cv::slam::OdometryParams::kfRotThreshDeg
    //

@property double kfRotThreshDeg;

    //
    // C++: double cv::slam::OdometryParams::kfTransThresh
    //

@property double kfTransThresh;

    //
    // C++: int cv::slam::OdometryParams::localMapTopK
    //

@property int localMapTopK;

    //
    // C++: int cv::slam::OdometryParams::localMapNeighborK
    //

@property int localMapNeighborK;

    //
    // C++: double cv::slam::OdometryParams::localMapRadius
    //

@property double localMapRadius;


@end

NS_ASSUME_NONNULL_END


