//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/volume_settings.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "Ptcloud.h"
@class Mat;



NS_ASSUME_NONNULL_BEGIN

// C++: class VolumeSettings
/**
 * The VolumeSettings module
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface VolumeSettings : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::VolumeSettings> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::VolumeSettings>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::VolumeSettings>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::VolumeSettings::VolumeSettings(VolumeType volumeType = VolumeType::TSDF)
//
/**
 * Constructor of settings for custom Volume type.
 * @param volumeType volume type.
 */
- (instancetype)initWithVolumeType:(CV_VolumeType)volumeType;

/**
 * Constructor of settings for custom Volume type.
 */
- (instancetype)init;


//
//  void cv::VolumeSettings::setIntegrateWidth(int val)
//
/**
 * Sets the width of the image for integration.
 * @param val input value.
 */
- (void)setIntegrateWidth:(int)val NS_SWIFT_NAME(setIntegrateWidth(val:));


//
//  int cv::VolumeSettings::getIntegrateWidth()
//
/**
 * Returns the width of the image for integration.
 */
- (int)getIntegrateWidth NS_SWIFT_NAME(getIntegrateWidth());


//
//  void cv::VolumeSettings::setIntegrateHeight(int val)
//
/**
 * Sets the height of the image for integration.
 * @param val input value.
 */
- (void)setIntegrateHeight:(int)val NS_SWIFT_NAME(setIntegrateHeight(val:));


//
//  int cv::VolumeSettings::getIntegrateHeight()
//
/**
 * Returns the height of the image for integration.
 */
- (int)getIntegrateHeight NS_SWIFT_NAME(getIntegrateHeight());


//
//  void cv::VolumeSettings::setRaycastWidth(int val)
//
/**
 * Sets the width of the raycasted image, used when user does not provide it at raycast() call.
 * @param val input value.
 */
- (void)setRaycastWidth:(int)val NS_SWIFT_NAME(setRaycastWidth(val:));


//
//  int cv::VolumeSettings::getRaycastWidth()
//
/**
 * Returns the width of the raycasted image, used when user does not provide it at raycast() call.
 */
- (int)getRaycastWidth NS_SWIFT_NAME(getRaycastWidth());


//
//  void cv::VolumeSettings::setRaycastHeight(int val)
//
/**
 * Sets the height of the raycasted image, used when user does not provide it at raycast() call.
 * @param val input value.
 */
- (void)setRaycastHeight:(int)val NS_SWIFT_NAME(setRaycastHeight(val:));


//
//  int cv::VolumeSettings::getRaycastHeight()
//
/**
 * Returns the height of the raycasted image, used when user does not provide it at raycast() call.
 */
- (int)getRaycastHeight NS_SWIFT_NAME(getRaycastHeight());


//
//  void cv::VolumeSettings::setDepthFactor(float val)
//
/**
 * Sets depth factor, witch is the number for depth scaling.
 * @param val input value.
 */
- (void)setDepthFactor:(float)val NS_SWIFT_NAME(setDepthFactor(val:));


//
//  float cv::VolumeSettings::getDepthFactor()
//
/**
 * Returns depth factor, witch is the number for depth scaling.
 */
- (float)getDepthFactor NS_SWIFT_NAME(getDepthFactor());


//
//  void cv::VolumeSettings::setVoxelSize(float val)
//
/**
 * Sets the size of voxel.
 * @param val input value.
 */
- (void)setVoxelSize:(float)val NS_SWIFT_NAME(setVoxelSize(val:));


//
//  float cv::VolumeSettings::getVoxelSize()
//
/**
 * Returns the size of voxel.
 */
- (float)getVoxelSize NS_SWIFT_NAME(getVoxelSize());


//
//  void cv::VolumeSettings::setTsdfTruncateDistance(float val)
//
/**
 * Sets TSDF truncation distance. Distances greater than value from surface will be truncated to 1.0.
 * @param val input value.
 */
- (void)setTsdfTruncateDistance:(float)val NS_SWIFT_NAME(setTsdfTruncateDistance(val:));


//
//  float cv::VolumeSettings::getTsdfTruncateDistance()
//
/**
 * Returns TSDF truncation distance. Distances greater than value from surface will be truncated to 1.0.
 */
- (float)getTsdfTruncateDistance NS_SWIFT_NAME(getTsdfTruncateDistance());


//
//  void cv::VolumeSettings::setGradientDeltaFactor(float val)
//
/**
 * Sets gradient delta factor used for normal estimation in TSDF volumes.
 * @param val input value.
 */
- (void)setGradientDeltaFactor:(float)val NS_SWIFT_NAME(setGradientDeltaFactor(val:));


//
//  float cv::VolumeSettings::getGradientDeltaFactor()
//
/**
 * Returns gradient delta factor used for normal estimation in TSDF volumes.
 */
- (float)getGradientDeltaFactor NS_SWIFT_NAME(getGradientDeltaFactor());


//
//  void cv::VolumeSettings::setVolumeUnitHideThreshold(int val)
//
/**
 * Sets threshold for number of frames after which invisible volume units are hidden/removed.
 * For HashTSDF and ColorHashTSDF volumes, units that haven't been visible for this many frames will be removed.
 * @param val input value.
 */
- (void)setVolumeUnitHideThreshold:(int)val NS_SWIFT_NAME(setVolumeUnitHideThreshold(val:));


//
//  int cv::VolumeSettings::getVolumeUnitHideThreshold()
//
/**
 * Returns threshold for number of frames after which invisible volume units are hidden/removed.
 * For HashTSDF and ColorHashTSDF volumes, units that haven't been visible for this many frames will be removed.
 */
- (int)getVolumeUnitHideThreshold NS_SWIFT_NAME(getVolumeUnitHideThreshold());


//
//  void cv::VolumeSettings::setMaxDepth(float val)
//
/**
 * Sets threshold for depth truncation in meters. Truncates the depth greater than threshold to 0.
 * @param val input value.
 */
- (void)setMaxDepth:(float)val NS_SWIFT_NAME(setMaxDepth(val:));


//
//  float cv::VolumeSettings::getMaxDepth()
//
/**
 * Returns threshold for depth truncation in meters. Truncates the depth greater than threshold to 0.
 */
- (float)getMaxDepth NS_SWIFT_NAME(getMaxDepth());


//
//  void cv::VolumeSettings::setMaxWeight(int val)
//
/**
 * Sets max number of frames to integrate per voxel.
 *         Represents the max number of frames over which a running average of the TSDF is calculated for a voxel.
 * @param val input value.
 */
- (void)setMaxWeight:(int)val NS_SWIFT_NAME(setMaxWeight(val:));


//
//  int cv::VolumeSettings::getMaxWeight()
//
/**
 * Returns max number of frames to integrate per voxel.
 *         Represents the max number of frames over which a running average of the TSDF is calculated for a voxel.
 */
- (int)getMaxWeight NS_SWIFT_NAME(getMaxWeight());


//
//  void cv::VolumeSettings::setRaycastStepFactor(float val)
//
/**
 * Sets length of single raycast step.
 *         Describes the percentage of voxel length that is skipped per march.
 * @param val input value.
 */
- (void)setRaycastStepFactor:(float)val NS_SWIFT_NAME(setRaycastStepFactor(val:));


//
//  float cv::VolumeSettings::getRaycastStepFactor()
//
/**
 * Returns length of single raycast step.
 *         Describes the percentage of voxel length that is skipped per march.
 */
- (float)getRaycastStepFactor NS_SWIFT_NAME(getRaycastStepFactor());


//
//  void cv::VolumeSettings::setVolumePose(Mat val)
//
/**
 * Sets volume pose.
 * @param val input value.
 */
- (void)setVolumePose:(Mat*)val NS_SWIFT_NAME(setVolumePose(val:));


//
//  void cv::VolumeSettings::getVolumePose(Mat& val)
//
/**
 * Sets volume pose.
 * @param val output value.
 */
- (void)getVolumePose:(Mat*)val NS_SWIFT_NAME(getVolumePose(val:));


//
//  void cv::VolumeSettings::setVolumeResolution(Mat val)
//
/**
 * Resolution of voxel space.
 *         Number of voxels in each dimension.
 *         Applicable only for TSDF and ColorTSDF volumes.
 *         HashTSDF and ColorHashTSDF volumes only support equal resolution in all three dimensions.
 * @param val input value.
 */
- (void)setVolumeResolution:(Mat*)val NS_SWIFT_NAME(setVolumeResolution(val:));


//
//  void cv::VolumeSettings::getVolumeResolution(Mat& val)
//
/**
 * Resolution of voxel space.
 *         Number of voxels in each dimension.
 *         Applicable only for TSDF and ColorTSDF volumes.
 *         HashTSDF and ColorHashTSDF volumes only support equal resolution in all three dimensions.
 * @param val output value.
 */
- (void)getVolumeResolution:(Mat*)val NS_SWIFT_NAME(getVolumeResolution(val:));


//
//  void cv::VolumeSettings::getVolumeStrides(Mat& val)
//
/**
 * Returns 3 integers representing strides by x, y and z dimension.
 *         Can be used to iterate over raw volume unit data.
 * @param val output value.
 */
- (void)getVolumeStrides:(Mat*)val NS_SWIFT_NAME(getVolumeStrides(val:));


//
//  void cv::VolumeSettings::setCameraIntegrateIntrinsics(Mat val)
//
/**
 * Sets intrinsics of camera for integrations.
 * Format of input:
 * [ fx  0 cx ]
 * [  0 fy cy ]
 * [  0  0  1 ]
 * where fx and fy are focus points of Ox and Oy axises, and cx and cy are central points of Ox and Oy axises.
 * @param val input value.
 */
- (void)setCameraIntegrateIntrinsics:(Mat*)val NS_SWIFT_NAME(setCameraIntegrateIntrinsics(val:));


//
//  void cv::VolumeSettings::getCameraIntegrateIntrinsics(Mat& val)
//
/**
 * Returns intrinsics of camera for integrations.
 * Format of output:
 * [ fx  0 cx ]
 * [  0 fy cy ]
 * [  0  0  1 ]
 * where fx and fy are focus points of Ox and Oy axises, and cx and cy are central points of Ox and Oy axises.
 * @param val output value.
 */
- (void)getCameraIntegrateIntrinsics:(Mat*)val NS_SWIFT_NAME(getCameraIntegrateIntrinsics(val:));


//
//  void cv::VolumeSettings::setCameraRaycastIntrinsics(Mat val)
//
/**
 * Sets camera intrinsics for raycast image which, used when user does not provide them at raycast() call.
 * Format of input:
 * [ fx  0 cx ]
 * [  0 fy cy ]
 * [  0  0  1 ]
 * where fx and fy are focus points of Ox and Oy axises, and cx and cy are central points of Ox and Oy axises.
 * @param val input value.
 */
- (void)setCameraRaycastIntrinsics:(Mat*)val NS_SWIFT_NAME(setCameraRaycastIntrinsics(val:));


//
//  void cv::VolumeSettings::getCameraRaycastIntrinsics(Mat& val)
//
/**
 * Returns camera intrinsics for raycast image, used when user does not provide them at raycast() call.
 * Format of output:
 * [ fx  0 cx ]
 * [  0 fy cy ]
 * [  0  0  1 ]
 * where fx and fy are focus points of Ox and Oy axises, and cx and cy are central points of Ox and Oy axises.
 * @param val output value.
 */
- (void)getCameraRaycastIntrinsics:(Mat*)val NS_SWIFT_NAME(getCameraRaycastIntrinsics(val:));



@end

NS_ASSUME_NONNULL_END


