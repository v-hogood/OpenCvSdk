//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/ptcloud.hpp"
#import "opencv2/ptcloud/volume.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


#import "Ptcloud.h"
@class Mat;
@class OdometryFrame;
@class VolumeSettings;


// C++: enum BoundingBoxPrecision (cv.Volume.BoundingBoxPrecision)
typedef NS_ENUM(int, BoundingBoxPrecision) {
    Volume_VOLUME_UNIT NS_SWIFT_NAME(VOLUME_UNIT) = 0,
    Volume_VOXEL NS_SWIFT_NAME(VOXEL) = 1
};



NS_ASSUME_NONNULL_BEGIN

// C++: class Volume
/**
 * The Volume module
 *
 * Member of `Ptcloud`
 */
CV_EXPORTS @interface Volume : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::Volume> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::Volume>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::Volume>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::Volume::Volume(VolumeType vtype = VolumeType::TSDF, VolumeSettings settings = VolumeSettings(VolumeType::TSDF))
//
/**
 * Constructor of custom volume.
 * @param vtype the volume type [TSDF, HashTSDF, ColorTSDF, ColorHashTSDF].
 * @param settings the custom settings for volume.
 */
- (instancetype)initWithVtype:(CV_VolumeType)vtype settings:(VolumeSettings*)settings;

/**
 * Constructor of custom volume.
 * @param vtype the volume type [TSDF, HashTSDF, ColorTSDF, ColorHashTSDF].
 */
- (instancetype)initWithVtype:(CV_VolumeType)vtype;

/**
 * Constructor of custom volume.
 */
- (instancetype)init;


//
//  void cv::Volume::integrate(OdometryFrame frame, Mat pose)
//
/**
 * Integrates the input data to the volume.
 *
 *     Camera intrinsics are taken from volume settings structure.
 *
 * @param frame the object from which to take depth and image data.
 *       For color TSDF a depth data should be registered with color data, i.e. have the same intrinsics & camera pose.
 *       This can be done using function registerDepth() from 3d module.
 * @param pose the pose of camera in global coordinates.
 */
- (void)integrateFrame:(OdometryFrame*)frame pose:(Mat*)pose NS_SWIFT_NAME(integrate(frame:pose:));


//
//  void cv::Volume::integrate(Mat depth, Mat pose)
//
/**
 * Integrates the input data to the volume.
 *
 *     Camera intrinsics are taken from volume settings structure.
 *
 * @param depth the depth image.
 * @param pose the pose of camera in global coordinates.
 */
- (void)integrate:(Mat*)depth pose:(Mat*)pose NS_SWIFT_NAME(integrate(depth:pose:));


//
//  void cv::Volume::integrate(Mat depth, Mat image, Mat pose)
//
/**
 * Integrates the input data to the volume.
 *
 *     Camera intrinsics are taken from volume settings structure.
 *
 * @param depth the depth image.
 * @param image the color image (only for ColorTSDF and ColorHashTSDF).
 *       For color TSDF a depth data should be registered with color data, i.e. have the same intrinsics & camera pose.
 *       This can be done using function registerDepth() from 3d module.
 * @param pose the pose of camera in global coordinates.
 */
- (void)integrateColor:(Mat*)depth image:(Mat*)image pose:(Mat*)pose NS_SWIFT_NAME(integrate(depth:image:pose:));


//
//  void cv::Volume::raycast(Mat cameraPose, Mat& points, Mat& normals)
//
/**
 * Renders the volume contents into an image. The resulting points and normals are in camera's coordinate system.
 *
 *     Rendered image size and camera intrinsics are taken from volume settings structure.
 *
 * @param cameraPose the pose of camera in global coordinates.
 * @param points image to store rendered points.
 * @param normals image to store rendered normals corresponding to points.
 */
- (void)raycast:(Mat*)cameraPose points:(Mat*)points normals:(Mat*)normals NS_SWIFT_NAME(raycast(cameraPose:points:normals:));


//
//  void cv::Volume::raycast(Mat cameraPose, Mat& points, Mat& normals, Mat& colors)
//
/**
 * Renders the volume contents into an image. The resulting points and normals are in camera's coordinate system.
 *
 *     Rendered image size and camera intrinsics are taken from volume settings structure.
 *
 * @param cameraPose the pose of camera in global coordinates.
 * @param points image to store rendered points.
 * @param normals image to store rendered normals corresponding to points.
 * @param colors image to store rendered colors corresponding to points (only for ColorTSDF and ColorHashTSDF).
 */
- (void)raycastColor:(Mat*)cameraPose points:(Mat*)points normals:(Mat*)normals colors:(Mat*)colors NS_SWIFT_NAME(raycast(cameraPose:points:normals:colors:));


//
//  void cv::Volume::raycast(Mat cameraPose, int height, int width, Mat K, Mat& points, Mat& normals)
//
/**
 * Renders the volume contents into an image. The resulting points and normals are in camera's coordinate system.
 *
 *     Rendered image size and camera intrinsics are taken from volume settings structure.
 *
 * @param cameraPose the pose of camera in global coordinates.
 * @param height the height of result image
 * @param width the width of result image
 * @param K camera raycast intrinsics
 * @param points image to store rendered points.
 * @param normals image to store rendered normals corresponding to points.
 */
- (void)raycastEx:(Mat*)cameraPose height:(int)height width:(int)width K:(Mat*)K points:(Mat*)points normals:(Mat*)normals NS_SWIFT_NAME(raycast(cameraPose:height:width:K:points:normals:));


//
//  void cv::Volume::raycast(Mat cameraPose, int height, int width, Mat K, Mat& points, Mat& normals, Mat& colors)
//
/**
 * Renders the volume contents into an image. The resulting points and normals are in camera's coordinate system.
 *
 *     Rendered image size and camera intrinsics are taken from volume settings structure.
 *
 * @param cameraPose the pose of camera in global coordinates.
 * @param height the height of result image
 * @param width the width of result image
 * @param K camera raycast intrinsics
 * @param points image to store rendered points.
 * @param normals image to store rendered normals corresponding to points.
 * @param colors image to store rendered colors corresponding to points (only for ColorTSDF and ColorHashTSDF).
 */
- (void)raycastExColor:(Mat*)cameraPose height:(int)height width:(int)width K:(Mat*)K points:(Mat*)points normals:(Mat*)normals colors:(Mat*)colors NS_SWIFT_NAME(raycast(cameraPose:height:width:K:points:normals:colors:));


//
//  void cv::Volume::fetchNormals(Mat points, Mat& normals)
//
/**
 * Extract the all data from volume.
 * @param points the input exist point.
 * @param normals the storage of normals (corresponding to input points) in the image.
 */
- (void)fetchNormals:(Mat*)points normals:(Mat*)normals NS_SWIFT_NAME(fetchNormals(points:normals:));


//
//  void cv::Volume::fetchPointsNormals(Mat& points, Mat& normals)
//
/**
 * Extract the all data from volume.
 * @param points the storage of all points.
 * @param normals the storage of all normals, corresponding to points.
 */
- (void)fetchPointsNormals:(Mat*)points normals:(Mat*)normals NS_SWIFT_NAME(fetchPointsNormals(points:normals:));


//
//  void cv::Volume::fetchPointsNormalsColors(Mat& points, Mat& normals, Mat& colors)
//
/**
 * Extract the all data from volume.
 * @param points the storage of all points.
 * @param normals the storage of all normals, corresponding to points.
 * @param colors the storage of all colors, corresponding to points (only for ColorTSDF and ColorHashTSDF).
 */
- (void)fetchPointsNormalsColors:(Mat*)points normals:(Mat*)normals colors:(Mat*)colors NS_SWIFT_NAME(fetchPointsNormalsColors(points:normals:colors:));


//
//  void cv::Volume::reset()
//
/**
 * clear all data in volume.
 */
- (void)reset NS_SWIFT_NAME(reset());


//
//  int cv::Volume::getVisibleBlocks()
//
/**
 * return visible blocks in volume.
 */
- (int)getVisibleBlocks NS_SWIFT_NAME(getVisibleBlocks());


//
//  size_t cv::Volume::getTotalVolumeUnits()
//
/**
 * return number of volume units in volume.
 */
- (size_t)getTotalVolumeUnits NS_SWIFT_NAME(getTotalVolumeUnits());


//
//  void cv::Volume::getBoundingBox(Mat& bb, int precision)
//
/**
 * Gets bounding box in volume coordinates with given precision:
 * VOLUME_UNIT - up to volume unit
 * VOXEL - up to voxel (currently not supported)
 * @param bb 6-float 1d array containing (min_x, min_y, min_z, max_x, max_y, max_z) in volume coordinates
 * @param precision bounding box calculation precision
 */
- (void)getBoundingBox:(Mat*)bb precision:(int)precision NS_SWIFT_NAME(getBoundingBox(bb:precision:));


//
//  void cv::Volume::setEnableGrowth(bool v)
//
/**
 * Enables or disables new volume unit allocation during integration.
 * Makes sense for HashTSDF and ColorHashTSDF only.
 */
- (void)setEnableGrowth:(BOOL)v NS_SWIFT_NAME(setEnableGrowth(v:));


//
//  bool cv::Volume::getEnableGrowth()
//
/**
 * Returns if new volume units are allocated during integration or not.
 * Makes sense for HashTSDF and ColorHashTSDF only.
 */
- (BOOL)getEnableGrowth NS_SWIFT_NAME(getEnableGrowth());



@end

NS_ASSUME_NONNULL_END


