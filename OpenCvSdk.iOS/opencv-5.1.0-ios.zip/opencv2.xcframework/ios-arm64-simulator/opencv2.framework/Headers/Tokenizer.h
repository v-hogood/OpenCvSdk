//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/dnn.hpp"
#import "opencv2/dnn/dnn.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


@class IntVector;



NS_ASSUME_NONNULL_BEGIN

// C++: class Tokenizer
/**
 * High-level tokenizer wrapper for DNN usage.
 *
 * Provides a simple API to encode and decode tokens for LLMs.
 * Models are loaded via Tokenizer::load().
 *
 *
 * using namespace cv::dnn;
 * Tokenizer tok = Tokenizer::load("/path/to/model/");
 * std::vector<int> ids = tok.encode("hello world");
 * std::string text = tok.decode(ids);
 *
 *
 * Member of `Dnn`
 */
CV_EXPORTS @interface Tokenizer : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::dnn::Tokenizer> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::dnn::Tokenizer>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::dnn::Tokenizer>)nativePtr;
#endif


#pragma mark - Methods


//
// static Tokenizer cv::dnn::Tokenizer::load(string model_config)
//
/**
 * Load a tokenizer from a model directory.
 *
 * Accepts either the model directory or the path to its `config.json`. The
 * directory must contain:
 * - `config.json`. An optional `method` field (one of: BPE, Gemma, SentencePiece,
 * Unigram, WordPiece) selects the family; without it the family is detected from
 * `tokenizer.json`, so a stock Hugging Face config works unmodified.
 * - `tokenizer.json` produced by the corresponding model family.
 *
 * @param model_config  Model directory, or the path to its config.json.
 * @return A Tokenizer ready for use. Throws cv::Exception if files are missing or `method` is unsupported.
 */
+ (Tokenizer*)load:(NSString*)model_config NS_SWIFT_NAME(load(model_config:));


//
//  vector_int cv::dnn::Tokenizer::encode(string text)
//
/**
 * Encode UTF-8 text to token ids.
 *
 * Special-token text in @p text is recognized and mapped to its own id, and any
 * wrapper the model's post_processor declares (e.g. BERT's `[CLS]`/`[SEP]`) is
 * applied.
 *
 * @param text  UTF-8 input string.
 * @return Vector of token ids (32-bit ids narrowed to int for convenience).
 */
- (IntVector*)encode:(NSString*)text NS_SWIFT_NAME(encode(text:));


//
//  vector_int cv::dnn::Tokenizer::encode(vector_string textChunks)
//
/**
 * Encode several text chunks as one sequence.
 *
 * The chunks are laid out the way the model's own post_processor declares a pair of
 * sequences, repeated for as many chunks as are given. For a BERT-family tokenizer
 * that is `[CLS] textChunks[0] [SEP] textChunks[1] [SEP] ... textChunks[N-1] [SEP]`;
 * for T5 it is `textChunks[0] </s> textChunks[1] </s> ...`. Whatever the template
 * puts between its two sequences is repeated between every neighbouring pair.
 *
 * A single chunk is encoded exactly like encode(const std::string&). Two or more
 * require a tokenizer whose `post_processor` declares a `pair` template: BERT and
 * ALBERT, T5 and Gemma do; byte-level BPE models such as GPT-2 do not, and throw.
 *
 * @param textChunks  UTF-8 input chunks; must not be empty.
 * @return Vector of token ids. Throws cv::Exception if @p textChunks is empty, or if
 * it holds more than one chunk and the loaded tokenizer has no pair template.
 */
- (IntVector*)encodeChunks:(NSArray<NSString*>*)textChunks NS_SWIFT_NAME(encode(textChunks:));


//
//  string cv::dnn::Tokenizer::decode(vector_int tokens)
//
- (NSString*)decode:(IntVector*)tokens NS_SWIFT_NAME(decode(tokens:));



@end

NS_ASSUME_NONNULL_END


