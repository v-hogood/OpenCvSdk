//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/imgproc.hpp"
#import "imgproc/bindings.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>

#import "Core.h"
#import "Geometry.h"
@class CLAHE;
@class Filter2DParams;
@class FloatVector;
@class FontFace;
@class GeneralizedHoughBallard;
@class GeneralizedHoughGuil;
@class IntVector;
@class LineSegmentDetector;
@class Mat;
@class Point2d;
@class Point2f;
@class Point2i;
@class Range;
@class Rect2i;
@class RotatedRect;
@class Scalar;
@class Size2i;
@class TermCriteria;


// C++: enum AdaptiveThresholdTypes (cv.AdaptiveThresholdTypes)
typedef NS_ENUM(int, AdaptiveThresholdTypes) {
    ADAPTIVE_THRESH_MEAN_C = 0,
    ADAPTIVE_THRESH_GAUSSIAN_C = 1
};


// C++: enum AlphaCompositeOperations (cv.AlphaCompositeOperations)
typedef NS_ENUM(int, AlphaCompositeOperations) {
    ALPHA_COMPOSITE_CLEAR = 0,
    ALPHA_COMPOSITE_SOURCE = 1,
    ALPHA_COMPOSITE_DEST = 2,
    ALPHA_COMPOSITE_OVER = 3,
    ALPHA_COMPOSITE_DEST_OVER = 4,
    ALPHA_COMPOSITE_IN = 5,
    ALPHA_COMPOSITE_DEST_IN = 6,
    ALPHA_COMPOSITE_OUT = 7,
    ALPHA_COMPOSITE_DEST_OUT = 8,
    ALPHA_COMPOSITE_ATOP = 9,
    ALPHA_COMPOSITE_DEST_ATOP = 10,
    ALPHA_COMPOSITE_XOR = 11,
    ALPHA_COMPOSITE_PLUS = 12
};


// C++: enum ColorConversionCodes (cv.ColorConversionCodes)
typedef NS_ENUM(int, ColorConversionCodes) {
    COLOR_BGR2BGRA = 0,
    COLOR_RGB2RGBA = COLOR_BGR2BGRA,
    COLOR_BGRA2BGR = 1,
    COLOR_RGBA2RGB = COLOR_BGRA2BGR,
    COLOR_BGR2RGBA = 2,
    COLOR_RGB2BGRA = COLOR_BGR2RGBA,
    COLOR_RGBA2BGR = 3,
    COLOR_BGRA2RGB = COLOR_RGBA2BGR,
    COLOR_BGR2RGB = 4,
    COLOR_RGB2BGR = COLOR_BGR2RGB,
    COLOR_BGRA2RGBA = 5,
    COLOR_RGBA2BGRA = COLOR_BGRA2RGBA,
    COLOR_BGR2GRAY = 6,
    COLOR_RGB2GRAY = 7,
    COLOR_GRAY2BGR = 8,
    COLOR_GRAY2RGB = COLOR_GRAY2BGR,
    COLOR_GRAY2BGRA = 9,
    COLOR_GRAY2RGBA = COLOR_GRAY2BGRA,
    COLOR_BGRA2GRAY = 10,
    COLOR_RGBA2GRAY = 11,
    COLOR_BGR2BGR565 = 12,
    COLOR_RGB2BGR565 = 13,
    COLOR_BGR5652BGR = 14,
    COLOR_BGR5652RGB = 15,
    COLOR_BGRA2BGR565 = 16,
    COLOR_RGBA2BGR565 = 17,
    COLOR_BGR5652BGRA = 18,
    COLOR_BGR5652RGBA = 19,
    COLOR_GRAY2BGR565 = 20,
    COLOR_BGR5652GRAY = 21,
    COLOR_BGR2BGR555 = 22,
    COLOR_RGB2BGR555 = 23,
    COLOR_BGR5552BGR = 24,
    COLOR_BGR5552RGB = 25,
    COLOR_BGRA2BGR555 = 26,
    COLOR_RGBA2BGR555 = 27,
    COLOR_BGR5552BGRA = 28,
    COLOR_BGR5552RGBA = 29,
    COLOR_GRAY2BGR555 = 30,
    COLOR_BGR5552GRAY = 31,
    COLOR_BGR2XYZ = 32,
    COLOR_RGB2XYZ = 33,
    COLOR_XYZ2BGR = 34,
    COLOR_XYZ2RGB = 35,
    COLOR_BGR2YCrCb = 36,
    COLOR_RGB2YCrCb = 37,
    COLOR_YCrCb2BGR = 38,
    COLOR_YCrCb2RGB = 39,
    COLOR_BGR2HSV = 40,
    COLOR_RGB2HSV = 41,
    COLOR_BGR2Lab = 44,
    COLOR_RGB2Lab = 45,
    COLOR_BGR2Luv = 50,
    COLOR_RGB2Luv = 51,
    COLOR_BGR2HLS = 52,
    COLOR_RGB2HLS = 53,
    COLOR_HSV2BGR = 54,
    COLOR_HSV2RGB = 55,
    COLOR_Lab2BGR = 56,
    COLOR_Lab2RGB = 57,
    COLOR_Luv2BGR = 58,
    COLOR_Luv2RGB = 59,
    COLOR_HLS2BGR = 60,
    COLOR_HLS2RGB = 61,
    COLOR_BGR2HSV_FULL = 66,
    COLOR_RGB2HSV_FULL = 67,
    COLOR_BGR2HLS_FULL = 68,
    COLOR_RGB2HLS_FULL = 69,
    COLOR_HSV2BGR_FULL = 70,
    COLOR_HSV2RGB_FULL = 71,
    COLOR_HLS2BGR_FULL = 72,
    COLOR_HLS2RGB_FULL = 73,
    COLOR_LBGR2Lab = 74,
    COLOR_LRGB2Lab = 75,
    COLOR_LBGR2Luv = 76,
    COLOR_LRGB2Luv = 77,
    COLOR_Lab2LBGR = 78,
    COLOR_Lab2LRGB = 79,
    COLOR_Luv2LBGR = 80,
    COLOR_Luv2LRGB = 81,
    COLOR_BGR2YUV = 82,
    COLOR_RGB2YUV = 83,
    COLOR_YUV2BGR = 84,
    COLOR_YUV2RGB = 85,
    COLOR_YUV2RGB_NV12 = 90,
    COLOR_YUV2BGR_NV12 = 91,
    COLOR_YUV2RGB_NV21 = 92,
    COLOR_YUV2BGR_NV21 = 93,
    COLOR_YUV420sp2RGB = COLOR_YUV2RGB_NV21,
    COLOR_YUV420sp2BGR = COLOR_YUV2BGR_NV21,
    COLOR_YUV2RGBA_NV12 = 94,
    COLOR_YUV2BGRA_NV12 = 95,
    COLOR_YUV2RGBA_NV21 = 96,
    COLOR_YUV2BGRA_NV21 = 97,
    COLOR_YUV420sp2RGBA = COLOR_YUV2RGBA_NV21,
    COLOR_YUV420sp2BGRA = COLOR_YUV2BGRA_NV21,
    COLOR_YUV2RGB_YV12 = 98,
    COLOR_YUV2BGR_YV12 = 99,
    COLOR_YUV2RGB_IYUV = 100,
    COLOR_YUV2BGR_IYUV = 101,
    COLOR_YUV2RGB_I420 = COLOR_YUV2RGB_IYUV,
    COLOR_YUV2BGR_I420 = COLOR_YUV2BGR_IYUV,
    COLOR_YUV420p2RGB = COLOR_YUV2RGB_YV12,
    COLOR_YUV420p2BGR = COLOR_YUV2BGR_YV12,
    COLOR_YUV2RGBA_YV12 = 102,
    COLOR_YUV2BGRA_YV12 = 103,
    COLOR_YUV2RGBA_IYUV = 104,
    COLOR_YUV2BGRA_IYUV = 105,
    COLOR_YUV2RGBA_I420 = COLOR_YUV2RGBA_IYUV,
    COLOR_YUV2BGRA_I420 = COLOR_YUV2BGRA_IYUV,
    COLOR_YUV420p2RGBA = COLOR_YUV2RGBA_YV12,
    COLOR_YUV420p2BGRA = COLOR_YUV2BGRA_YV12,
    COLOR_YUV2GRAY_420 = 106,
    COLOR_YUV2GRAY_NV21 = COLOR_YUV2GRAY_420,
    COLOR_YUV2GRAY_NV12 = COLOR_YUV2GRAY_420,
    COLOR_YUV2GRAY_YV12 = COLOR_YUV2GRAY_420,
    COLOR_YUV2GRAY_IYUV = COLOR_YUV2GRAY_420,
    COLOR_YUV2GRAY_I420 = COLOR_YUV2GRAY_420,
    COLOR_YUV420sp2GRAY = COLOR_YUV2GRAY_420,
    COLOR_YUV420p2GRAY = COLOR_YUV2GRAY_420,
    COLOR_YUV2RGB_UYVY = 107,
    COLOR_YUV2BGR_UYVY = 108,
    COLOR_YUV2RGB_Y422 = COLOR_YUV2RGB_UYVY,
    COLOR_YUV2BGR_Y422 = COLOR_YUV2BGR_UYVY,
    COLOR_YUV2RGB_UYNV = COLOR_YUV2RGB_UYVY,
    COLOR_YUV2BGR_UYNV = COLOR_YUV2BGR_UYVY,
    COLOR_YUV2RGBA_UYVY = 111,
    COLOR_YUV2BGRA_UYVY = 112,
    COLOR_YUV2RGBA_Y422 = COLOR_YUV2RGBA_UYVY,
    COLOR_YUV2BGRA_Y422 = COLOR_YUV2BGRA_UYVY,
    COLOR_YUV2RGBA_UYNV = COLOR_YUV2RGBA_UYVY,
    COLOR_YUV2BGRA_UYNV = COLOR_YUV2BGRA_UYVY,
    COLOR_YUV2RGB_YUY2 = 115,
    COLOR_YUV2BGR_YUY2 = 116,
    COLOR_YUV2RGB_YVYU = 117,
    COLOR_YUV2BGR_YVYU = 118,
    COLOR_YUV2RGB_YUYV = COLOR_YUV2RGB_YUY2,
    COLOR_YUV2BGR_YUYV = COLOR_YUV2BGR_YUY2,
    COLOR_YUV2RGB_YUNV = COLOR_YUV2RGB_YUY2,
    COLOR_YUV2BGR_YUNV = COLOR_YUV2BGR_YUY2,
    COLOR_YUV2RGBA_YUY2 = 119,
    COLOR_YUV2BGRA_YUY2 = 120,
    COLOR_YUV2RGBA_YVYU = 121,
    COLOR_YUV2BGRA_YVYU = 122,
    COLOR_YUV2RGBA_YUYV = COLOR_YUV2RGBA_YUY2,
    COLOR_YUV2BGRA_YUYV = COLOR_YUV2BGRA_YUY2,
    COLOR_YUV2RGBA_YUNV = COLOR_YUV2RGBA_YUY2,
    COLOR_YUV2BGRA_YUNV = COLOR_YUV2BGRA_YUY2,
    COLOR_YUV2GRAY_UYVY = 123,
    COLOR_YUV2GRAY_YUY2 = 124,
    COLOR_YUV2GRAY_Y422 = COLOR_YUV2GRAY_UYVY,
    COLOR_YUV2GRAY_UYNV = COLOR_YUV2GRAY_UYVY,
    COLOR_YUV2GRAY_YVYU = COLOR_YUV2GRAY_YUY2,
    COLOR_YUV2GRAY_YUYV = COLOR_YUV2GRAY_YUY2,
    COLOR_YUV2GRAY_YUNV = COLOR_YUV2GRAY_YUY2,
    COLOR_RGBA2mRGBA = 125,
    COLOR_mRGBA2RGBA = 126,
    COLOR_RGB2YUV_I420 = 127,
    COLOR_BGR2YUV_I420 = 128,
    COLOR_RGB2YUV_IYUV = COLOR_RGB2YUV_I420,
    COLOR_BGR2YUV_IYUV = COLOR_BGR2YUV_I420,
    COLOR_RGBA2YUV_I420 = 129,
    COLOR_BGRA2YUV_I420 = 130,
    COLOR_RGBA2YUV_IYUV = COLOR_RGBA2YUV_I420,
    COLOR_BGRA2YUV_IYUV = COLOR_BGRA2YUV_I420,
    COLOR_RGB2YUV_YV12 = 131,
    COLOR_BGR2YUV_YV12 = 132,
    COLOR_RGBA2YUV_YV12 = 133,
    COLOR_BGRA2YUV_YV12 = 134,
    COLOR_BayerBG2BGR = 46,
    COLOR_BayerGB2BGR = 47,
    COLOR_BayerRG2BGR = 48,
    COLOR_BayerGR2BGR = 49,
    COLOR_BayerRGGB2BGR = COLOR_BayerBG2BGR,
    COLOR_BayerGRBG2BGR = COLOR_BayerGB2BGR,
    COLOR_BayerBGGR2BGR = COLOR_BayerRG2BGR,
    COLOR_BayerGBRG2BGR = COLOR_BayerGR2BGR,
    COLOR_BayerRGGB2RGB = COLOR_BayerBGGR2BGR,
    COLOR_BayerGRBG2RGB = COLOR_BayerGBRG2BGR,
    COLOR_BayerBGGR2RGB = COLOR_BayerRGGB2BGR,
    COLOR_BayerGBRG2RGB = COLOR_BayerGRBG2BGR,
    COLOR_BayerBG2RGB = COLOR_BayerRG2BGR,
    COLOR_BayerGB2RGB = COLOR_BayerGR2BGR,
    COLOR_BayerRG2RGB = COLOR_BayerBG2BGR,
    COLOR_BayerGR2RGB = COLOR_BayerGB2BGR,
    COLOR_BayerBG2GRAY = 86,
    COLOR_BayerGB2GRAY = 87,
    COLOR_BayerRG2GRAY = 88,
    COLOR_BayerGR2GRAY = 89,
    COLOR_BayerRGGB2GRAY = COLOR_BayerBG2GRAY,
    COLOR_BayerGRBG2GRAY = COLOR_BayerGB2GRAY,
    COLOR_BayerBGGR2GRAY = COLOR_BayerRG2GRAY,
    COLOR_BayerGBRG2GRAY = COLOR_BayerGR2GRAY,
    COLOR_BayerBG2BGR_VNG = 62,
    COLOR_BayerGB2BGR_VNG = 63,
    COLOR_BayerRG2BGR_VNG = 64,
    COLOR_BayerGR2BGR_VNG = 65,
    COLOR_BayerRGGB2BGR_VNG = COLOR_BayerBG2BGR_VNG,
    COLOR_BayerGRBG2BGR_VNG = COLOR_BayerGB2BGR_VNG,
    COLOR_BayerBGGR2BGR_VNG = COLOR_BayerRG2BGR_VNG,
    COLOR_BayerGBRG2BGR_VNG = COLOR_BayerGR2BGR_VNG,
    COLOR_BayerRGGB2RGB_VNG = COLOR_BayerBGGR2BGR_VNG,
    COLOR_BayerGRBG2RGB_VNG = COLOR_BayerGBRG2BGR_VNG,
    COLOR_BayerBGGR2RGB_VNG = COLOR_BayerRGGB2BGR_VNG,
    COLOR_BayerGBRG2RGB_VNG = COLOR_BayerGRBG2BGR_VNG,
    COLOR_BayerBG2RGB_VNG = COLOR_BayerRG2BGR_VNG,
    COLOR_BayerGB2RGB_VNG = COLOR_BayerGR2BGR_VNG,
    COLOR_BayerRG2RGB_VNG = COLOR_BayerBG2BGR_VNG,
    COLOR_BayerGR2RGB_VNG = COLOR_BayerGB2BGR_VNG,
    COLOR_BayerBG2BGR_EA = 135,
    COLOR_BayerGB2BGR_EA = 136,
    COLOR_BayerRG2BGR_EA = 137,
    COLOR_BayerGR2BGR_EA = 138,
    COLOR_BayerRGGB2BGR_EA = COLOR_BayerBG2BGR_EA,
    COLOR_BayerGRBG2BGR_EA = COLOR_BayerGB2BGR_EA,
    COLOR_BayerBGGR2BGR_EA = COLOR_BayerRG2BGR_EA,
    COLOR_BayerGBRG2BGR_EA = COLOR_BayerGR2BGR_EA,
    COLOR_BayerRGGB2RGB_EA = COLOR_BayerBGGR2BGR_EA,
    COLOR_BayerGRBG2RGB_EA = COLOR_BayerGBRG2BGR_EA,
    COLOR_BayerBGGR2RGB_EA = COLOR_BayerRGGB2BGR_EA,
    COLOR_BayerGBRG2RGB_EA = COLOR_BayerGRBG2BGR_EA,
    COLOR_BayerBG2RGB_EA = COLOR_BayerRG2BGR_EA,
    COLOR_BayerGB2RGB_EA = COLOR_BayerGR2BGR_EA,
    COLOR_BayerRG2RGB_EA = COLOR_BayerBG2BGR_EA,
    COLOR_BayerGR2RGB_EA = COLOR_BayerGB2BGR_EA,
    COLOR_BayerBG2BGRA = 139,
    COLOR_BayerGB2BGRA = 140,
    COLOR_BayerRG2BGRA = 141,
    COLOR_BayerGR2BGRA = 142,
    COLOR_BayerRGGB2BGRA = COLOR_BayerBG2BGRA,
    COLOR_BayerGRBG2BGRA = COLOR_BayerGB2BGRA,
    COLOR_BayerBGGR2BGRA = COLOR_BayerRG2BGRA,
    COLOR_BayerGBRG2BGRA = COLOR_BayerGR2BGRA,
    COLOR_BayerRGGB2RGBA = COLOR_BayerBGGR2BGRA,
    COLOR_BayerGRBG2RGBA = COLOR_BayerGBRG2BGRA,
    COLOR_BayerBGGR2RGBA = COLOR_BayerRGGB2BGRA,
    COLOR_BayerGBRG2RGBA = COLOR_BayerGRBG2BGRA,
    COLOR_BayerBG2RGBA = COLOR_BayerRG2BGRA,
    COLOR_BayerGB2RGBA = COLOR_BayerGR2BGRA,
    COLOR_BayerRG2RGBA = COLOR_BayerBG2BGRA,
    COLOR_BayerGR2RGBA = COLOR_BayerGB2BGRA,
    COLOR_RGB2YUV_UYVY = 143,
    COLOR_BGR2YUV_UYVY = 144,
    COLOR_RGB2YUV_Y422 = COLOR_RGB2YUV_UYVY,
    COLOR_BGR2YUV_Y422 = COLOR_BGR2YUV_UYVY,
    COLOR_RGB2YUV_UYNV = COLOR_RGB2YUV_UYVY,
    COLOR_BGR2YUV_UYNV = COLOR_BGR2YUV_UYVY,
    COLOR_RGBA2YUV_UYVY = 145,
    COLOR_BGRA2YUV_UYVY = 146,
    COLOR_RGBA2YUV_Y422 = COLOR_RGBA2YUV_UYVY,
    COLOR_BGRA2YUV_Y422 = COLOR_BGRA2YUV_UYVY,
    COLOR_RGBA2YUV_UYNV = COLOR_RGBA2YUV_UYVY,
    COLOR_BGRA2YUV_UYNV = COLOR_BGRA2YUV_UYVY,
    COLOR_RGB2YUV_YUY2 = 147,
    COLOR_BGR2YUV_YUY2 = 148,
    COLOR_RGB2YUV_YVYU = 149,
    COLOR_BGR2YUV_YVYU = 150,
    COLOR_RGB2YUV_YUYV = COLOR_RGB2YUV_YUY2,
    COLOR_BGR2YUV_YUYV = COLOR_BGR2YUV_YUY2,
    COLOR_RGB2YUV_YUNV = COLOR_RGB2YUV_YUY2,
    COLOR_BGR2YUV_YUNV = COLOR_BGR2YUV_YUY2,
    COLOR_RGBA2YUV_YUY2 = 151,
    COLOR_BGRA2YUV_YUY2 = 152,
    COLOR_RGBA2YUV_YVYU = 153,
    COLOR_BGRA2YUV_YVYU = 154,
    COLOR_RGBA2YUV_YUYV = COLOR_RGBA2YUV_YUY2,
    COLOR_BGRA2YUV_YUYV = COLOR_BGRA2YUV_YUY2,
    COLOR_RGBA2YUV_YUNV = COLOR_RGBA2YUV_YUY2,
    COLOR_BGRA2YUV_YUNV = COLOR_BGRA2YUV_YUY2,
    COLOR_BGR2Oklab = 155,
    COLOR_RGB2Oklab = 156,
    COLOR_Oklab2BGR = 157,
    COLOR_Oklab2RGB = 158,
    COLOR_COLORCVT_MAX = 159
};


// C++: enum ColormapTypes (cv.ColormapTypes)
typedef NS_ENUM(int, ColormapTypes) {
    COLORMAP_AUTUMN = 0,
    COLORMAP_BONE = 1,
    COLORMAP_JET = 2,
    COLORMAP_WINTER = 3,
    COLORMAP_RAINBOW = 4,
    COLORMAP_OCEAN = 5,
    COLORMAP_SUMMER = 6,
    COLORMAP_SPRING = 7,
    COLORMAP_COOL = 8,
    COLORMAP_HSV = 9,
    COLORMAP_PINK = 10,
    COLORMAP_HOT = 11,
    COLORMAP_PARULA = 12,
    COLORMAP_MAGMA = 13,
    COLORMAP_INFERNO = 14,
    COLORMAP_PLASMA = 15,
    COLORMAP_VIRIDIS = 16,
    COLORMAP_CIVIDIS = 17,
    COLORMAP_TWILIGHT = 18,
    COLORMAP_TWILIGHT_SHIFTED = 19,
    COLORMAP_TURBO = 20,
    COLORMAP_DEEPGREEN = 21
};


// C++: enum ConnectedComponentsAlgorithmsTypes (cv.ConnectedComponentsAlgorithmsTypes)
typedef NS_ENUM(int, ConnectedComponentsAlgorithmsTypes) {
    CCL_DEFAULT = -1,
    CCL_WU = 0,
    CCL_GRANA = 1,
    CCL_BOLELLI = 2,
    CCL_SAUF = 3,
    CCL_BBDT = 4,
    CCL_SPAGHETTI = 5
};


// C++: enum ConnectedComponentsTypes (cv.ConnectedComponentsTypes)
typedef NS_ENUM(int, ConnectedComponentsTypes) {
    CC_STAT_LEFT = 0,
    CC_STAT_TOP = 1,
    CC_STAT_WIDTH = 2,
    CC_STAT_HEIGHT = 3,
    CC_STAT_AREA = 4,
    CC_STAT_MAX = 5
};


// C++: enum ContourApproximationModes (cv.ContourApproximationModes)
typedef NS_ENUM(int, ContourApproximationModes) {
    CHAIN_CODE = 0,
    CHAIN_APPROX_NONE = 1,
    CHAIN_APPROX_SIMPLE = 2,
    CHAIN_APPROX_TC89_L1 = 3,
    CHAIN_APPROX_TC89_KCOS = 4,
    LINK_RUNS = 5
};


// C++: enum DistanceTransformLabelTypes (cv.DistanceTransformLabelTypes)
typedef NS_ENUM(int, DistanceTransformLabelTypes) {
    DIST_LABEL_CCOMP = 0,
    DIST_LABEL_PIXEL = 1
};


// C++: enum DistanceTransformMasks (cv.DistanceTransformMasks)
typedef NS_ENUM(int, DistanceTransformMasks) {
    DIST_MASK_3 = 3,
    DIST_MASK_5 = 5,
    DIST_MASK_PRECISE = 0
};


// C++: enum FloodFillFlags (cv.FloodFillFlags)
typedef NS_ENUM(int, FloodFillFlags) {
    FLOODFILL_FIXED_RANGE = 1 << 16,
    FLOODFILL_MASK_ONLY = 1 << 17
};


// C++: enum GrabCutClasses (cv.GrabCutClasses)
typedef NS_ENUM(int, GrabCutClasses) {
    GC_BGD = 0,
    GC_FGD = 1,
    GC_PR_BGD = 2,
    GC_PR_FGD = 3
};


// C++: enum GrabCutModes (cv.GrabCutModes)
typedef NS_ENUM(int, GrabCutModes) {
    GC_INIT_WITH_RECT = 0,
    GC_INIT_WITH_MASK = 1,
    GC_EVAL = 2,
    GC_EVAL_FREEZE_MODEL = 3
};


// C++: enum HersheyFonts (cv.HersheyFonts)
typedef NS_ENUM(int, HersheyFonts) {
    FONT_HERSHEY_SIMPLEX = 0,
    FONT_HERSHEY_PLAIN = 1,
    FONT_HERSHEY_DUPLEX = 2,
    FONT_HERSHEY_COMPLEX = 3,
    FONT_HERSHEY_TRIPLEX = 4,
    FONT_HERSHEY_COMPLEX_SMALL = 5,
    FONT_HERSHEY_SCRIPT_SIMPLEX = 6,
    FONT_HERSHEY_SCRIPT_COMPLEX = 7,
    FONT_ITALIC = 16
};


// C++: enum HistCompMethods (cv.HistCompMethods)
typedef NS_ENUM(int, HistCompMethods) {
    HISTCMP_CORREL = 0,
    HISTCMP_CHISQR = 1,
    HISTCMP_INTERSECT = 2,
    HISTCMP_BHATTACHARYYA = 3,
    HISTCMP_HELLINGER = HISTCMP_BHATTACHARYYA,
    HISTCMP_CHISQR_ALT = 4,
    HISTCMP_KL_DIV = 5
};


// C++: enum HoughModes (cv.HoughModes)
typedef NS_ENUM(int, HoughModes) {
    HOUGH_STANDARD = 0,
    HOUGH_PROBABILISTIC = 1,
    HOUGH_MULTI_SCALE = 2,
    HOUGH_GRADIENT = 3,
    HOUGH_GRADIENT_ALT = 4
};


// C++: enum InterpolationFlags (cv.InterpolationFlags)
typedef NS_ENUM(int, InterpolationFlags) {
    INTER_NEAREST = 0,
    INTER_LINEAR = 1,
    INTER_CUBIC = 2,
    INTER_AREA = 3,
    INTER_LANCZOS4 = 4,
    INTER_LINEAR_EXACT = 5,
    INTER_NEAREST_EXACT = 6,
    INTER_MAX = 7,
    WARP_FILL_OUTLIERS = 8,
    WARP_INVERSE_MAP = 16,
    WARP_RELATIVE_MAP = 32
};


// C++: enum InterpolationMasks (cv.InterpolationMasks)
typedef NS_ENUM(int, InterpolationMasks) {
    INTER_BITS = 5,
    INTER_BITS2 = INTER_BITS * 2,
    INTER_TAB_SIZE = 1 << INTER_BITS,
    INTER_TAB_SIZE2 = INTER_TAB_SIZE * INTER_TAB_SIZE
};


// C++: enum LineSegmentDetectorModes (cv.LineSegmentDetectorModes)
typedef NS_ENUM(int, LineSegmentDetectorModes) {
    LSD_REFINE_NONE = 0,
    LSD_REFINE_STD = 1,
    LSD_REFINE_ADV = 2
};


// C++: enum LineTypes (cv.LineTypes)
typedef NS_ENUM(int, LineTypes) {
    FILLED = -1,
    LINE_4 = 4,
    LINE_8 = 8,
    LINE_AA = 16
};


// C++: enum MarkerTypes (cv.MarkerTypes)
typedef NS_ENUM(int, MarkerTypes) {
    MARKER_CROSS = 0,
    MARKER_TILTED_CROSS = 1,
    MARKER_STAR = 2,
    MARKER_DIAMOND = 3,
    MARKER_SQUARE = 4,
    MARKER_TRIANGLE_UP = 5,
    MARKER_TRIANGLE_DOWN = 6
};


// C++: enum MorphShapes (cv.MorphShapes)
typedef NS_ENUM(int, MorphShapes) {
    MORPH_RECT = 0,
    MORPH_CROSS = 1,
    MORPH_ELLIPSE = 2,
    MORPH_DIAMOND = 3
};


// C++: enum MorphTypes (cv.MorphTypes)
typedef NS_ENUM(int, MorphTypes) {
    MORPH_ERODE = 0,
    MORPH_DILATE = 1,
    MORPH_OPEN = 2,
    MORPH_CLOSE = 3,
    MORPH_GRADIENT = 4,
    MORPH_TOPHAT = 5,
    MORPH_BLACKHAT = 6,
    MORPH_HITMISS = 7
};


// C++: enum PutTextFlags (cv.PutTextFlags)
typedef NS_ENUM(int, PutTextFlags) {
    PUT_TEXT_ALIGN_LEFT = 0,
    PUT_TEXT_ALIGN_CENTER = 1,
    PUT_TEXT_ALIGN_RIGHT = 2,
    PUT_TEXT_ALIGN_MASK = 3,
    PUT_TEXT_ORIGIN_TL = 0,
    PUT_TEXT_ORIGIN_BL = 32,
    PUT_TEXT_WRAP = 128
};


// C++: enum RetrievalModes (cv.RetrievalModes)
typedef NS_ENUM(int, RetrievalModes) {
    RETR_EXTERNAL = 0,
    RETR_LIST = 1,
    RETR_CCOMP = 2,
    RETR_TREE = 3,
    RETR_FLOODFILL = 4
};


// C++: enum ShapeMatchModes (cv.ShapeMatchModes)
typedef NS_ENUM(int, ShapeMatchModes) {
    CONTOURS_MATCH_I1 = 1,
    CONTOURS_MATCH_I2 = 2,
    CONTOURS_MATCH_I3 = 3
};


// C++: enum SpecialFilter (cv.SpecialFilter)
typedef NS_ENUM(int, SpecialFilter) {
    FILTER_SCHARR = -1
};


// C++: enum TemplateMatchModes (cv.TemplateMatchModes)
typedef NS_ENUM(int, TemplateMatchModes) {
    TM_SQDIFF = 0,
    TM_SQDIFF_NORMED = 1,
    TM_CCORR = 2,
    TM_CCORR_NORMED = 3,
    TM_CCOEFF = 4,
    TM_CCOEFF_NORMED = 5
};


// C++: enum ThresholdTypes (cv.ThresholdTypes)
typedef NS_ENUM(int, ThresholdTypes) {
    THRESH_BINARY = 0,
    THRESH_BINARY_INV = 1,
    THRESH_TRUNC = 2,
    THRESH_TOZERO = 3,
    THRESH_TOZERO_INV = 4,
    THRESH_MASK = 7,
    THRESH_OTSU = 8,
    THRESH_TRIANGLE = 16,
    THRESH_DRYRUN = 128
};


// C++: enum UndistortTypes (cv.UndistortTypes)
typedef NS_ENUM(int, UndistortTypes) {
    PROJ_SPHERICAL_ORTHO = 0,
    PROJ_SPHERICAL_EQRECT = 1
};


// C++: enum WarpPolarMode (cv.WarpPolarMode)
typedef NS_ENUM(int, WarpPolarMode) {
    WARP_POLAR_LINEAR = 0,
    WARP_POLAR_LOG = 256
};



NS_ASSUME_NONNULL_BEGIN

// C++: class Imgproc
/**
 * The Imgproc module
 *
 * Member classes: `GeneralizedHough`, `GeneralizedHoughBallard`, `GeneralizedHoughGuil`, `CLAHE`, `LineSegmentDetector`, `Filter2DParams`, `Moments`, `FontFace`
 *
 * Member enums: `SpecialFilter`, `MorphTypes`, `MorphShapes`, `InterpolationFlags`, `WarpPolarMode`, `InterpolationMasks`, `DistanceTransformMasks`, `ThresholdTypes`, `AdaptiveThresholdTypes`, `GrabCutClasses`, `GrabCutModes`, `DistanceTransformLabelTypes`, `FloodFillFlags`, `AlphaCompositeOperations`, `ConnectedComponentsTypes`, `ConnectedComponentsAlgorithmsTypes`, `RetrievalModes`, `ContourApproximationModes`, `ShapeMatchModes`, `HoughModes`, `HistCompMethods`, `LineSegmentDetectorModes`, `ColorConversionCodes`, `LineTypes`, `HersheyFonts`, `MarkerTypes`, `UndistortTypes`, `TemplateMatchModes`, `ColormapTypes`, `PutTextFlags`
 */
CV_EXPORTS @interface Imgproc : NSObject

#pragma mark - Methods


//
//  Ptr_LineSegmentDetector cv::createLineSegmentDetector(LineSegmentDetectorModes refine = LSD_REFINE_STD, double scale = 0.8, double sigma_scale = 0.6, double quant = 2.0, double ang_th = 22.5, double log_eps = 0, double density_th = 0.7, int n_bins = 1024)
//
/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 * @param refine The way found lines will be refined, see ``LineSegmentDetectorModes``
 * @param scale The scale of the image that will be used to find the lines. Range (0..1].
 * @param sigma_scale Sigma for Gaussian filter. It is computed as sigma = sigma_scale/scale.
 * @param quant Bound to the quantization error on the gradient norm.
 * @param ang_th Gradient angle tolerance in degrees.
 * @param log_eps Detection threshold: -log10(NFA) \> log_eps. Used only when advance refinement is chosen.
 * @param density_th Minimal density of aligned region points in the enclosing rectangle.
 * @param n_bins Number of bins in pseudo-ordering of gradient modulus.
 */
+ (LineSegmentDetector*)createLineSegmentDetector:(LineSegmentDetectorModes)refine scale:(double)scale sigma_scale:(double)sigma_scale quant:(double)quant ang_th:(double)ang_th log_eps:(double)log_eps density_th:(double)density_th n_bins:(int)n_bins NS_SWIFT_NAME(createLineSegmentDetector(refine:scale:sigma_scale:quant:ang_th:log_eps:density_th:n_bins:));

/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 * @param refine The way found lines will be refined, see ``LineSegmentDetectorModes``
 * @param scale The scale of the image that will be used to find the lines. Range (0..1].
 * @param sigma_scale Sigma for Gaussian filter. It is computed as sigma = sigma_scale/scale.
 * @param quant Bound to the quantization error on the gradient norm.
 * @param ang_th Gradient angle tolerance in degrees.
 * @param log_eps Detection threshold: -log10(NFA) \> log_eps. Used only when advance refinement is chosen.
 * @param density_th Minimal density of aligned region points in the enclosing rectangle.
 */
+ (LineSegmentDetector*)createLineSegmentDetector:(LineSegmentDetectorModes)refine scale:(double)scale sigma_scale:(double)sigma_scale quant:(double)quant ang_th:(double)ang_th log_eps:(double)log_eps density_th:(double)density_th NS_SWIFT_NAME(createLineSegmentDetector(refine:scale:sigma_scale:quant:ang_th:log_eps:density_th:));

/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 * @param refine The way found lines will be refined, see ``LineSegmentDetectorModes``
 * @param scale The scale of the image that will be used to find the lines. Range (0..1].
 * @param sigma_scale Sigma for Gaussian filter. It is computed as sigma = sigma_scale/scale.
 * @param quant Bound to the quantization error on the gradient norm.
 * @param ang_th Gradient angle tolerance in degrees.
 * @param log_eps Detection threshold: -log10(NFA) \> log_eps. Used only when advance refinement is chosen.
 */
+ (LineSegmentDetector*)createLineSegmentDetector:(LineSegmentDetectorModes)refine scale:(double)scale sigma_scale:(double)sigma_scale quant:(double)quant ang_th:(double)ang_th log_eps:(double)log_eps NS_SWIFT_NAME(createLineSegmentDetector(refine:scale:sigma_scale:quant:ang_th:log_eps:));

/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 * @param refine The way found lines will be refined, see ``LineSegmentDetectorModes``
 * @param scale The scale of the image that will be used to find the lines. Range (0..1].
 * @param sigma_scale Sigma for Gaussian filter. It is computed as sigma = sigma_scale/scale.
 * @param quant Bound to the quantization error on the gradient norm.
 * @param ang_th Gradient angle tolerance in degrees.
 */
+ (LineSegmentDetector*)createLineSegmentDetector:(LineSegmentDetectorModes)refine scale:(double)scale sigma_scale:(double)sigma_scale quant:(double)quant ang_th:(double)ang_th NS_SWIFT_NAME(createLineSegmentDetector(refine:scale:sigma_scale:quant:ang_th:));

/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 * @param refine The way found lines will be refined, see ``LineSegmentDetectorModes``
 * @param scale The scale of the image that will be used to find the lines. Range (0..1].
 * @param sigma_scale Sigma for Gaussian filter. It is computed as sigma = sigma_scale/scale.
 * @param quant Bound to the quantization error on the gradient norm.
 */
+ (LineSegmentDetector*)createLineSegmentDetector:(LineSegmentDetectorModes)refine scale:(double)scale sigma_scale:(double)sigma_scale quant:(double)quant NS_SWIFT_NAME(createLineSegmentDetector(refine:scale:sigma_scale:quant:));

/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 * @param refine The way found lines will be refined, see ``LineSegmentDetectorModes``
 * @param scale The scale of the image that will be used to find the lines. Range (0..1].
 * @param sigma_scale Sigma for Gaussian filter. It is computed as sigma = sigma_scale/scale.
 */
+ (LineSegmentDetector*)createLineSegmentDetector:(LineSegmentDetectorModes)refine scale:(double)scale sigma_scale:(double)sigma_scale NS_SWIFT_NAME(createLineSegmentDetector(refine:scale:sigma_scale:));

/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 * @param refine The way found lines will be refined, see ``LineSegmentDetectorModes``
 * @param scale The scale of the image that will be used to find the lines. Range (0..1].
 */
+ (LineSegmentDetector*)createLineSegmentDetector:(LineSegmentDetectorModes)refine scale:(double)scale NS_SWIFT_NAME(createLineSegmentDetector(refine:scale:));

/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 * @param refine The way found lines will be refined, see ``LineSegmentDetectorModes``
 */
+ (LineSegmentDetector*)createLineSegmentDetector:(LineSegmentDetectorModes)refine NS_SWIFT_NAME(createLineSegmentDetector(refine:));

/**
 * Creates a smart pointer to a LineSegmentDetector object and initializes it.
 *
 * The LineSegmentDetector algorithm is defined using the standard values. Only advanced users may want
 * to edit those, as to tailor it for their own application.
 *
 */
+ (LineSegmentDetector*)createLineSegmentDetector NS_SWIFT_NAME(createLineSegmentDetector());


//
//  Mat cv::getGaussianKernel(int ksize, double sigma, int ktype = CV_64F)
//
/**
 * Returns Gaussian filter coefficients.
 *
 * The function computes and returns the `$$\texttt{ksize} \times 1$$` matrix of Gaussian filter
 * coefficients:
 *
 * `$$G_i= \alpha *e^{-(i-( \texttt{ksize} -1)/2)^2/(2* \texttt{sigma}^2)},$$`
 *
 * where `$$i=0..\texttt{ksize}-1$$` and `$$\alpha$$` is the scale factor chosen so that `$$\sum_i G_i=1$$`.
 *
 * Two of such generated kernels can be passed to sepFilter2D. Those functions automatically recognize
 * smoothing kernels (a symmetrical kernel with sum of weights equal to 1) and handle them accordingly.
 * You may also use the higher-level GaussianBlur.
 * @param ksize Aperture size. It should be odd ( `$$\texttt{ksize} \mod 2 = 1$$` ) and positive.
 * @param sigma Gaussian standard deviation. If it is non-positive, it is computed from ksize as
 * `sigma = 0.3*((ksize-1)*0.5 - 1) + 0.8`.
 * @param ktype Type of filter coefficients. It can be CV_32F or CV_64F .
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``getDerivKernels:ky:dx:dy:ksize:normalize:ktype:``, ``getStructuringElement:ksize:anchor:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``
 */
+ (Mat*)getGaussianKernel:(int)ksize sigma:(double)sigma ktype:(int)ktype NS_SWIFT_NAME(getGaussianKernel(ksize:sigma:ktype:));

/**
 * Returns Gaussian filter coefficients.
 *
 * The function computes and returns the `$$\texttt{ksize} \times 1$$` matrix of Gaussian filter
 * coefficients:
 *
 * `$$G_i= \alpha *e^{-(i-( \texttt{ksize} -1)/2)^2/(2* \texttt{sigma}^2)},$$`
 *
 * where `$$i=0..\texttt{ksize}-1$$` and `$$\alpha$$` is the scale factor chosen so that `$$\sum_i G_i=1$$`.
 *
 * Two of such generated kernels can be passed to sepFilter2D. Those functions automatically recognize
 * smoothing kernels (a symmetrical kernel with sum of weights equal to 1) and handle them accordingly.
 * You may also use the higher-level GaussianBlur.
 * @param ksize Aperture size. It should be odd ( `$$\texttt{ksize} \mod 2 = 1$$` ) and positive.
 * @param sigma Gaussian standard deviation. If it is non-positive, it is computed from ksize as
 * `sigma = 0.3*((ksize-1)*0.5 - 1) + 0.8`.
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``getDerivKernels:ky:dx:dy:ksize:normalize:ktype:``, ``getStructuringElement:ksize:anchor:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``
 */
+ (Mat*)getGaussianKernel:(int)ksize sigma:(double)sigma NS_SWIFT_NAME(getGaussianKernel(ksize:sigma:));


//
//  void cv::getDerivKernels(Mat& kx, Mat& ky, int dx, int dy, int ksize, bool normalize = false, int ktype = CV_32F)
//
/**
 * Returns filter coefficients for computing spatial image derivatives.
 *
 * The function computes and returns the filter coefficients for spatial image derivatives. When
 * `ksize=FILTER_SCHARR`, the Scharr `$$3 \times 3$$` kernels are generated (see ``Imgproc/Scharr``). Otherwise, Sobel
 * kernels are generated (see ``Imgproc/Sobel``). The filters are normally passed to ``Imgproc/sepFilter2D`` or to
 *
 * @param kx Output matrix of row filter coefficients. It has the type ktype .
 * @param ky Output matrix of column filter coefficients. It has the type ktype .
 * @param dx Derivative order in respect of x.
 * @param dy Derivative order in respect of y.
 * @param ksize Aperture size. It can be FILTER_SCHARR, 1, 3, 5, or 7.
 * @param normalize Flag indicating whether to normalize (scale down) the filter coefficients or not.
 * Theoretically, the coefficients should have the denominator `$$=2^{ksize*2-dx-dy-2}$$`. If you are
 * going to filter floating-point images, you are likely to use the normalized kernels. But if you
 * compute derivatives of an 8-bit image, store the results in a 16-bit image, and wish to preserve
 * all the fractional bits, you may want to set normalize=false .
 * @param ktype Type of filter coefficients. It can be CV_32f or CV_64F .
 */
+ (void)getDerivKernels:(Mat*)kx ky:(Mat*)ky dx:(int)dx dy:(int)dy ksize:(int)ksize normalize:(BOOL)normalize ktype:(int)ktype NS_SWIFT_NAME(getDerivKernels(kx:ky:dx:dy:ksize:normalize:ktype:));

/**
 * Returns filter coefficients for computing spatial image derivatives.
 *
 * The function computes and returns the filter coefficients for spatial image derivatives. When
 * `ksize=FILTER_SCHARR`, the Scharr `$$3 \times 3$$` kernels are generated (see ``Imgproc/Scharr``). Otherwise, Sobel
 * kernels are generated (see ``Imgproc/Sobel``). The filters are normally passed to ``Imgproc/sepFilter2D`` or to
 *
 * @param kx Output matrix of row filter coefficients. It has the type ktype .
 * @param ky Output matrix of column filter coefficients. It has the type ktype .
 * @param dx Derivative order in respect of x.
 * @param dy Derivative order in respect of y.
 * @param ksize Aperture size. It can be FILTER_SCHARR, 1, 3, 5, or 7.
 * @param normalize Flag indicating whether to normalize (scale down) the filter coefficients or not.
 * Theoretically, the coefficients should have the denominator `$$=2^{ksize*2-dx-dy-2}$$`. If you are
 * going to filter floating-point images, you are likely to use the normalized kernels. But if you
 * compute derivatives of an 8-bit image, store the results in a 16-bit image, and wish to preserve
 * all the fractional bits, you may want to set normalize=false .
 */
+ (void)getDerivKernels:(Mat*)kx ky:(Mat*)ky dx:(int)dx dy:(int)dy ksize:(int)ksize normalize:(BOOL)normalize NS_SWIFT_NAME(getDerivKernels(kx:ky:dx:dy:ksize:normalize:));

/**
 * Returns filter coefficients for computing spatial image derivatives.
 *
 * The function computes and returns the filter coefficients for spatial image derivatives. When
 * `ksize=FILTER_SCHARR`, the Scharr `$$3 \times 3$$` kernels are generated (see ``Imgproc/Scharr``). Otherwise, Sobel
 * kernels are generated (see ``Imgproc/Sobel``). The filters are normally passed to ``Imgproc/sepFilter2D`` or to
 *
 * @param kx Output matrix of row filter coefficients. It has the type ktype .
 * @param ky Output matrix of column filter coefficients. It has the type ktype .
 * @param dx Derivative order in respect of x.
 * @param dy Derivative order in respect of y.
 * @param ksize Aperture size. It can be FILTER_SCHARR, 1, 3, 5, or 7.
 * Theoretically, the coefficients should have the denominator `$$=2^{ksize*2-dx-dy-2}$$`. If you are
 * going to filter floating-point images, you are likely to use the normalized kernels. But if you
 * compute derivatives of an 8-bit image, store the results in a 16-bit image, and wish to preserve
 * all the fractional bits, you may want to set normalize=false .
 */
+ (void)getDerivKernels:(Mat*)kx ky:(Mat*)ky dx:(int)dx dy:(int)dy ksize:(int)ksize NS_SWIFT_NAME(getDerivKernels(kx:ky:dx:dy:ksize:));


//
//  Mat cv::getGaborKernel(Size ksize, double sigma, double theta, double lambd, double gamma, double psi = CV_PI*0.5, int ktype = CV_64F)
//
/**
 * Returns Gabor filter coefficients.
 *
 * For more details about gabor filter equations and parameters, see: [Gabor
 * Filter](https://en.wikipedia.org/wiki/Gabor_filter).
 *
 * @param ksize Size of the filter returned.
 * @param sigma Standard deviation of the gaussian envelope.
 * @param theta Orientation of the normal to the parallel stripes of a Gabor function.
 * @param lambd Wavelength of the sinusoidal factor.
 * @param gamma Spatial aspect ratio.
 * @param psi Phase offset.
 * @param ktype Type of filter coefficients. It can be CV_32F or CV_64F .
 */
+ (Mat*)getGaborKernel:(Size2i*)ksize sigma:(double)sigma theta:(double)theta lambd:(double)lambd gamma:(double)gamma psi:(double)psi ktype:(int)ktype NS_SWIFT_NAME(getGaborKernel(ksize:sigma:theta:lambd:gamma:psi:ktype:));

/**
 * Returns Gabor filter coefficients.
 *
 * For more details about gabor filter equations and parameters, see: [Gabor
 * Filter](https://en.wikipedia.org/wiki/Gabor_filter).
 *
 * @param ksize Size of the filter returned.
 * @param sigma Standard deviation of the gaussian envelope.
 * @param theta Orientation of the normal to the parallel stripes of a Gabor function.
 * @param lambd Wavelength of the sinusoidal factor.
 * @param gamma Spatial aspect ratio.
 * @param psi Phase offset.
 */
+ (Mat*)getGaborKernel:(Size2i*)ksize sigma:(double)sigma theta:(double)theta lambd:(double)lambd gamma:(double)gamma psi:(double)psi NS_SWIFT_NAME(getGaborKernel(ksize:sigma:theta:lambd:gamma:psi:));

/**
 * Returns Gabor filter coefficients.
 *
 * For more details about gabor filter equations and parameters, see: [Gabor
 * Filter](https://en.wikipedia.org/wiki/Gabor_filter).
 *
 * @param ksize Size of the filter returned.
 * @param sigma Standard deviation of the gaussian envelope.
 * @param theta Orientation of the normal to the parallel stripes of a Gabor function.
 * @param lambd Wavelength of the sinusoidal factor.
 * @param gamma Spatial aspect ratio.
 */
+ (Mat*)getGaborKernel:(Size2i*)ksize sigma:(double)sigma theta:(double)theta lambd:(double)lambd gamma:(double)gamma NS_SWIFT_NAME(getGaborKernel(ksize:sigma:theta:lambd:gamma:));


//
//  Mat cv::getStructuringElement(MorphShapes shape, Size ksize, Point anchor = Point(-1,-1))
//
/**
 * Returns a structuring element of the specified size and shape for morphological operations.
 *
 * The function constructs and returns the structuring element that can be further passed to ``Imgproc/erode``,
 * ``Imgproc/dilate`` or ``Imgproc/morphologyEx``. But you can also construct an arbitrary binary mask yourself and use it as
 * the structuring element.
 *
 * @param shape Element shape that could be one of ``MorphShapes``
 * @param ksize Size of the structuring element.
 * @param anchor Anchor position within the element. The default value `$$(-1, -1)$$` means that the
 * anchor is at the center. Note that only the shape of a cross-shaped element depends on the anchor
 * position. In other cases the anchor just regulates how much the result of the morphological
 * operation is shifted.
 */
+ (Mat*)getStructuringElement:(MorphShapes)shape ksize:(Size2i*)ksize anchor:(Point2i*)anchor NS_SWIFT_NAME(getStructuringElement(shape:ksize:anchor:));

/**
 * Returns a structuring element of the specified size and shape for morphological operations.
 *
 * The function constructs and returns the structuring element that can be further passed to ``Imgproc/erode``,
 * ``Imgproc/dilate`` or ``Imgproc/morphologyEx``. But you can also construct an arbitrary binary mask yourself and use it as
 * the structuring element.
 *
 * @param shape Element shape that could be one of ``MorphShapes``
 * @param ksize Size of the structuring element.
 * anchor is at the center. Note that only the shape of a cross-shaped element depends on the anchor
 * position. In other cases the anchor just regulates how much the result of the morphological
 * operation is shifted.
 */
+ (Mat*)getStructuringElement:(MorphShapes)shape ksize:(Size2i*)ksize NS_SWIFT_NAME(getStructuringElement(shape:ksize:));


//
//  void cv::medianBlur(Mat src, Mat& dst, int ksize)
//
/**
 * Blurs an image using the median filter.
 *
 * The function smoothes an image using the median filter with the `$$\texttt{ksize} \times
 * \texttt{ksize}$$` aperture. Each channel of a multi-channel image is processed independently.
 * In-place operation is supported.
 *
 * Note:* The median filter uses ``BorderTypes/BORDER_REPLICATE`` internally to cope with border pixels, see ``BorderTypes``
 *
 * @param src input 1-, 3-, or 4-channel image; when ksize is 3 or 5, the image depth should be
 * CV_8U, CV_16U, or CV_32F, for larger aperture sizes, it can only be CV_8U.
 * @param dst destination array of the same size and type as src.
 * @param ksize aperture linear size; it must be odd and greater than 1, for example: 3, 5, 7 ...
 *
 * - SeeAlso ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``blur:dst:ksize:anchor:borderType:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``
 */
+ (void)medianBlur:(Mat*)src dst:(Mat*)dst ksize:(int)ksize NS_SWIFT_NAME(medianBlur(src:dst:ksize:));


//
//  void cv::GaussianBlur(Mat src, Mat& dst, Size ksize, double sigmaX, double sigmaY = 0, BorderTypes borderType = BORDER_DEFAULT, AlgorithmHint hint = cv::ALGO_HINT_DEFAULT)
//
/**
 * Blurs an image using a Gaussian filter.
 *
 * The function convolves the source image with the specified Gaussian kernel. In-place filtering is
 * supported.
 *
 * @param src input image; the image can have any number of channels, which are processed
 * independently, but the depth should be CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param ksize Gaussian kernel size. ksize.width and ksize.height can differ but they both must be
 * positive and odd. Or, they can be zero's and then they are computed from sigma.
 * @param sigmaX Gaussian kernel standard deviation in X direction.
 * @param sigmaY Gaussian kernel standard deviation in Y direction; if sigmaY is zero, it is set to be
 * equal to sigmaX, if both sigmas are zeros, they are computed from ksize.width and ksize.height,
 * respectively (see ``Imgproc/getGaussianKernel`` for details); to fully control the result regardless of
 * possible future modifications of all this semantics, it is recommended to specify all of ksize,
 * sigmaX, and sigmaY.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 * @param hint Implementation modification flags. See ``AlgorithmHint``
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``blur:dst:ksize:anchor:borderType:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``medianBlur:dst:ksize:``
 */
+ (void)GaussianBlur:(Mat*)src dst:(Mat*)dst ksize:(Size2i*)ksize sigmaX:(double)sigmaX sigmaY:(double)sigmaY borderType:(BorderTypes)borderType hint:(AlgorithmHint)hint NS_SWIFT_NAME(GaussianBlur(src:dst:ksize:sigmaX:sigmaY:borderType:hint:));

/**
 * Blurs an image using a Gaussian filter.
 *
 * The function convolves the source image with the specified Gaussian kernel. In-place filtering is
 * supported.
 *
 * @param src input image; the image can have any number of channels, which are processed
 * independently, but the depth should be CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param ksize Gaussian kernel size. ksize.width and ksize.height can differ but they both must be
 * positive and odd. Or, they can be zero's and then they are computed from sigma.
 * @param sigmaX Gaussian kernel standard deviation in X direction.
 * @param sigmaY Gaussian kernel standard deviation in Y direction; if sigmaY is zero, it is set to be
 * equal to sigmaX, if both sigmas are zeros, they are computed from ksize.width and ksize.height,
 * respectively (see ``Imgproc/getGaussianKernel`` for details); to fully control the result regardless of
 * possible future modifications of all this semantics, it is recommended to specify all of ksize,
 * sigmaX, and sigmaY.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``blur:dst:ksize:anchor:borderType:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``medianBlur:dst:ksize:``
 */
+ (void)GaussianBlur:(Mat*)src dst:(Mat*)dst ksize:(Size2i*)ksize sigmaX:(double)sigmaX sigmaY:(double)sigmaY borderType:(BorderTypes)borderType NS_SWIFT_NAME(GaussianBlur(src:dst:ksize:sigmaX:sigmaY:borderType:));

/**
 * Blurs an image using a Gaussian filter.
 *
 * The function convolves the source image with the specified Gaussian kernel. In-place filtering is
 * supported.
 *
 * @param src input image; the image can have any number of channels, which are processed
 * independently, but the depth should be CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param ksize Gaussian kernel size. ksize.width and ksize.height can differ but they both must be
 * positive and odd. Or, they can be zero's and then they are computed from sigma.
 * @param sigmaX Gaussian kernel standard deviation in X direction.
 * @param sigmaY Gaussian kernel standard deviation in Y direction; if sigmaY is zero, it is set to be
 * equal to sigmaX, if both sigmas are zeros, they are computed from ksize.width and ksize.height,
 * respectively (see ``Imgproc/getGaussianKernel`` for details); to fully control the result regardless of
 * possible future modifications of all this semantics, it is recommended to specify all of ksize,
 * sigmaX, and sigmaY.
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``blur:dst:ksize:anchor:borderType:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``medianBlur:dst:ksize:``
 */
+ (void)GaussianBlur:(Mat*)src dst:(Mat*)dst ksize:(Size2i*)ksize sigmaX:(double)sigmaX sigmaY:(double)sigmaY NS_SWIFT_NAME(GaussianBlur(src:dst:ksize:sigmaX:sigmaY:));

/**
 * Blurs an image using a Gaussian filter.
 *
 * The function convolves the source image with the specified Gaussian kernel. In-place filtering is
 * supported.
 *
 * @param src input image; the image can have any number of channels, which are processed
 * independently, but the depth should be CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param ksize Gaussian kernel size. ksize.width and ksize.height can differ but they both must be
 * positive and odd. Or, they can be zero's and then they are computed from sigma.
 * @param sigmaX Gaussian kernel standard deviation in X direction.
 * equal to sigmaX, if both sigmas are zeros, they are computed from ksize.width and ksize.height,
 * respectively (see ``Imgproc/getGaussianKernel`` for details); to fully control the result regardless of
 * possible future modifications of all this semantics, it is recommended to specify all of ksize,
 * sigmaX, and sigmaY.
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``blur:dst:ksize:anchor:borderType:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``medianBlur:dst:ksize:``
 */
+ (void)GaussianBlur:(Mat*)src dst:(Mat*)dst ksize:(Size2i*)ksize sigmaX:(double)sigmaX NS_SWIFT_NAME(GaussianBlur(src:dst:ksize:sigmaX:));


//
//  void cv::bilateralFilter(Mat src, Mat& dst, int d, double sigmaColor, double sigmaSpace, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Applies the bilateral filter to an image.
 *
 * The function applies bilateral filtering to the input image, as described in
 * https://homepages.inf.ed.ac.uk/rbf/CVonline/LOCAL_COPIES/MANDUCHI1/Bilateral_Filtering.html
 * bilateralFilter can reduce unwanted noise very well while keeping edges fairly sharp. However, it is
 * very slow compared to most filters.
 *
 * _Sigma values_: For simplicity, you can set the 2 sigma values to be the same. If they are small (\<
 * 10), the filter will not have much effect, whereas if they are large (\> 150), they will have a very
 * strong effect, making the image look "cartoonish".
 *
 * _Filter size_: Large filters (d \> 5) are very slow, so it is recommended to use d=5 for real-time
 * applications, and perhaps d=9 for offline applications that need heavy noise filtering.
 *
 * This filter does not work inplace.
 * @param src Source 8-bit or floating-point, 1-channel or 3-channel image.
 * @param dst Destination image of the same size and type as src .
 * @param d Diameter of each pixel neighborhood that is used during filtering. If it is non-positive,
 * it is computed from sigmaSpace.
 * @param sigmaColor Filter sigma in the color space. A larger value of the parameter means that
 * farther colors within the pixel neighborhood (see sigmaSpace) will be mixed together, resulting
 * in larger areas of semi-equal color.
 * @param sigmaSpace Filter sigma in the coordinate space. A larger value of the parameter means that
 * farther pixels will influence each other as long as their colors are close enough (see sigmaColor
 * ). When d\>0, it specifies the neighborhood size regardless of sigmaSpace. Otherwise, d is
 * proportional to sigmaSpace.
 * @param borderType border mode used to extrapolate pixels outside of the image, see ``BorderTypes``
 */
+ (void)bilateralFilter:(Mat*)src dst:(Mat*)dst d:(int)d sigmaColor:(double)sigmaColor sigmaSpace:(double)sigmaSpace borderType:(BorderTypes)borderType NS_SWIFT_NAME(bilateralFilter(src:dst:d:sigmaColor:sigmaSpace:borderType:));

/**
 * Applies the bilateral filter to an image.
 *
 * The function applies bilateral filtering to the input image, as described in
 * https://homepages.inf.ed.ac.uk/rbf/CVonline/LOCAL_COPIES/MANDUCHI1/Bilateral_Filtering.html
 * bilateralFilter can reduce unwanted noise very well while keeping edges fairly sharp. However, it is
 * very slow compared to most filters.
 *
 * _Sigma values_: For simplicity, you can set the 2 sigma values to be the same. If they are small (\<
 * 10), the filter will not have much effect, whereas if they are large (\> 150), they will have a very
 * strong effect, making the image look "cartoonish".
 *
 * _Filter size_: Large filters (d \> 5) are very slow, so it is recommended to use d=5 for real-time
 * applications, and perhaps d=9 for offline applications that need heavy noise filtering.
 *
 * This filter does not work inplace.
 * @param src Source 8-bit or floating-point, 1-channel or 3-channel image.
 * @param dst Destination image of the same size and type as src .
 * @param d Diameter of each pixel neighborhood that is used during filtering. If it is non-positive,
 * it is computed from sigmaSpace.
 * @param sigmaColor Filter sigma in the color space. A larger value of the parameter means that
 * farther colors within the pixel neighborhood (see sigmaSpace) will be mixed together, resulting
 * in larger areas of semi-equal color.
 * @param sigmaSpace Filter sigma in the coordinate space. A larger value of the parameter means that
 * farther pixels will influence each other as long as their colors are close enough (see sigmaColor
 * ). When d\>0, it specifies the neighborhood size regardless of sigmaSpace. Otherwise, d is
 * proportional to sigmaSpace.
 */
+ (void)bilateralFilter:(Mat*)src dst:(Mat*)dst d:(int)d sigmaColor:(double)sigmaColor sigmaSpace:(double)sigmaSpace NS_SWIFT_NAME(bilateralFilter(src:dst:d:sigmaColor:sigmaSpace:));


//
//  void cv::boxFilter(Mat src, Mat& dst, int ddepth, Size ksize, Point anchor = Point(-1,-1), bool normalize = true, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Blurs an image using the box filter.
 *
 * The function smooths an image using the kernel:
 *
 * `$$\texttt{K} =  \alpha \begin{bmatrix} 1 & 1 & 1 &  \cdots & 1 & 1  \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \hdotsfor{6} \\ 1 & 1 & 1 &  \cdots & 1 & 1 \end{bmatrix}$$`
 *
 * where
 *
 * `$$\alpha = \begin{cases} \frac{1}{\texttt{ksize.width*ksize.height}} & \texttt{when } \texttt{normalize=true}  \\1 & \texttt{otherwise}\end{cases}$$`
 *
 * Unnormalized box filter is useful for computing various integral characteristics over each pixel
 * neighborhood, such as covariance matrices of image derivatives (used in dense optical flow
 * algorithms, and so on). If you need to compute pixel sums over variable-size windows, use ``Imgproc/integral``.
 *
 * @param src input image.
 * @param dst output image of the same size and type as src.
 * @param ddepth the output image depth (-1 to use src.depth()).
 * @param ksize blurring kernel size.
 * @param anchor anchor point; default value Point(-1,-1) means that the anchor is at the kernel
 * center.
 * @param normalize flag, specifying whether the kernel is normalized by its area or not.
 * @param borderType border mode used to extrapolate pixels outside of the image, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``blur:dst:ksize:anchor:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``medianBlur:dst:ksize:``, ``integral:sum:sdepth:``
 */
+ (void)boxFilter:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(Size2i*)ksize anchor:(Point2i*)anchor normalize:(BOOL)normalize borderType:(BorderTypes)borderType NS_SWIFT_NAME(boxFilter(src:dst:ddepth:ksize:anchor:normalize:borderType:));

/**
 * Blurs an image using the box filter.
 *
 * The function smooths an image using the kernel:
 *
 * `$$\texttt{K} =  \alpha \begin{bmatrix} 1 & 1 & 1 &  \cdots & 1 & 1  \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \hdotsfor{6} \\ 1 & 1 & 1 &  \cdots & 1 & 1 \end{bmatrix}$$`
 *
 * where
 *
 * `$$\alpha = \begin{cases} \frac{1}{\texttt{ksize.width*ksize.height}} & \texttt{when } \texttt{normalize=true}  \\1 & \texttt{otherwise}\end{cases}$$`
 *
 * Unnormalized box filter is useful for computing various integral characteristics over each pixel
 * neighborhood, such as covariance matrices of image derivatives (used in dense optical flow
 * algorithms, and so on). If you need to compute pixel sums over variable-size windows, use ``Imgproc/integral``.
 *
 * @param src input image.
 * @param dst output image of the same size and type as src.
 * @param ddepth the output image depth (-1 to use src.depth()).
 * @param ksize blurring kernel size.
 * @param anchor anchor point; default value Point(-1,-1) means that the anchor is at the kernel
 * center.
 * @param normalize flag, specifying whether the kernel is normalized by its area or not.
 *
 * - SeeAlso ``blur:dst:ksize:anchor:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``medianBlur:dst:ksize:``, ``integral:sum:sdepth:``
 */
+ (void)boxFilter:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(Size2i*)ksize anchor:(Point2i*)anchor normalize:(BOOL)normalize NS_SWIFT_NAME(boxFilter(src:dst:ddepth:ksize:anchor:normalize:));

/**
 * Blurs an image using the box filter.
 *
 * The function smooths an image using the kernel:
 *
 * `$$\texttt{K} =  \alpha \begin{bmatrix} 1 & 1 & 1 &  \cdots & 1 & 1  \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \hdotsfor{6} \\ 1 & 1 & 1 &  \cdots & 1 & 1 \end{bmatrix}$$`
 *
 * where
 *
 * `$$\alpha = \begin{cases} \frac{1}{\texttt{ksize.width*ksize.height}} & \texttt{when } \texttt{normalize=true}  \\1 & \texttt{otherwise}\end{cases}$$`
 *
 * Unnormalized box filter is useful for computing various integral characteristics over each pixel
 * neighborhood, such as covariance matrices of image derivatives (used in dense optical flow
 * algorithms, and so on). If you need to compute pixel sums over variable-size windows, use ``Imgproc/integral``.
 *
 * @param src input image.
 * @param dst output image of the same size and type as src.
 * @param ddepth the output image depth (-1 to use src.depth()).
 * @param ksize blurring kernel size.
 * @param anchor anchor point; default value Point(-1,-1) means that the anchor is at the kernel
 * center.
 *
 * - SeeAlso ``blur:dst:ksize:anchor:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``medianBlur:dst:ksize:``, ``integral:sum:sdepth:``
 */
+ (void)boxFilter:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(Size2i*)ksize anchor:(Point2i*)anchor NS_SWIFT_NAME(boxFilter(src:dst:ddepth:ksize:anchor:));

/**
 * Blurs an image using the box filter.
 *
 * The function smooths an image using the kernel:
 *
 * `$$\texttt{K} =  \alpha \begin{bmatrix} 1 & 1 & 1 &  \cdots & 1 & 1  \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \hdotsfor{6} \\ 1 & 1 & 1 &  \cdots & 1 & 1 \end{bmatrix}$$`
 *
 * where
 *
 * `$$\alpha = \begin{cases} \frac{1}{\texttt{ksize.width*ksize.height}} & \texttt{when } \texttt{normalize=true}  \\1 & \texttt{otherwise}\end{cases}$$`
 *
 * Unnormalized box filter is useful for computing various integral characteristics over each pixel
 * neighborhood, such as covariance matrices of image derivatives (used in dense optical flow
 * algorithms, and so on). If you need to compute pixel sums over variable-size windows, use ``Imgproc/integral``.
 *
 * @param src input image.
 * @param dst output image of the same size and type as src.
 * @param ddepth the output image depth (-1 to use src.depth()).
 * @param ksize blurring kernel size.
 * center.
 *
 * - SeeAlso ``blur:dst:ksize:anchor:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``medianBlur:dst:ksize:``, ``integral:sum:sdepth:``
 */
+ (void)boxFilter:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(Size2i*)ksize NS_SWIFT_NAME(boxFilter(src:dst:ddepth:ksize:));


//
//  void cv::sqrBoxFilter(Mat src, Mat& dst, int ddepth, Size ksize, Point anchor = Point(-1, -1), bool normalize = true, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Calculates the normalized sum of squares of the pixel values overlapping the filter.
 *
 * For every pixel `$$ (x, y) $$` in the source image, the function calculates the sum of squares of those neighboring
 * pixel values which overlap the filter placed over the pixel `$$ (x, y) $$`.
 *
 * The unnormalized square box filter can be useful in computing local image statistics such as the local
 * variance and standard deviation around the neighborhood of a pixel.
 *
 * @param src input image
 * @param dst output image of the same size and type as src
 * @param ddepth the output image depth (-1 to use src.depth())
 * @param ksize kernel size
 * @param anchor kernel anchor point. The default value of Point(-1, -1) denotes that the anchor is at the kernel
 * center.
 * @param normalize flag, specifying whether the kernel is to be normalized by it's area or not.
 * @param borderType border mode used to extrapolate pixels outside of the image, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``
 */
+ (void)sqrBoxFilter:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(Size2i*)ksize anchor:(Point2i*)anchor normalize:(BOOL)normalize borderType:(BorderTypes)borderType NS_SWIFT_NAME(sqrBoxFilter(src:dst:ddepth:ksize:anchor:normalize:borderType:));

/**
 * Calculates the normalized sum of squares of the pixel values overlapping the filter.
 *
 * For every pixel `$$ (x, y) $$` in the source image, the function calculates the sum of squares of those neighboring
 * pixel values which overlap the filter placed over the pixel `$$ (x, y) $$`.
 *
 * The unnormalized square box filter can be useful in computing local image statistics such as the local
 * variance and standard deviation around the neighborhood of a pixel.
 *
 * @param src input image
 * @param dst output image of the same size and type as src
 * @param ddepth the output image depth (-1 to use src.depth())
 * @param ksize kernel size
 * @param anchor kernel anchor point. The default value of Point(-1, -1) denotes that the anchor is at the kernel
 * center.
 * @param normalize flag, specifying whether the kernel is to be normalized by it's area or not.
 *
 * - SeeAlso ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``
 */
+ (void)sqrBoxFilter:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(Size2i*)ksize anchor:(Point2i*)anchor normalize:(BOOL)normalize NS_SWIFT_NAME(sqrBoxFilter(src:dst:ddepth:ksize:anchor:normalize:));

/**
 * Calculates the normalized sum of squares of the pixel values overlapping the filter.
 *
 * For every pixel `$$ (x, y) $$` in the source image, the function calculates the sum of squares of those neighboring
 * pixel values which overlap the filter placed over the pixel `$$ (x, y) $$`.
 *
 * The unnormalized square box filter can be useful in computing local image statistics such as the local
 * variance and standard deviation around the neighborhood of a pixel.
 *
 * @param src input image
 * @param dst output image of the same size and type as src
 * @param ddepth the output image depth (-1 to use src.depth())
 * @param ksize kernel size
 * @param anchor kernel anchor point. The default value of Point(-1, -1) denotes that the anchor is at the kernel
 * center.
 *
 * - SeeAlso ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``
 */
+ (void)sqrBoxFilter:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(Size2i*)ksize anchor:(Point2i*)anchor NS_SWIFT_NAME(sqrBoxFilter(src:dst:ddepth:ksize:anchor:));

/**
 * Calculates the normalized sum of squares of the pixel values overlapping the filter.
 *
 * For every pixel `$$ (x, y) $$` in the source image, the function calculates the sum of squares of those neighboring
 * pixel values which overlap the filter placed over the pixel `$$ (x, y) $$`.
 *
 * The unnormalized square box filter can be useful in computing local image statistics such as the local
 * variance and standard deviation around the neighborhood of a pixel.
 *
 * @param src input image
 * @param dst output image of the same size and type as src
 * @param ddepth the output image depth (-1 to use src.depth())
 * @param ksize kernel size
 * center.
 *
 * - SeeAlso ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``
 */
+ (void)sqrBoxFilter:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(Size2i*)ksize NS_SWIFT_NAME(sqrBoxFilter(src:dst:ddepth:ksize:));


//
//  void cv::blur(Mat src, Mat& dst, Size ksize, Point anchor = Point(-1,-1), BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Blurs an image using the normalized box filter.
 *
 * The function smooths an image using the kernel:
 *
 * `$$\texttt{K} =  \frac{1}{\texttt{ksize.width*ksize.height}} \begin{bmatrix} 1 & 1 & 1 &  \cdots & 1 & 1  \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \hdotsfor{6} \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \end{bmatrix}$$`
 *
 * The call `blur(src, dst, ksize, anchor, borderType)` is equivalent to `boxFilter(src, dst, src.type(), ksize,
 * anchor, true, borderType)`.
 *
 * @param src input image; it can have any number of channels, which are processed independently, but
 * the depth should be CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param ksize blurring kernel size.
 * @param anchor anchor point; default value Point(-1,-1) means that the anchor is at the kernel
 * center.
 * @param borderType border mode used to extrapolate pixels outside of the image, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``medianBlur:dst:ksize:``
 */
+ (void)blur:(Mat*)src dst:(Mat*)dst ksize:(Size2i*)ksize anchor:(Point2i*)anchor borderType:(BorderTypes)borderType NS_SWIFT_NAME(blur(src:dst:ksize:anchor:borderType:));

/**
 * Blurs an image using the normalized box filter.
 *
 * The function smooths an image using the kernel:
 *
 * `$$\texttt{K} =  \frac{1}{\texttt{ksize.width*ksize.height}} \begin{bmatrix} 1 & 1 & 1 &  \cdots & 1 & 1  \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \hdotsfor{6} \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \end{bmatrix}$$`
 *
 * The call `blur(src, dst, ksize, anchor, borderType)` is equivalent to `boxFilter(src, dst, src.type(), ksize,
 * anchor, true, borderType)`.
 *
 * @param src input image; it can have any number of channels, which are processed independently, but
 * the depth should be CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param ksize blurring kernel size.
 * @param anchor anchor point; default value Point(-1,-1) means that the anchor is at the kernel
 * center.
 *
 * - SeeAlso ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``medianBlur:dst:ksize:``
 */
+ (void)blur:(Mat*)src dst:(Mat*)dst ksize:(Size2i*)ksize anchor:(Point2i*)anchor NS_SWIFT_NAME(blur(src:dst:ksize:anchor:));

/**
 * Blurs an image using the normalized box filter.
 *
 * The function smooths an image using the kernel:
 *
 * `$$\texttt{K} =  \frac{1}{\texttt{ksize.width*ksize.height}} \begin{bmatrix} 1 & 1 & 1 &  \cdots & 1 & 1  \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \hdotsfor{6} \\ 1 & 1 & 1 &  \cdots & 1 & 1  \\ \end{bmatrix}$$`
 *
 * The call `blur(src, dst, ksize, anchor, borderType)` is equivalent to `boxFilter(src, dst, src.type(), ksize,
 * anchor, true, borderType)`.
 *
 * @param src input image; it can have any number of channels, which are processed independently, but
 * the depth should be CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param ksize blurring kernel size.
 * center.
 *
 * - SeeAlso ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``bilateralFilter:dst:d:sigmaColor:sigmaSpace:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``medianBlur:dst:ksize:``
 */
+ (void)blur:(Mat*)src dst:(Mat*)dst ksize:(Size2i*)ksize NS_SWIFT_NAME(blur(src:dst:ksize:));


//
//  void cv::stackBlur(Mat src, Mat& dst, Size ksize)
//
/**
 * Blurs an image using the stackBlur.
 *
 * The function applies and stackBlur to an image.
 * stackBlur can generate similar results as Gaussian blur, and the time consumption does not increase with the increase of kernel size.
 * It creates a kind of moving stack of colors whilst scanning through the image. Thereby it just has to add one new block of color to the right side
 * of the stack and remove the leftmost color. The remaining colors on the topmost layer of the stack are either added on or reduced by one,
 * depending on if they are on the right or on the left side of the stack. The only supported borderType is BORDER_REPLICATE.
 * Original paper was proposed by Mario Klingemann, which can be found https://underdestruction.com/2004/02/25/stackblur-2004.
 *
 * @param src input image. The number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S or CV_32F.
 * @param dst output image of the same size and type as src.
 * @param ksize stack-blurring kernel size. The ksize.width and ksize.height can differ but they both must be
 * positive and odd.
 */
+ (void)stackBlur:(Mat*)src dst:(Mat*)dst ksize:(Size2i*)ksize NS_SWIFT_NAME(stackBlur(src:dst:ksize:));


//
//  void cv::filter2D(Mat src, Mat& dst, int ddepth, Mat kernel, Point anchor = Point(-1,-1), double delta = 0, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Convolves an image with the kernel.
 *
 * The function applies an arbitrary linear filter to an image. In-place operation is supported. When
 * the aperture is partially outside the image, the function interpolates outlier pixel values
 * according to the specified border mode.
 *
 * The function does actually compute correlation, not the convolution:
 *
 * `$$\texttt{dst} (x,y) =  \sum _{ \substack{0\leq x' < \texttt{kernel.cols}\\{0\leq y' < \texttt{kernel.rows}}}}  \texttt{kernel} (x',y')* \texttt{src} (x+x'- \texttt{anchor.x} ,y+y'- \texttt{anchor.y} )$$`
 *
 * That is, the kernel is not mirrored around the anchor point. If you need a real convolution, flip
 * the kernel using ``Core/flip`` and set the new anchor to `(kernel.cols - anchor.x - 1, kernel.rows -
 * anchor.y - 1)`.
 *
 * The function uses the DFT-based algorithm in case of sufficiently large kernels (~`11 x 11` or
 * larger) and the direct algorithm for small kernels.
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src.
 * @param ddepth desired depth of the destination image, see *Ref:* filter_depths "combinations"
 * @param kernel convolution kernel (or rather a correlation kernel), a single-channel floating point
 * matrix; if you want to apply different kernels to different channels, split the image into
 * separate color planes using split and process them individually.
 * @param anchor anchor of the kernel that indicates the relative position of a filtered point within
 * the kernel; the anchor should lie within the kernel; default value (-1,-1) means that the anchor
 * is at the kernel center.
 * @param delta optional value added to the filtered pixels before storing them in dst.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, dft, ``matchTemplate:templ:result:method:mask:``
 */
+ (void)filter2D:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth kernel:(Mat*)kernel anchor:(Point2i*)anchor delta:(double)delta borderType:(BorderTypes)borderType NS_SWIFT_NAME(filter2D(src:dst:ddepth:kernel:anchor:delta:borderType:));

/**
 * Convolves an image with the kernel.
 *
 * The function applies an arbitrary linear filter to an image. In-place operation is supported. When
 * the aperture is partially outside the image, the function interpolates outlier pixel values
 * according to the specified border mode.
 *
 * The function does actually compute correlation, not the convolution:
 *
 * `$$\texttt{dst} (x,y) =  \sum _{ \substack{0\leq x' < \texttt{kernel.cols}\\{0\leq y' < \texttt{kernel.rows}}}}  \texttt{kernel} (x',y')* \texttt{src} (x+x'- \texttt{anchor.x} ,y+y'- \texttt{anchor.y} )$$`
 *
 * That is, the kernel is not mirrored around the anchor point. If you need a real convolution, flip
 * the kernel using ``Core/flip`` and set the new anchor to `(kernel.cols - anchor.x - 1, kernel.rows -
 * anchor.y - 1)`.
 *
 * The function uses the DFT-based algorithm in case of sufficiently large kernels (~`11 x 11` or
 * larger) and the direct algorithm for small kernels.
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src.
 * @param ddepth desired depth of the destination image, see *Ref:* filter_depths "combinations"
 * @param kernel convolution kernel (or rather a correlation kernel), a single-channel floating point
 * matrix; if you want to apply different kernels to different channels, split the image into
 * separate color planes using split and process them individually.
 * @param anchor anchor of the kernel that indicates the relative position of a filtered point within
 * the kernel; the anchor should lie within the kernel; default value (-1,-1) means that the anchor
 * is at the kernel center.
 * @param delta optional value added to the filtered pixels before storing them in dst.
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, dft, ``matchTemplate:templ:result:method:mask:``
 */
+ (void)filter2D:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth kernel:(Mat*)kernel anchor:(Point2i*)anchor delta:(double)delta NS_SWIFT_NAME(filter2D(src:dst:ddepth:kernel:anchor:delta:));

/**
 * Convolves an image with the kernel.
 *
 * The function applies an arbitrary linear filter to an image. In-place operation is supported. When
 * the aperture is partially outside the image, the function interpolates outlier pixel values
 * according to the specified border mode.
 *
 * The function does actually compute correlation, not the convolution:
 *
 * `$$\texttt{dst} (x,y) =  \sum _{ \substack{0\leq x' < \texttt{kernel.cols}\\{0\leq y' < \texttt{kernel.rows}}}}  \texttt{kernel} (x',y')* \texttt{src} (x+x'- \texttt{anchor.x} ,y+y'- \texttt{anchor.y} )$$`
 *
 * That is, the kernel is not mirrored around the anchor point. If you need a real convolution, flip
 * the kernel using ``Core/flip`` and set the new anchor to `(kernel.cols - anchor.x - 1, kernel.rows -
 * anchor.y - 1)`.
 *
 * The function uses the DFT-based algorithm in case of sufficiently large kernels (~`11 x 11` or
 * larger) and the direct algorithm for small kernels.
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src.
 * @param ddepth desired depth of the destination image, see *Ref:* filter_depths "combinations"
 * @param kernel convolution kernel (or rather a correlation kernel), a single-channel floating point
 * matrix; if you want to apply different kernels to different channels, split the image into
 * separate color planes using split and process them individually.
 * @param anchor anchor of the kernel that indicates the relative position of a filtered point within
 * the kernel; the anchor should lie within the kernel; default value (-1,-1) means that the anchor
 * is at the kernel center.
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, dft, ``matchTemplate:templ:result:method:mask:``
 */
+ (void)filter2D:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth kernel:(Mat*)kernel anchor:(Point2i*)anchor NS_SWIFT_NAME(filter2D(src:dst:ddepth:kernel:anchor:));

/**
 * Convolves an image with the kernel.
 *
 * The function applies an arbitrary linear filter to an image. In-place operation is supported. When
 * the aperture is partially outside the image, the function interpolates outlier pixel values
 * according to the specified border mode.
 *
 * The function does actually compute correlation, not the convolution:
 *
 * `$$\texttt{dst} (x,y) =  \sum _{ \substack{0\leq x' < \texttt{kernel.cols}\\{0\leq y' < \texttt{kernel.rows}}}}  \texttt{kernel} (x',y')* \texttt{src} (x+x'- \texttt{anchor.x} ,y+y'- \texttt{anchor.y} )$$`
 *
 * That is, the kernel is not mirrored around the anchor point. If you need a real convolution, flip
 * the kernel using ``Core/flip`` and set the new anchor to `(kernel.cols - anchor.x - 1, kernel.rows -
 * anchor.y - 1)`.
 *
 * The function uses the DFT-based algorithm in case of sufficiently large kernels (~`11 x 11` or
 * larger) and the direct algorithm for small kernels.
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src.
 * @param ddepth desired depth of the destination image, see *Ref:* filter_depths "combinations"
 * @param kernel convolution kernel (or rather a correlation kernel), a single-channel floating point
 * matrix; if you want to apply different kernels to different channels, split the image into
 * separate color planes using split and process them individually.
 * the kernel; the anchor should lie within the kernel; default value (-1,-1) means that the anchor
 * is at the kernel center.
 *
 * - SeeAlso ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, dft, ``matchTemplate:templ:result:method:mask:``
 */
+ (void)filter2D:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth kernel:(Mat*)kernel NS_SWIFT_NAME(filter2D(src:dst:ddepth:kernel:));


//
//  void cv::filter2D(Mat src, Mat& dst, Mat kernel, Filter2DParams params = Filter2DParams())
//
+ (void)filter2Dp:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel params:(Filter2DParams*)params NS_SWIFT_NAME(filter2D(src:dst:kernel:params:));

+ (void)filter2Dp:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel NS_SWIFT_NAME(filter2D(src:dst:kernel:));


//
//  void cv::sepFilter2D(Mat src, Mat& dst, int ddepth, Mat kernelX, Mat kernelY, Point anchor = Point(-1,-1), double delta = 0, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Applies a separable linear filter to an image.
 *
 * The function applies a separable linear filter to the image. That is, first, every row of src is
 * filtered with the 1D kernel kernelX. Then, every column of the result is filtered with the 1D
 * kernel kernelY. The final result shifted by delta is stored in dst .
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Destination image depth, see *Ref:* filter_depths "combinations"
 * @param kernelX Coefficients for filtering each row.
 * @param kernelY Coefficients for filtering each column.
 * @param anchor Anchor position within the kernel. The default value `$$(-1,-1)$$` means that the anchor
 * is at the kernel center.
 * @param delta Value added to the filtered results before storing them.
 * @param borderType Pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``blur:dst:ksize:anchor:borderType:``
 */
+ (void)sepFilter2D:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth kernelX:(Mat*)kernelX kernelY:(Mat*)kernelY anchor:(Point2i*)anchor delta:(double)delta borderType:(BorderTypes)borderType NS_SWIFT_NAME(sepFilter2D(src:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:));

/**
 * Applies a separable linear filter to an image.
 *
 * The function applies a separable linear filter to the image. That is, first, every row of src is
 * filtered with the 1D kernel kernelX. Then, every column of the result is filtered with the 1D
 * kernel kernelY. The final result shifted by delta is stored in dst .
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Destination image depth, see *Ref:* filter_depths "combinations"
 * @param kernelX Coefficients for filtering each row.
 * @param kernelY Coefficients for filtering each column.
 * @param anchor Anchor position within the kernel. The default value `$$(-1,-1)$$` means that the anchor
 * is at the kernel center.
 * @param delta Value added to the filtered results before storing them.
 *
 * - SeeAlso ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``blur:dst:ksize:anchor:borderType:``
 */
+ (void)sepFilter2D:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth kernelX:(Mat*)kernelX kernelY:(Mat*)kernelY anchor:(Point2i*)anchor delta:(double)delta NS_SWIFT_NAME(sepFilter2D(src:dst:ddepth:kernelX:kernelY:anchor:delta:));

/**
 * Applies a separable linear filter to an image.
 *
 * The function applies a separable linear filter to the image. That is, first, every row of src is
 * filtered with the 1D kernel kernelX. Then, every column of the result is filtered with the 1D
 * kernel kernelY. The final result shifted by delta is stored in dst .
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Destination image depth, see *Ref:* filter_depths "combinations"
 * @param kernelX Coefficients for filtering each row.
 * @param kernelY Coefficients for filtering each column.
 * @param anchor Anchor position within the kernel. The default value `$$(-1,-1)$$` means that the anchor
 * is at the kernel center.
 *
 * - SeeAlso ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``blur:dst:ksize:anchor:borderType:``
 */
+ (void)sepFilter2D:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth kernelX:(Mat*)kernelX kernelY:(Mat*)kernelY anchor:(Point2i*)anchor NS_SWIFT_NAME(sepFilter2D(src:dst:ddepth:kernelX:kernelY:anchor:));

/**
 * Applies a separable linear filter to an image.
 *
 * The function applies a separable linear filter to the image. That is, first, every row of src is
 * filtered with the 1D kernel kernelX. Then, every column of the result is filtered with the 1D
 * kernel kernelY. The final result shifted by delta is stored in dst .
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Destination image depth, see *Ref:* filter_depths "combinations"
 * @param kernelX Coefficients for filtering each row.
 * @param kernelY Coefficients for filtering each column.
 * is at the kernel center.
 *
 * - SeeAlso ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, ``boxFilter:dst:ddepth:ksize:anchor:normalize:borderType:``, ``blur:dst:ksize:anchor:borderType:``
 */
+ (void)sepFilter2D:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth kernelX:(Mat*)kernelX kernelY:(Mat*)kernelY NS_SWIFT_NAME(sepFilter2D(src:dst:ddepth:kernelX:kernelY:));


//
//  void cv::Sobel(Mat src, Mat& dst, int ddepth, int dx, int dy, int ksize = 3, double scale = 1, double delta = 0, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Calculates the first, second, third, or mixed image derivatives using an extended Sobel operator.
 *
 * In all cases except one, the `$$\texttt{ksize} \times \texttt{ksize}$$` separable kernel is used to
 * calculate the derivative. When `$$\texttt{ksize = 1}$$`, the `$$3 \times 1$$` or `$$1 \times 3$$`
 * kernel is used (that is, no Gaussian smoothing is done). `ksize = 1` can only be used for the first
 * or the second x- or y- derivatives.
 *
 * There is also the special value `ksize = ``SpecialFilter/FILTER_SCHARR`` (-1)` that corresponds to the `$$3\times3$$` Scharr
 * filter that may give more accurate results than the `$$3\times3$$` Sobel. The Scharr aperture is
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-3}{0}{3}{-10}{0}{10}{-3}{0}{3}$$`
 *
 * for the x-derivative, or transposed for the y-derivative.
 *
 * The function calculates an image derivative by convolving the image with the appropriate kernel:
 *
 * `$$\texttt{dst} =  \frac{\partial^{xorder+yorder} \texttt{src}}{\partial x^{xorder} \partial y^{yorder}}$$`
 *
 * The Sobel operators combine Gaussian smoothing and differentiation, so the result is more or less
 * resistant to the noise. Most often, the function is called with ( xorder = 1, yorder = 0, ksize = 3)
 * or ( xorder = 0, yorder = 1, ksize = 3) to calculate the first x- or y- image derivative. The first
 * case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{0}{1}{-2}{0}{2}{-1}{0}{1}$$`
 *
 * The second case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{-2}{-1}{0}{0}{0}{1}{2}{1}$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src .
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"; in the case of
 *     8-bit input images it will result in truncated derivatives.
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * @param ksize size of the extended Sobel kernel; it must be 1, 3, 5, or 7.
 * @param scale optional scale factor for the computed derivative values; by default, no scaling is
 * applied (see ``Imgproc/getDerivKernels`` for details).
 * @param delta optional delta value that is added to the results prior to storing them in dst.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``, ``Laplacian:dst:ddepth:ksize:scale:delta:borderType:``, ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, cartToPolar
 */
+ (void)Sobel:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy ksize:(int)ksize scale:(double)scale delta:(double)delta borderType:(BorderTypes)borderType NS_SWIFT_NAME(Sobel(src:dst:ddepth:dx:dy:ksize:scale:delta:borderType:));

/**
 * Calculates the first, second, third, or mixed image derivatives using an extended Sobel operator.
 *
 * In all cases except one, the `$$\texttt{ksize} \times \texttt{ksize}$$` separable kernel is used to
 * calculate the derivative. When `$$\texttt{ksize = 1}$$`, the `$$3 \times 1$$` or `$$1 \times 3$$`
 * kernel is used (that is, no Gaussian smoothing is done). `ksize = 1` can only be used for the first
 * or the second x- or y- derivatives.
 *
 * There is also the special value `ksize = ``SpecialFilter/FILTER_SCHARR`` (-1)` that corresponds to the `$$3\times3$$` Scharr
 * filter that may give more accurate results than the `$$3\times3$$` Sobel. The Scharr aperture is
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-3}{0}{3}{-10}{0}{10}{-3}{0}{3}$$`
 *
 * for the x-derivative, or transposed for the y-derivative.
 *
 * The function calculates an image derivative by convolving the image with the appropriate kernel:
 *
 * `$$\texttt{dst} =  \frac{\partial^{xorder+yorder} \texttt{src}}{\partial x^{xorder} \partial y^{yorder}}$$`
 *
 * The Sobel operators combine Gaussian smoothing and differentiation, so the result is more or less
 * resistant to the noise. Most often, the function is called with ( xorder = 1, yorder = 0, ksize = 3)
 * or ( xorder = 0, yorder = 1, ksize = 3) to calculate the first x- or y- image derivative. The first
 * case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{0}{1}{-2}{0}{2}{-1}{0}{1}$$`
 *
 * The second case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{-2}{-1}{0}{0}{0}{1}{2}{1}$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src .
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"; in the case of
 *     8-bit input images it will result in truncated derivatives.
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * @param ksize size of the extended Sobel kernel; it must be 1, 3, 5, or 7.
 * @param scale optional scale factor for the computed derivative values; by default, no scaling is
 * applied (see ``Imgproc/getDerivKernels`` for details).
 * @param delta optional delta value that is added to the results prior to storing them in dst.
 *
 * - SeeAlso ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``, ``Laplacian:dst:ddepth:ksize:scale:delta:borderType:``, ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, cartToPolar
 */
+ (void)Sobel:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy ksize:(int)ksize scale:(double)scale delta:(double)delta NS_SWIFT_NAME(Sobel(src:dst:ddepth:dx:dy:ksize:scale:delta:));

/**
 * Calculates the first, second, third, or mixed image derivatives using an extended Sobel operator.
 *
 * In all cases except one, the `$$\texttt{ksize} \times \texttt{ksize}$$` separable kernel is used to
 * calculate the derivative. When `$$\texttt{ksize = 1}$$`, the `$$3 \times 1$$` or `$$1 \times 3$$`
 * kernel is used (that is, no Gaussian smoothing is done). `ksize = 1` can only be used for the first
 * or the second x- or y- derivatives.
 *
 * There is also the special value `ksize = ``SpecialFilter/FILTER_SCHARR`` (-1)` that corresponds to the `$$3\times3$$` Scharr
 * filter that may give more accurate results than the `$$3\times3$$` Sobel. The Scharr aperture is
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-3}{0}{3}{-10}{0}{10}{-3}{0}{3}$$`
 *
 * for the x-derivative, or transposed for the y-derivative.
 *
 * The function calculates an image derivative by convolving the image with the appropriate kernel:
 *
 * `$$\texttt{dst} =  \frac{\partial^{xorder+yorder} \texttt{src}}{\partial x^{xorder} \partial y^{yorder}}$$`
 *
 * The Sobel operators combine Gaussian smoothing and differentiation, so the result is more or less
 * resistant to the noise. Most often, the function is called with ( xorder = 1, yorder = 0, ksize = 3)
 * or ( xorder = 0, yorder = 1, ksize = 3) to calculate the first x- or y- image derivative. The first
 * case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{0}{1}{-2}{0}{2}{-1}{0}{1}$$`
 *
 * The second case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{-2}{-1}{0}{0}{0}{1}{2}{1}$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src .
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"; in the case of
 *     8-bit input images it will result in truncated derivatives.
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * @param ksize size of the extended Sobel kernel; it must be 1, 3, 5, or 7.
 * @param scale optional scale factor for the computed derivative values; by default, no scaling is
 * applied (see ``Imgproc/getDerivKernels`` for details).
 *
 * - SeeAlso ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``, ``Laplacian:dst:ddepth:ksize:scale:delta:borderType:``, ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, cartToPolar
 */
+ (void)Sobel:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy ksize:(int)ksize scale:(double)scale NS_SWIFT_NAME(Sobel(src:dst:ddepth:dx:dy:ksize:scale:));

/**
 * Calculates the first, second, third, or mixed image derivatives using an extended Sobel operator.
 *
 * In all cases except one, the `$$\texttt{ksize} \times \texttt{ksize}$$` separable kernel is used to
 * calculate the derivative. When `$$\texttt{ksize = 1}$$`, the `$$3 \times 1$$` or `$$1 \times 3$$`
 * kernel is used (that is, no Gaussian smoothing is done). `ksize = 1` can only be used for the first
 * or the second x- or y- derivatives.
 *
 * There is also the special value `ksize = ``SpecialFilter/FILTER_SCHARR`` (-1)` that corresponds to the `$$3\times3$$` Scharr
 * filter that may give more accurate results than the `$$3\times3$$` Sobel. The Scharr aperture is
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-3}{0}{3}{-10}{0}{10}{-3}{0}{3}$$`
 *
 * for the x-derivative, or transposed for the y-derivative.
 *
 * The function calculates an image derivative by convolving the image with the appropriate kernel:
 *
 * `$$\texttt{dst} =  \frac{\partial^{xorder+yorder} \texttt{src}}{\partial x^{xorder} \partial y^{yorder}}$$`
 *
 * The Sobel operators combine Gaussian smoothing and differentiation, so the result is more or less
 * resistant to the noise. Most often, the function is called with ( xorder = 1, yorder = 0, ksize = 3)
 * or ( xorder = 0, yorder = 1, ksize = 3) to calculate the first x- or y- image derivative. The first
 * case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{0}{1}{-2}{0}{2}{-1}{0}{1}$$`
 *
 * The second case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{-2}{-1}{0}{0}{0}{1}{2}{1}$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src .
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"; in the case of
 *     8-bit input images it will result in truncated derivatives.
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * @param ksize size of the extended Sobel kernel; it must be 1, 3, 5, or 7.
 * applied (see ``Imgproc/getDerivKernels`` for details).
 *
 * - SeeAlso ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``, ``Laplacian:dst:ddepth:ksize:scale:delta:borderType:``, ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, cartToPolar
 */
+ (void)Sobel:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy ksize:(int)ksize NS_SWIFT_NAME(Sobel(src:dst:ddepth:dx:dy:ksize:));

/**
 * Calculates the first, second, third, or mixed image derivatives using an extended Sobel operator.
 *
 * In all cases except one, the `$$\texttt{ksize} \times \texttt{ksize}$$` separable kernel is used to
 * calculate the derivative. When `$$\texttt{ksize = 1}$$`, the `$$3 \times 1$$` or `$$1 \times 3$$`
 * kernel is used (that is, no Gaussian smoothing is done). `ksize = 1` can only be used for the first
 * or the second x- or y- derivatives.
 *
 * There is also the special value `ksize = ``SpecialFilter/FILTER_SCHARR`` (-1)` that corresponds to the `$$3\times3$$` Scharr
 * filter that may give more accurate results than the `$$3\times3$$` Sobel. The Scharr aperture is
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-3}{0}{3}{-10}{0}{10}{-3}{0}{3}$$`
 *
 * for the x-derivative, or transposed for the y-derivative.
 *
 * The function calculates an image derivative by convolving the image with the appropriate kernel:
 *
 * `$$\texttt{dst} =  \frac{\partial^{xorder+yorder} \texttt{src}}{\partial x^{xorder} \partial y^{yorder}}$$`
 *
 * The Sobel operators combine Gaussian smoothing and differentiation, so the result is more or less
 * resistant to the noise. Most often, the function is called with ( xorder = 1, yorder = 0, ksize = 3)
 * or ( xorder = 0, yorder = 1, ksize = 3) to calculate the first x- or y- image derivative. The first
 * case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{0}{1}{-2}{0}{2}{-1}{0}{1}$$`
 *
 * The second case corresponds to a kernel of:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree{-1}{-2}{-1}{0}{0}{0}{1}{2}{1}$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src .
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"; in the case of
 *     8-bit input images it will result in truncated derivatives.
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * applied (see ``Imgproc/getDerivKernels`` for details).
 *
 * - SeeAlso ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``, ``Laplacian:dst:ddepth:ksize:scale:delta:borderType:``, ``sepFilter2D:dst:ddepth:kernelX:kernelY:anchor:delta:borderType:``, ``filter2D:dst:ddepth:kernel:anchor:delta:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``, cartToPolar
 */
+ (void)Sobel:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy NS_SWIFT_NAME(Sobel(src:dst:ddepth:dx:dy:));


//
//  void cv::spatialGradient(Mat src, Mat& dx, Mat& dy, int ksize = 3, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Calculates the first order image derivative in both x and y using a Sobel operator
 *
 * Equivalent to calling:
 *
 *
 * Sobel( src, dx, CV_16SC1, 1, 0, 3 );
 * Sobel( src, dy, CV_16SC1, 0, 1, 3 );
 *
 *
 * @param src input image.
 * @param dx output image with first-order derivative in x.
 * @param dy output image with first-order derivative in y.
 * @param ksize size of Sobel kernel. It must be 3.
 * @param borderType pixel extrapolation method, see ``BorderTypes``.
 *                   Only #BORDER_DEFAULT=#BORDER_REFLECT_101 and ``BorderTypes/BORDER_REPLICATE`` are supported.
 *
 * - SeeAlso ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``
 */
+ (void)spatialGradient:(Mat*)src dx:(Mat*)dx dy:(Mat*)dy ksize:(int)ksize borderType:(BorderTypes)borderType NS_SWIFT_NAME(spatialGradient(src:dx:dy:ksize:borderType:));

/**
 * Calculates the first order image derivative in both x and y using a Sobel operator
 *
 * Equivalent to calling:
 *
 *
 * Sobel( src, dx, CV_16SC1, 1, 0, 3 );
 * Sobel( src, dy, CV_16SC1, 0, 1, 3 );
 *
 *
 * @param src input image.
 * @param dx output image with first-order derivative in x.
 * @param dy output image with first-order derivative in y.
 * @param ksize size of Sobel kernel. It must be 3.
 *                   Only #BORDER_DEFAULT=#BORDER_REFLECT_101 and ``BorderTypes/BORDER_REPLICATE`` are supported.
 *
 * - SeeAlso ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``
 */
+ (void)spatialGradient:(Mat*)src dx:(Mat*)dx dy:(Mat*)dy ksize:(int)ksize NS_SWIFT_NAME(spatialGradient(src:dx:dy:ksize:));

/**
 * Calculates the first order image derivative in both x and y using a Sobel operator
 *
 * Equivalent to calling:
 *
 *
 * Sobel( src, dx, CV_16SC1, 1, 0, 3 );
 * Sobel( src, dy, CV_16SC1, 0, 1, 3 );
 *
 *
 * @param src input image.
 * @param dx output image with first-order derivative in x.
 * @param dy output image with first-order derivative in y.
 *                   Only #BORDER_DEFAULT=#BORDER_REFLECT_101 and ``BorderTypes/BORDER_REPLICATE`` are supported.
 *
 * - SeeAlso ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``
 */
+ (void)spatialGradient:(Mat*)src dx:(Mat*)dx dy:(Mat*)dy NS_SWIFT_NAME(spatialGradient(src:dx:dy:));


//
//  void cv::Scharr(Mat src, Mat& dst, int ddepth, int dx, int dy, double scale = 1, double delta = 0, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Calculates the first x- or y- image derivative using Scharr operator.
 *
 * The function computes the first x- or y- spatial image derivative using the Scharr operator. The
 * call
 *
 * `$$\texttt{Scharr(src, dst, ddepth, dx, dy, scale, delta, borderType)}$$`
 *
 * is equivalent to
 *
 * `$$\texttt{Sobel(src, dst, ddepth, dx, dy, FILTER\_SCHARR, scale, delta, borderType)} .$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src.
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * @param scale optional scale factor for the computed derivative values; by default, no scaling is
 * applied (see ``Imgproc/getDerivKernels`` for details).
 * @param delta optional delta value that is added to the results prior to storing them in dst.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso cartToPolar
 */
+ (void)Scharr:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy scale:(double)scale delta:(double)delta borderType:(BorderTypes)borderType NS_SWIFT_NAME(Scharr(src:dst:ddepth:dx:dy:scale:delta:borderType:));

/**
 * Calculates the first x- or y- image derivative using Scharr operator.
 *
 * The function computes the first x- or y- spatial image derivative using the Scharr operator. The
 * call
 *
 * `$$\texttt{Scharr(src, dst, ddepth, dx, dy, scale, delta, borderType)}$$`
 *
 * is equivalent to
 *
 * `$$\texttt{Sobel(src, dst, ddepth, dx, dy, FILTER\_SCHARR, scale, delta, borderType)} .$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src.
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * @param scale optional scale factor for the computed derivative values; by default, no scaling is
 * applied (see ``Imgproc/getDerivKernels`` for details).
 * @param delta optional delta value that is added to the results prior to storing them in dst.
 *
 * - SeeAlso cartToPolar
 */
+ (void)Scharr:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy scale:(double)scale delta:(double)delta NS_SWIFT_NAME(Scharr(src:dst:ddepth:dx:dy:scale:delta:));

/**
 * Calculates the first x- or y- image derivative using Scharr operator.
 *
 * The function computes the first x- or y- spatial image derivative using the Scharr operator. The
 * call
 *
 * `$$\texttt{Scharr(src, dst, ddepth, dx, dy, scale, delta, borderType)}$$`
 *
 * is equivalent to
 *
 * `$$\texttt{Sobel(src, dst, ddepth, dx, dy, FILTER\_SCHARR, scale, delta, borderType)} .$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src.
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * @param scale optional scale factor for the computed derivative values; by default, no scaling is
 * applied (see ``Imgproc/getDerivKernels`` for details).
 *
 * - SeeAlso cartToPolar
 */
+ (void)Scharr:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy scale:(double)scale NS_SWIFT_NAME(Scharr(src:dst:ddepth:dx:dy:scale:));

/**
 * Calculates the first x- or y- image derivative using Scharr operator.
 *
 * The function computes the first x- or y- spatial image derivative using the Scharr operator. The
 * call
 *
 * `$$\texttt{Scharr(src, dst, ddepth, dx, dy, scale, delta, borderType)}$$`
 *
 * is equivalent to
 *
 * `$$\texttt{Sobel(src, dst, ddepth, dx, dy, FILTER\_SCHARR, scale, delta, borderType)} .$$`
 *
 * @param src input image.
 * @param dst output image of the same size and the same number of channels as src.
 * @param ddepth output image depth, see *Ref:* filter_depths "combinations"
 * @param dx order of the derivative x.
 * @param dy order of the derivative y.
 * applied (see ``Imgproc/getDerivKernels`` for details).
 *
 * - SeeAlso cartToPolar
 */
+ (void)Scharr:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth dx:(int)dx dy:(int)dy NS_SWIFT_NAME(Scharr(src:dst:ddepth:dx:dy:));


//
//  void cv::Laplacian(Mat src, Mat& dst, int ddepth, int ksize = 1, double scale = 1, double delta = 0, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Calculates the Laplacian of an image.
 *
 * The function calculates the Laplacian of the source image by adding up the second x and y
 * derivatives calculated using the Sobel operator:
 *
 * `$$\texttt{dst} =  \Delta \texttt{src} =  \frac{\partial^2 \texttt{src}}{\partial x^2} +  \frac{\partial^2 \texttt{src}}{\partial y^2}$$`
 *
 * This is done when `ksize > 1`. When `ksize == 1`, the Laplacian is computed by filtering the image
 * with the following `$$3 \times 3$$` aperture:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree {0}{1}{0}{1}{-4}{1}{0}{1}{0}$$`
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Desired depth of the destination image, see *Ref:* filter_depths "combinations".
 * @param ksize Aperture size used to compute the second-derivative filters. See ``Imgproc/getDerivKernels`` for
 * details. The size must be positive and odd.
 * @param scale Optional scale factor for the computed Laplacian values. By default, no scaling is
 * applied. See ``Imgproc/getDerivKernels`` for details.
 * @param delta Optional delta value that is added to the results prior to storing them in dst .
 * @param borderType Pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``
 */
+ (void)Laplacian:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(int)ksize scale:(double)scale delta:(double)delta borderType:(BorderTypes)borderType NS_SWIFT_NAME(Laplacian(src:dst:ddepth:ksize:scale:delta:borderType:));

/**
 * Calculates the Laplacian of an image.
 *
 * The function calculates the Laplacian of the source image by adding up the second x and y
 * derivatives calculated using the Sobel operator:
 *
 * `$$\texttt{dst} =  \Delta \texttt{src} =  \frac{\partial^2 \texttt{src}}{\partial x^2} +  \frac{\partial^2 \texttt{src}}{\partial y^2}$$`
 *
 * This is done when `ksize > 1`. When `ksize == 1`, the Laplacian is computed by filtering the image
 * with the following `$$3 \times 3$$` aperture:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree {0}{1}{0}{1}{-4}{1}{0}{1}{0}$$`
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Desired depth of the destination image, see *Ref:* filter_depths "combinations".
 * @param ksize Aperture size used to compute the second-derivative filters. See ``Imgproc/getDerivKernels`` for
 * details. The size must be positive and odd.
 * @param scale Optional scale factor for the computed Laplacian values. By default, no scaling is
 * applied. See ``Imgproc/getDerivKernels`` for details.
 * @param delta Optional delta value that is added to the results prior to storing them in dst .
 *
 * - SeeAlso ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``
 */
+ (void)Laplacian:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(int)ksize scale:(double)scale delta:(double)delta NS_SWIFT_NAME(Laplacian(src:dst:ddepth:ksize:scale:delta:));

/**
 * Calculates the Laplacian of an image.
 *
 * The function calculates the Laplacian of the source image by adding up the second x and y
 * derivatives calculated using the Sobel operator:
 *
 * `$$\texttt{dst} =  \Delta \texttt{src} =  \frac{\partial^2 \texttt{src}}{\partial x^2} +  \frac{\partial^2 \texttt{src}}{\partial y^2}$$`
 *
 * This is done when `ksize > 1`. When `ksize == 1`, the Laplacian is computed by filtering the image
 * with the following `$$3 \times 3$$` aperture:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree {0}{1}{0}{1}{-4}{1}{0}{1}{0}$$`
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Desired depth of the destination image, see *Ref:* filter_depths "combinations".
 * @param ksize Aperture size used to compute the second-derivative filters. See ``Imgproc/getDerivKernels`` for
 * details. The size must be positive and odd.
 * @param scale Optional scale factor for the computed Laplacian values. By default, no scaling is
 * applied. See ``Imgproc/getDerivKernels`` for details.
 *
 * - SeeAlso ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``
 */
+ (void)Laplacian:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(int)ksize scale:(double)scale NS_SWIFT_NAME(Laplacian(src:dst:ddepth:ksize:scale:));

/**
 * Calculates the Laplacian of an image.
 *
 * The function calculates the Laplacian of the source image by adding up the second x and y
 * derivatives calculated using the Sobel operator:
 *
 * `$$\texttt{dst} =  \Delta \texttt{src} =  \frac{\partial^2 \texttt{src}}{\partial x^2} +  \frac{\partial^2 \texttt{src}}{\partial y^2}$$`
 *
 * This is done when `ksize > 1`. When `ksize == 1`, the Laplacian is computed by filtering the image
 * with the following `$$3 \times 3$$` aperture:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree {0}{1}{0}{1}{-4}{1}{0}{1}{0}$$`
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Desired depth of the destination image, see *Ref:* filter_depths "combinations".
 * @param ksize Aperture size used to compute the second-derivative filters. See ``Imgproc/getDerivKernels`` for
 * details. The size must be positive and odd.
 * applied. See ``Imgproc/getDerivKernels`` for details.
 *
 * - SeeAlso ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``
 */
+ (void)Laplacian:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth ksize:(int)ksize NS_SWIFT_NAME(Laplacian(src:dst:ddepth:ksize:));

/**
 * Calculates the Laplacian of an image.
 *
 * The function calculates the Laplacian of the source image by adding up the second x and y
 * derivatives calculated using the Sobel operator:
 *
 * `$$\texttt{dst} =  \Delta \texttt{src} =  \frac{\partial^2 \texttt{src}}{\partial x^2} +  \frac{\partial^2 \texttt{src}}{\partial y^2}$$`
 *
 * This is done when `ksize > 1`. When `ksize == 1`, the Laplacian is computed by filtering the image
 * with the following `$$3 \times 3$$` aperture:
 *
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } \vecthreethree {0}{1}{0}{1}{-4}{1}{0}{1}{0}$$`
 *
 * @param src Source image.
 * @param dst Destination image of the same size and the same number of channels as src .
 * @param ddepth Desired depth of the destination image, see *Ref:* filter_depths "combinations".
 * details. The size must be positive and odd.
 * applied. See ``Imgproc/getDerivKernels`` for details.
 *
 * - SeeAlso ``Sobel:dst:ddepth:dx:dy:ksize:scale:delta:borderType:``, ``Scharr:dst:ddepth:dx:dy:scale:delta:borderType:``
 */
+ (void)Laplacian:(Mat*)src dst:(Mat*)dst ddepth:(int)ddepth NS_SWIFT_NAME(Laplacian(src:dst:ddepth:));


//
//  void cv::Canny(Mat image, Mat& edges, double threshold1, double threshold2, int apertureSize = 3, bool L2gradient = false)
//
/**
 * Finds edges in an image using the Canny algorithm *Cite:* Canny86 .
 *
 * The function finds edges in the input image and marks them in the output map edges using the
 * Canny algorithm. The smallest value between threshold1 and threshold2 is used for edge linking. The
 * largest value is used to find initial segments of strong edges. See
 * <https://en.wikipedia.org/wiki/Canny_edge_detector>
 *
 * @param image 8-bit input image.
 * @param edges output edge map; single channels 8-bit image, which has the same size as image .
 * @param threshold1 first threshold for the hysteresis procedure.
 * @param threshold2 second threshold for the hysteresis procedure.
 * @param apertureSize aperture size for the Sobel operator.
 * @param L2gradient a flag, indicating whether a more accurate `$$L_2$$` norm
 * `$$=\sqrt{(dI/dx)^2 + (dI/dy)^2}$$` should be used to calculate the image gradient magnitude (
 * L2gradient=true ), or whether the default `$$L_1$$` norm `$$=|dI/dx|+|dI/dy|$$` is enough (
 * L2gradient=false ).
 * For efficiency, when L2gradient=true the implementation compares the squared
 * gradient magnitude `$$(dI/dx)^2 + (dI/dy)^2$$` against the squared thresholds
 * instead of computing the square root; the resulting edge map is the same as if
 * the `$$L_2$$` norm were computed directly.
 */
+ (void)Canny:(Mat*)image edges:(Mat*)edges threshold1:(double)threshold1 threshold2:(double)threshold2 apertureSize:(int)apertureSize L2gradient:(BOOL)L2gradient NS_SWIFT_NAME(Canny(image:edges:threshold1:threshold2:apertureSize:L2gradient:));

/**
 * Finds edges in an image using the Canny algorithm *Cite:* Canny86 .
 *
 * The function finds edges in the input image and marks them in the output map edges using the
 * Canny algorithm. The smallest value between threshold1 and threshold2 is used for edge linking. The
 * largest value is used to find initial segments of strong edges. See
 * <https://en.wikipedia.org/wiki/Canny_edge_detector>
 *
 * @param image 8-bit input image.
 * @param edges output edge map; single channels 8-bit image, which has the same size as image .
 * @param threshold1 first threshold for the hysteresis procedure.
 * @param threshold2 second threshold for the hysteresis procedure.
 * @param apertureSize aperture size for the Sobel operator.
 * `$$=\sqrt{(dI/dx)^2 + (dI/dy)^2}$$` should be used to calculate the image gradient magnitude (
 * L2gradient=true ), or whether the default `$$L_1$$` norm `$$=|dI/dx|+|dI/dy|$$` is enough (
 * L2gradient=false ).
 * For efficiency, when L2gradient=true the implementation compares the squared
 * gradient magnitude `$$(dI/dx)^2 + (dI/dy)^2$$` against the squared thresholds
 * instead of computing the square root; the resulting edge map is the same as if
 * the `$$L_2$$` norm were computed directly.
 */
+ (void)Canny:(Mat*)image edges:(Mat*)edges threshold1:(double)threshold1 threshold2:(double)threshold2 apertureSize:(int)apertureSize NS_SWIFT_NAME(Canny(image:edges:threshold1:threshold2:apertureSize:));

/**
 * Finds edges in an image using the Canny algorithm *Cite:* Canny86 .
 *
 * The function finds edges in the input image and marks them in the output map edges using the
 * Canny algorithm. The smallest value between threshold1 and threshold2 is used for edge linking. The
 * largest value is used to find initial segments of strong edges. See
 * <https://en.wikipedia.org/wiki/Canny_edge_detector>
 *
 * @param image 8-bit input image.
 * @param edges output edge map; single channels 8-bit image, which has the same size as image .
 * @param threshold1 first threshold for the hysteresis procedure.
 * @param threshold2 second threshold for the hysteresis procedure.
 * `$$=\sqrt{(dI/dx)^2 + (dI/dy)^2}$$` should be used to calculate the image gradient magnitude (
 * L2gradient=true ), or whether the default `$$L_1$$` norm `$$=|dI/dx|+|dI/dy|$$` is enough (
 * L2gradient=false ).
 * For efficiency, when L2gradient=true the implementation compares the squared
 * gradient magnitude `$$(dI/dx)^2 + (dI/dy)^2$$` against the squared thresholds
 * instead of computing the square root; the resulting edge map is the same as if
 * the `$$L_2$$` norm were computed directly.
 */
+ (void)Canny:(Mat*)image edges:(Mat*)edges threshold1:(double)threshold1 threshold2:(double)threshold2 NS_SWIFT_NAME(Canny(image:edges:threshold1:threshold2:));


//
//  void cv::Canny(Mat dx, Mat dy, Mat& edges, double threshold1, double threshold2, bool L2gradient = false)
//
/**
 * \overload
 *
 * Finds edges in an image using the Canny algorithm with custom image gradient.
 *
 * @param dx 16-bit x derivative of input image (CV_16SC1 or CV_16SC3).
 * @param dy 16-bit y derivative of input image (same type as dx).
 * @param edges output edge map; single channels 8-bit image, which has the same size as image .
 * @param threshold1 first threshold for the hysteresis procedure.
 * @param threshold2 second threshold for the hysteresis procedure.
 * @param L2gradient a flag, indicating whether a more accurate `$$L_2$$` norm
 * `$$=\sqrt{(dI/dx)^2 + (dI/dy)^2}$$` should be used to calculate the image gradient magnitude (
 * L2gradient=true ), or whether the default `$$L_1$$` norm `$$=|dI/dx|+|dI/dy|$$` is enough (
 * L2gradient=false ).
 * For efficiency, when L2gradient=true the implementation compares the squared
 * gradient magnitude `$$(dI/dx)^2 + (dI/dy)^2$$` against the squared thresholds
 * instead of computing the square root; the resulting edge map is the same as if
 * the `$$L_2$$` norm were computed directly.
 */
+ (void)Canny:(Mat*)dx dy:(Mat*)dy edges:(Mat*)edges threshold1:(double)threshold1 threshold2:(double)threshold2 L2gradient:(BOOL)L2gradient NS_SWIFT_NAME(Canny(dx:dy:edges:threshold1:threshold2:L2gradient:));

/**
 * \overload
 *
 * Finds edges in an image using the Canny algorithm with custom image gradient.
 *
 * @param dx 16-bit x derivative of input image (CV_16SC1 or CV_16SC3).
 * @param dy 16-bit y derivative of input image (same type as dx).
 * @param edges output edge map; single channels 8-bit image, which has the same size as image .
 * @param threshold1 first threshold for the hysteresis procedure.
 * @param threshold2 second threshold for the hysteresis procedure.
 * `$$=\sqrt{(dI/dx)^2 + (dI/dy)^2}$$` should be used to calculate the image gradient magnitude (
 * L2gradient=true ), or whether the default `$$L_1$$` norm `$$=|dI/dx|+|dI/dy|$$` is enough (
 * L2gradient=false ).
 * For efficiency, when L2gradient=true the implementation compares the squared
 * gradient magnitude `$$(dI/dx)^2 + (dI/dy)^2$$` against the squared thresholds
 * instead of computing the square root; the resulting edge map is the same as if
 * the `$$L_2$$` norm were computed directly.
 */
+ (void)Canny:(Mat*)dx dy:(Mat*)dy edges:(Mat*)edges threshold1:(double)threshold1 threshold2:(double)threshold2 NS_SWIFT_NAME(Canny(dx:dy:edges:threshold1:threshold2:));


//
//  void cv::cornerMinEigenVal(Mat src, Mat& dst, int blockSize, int ksize = 3, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Calculates the minimal eigenvalue of gradient matrices for corner detection.
 *
 * The function is similar to cornerEigenValsAndVecs but it calculates and stores only the minimal
 * eigenvalue of the covariance matrix of derivatives, that is, `$$\min(\lambda_1, \lambda_2)$$` in terms
 * of the formulae in the cornerEigenValsAndVecs description.
 *
 * @param src Input single-channel 8-bit or floating-point image.
 * @param dst Image to store the minimal eigenvalues. It has the type CV_32FC1 and the same size as
 * src .
 * @param blockSize Neighborhood size (see the details on ``Imgproc/cornerEigenValsAndVecs`` ).
 * @param ksize Aperture parameter for the Sobel operator.
 * @param borderType Pixel extrapolation method. See ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 */
+ (void)cornerMinEigenVal:(Mat*)src dst:(Mat*)dst blockSize:(int)blockSize ksize:(int)ksize borderType:(BorderTypes)borderType NS_SWIFT_NAME(cornerMinEigenVal(src:dst:blockSize:ksize:borderType:));

/**
 * Calculates the minimal eigenvalue of gradient matrices for corner detection.
 *
 * The function is similar to cornerEigenValsAndVecs but it calculates and stores only the minimal
 * eigenvalue of the covariance matrix of derivatives, that is, `$$\min(\lambda_1, \lambda_2)$$` in terms
 * of the formulae in the cornerEigenValsAndVecs description.
 *
 * @param src Input single-channel 8-bit or floating-point image.
 * @param dst Image to store the minimal eigenvalues. It has the type CV_32FC1 and the same size as
 * src .
 * @param blockSize Neighborhood size (see the details on ``Imgproc/cornerEigenValsAndVecs`` ).
 * @param ksize Aperture parameter for the Sobel operator.
 */
+ (void)cornerMinEigenVal:(Mat*)src dst:(Mat*)dst blockSize:(int)blockSize ksize:(int)ksize NS_SWIFT_NAME(cornerMinEigenVal(src:dst:blockSize:ksize:));

/**
 * Calculates the minimal eigenvalue of gradient matrices for corner detection.
 *
 * The function is similar to cornerEigenValsAndVecs but it calculates and stores only the minimal
 * eigenvalue of the covariance matrix of derivatives, that is, `$$\min(\lambda_1, \lambda_2)$$` in terms
 * of the formulae in the cornerEigenValsAndVecs description.
 *
 * @param src Input single-channel 8-bit or floating-point image.
 * @param dst Image to store the minimal eigenvalues. It has the type CV_32FC1 and the same size as
 * src .
 * @param blockSize Neighborhood size (see the details on ``Imgproc/cornerEigenValsAndVecs`` ).
 */
+ (void)cornerMinEigenVal:(Mat*)src dst:(Mat*)dst blockSize:(int)blockSize NS_SWIFT_NAME(cornerMinEigenVal(src:dst:blockSize:));


//
//  void cv::cornerHarris(Mat src, Mat& dst, int blockSize, int ksize, double k, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Harris corner detector.
 *
 * The function runs the Harris corner detector on the image. Similarly to cornerMinEigenVal and
 * cornerEigenValsAndVecs , for each pixel `$$(x, y)$$` it calculates a `$$2\times2$$` gradient covariance
 * matrix `$$M^{(x,y)}$$` over a `$$\texttt{blockSize} \times \texttt{blockSize}$$` neighborhood. Then, it
 * computes the following characteristic:
 *
 * `$$\texttt{dst} (x,y) =  \mathrm{det} M^{(x,y)} - k  \cdot \left ( \mathrm{tr} M^{(x,y)} \right )^2$$`
 *
 * Corners in the image can be found as the local maxima of this response map.
 *
 * @param src Input single-channel 8-bit or floating-point image.
 * @param dst Image to store the Harris detector responses. It has the type CV_32FC1 and the same
 * size as src .
 * @param blockSize Neighborhood size (see the details on ``Imgproc/cornerEigenValsAndVecs`` ).
 * @param ksize Aperture parameter for the Sobel operator.
 * @param k Harris detector free parameter. See the formula above.
 * @param borderType Pixel extrapolation method. See ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 */
+ (void)cornerHarris:(Mat*)src dst:(Mat*)dst blockSize:(int)blockSize ksize:(int)ksize k:(double)k borderType:(BorderTypes)borderType NS_SWIFT_NAME(cornerHarris(src:dst:blockSize:ksize:k:borderType:));

/**
 * Harris corner detector.
 *
 * The function runs the Harris corner detector on the image. Similarly to cornerMinEigenVal and
 * cornerEigenValsAndVecs , for each pixel `$$(x, y)$$` it calculates a `$$2\times2$$` gradient covariance
 * matrix `$$M^{(x,y)}$$` over a `$$\texttt{blockSize} \times \texttt{blockSize}$$` neighborhood. Then, it
 * computes the following characteristic:
 *
 * `$$\texttt{dst} (x,y) =  \mathrm{det} M^{(x,y)} - k  \cdot \left ( \mathrm{tr} M^{(x,y)} \right )^2$$`
 *
 * Corners in the image can be found as the local maxima of this response map.
 *
 * @param src Input single-channel 8-bit or floating-point image.
 * @param dst Image to store the Harris detector responses. It has the type CV_32FC1 and the same
 * size as src .
 * @param blockSize Neighborhood size (see the details on ``Imgproc/cornerEigenValsAndVecs`` ).
 * @param ksize Aperture parameter for the Sobel operator.
 * @param k Harris detector free parameter. See the formula above.
 */
+ (void)cornerHarris:(Mat*)src dst:(Mat*)dst blockSize:(int)blockSize ksize:(int)ksize k:(double)k NS_SWIFT_NAME(cornerHarris(src:dst:blockSize:ksize:k:));


//
//  void cv::cornerEigenValsAndVecs(Mat src, Mat& dst, int blockSize, int ksize, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Calculates eigenvalues and eigenvectors of image blocks for corner detection.
 *
 * For every pixel `$$p$$` , the function cornerEigenValsAndVecs considers a blockSize `$$\times$$` blockSize
 * neighborhood `$$S(p)$$` . It calculates the covariation matrix of derivatives over the neighborhood as:
 *
 * `$$M =  \begin{bmatrix} \sum _{S(p)}(dI/dx)^2 &  \sum _{S(p)}dI/dx dI/dy  \\ \sum _{S(p)}dI/dx dI/dy &  \sum _{S(p)}(dI/dy)^2 \end{bmatrix}$$`
 *
 * where the derivatives are computed using the Sobel operator.
 *
 * After that, it finds eigenvectors and eigenvalues of `$$M$$` and stores them in the destination image as
 * `$$(\lambda_1, \lambda_2, x_1, y_1, x_2, y_2)$$` where
 *
 * -   `$$\lambda_1, \lambda_2$$` are the non-sorted eigenvalues of `$$M$$`
 * -   `$$x_1, y_1$$` are the eigenvectors corresponding to `$$\lambda_1$$`
 * -   `$$x_2, y_2$$` are the eigenvectors corresponding to `$$\lambda_2$$`
 *
 * The output of the function can be used for robust edge or corner detection.
 *
 * @param src Input single-channel 8-bit or floating-point image.
 * @param dst Image to store the results. It has the same size as src and the type CV_32FC(6) .
 * @param blockSize Neighborhood size (see details below).
 * @param ksize Aperture parameter for the Sobel operator.
 * @param borderType Pixel extrapolation method. See ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``cornerMinEigenVal:dst:blockSize:ksize:borderType:``, ``cornerHarris:dst:blockSize:ksize:k:borderType:``, ``preCornerDetect:dst:ksize:borderType:``
 */
+ (void)cornerEigenValsAndVecs:(Mat*)src dst:(Mat*)dst blockSize:(int)blockSize ksize:(int)ksize borderType:(BorderTypes)borderType NS_SWIFT_NAME(cornerEigenValsAndVecs(src:dst:blockSize:ksize:borderType:));

/**
 * Calculates eigenvalues and eigenvectors of image blocks for corner detection.
 *
 * For every pixel `$$p$$` , the function cornerEigenValsAndVecs considers a blockSize `$$\times$$` blockSize
 * neighborhood `$$S(p)$$` . It calculates the covariation matrix of derivatives over the neighborhood as:
 *
 * `$$M =  \begin{bmatrix} \sum _{S(p)}(dI/dx)^2 &  \sum _{S(p)}dI/dx dI/dy  \\ \sum _{S(p)}dI/dx dI/dy &  \sum _{S(p)}(dI/dy)^2 \end{bmatrix}$$`
 *
 * where the derivatives are computed using the Sobel operator.
 *
 * After that, it finds eigenvectors and eigenvalues of `$$M$$` and stores them in the destination image as
 * `$$(\lambda_1, \lambda_2, x_1, y_1, x_2, y_2)$$` where
 *
 * -   `$$\lambda_1, \lambda_2$$` are the non-sorted eigenvalues of `$$M$$`
 * -   `$$x_1, y_1$$` are the eigenvectors corresponding to `$$\lambda_1$$`
 * -   `$$x_2, y_2$$` are the eigenvectors corresponding to `$$\lambda_2$$`
 *
 * The output of the function can be used for robust edge or corner detection.
 *
 * @param src Input single-channel 8-bit or floating-point image.
 * @param dst Image to store the results. It has the same size as src and the type CV_32FC(6) .
 * @param blockSize Neighborhood size (see details below).
 * @param ksize Aperture parameter for the Sobel operator.
 *
 * - SeeAlso ``cornerMinEigenVal:dst:blockSize:ksize:borderType:``, ``cornerHarris:dst:blockSize:ksize:k:borderType:``, ``preCornerDetect:dst:ksize:borderType:``
 */
+ (void)cornerEigenValsAndVecs:(Mat*)src dst:(Mat*)dst blockSize:(int)blockSize ksize:(int)ksize NS_SWIFT_NAME(cornerEigenValsAndVecs(src:dst:blockSize:ksize:));


//
//  void cv::preCornerDetect(Mat src, Mat& dst, int ksize, BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Calculates a feature map for corner detection.
 *
 * The function calculates the complex spatial derivative-based function of the source image
 *
 * `$$\texttt{dst} = (D_x  \texttt{src} )^2  \cdot D_{yy}  \texttt{src} + (D_y  \texttt{src} )^2  \cdot D_{xx}  \texttt{src} - 2 D_x  \texttt{src} \cdot D_y  \texttt{src} \cdot D_{xy}  \texttt{src}$$`
 *
 * where `$$D_x$$`,`$$D_y$$` are the first image derivatives, `$$D_{xx}$$`,`$$D_{yy}$$` are the second image
 * derivatives, and `$$D_{xy}$$` is the mixed derivative.
 *
 * The corners can be found as local maximums of the functions, as shown below:
 *
 *     Mat corners, dilated_corners;
 *     preCornerDetect(image, corners, 3);
 *     // dilation with 3x3 rectangular structuring element
 *     dilate(corners, dilated_corners, Mat(), 1);
 *     Mat corner_mask = corners == dilated_corners;
 *
 *
 * @param src Source single-channel 8-bit of floating-point image.
 * @param dst Output image that has the type CV_32F and the same size as src .
 * @param ksize %Aperture size of the Sobel .
 * @param borderType Pixel extrapolation method. See ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 */
+ (void)preCornerDetect:(Mat*)src dst:(Mat*)dst ksize:(int)ksize borderType:(BorderTypes)borderType NS_SWIFT_NAME(preCornerDetect(src:dst:ksize:borderType:));

/**
 * Calculates a feature map for corner detection.
 *
 * The function calculates the complex spatial derivative-based function of the source image
 *
 * `$$\texttt{dst} = (D_x  \texttt{src} )^2  \cdot D_{yy}  \texttt{src} + (D_y  \texttt{src} )^2  \cdot D_{xx}  \texttt{src} - 2 D_x  \texttt{src} \cdot D_y  \texttt{src} \cdot D_{xy}  \texttt{src}$$`
 *
 * where `$$D_x$$`,`$$D_y$$` are the first image derivatives, `$$D_{xx}$$`,`$$D_{yy}$$` are the second image
 * derivatives, and `$$D_{xy}$$` is the mixed derivative.
 *
 * The corners can be found as local maximums of the functions, as shown below:
 *
 *     Mat corners, dilated_corners;
 *     preCornerDetect(image, corners, 3);
 *     // dilation with 3x3 rectangular structuring element
 *     dilate(corners, dilated_corners, Mat(), 1);
 *     Mat corner_mask = corners == dilated_corners;
 *
 *
 * @param src Source single-channel 8-bit of floating-point image.
 * @param dst Output image that has the type CV_32F and the same size as src .
 * @param ksize %Aperture size of the Sobel .
 */
+ (void)preCornerDetect:(Mat*)src dst:(Mat*)dst ksize:(int)ksize NS_SWIFT_NAME(preCornerDetect(src:dst:ksize:));


//
//  void cv::cornerSubPix(Mat image, Mat& corners, Size winSize, Size zeroZone, TermCriteria criteria)
//
/**
 * Refines the corner locations.
 *
 * The function iterates to find the sub-pixel accurate location of corners or radial saddle
 * points as described in *Cite:* forstner1987fast, and as shown on the figure below.
 *
 * ![image](cornersubpix)
 *
 * Sub-pixel accurate corner locator is based on the observation that every vector from the center `$$q$$`
 * to a point `$$p$$` located within a neighborhood of `$$q$$` is orthogonal to the image gradient at `$$p$$`
 * subject to image and measurement noise. Consider the expression:
 *
 * `$$\epsilon _i = {DI_{p_i}}^T  \cdot (q - p_i)$$`
 *
 * where `$${DI_{p_i}}$$` is an image gradient at one of the points `$$p_i$$` in a neighborhood of `$$q$$` . The
 * value of `$$q$$` is to be found so that `$$\epsilon_i$$` is minimized. A system of equations may be set up
 * with `$$\epsilon_i$$` set to zero:
 *
 * `$$\sum _i(DI_{p_i}  \cdot {DI_{p_i}}^T) \cdot q -  \sum _i(DI_{p_i}  \cdot {DI_{p_i}}^T  \cdot p_i)$$`
 *
 * where the gradients are summed within a neighborhood ("search window") of `$$q$$` . Calling the first
 * gradient term `$$G$$` and the second gradient term `$$b$$` gives:
 *
 * `$$q = G^{-1}  \cdot b$$`
 *
 * The algorithm sets the center of the neighborhood window at this new center `$$q$$` and then iterates
 * until the center stays within a set threshold.
 *
 * @param image Input single-channel, 8-bit or float image.
 * @param corners Initial coordinates of the input corners and refined coordinates provided for
 * output.
 * @param winSize Half of the side length of the search window. For example, if winSize=Size(5,5) ,
 * then a `$$(5*2+1) \times (5*2+1) = 11 \times 11$$` search window is used.
 * @param zeroZone Half of the size of the dead region in the middle of the search zone over which
 * the summation in the formula below is not done. It is used sometimes to avoid possible
 * singularities of the autocorrelation matrix. The value of (-1,-1) indicates that there is no such
 * a size.
 * @param criteria Criteria for termination of the iterative process of corner refinement. That is,
 * the process of corner position refinement stops either after criteria.maxCount iterations or when
 * the corner position moves by less than criteria.epsilon on some iteration.
 */
+ (void)cornerSubPix:(Mat*)image corners:(Mat*)corners winSize:(Size2i*)winSize zeroZone:(Size2i*)zeroZone criteria:(TermCriteria*)criteria NS_SWIFT_NAME(cornerSubPix(image:corners:winSize:zeroZone:criteria:));


//
//  void cv::HoughLines(Mat image, Mat& lines, double rho, double theta, int threshold, double srn = 0, double stn = 0, double min_theta = 0, double max_theta = CV_PI, bool use_edgeval = false)
//
/**
 * Finds lines in a binary image using the standard Hough transform.
 *
 * The function implements the standard or standard multi-scale Hough transform algorithm for line
 * detection. See <https://homepages.inf.ed.ac.uk/rbf/HIPR2/hough.htm> for a good explanation of Hough
 * transform.
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 2 or 3 element vector
 * `$$(\rho, \theta)$$` or `$$(\rho, \theta, \textrm{votes})$$`, where `$$\rho$$` is the distance from
 * the coordinate origin `$$(0,0)$$` (top-left corner of the image), `$$\theta$$` is the line rotation
 * angle in radians ( `$$0 \sim \textrm{vertical line}, \pi/2 \sim \textrm{horizontal line}$$` ), and
 * `$$\textrm{votes}$$` is the value of accumulator.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * @param srn For the multi-scale Hough transform, it is a divisor for the distance resolution rho.
 * The coarse accumulator distance resolution is rho and the accurate accumulator resolution is
 * rho/srn. If both srn=0 and stn=0, the classical Hough transform is used. Otherwise, both these
 * parameters should be positive.
 * @param stn For the multi-scale Hough transform, it is a divisor for the distance resolution theta.
 * @param min_theta For standard and multi-scale Hough transform, minimum angle to check for lines.
 * Must fall between 0 and max_theta.
 * @param max_theta For standard and multi-scale Hough transform, an upper bound for the angle.
 * Must fall between min_theta and CV_PI. The actual maximum angle in the accumulator may be slightly
 * less than max_theta, depending on the parameters min_theta and theta.
 * @param use_edgeval True if you want to use weighted Hough transform.
 */
+ (void)HoughLines:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn stn:(double)stn min_theta:(double)min_theta max_theta:(double)max_theta use_edgeval:(BOOL)use_edgeval NS_SWIFT_NAME(HoughLines(image:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:use_edgeval:));

/**
 * Finds lines in a binary image using the standard Hough transform.
 *
 * The function implements the standard or standard multi-scale Hough transform algorithm for line
 * detection. See <https://homepages.inf.ed.ac.uk/rbf/HIPR2/hough.htm> for a good explanation of Hough
 * transform.
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 2 or 3 element vector
 * `$$(\rho, \theta)$$` or `$$(\rho, \theta, \textrm{votes})$$`, where `$$\rho$$` is the distance from
 * the coordinate origin `$$(0,0)$$` (top-left corner of the image), `$$\theta$$` is the line rotation
 * angle in radians ( `$$0 \sim \textrm{vertical line}, \pi/2 \sim \textrm{horizontal line}$$` ), and
 * `$$\textrm{votes}$$` is the value of accumulator.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * @param srn For the multi-scale Hough transform, it is a divisor for the distance resolution rho.
 * The coarse accumulator distance resolution is rho and the accurate accumulator resolution is
 * rho/srn. If both srn=0 and stn=0, the classical Hough transform is used. Otherwise, both these
 * parameters should be positive.
 * @param stn For the multi-scale Hough transform, it is a divisor for the distance resolution theta.
 * @param min_theta For standard and multi-scale Hough transform, minimum angle to check for lines.
 * Must fall between 0 and max_theta.
 * @param max_theta For standard and multi-scale Hough transform, an upper bound for the angle.
 * Must fall between min_theta and CV_PI. The actual maximum angle in the accumulator may be slightly
 * less than max_theta, depending on the parameters min_theta and theta.
 */
+ (void)HoughLines:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn stn:(double)stn min_theta:(double)min_theta max_theta:(double)max_theta NS_SWIFT_NAME(HoughLines(image:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:));

/**
 * Finds lines in a binary image using the standard Hough transform.
 *
 * The function implements the standard or standard multi-scale Hough transform algorithm for line
 * detection. See <https://homepages.inf.ed.ac.uk/rbf/HIPR2/hough.htm> for a good explanation of Hough
 * transform.
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 2 or 3 element vector
 * `$$(\rho, \theta)$$` or `$$(\rho, \theta, \textrm{votes})$$`, where `$$\rho$$` is the distance from
 * the coordinate origin `$$(0,0)$$` (top-left corner of the image), `$$\theta$$` is the line rotation
 * angle in radians ( `$$0 \sim \textrm{vertical line}, \pi/2 \sim \textrm{horizontal line}$$` ), and
 * `$$\textrm{votes}$$` is the value of accumulator.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * @param srn For the multi-scale Hough transform, it is a divisor for the distance resolution rho.
 * The coarse accumulator distance resolution is rho and the accurate accumulator resolution is
 * rho/srn. If both srn=0 and stn=0, the classical Hough transform is used. Otherwise, both these
 * parameters should be positive.
 * @param stn For the multi-scale Hough transform, it is a divisor for the distance resolution theta.
 * @param min_theta For standard and multi-scale Hough transform, minimum angle to check for lines.
 * Must fall between 0 and max_theta.
 * Must fall between min_theta and CV_PI. The actual maximum angle in the accumulator may be slightly
 * less than max_theta, depending on the parameters min_theta and theta.
 */
+ (void)HoughLines:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn stn:(double)stn min_theta:(double)min_theta NS_SWIFT_NAME(HoughLines(image:lines:rho:theta:threshold:srn:stn:min_theta:));

/**
 * Finds lines in a binary image using the standard Hough transform.
 *
 * The function implements the standard or standard multi-scale Hough transform algorithm for line
 * detection. See <https://homepages.inf.ed.ac.uk/rbf/HIPR2/hough.htm> for a good explanation of Hough
 * transform.
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 2 or 3 element vector
 * `$$(\rho, \theta)$$` or `$$(\rho, \theta, \textrm{votes})$$`, where `$$\rho$$` is the distance from
 * the coordinate origin `$$(0,0)$$` (top-left corner of the image), `$$\theta$$` is the line rotation
 * angle in radians ( `$$0 \sim \textrm{vertical line}, \pi/2 \sim \textrm{horizontal line}$$` ), and
 * `$$\textrm{votes}$$` is the value of accumulator.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * @param srn For the multi-scale Hough transform, it is a divisor for the distance resolution rho.
 * The coarse accumulator distance resolution is rho and the accurate accumulator resolution is
 * rho/srn. If both srn=0 and stn=0, the classical Hough transform is used. Otherwise, both these
 * parameters should be positive.
 * @param stn For the multi-scale Hough transform, it is a divisor for the distance resolution theta.
 * Must fall between 0 and max_theta.
 * Must fall between min_theta and CV_PI. The actual maximum angle in the accumulator may be slightly
 * less than max_theta, depending on the parameters min_theta and theta.
 */
+ (void)HoughLines:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn stn:(double)stn NS_SWIFT_NAME(HoughLines(image:lines:rho:theta:threshold:srn:stn:));

/**
 * Finds lines in a binary image using the standard Hough transform.
 *
 * The function implements the standard or standard multi-scale Hough transform algorithm for line
 * detection. See <https://homepages.inf.ed.ac.uk/rbf/HIPR2/hough.htm> for a good explanation of Hough
 * transform.
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 2 or 3 element vector
 * `$$(\rho, \theta)$$` or `$$(\rho, \theta, \textrm{votes})$$`, where `$$\rho$$` is the distance from
 * the coordinate origin `$$(0,0)$$` (top-left corner of the image), `$$\theta$$` is the line rotation
 * angle in radians ( `$$0 \sim \textrm{vertical line}, \pi/2 \sim \textrm{horizontal line}$$` ), and
 * `$$\textrm{votes}$$` is the value of accumulator.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * @param srn For the multi-scale Hough transform, it is a divisor for the distance resolution rho.
 * The coarse accumulator distance resolution is rho and the accurate accumulator resolution is
 * rho/srn. If both srn=0 and stn=0, the classical Hough transform is used. Otherwise, both these
 * parameters should be positive.
 * Must fall between 0 and max_theta.
 * Must fall between min_theta and CV_PI. The actual maximum angle in the accumulator may be slightly
 * less than max_theta, depending on the parameters min_theta and theta.
 */
+ (void)HoughLines:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn NS_SWIFT_NAME(HoughLines(image:lines:rho:theta:threshold:srn:));

/**
 * Finds lines in a binary image using the standard Hough transform.
 *
 * The function implements the standard or standard multi-scale Hough transform algorithm for line
 * detection. See <https://homepages.inf.ed.ac.uk/rbf/HIPR2/hough.htm> for a good explanation of Hough
 * transform.
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 2 or 3 element vector
 * `$$(\rho, \theta)$$` or `$$(\rho, \theta, \textrm{votes})$$`, where `$$\rho$$` is the distance from
 * the coordinate origin `$$(0,0)$$` (top-left corner of the image), `$$\theta$$` is the line rotation
 * angle in radians ( `$$0 \sim \textrm{vertical line}, \pi/2 \sim \textrm{horizontal line}$$` ), and
 * `$$\textrm{votes}$$` is the value of accumulator.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * The coarse accumulator distance resolution is rho and the accurate accumulator resolution is
 * rho/srn. If both srn=0 and stn=0, the classical Hough transform is used. Otherwise, both these
 * parameters should be positive.
 * Must fall between 0 and max_theta.
 * Must fall between min_theta and CV_PI. The actual maximum angle in the accumulator may be slightly
 * less than max_theta, depending on the parameters min_theta and theta.
 */
+ (void)HoughLines:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold NS_SWIFT_NAME(HoughLines(image:lines:rho:theta:threshold:));


//
//  void cv::HoughLinesP(Mat image, Mat& lines, double rho, double theta, int threshold, double minLineLength = 0, double maxLineGap = 0)
//
/**
 * Finds line segments in a binary image using the probabilistic Hough transform.
 *
 * The function implements the probabilistic Hough transform algorithm for line detection, described
 * in *Cite:* Matas00
 *
 * See the line detection example below:
 * Include: snippets/imgproc_HoughLinesP.cpp
 * This is a sample picture the function parameters have been tuned for:
 *
 * ![image](building)
 *
 * And this is the output of the above program in case of the probabilistic Hough transform:
 *
 * ![image](houghp)
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 4-element vector
 * `$$(x_1, y_1, x_2, y_2)$$` , where `$$(x_1,y_1)$$` and `$$(x_2, y_2)$$` are the ending points of each detected
 * line segment.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * @param minLineLength Minimum line length. Line segments shorter than that are rejected.
 * @param maxLineGap Maximum allowed gap between points on the same line to link them.
 *
 * - SeeAlso LineSegmentDetector
 */
+ (void)HoughLinesP:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold minLineLength:(double)minLineLength maxLineGap:(double)maxLineGap NS_SWIFT_NAME(HoughLinesP(image:lines:rho:theta:threshold:minLineLength:maxLineGap:));

/**
 * Finds line segments in a binary image using the probabilistic Hough transform.
 *
 * The function implements the probabilistic Hough transform algorithm for line detection, described
 * in *Cite:* Matas00
 *
 * See the line detection example below:
 * Include: snippets/imgproc_HoughLinesP.cpp
 * This is a sample picture the function parameters have been tuned for:
 *
 * ![image](building)
 *
 * And this is the output of the above program in case of the probabilistic Hough transform:
 *
 * ![image](houghp)
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 4-element vector
 * `$$(x_1, y_1, x_2, y_2)$$` , where `$$(x_1,y_1)$$` and `$$(x_2, y_2)$$` are the ending points of each detected
 * line segment.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * @param minLineLength Minimum line length. Line segments shorter than that are rejected.
 *
 * - SeeAlso LineSegmentDetector
 */
+ (void)HoughLinesP:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold minLineLength:(double)minLineLength NS_SWIFT_NAME(HoughLinesP(image:lines:rho:theta:threshold:minLineLength:));

/**
 * Finds line segments in a binary image using the probabilistic Hough transform.
 *
 * The function implements the probabilistic Hough transform algorithm for line detection, described
 * in *Cite:* Matas00
 *
 * See the line detection example below:
 * Include: snippets/imgproc_HoughLinesP.cpp
 * This is a sample picture the function parameters have been tuned for:
 *
 * ![image](building)
 *
 * And this is the output of the above program in case of the probabilistic Hough transform:
 *
 * ![image](houghp)
 *
 * @param image 8-bit, single-channel binary source image. The image may be modified by the function.
 * @param lines Output vector of lines. Each line is represented by a 4-element vector
 * `$$(x_1, y_1, x_2, y_2)$$` , where `$$(x_1,y_1)$$` and `$$(x_2, y_2)$$` are the ending points of each detected
 * line segment.
 * @param rho Distance resolution of the accumulator in pixels.
 * @param theta Angle resolution of the accumulator in radians.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 *
 * - SeeAlso LineSegmentDetector
 */
+ (void)HoughLinesP:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold NS_SWIFT_NAME(HoughLinesP(image:lines:rho:theta:threshold:));


//
//  void cv::HoughLinesPointSet(Mat point, Mat& lines, int lines_max, int threshold, double min_rho, double max_rho, double rho_step, double min_theta, double max_theta, double theta_step)
//
/**
 * Finds lines in a set of points using the standard Hough transform.
 *
 * The function finds lines in a set of points using a modification of the Hough transform.
 * Include: snippets/imgproc_HoughLinesPointSet.cpp
 * @param point Input vector of points. Each vector must be encoded as a Point vector `$$(x,y)$$`. Type must be CV_32FC2 or CV_32SC2.
 * @param lines Output vector of found lines. Each vector is encoded as a vector<Vec3d> `$$(votes, rho, theta)$$`.
 * The larger the value of 'votes', the higher the reliability of the Hough line.
 * @param lines_max Max count of Hough lines.
 * @param threshold %Accumulator threshold parameter. Only those lines are returned that get enough
 * votes ( `$$>\texttt{threshold}$$` ).
 * @param min_rho Minimum value for `$$\rho$$` for the accumulator (Note: `$$\rho$$` can be negative. The absolute value `$$|\rho|$$` is the distance of a line to the origin.).
 * @param max_rho Maximum value for `$$\rho$$` for the accumulator.
 * @param rho_step Distance resolution of the accumulator.
 * @param min_theta Minimum angle value of the accumulator in radians.
 * @param max_theta Upper bound for the angle value of the accumulator in radians. The actual maximum
 * angle may be slightly less than max_theta, depending on the parameters min_theta and theta_step.
 * @param theta_step Angle resolution of the accumulator in radians.
 */
+ (void)HoughLinesPointSet:(Mat*)point lines:(Mat*)lines lines_max:(int)lines_max threshold:(int)threshold min_rho:(double)min_rho max_rho:(double)max_rho rho_step:(double)rho_step min_theta:(double)min_theta max_theta:(double)max_theta theta_step:(double)theta_step NS_SWIFT_NAME(HoughLinesPointSet(point:lines:lines_max:threshold:min_rho:max_rho:rho_step:min_theta:max_theta:theta_step:));


//
//  void cv::HoughCircles(Mat image, Mat& circles, HoughModes method, double dp, double minDist, double param1 = 100, double param2 = 100, int minRadius = 0, int maxRadius = 0)
//
/**
 * Finds circles in a grayscale image using the Hough transform.
 *
 * The function finds circles in a grayscale image using a modification of the Hough transform.
 *
 * Example: :
 * Include: snippets/imgproc_HoughLinesCircles.cpp
 *
 * Note:* Usually the function detects the centers of circles well. However, it may fail to find correct
 * radii. You can assist to the function by specifying the radius range ( minRadius and maxRadius ) if
 * you know it. Or, in the case of ``HoughModes/HOUGH_GRADIENT`` method you may set maxRadius to a negative number
 * to return centers only without radius search, and find the correct radius using an additional procedure.
 *
 * It also helps to smooth image a bit unless it's already soft. For example,
 * GaussianBlur() with 7x7 kernel and 1.5x1.5 sigma or similar blurring may help.
 *
 * @param image 8-bit, single-channel, grayscale input image.
 * @param circles Output vector of found circles. Each vector is encoded as  3 or 4 element
 * floating-point vector `$$(x, y, radius)$$` or `$$(x, y, radius, votes)$$` .
 * @param method Detection method, see ``HoughModes``. The available methods are ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``.
 * @param dp Inverse ratio of the accumulator resolution to the image resolution. For example, if
 * dp=1 , the accumulator has the same resolution as the input image. If dp=2 , the accumulator has
 * half as big width and height. For ``HoughModes/HOUGH_GRADIENT_ALT`` the recommended value is dp=1.5,
 * unless some small very circles need to be detected.
 * @param minDist Minimum distance between the centers of the detected circles. If the parameter is
 * too small, multiple neighbor circles may be falsely detected in addition to a true one. If it is
 * too large, some circles may be missed.
 * @param param1 First method-specific parameter. In case of ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``,
 * it is the higher threshold of the two passed to the Canny edge detector (the lower one is twice smaller).
 * Note that ``HoughModes/HOUGH_GRADIENT_ALT`` uses ``Imgproc/Scharr`` algorithm to compute image derivatives, so the threshold value
 * should normally be higher, such as 300 or normally exposed and contrasty images.
 * @param param2 Second method-specific parameter. In case of ``HoughModes/HOUGH_GRADIENT``, it is the
 * accumulator threshold for the circle centers at the detection stage. The smaller it is, the more
 * false circles may be detected. Circles, corresponding to the larger accumulator values, will be
 * returned first. In the case of ``HoughModes/HOUGH_GRADIENT_ALT`` algorithm, this is the circle "perfectness" measure.
 * The closer it to 1, the better shaped circles algorithm selects. In most cases 0.9 should be fine.
 * If you want get better detection of small circles, you may decrease it to 0.85, 0.8 or even less.
 * But then also try to limit the search range [minRadius, maxRadius] to avoid many false circles.
 * @param minRadius Minimum circle radius.
 * @param maxRadius Maximum circle radius. If <= 0, uses the maximum image dimension. If < 0, ``HoughModes/HOUGH_GRADIENT`` returns
 * centers without finding the radius. ``HoughModes/HOUGH_GRADIENT_ALT`` always computes circle radiuses.
 *
 * - SeeAlso fitEllipse, minEnclosingCircle
 */
+ (void)HoughCircles:(Mat*)image circles:(Mat*)circles method:(HoughModes)method dp:(double)dp minDist:(double)minDist param1:(double)param1 param2:(double)param2 minRadius:(int)minRadius maxRadius:(int)maxRadius NS_SWIFT_NAME(HoughCircles(image:circles:method:dp:minDist:param1:param2:minRadius:maxRadius:));

/**
 * Finds circles in a grayscale image using the Hough transform.
 *
 * The function finds circles in a grayscale image using a modification of the Hough transform.
 *
 * Example: :
 * Include: snippets/imgproc_HoughLinesCircles.cpp
 *
 * Note:* Usually the function detects the centers of circles well. However, it may fail to find correct
 * radii. You can assist to the function by specifying the radius range ( minRadius and maxRadius ) if
 * you know it. Or, in the case of ``HoughModes/HOUGH_GRADIENT`` method you may set maxRadius to a negative number
 * to return centers only without radius search, and find the correct radius using an additional procedure.
 *
 * It also helps to smooth image a bit unless it's already soft. For example,
 * GaussianBlur() with 7x7 kernel and 1.5x1.5 sigma or similar blurring may help.
 *
 * @param image 8-bit, single-channel, grayscale input image.
 * @param circles Output vector of found circles. Each vector is encoded as  3 or 4 element
 * floating-point vector `$$(x, y, radius)$$` or `$$(x, y, radius, votes)$$` .
 * @param method Detection method, see ``HoughModes``. The available methods are ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``.
 * @param dp Inverse ratio of the accumulator resolution to the image resolution. For example, if
 * dp=1 , the accumulator has the same resolution as the input image. If dp=2 , the accumulator has
 * half as big width and height. For ``HoughModes/HOUGH_GRADIENT_ALT`` the recommended value is dp=1.5,
 * unless some small very circles need to be detected.
 * @param minDist Minimum distance between the centers of the detected circles. If the parameter is
 * too small, multiple neighbor circles may be falsely detected in addition to a true one. If it is
 * too large, some circles may be missed.
 * @param param1 First method-specific parameter. In case of ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``,
 * it is the higher threshold of the two passed to the Canny edge detector (the lower one is twice smaller).
 * Note that ``HoughModes/HOUGH_GRADIENT_ALT`` uses ``Imgproc/Scharr`` algorithm to compute image derivatives, so the threshold value
 * should normally be higher, such as 300 or normally exposed and contrasty images.
 * @param param2 Second method-specific parameter. In case of ``HoughModes/HOUGH_GRADIENT``, it is the
 * accumulator threshold for the circle centers at the detection stage. The smaller it is, the more
 * false circles may be detected. Circles, corresponding to the larger accumulator values, will be
 * returned first. In the case of ``HoughModes/HOUGH_GRADIENT_ALT`` algorithm, this is the circle "perfectness" measure.
 * The closer it to 1, the better shaped circles algorithm selects. In most cases 0.9 should be fine.
 * If you want get better detection of small circles, you may decrease it to 0.85, 0.8 or even less.
 * But then also try to limit the search range [minRadius, maxRadius] to avoid many false circles.
 * @param minRadius Minimum circle radius.
 * centers without finding the radius. ``HoughModes/HOUGH_GRADIENT_ALT`` always computes circle radiuses.
 *
 * - SeeAlso fitEllipse, minEnclosingCircle
 */
+ (void)HoughCircles:(Mat*)image circles:(Mat*)circles method:(HoughModes)method dp:(double)dp minDist:(double)minDist param1:(double)param1 param2:(double)param2 minRadius:(int)minRadius NS_SWIFT_NAME(HoughCircles(image:circles:method:dp:minDist:param1:param2:minRadius:));

/**
 * Finds circles in a grayscale image using the Hough transform.
 *
 * The function finds circles in a grayscale image using a modification of the Hough transform.
 *
 * Example: :
 * Include: snippets/imgproc_HoughLinesCircles.cpp
 *
 * Note:* Usually the function detects the centers of circles well. However, it may fail to find correct
 * radii. You can assist to the function by specifying the radius range ( minRadius and maxRadius ) if
 * you know it. Or, in the case of ``HoughModes/HOUGH_GRADIENT`` method you may set maxRadius to a negative number
 * to return centers only without radius search, and find the correct radius using an additional procedure.
 *
 * It also helps to smooth image a bit unless it's already soft. For example,
 * GaussianBlur() with 7x7 kernel and 1.5x1.5 sigma or similar blurring may help.
 *
 * @param image 8-bit, single-channel, grayscale input image.
 * @param circles Output vector of found circles. Each vector is encoded as  3 or 4 element
 * floating-point vector `$$(x, y, radius)$$` or `$$(x, y, radius, votes)$$` .
 * @param method Detection method, see ``HoughModes``. The available methods are ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``.
 * @param dp Inverse ratio of the accumulator resolution to the image resolution. For example, if
 * dp=1 , the accumulator has the same resolution as the input image. If dp=2 , the accumulator has
 * half as big width and height. For ``HoughModes/HOUGH_GRADIENT_ALT`` the recommended value is dp=1.5,
 * unless some small very circles need to be detected.
 * @param minDist Minimum distance between the centers of the detected circles. If the parameter is
 * too small, multiple neighbor circles may be falsely detected in addition to a true one. If it is
 * too large, some circles may be missed.
 * @param param1 First method-specific parameter. In case of ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``,
 * it is the higher threshold of the two passed to the Canny edge detector (the lower one is twice smaller).
 * Note that ``HoughModes/HOUGH_GRADIENT_ALT`` uses ``Imgproc/Scharr`` algorithm to compute image derivatives, so the threshold value
 * should normally be higher, such as 300 or normally exposed and contrasty images.
 * @param param2 Second method-specific parameter. In case of ``HoughModes/HOUGH_GRADIENT``, it is the
 * accumulator threshold for the circle centers at the detection stage. The smaller it is, the more
 * false circles may be detected. Circles, corresponding to the larger accumulator values, will be
 * returned first. In the case of ``HoughModes/HOUGH_GRADIENT_ALT`` algorithm, this is the circle "perfectness" measure.
 * The closer it to 1, the better shaped circles algorithm selects. In most cases 0.9 should be fine.
 * If you want get better detection of small circles, you may decrease it to 0.85, 0.8 or even less.
 * But then also try to limit the search range [minRadius, maxRadius] to avoid many false circles.
 * centers without finding the radius. ``HoughModes/HOUGH_GRADIENT_ALT`` always computes circle radiuses.
 *
 * - SeeAlso fitEllipse, minEnclosingCircle
 */
+ (void)HoughCircles:(Mat*)image circles:(Mat*)circles method:(HoughModes)method dp:(double)dp minDist:(double)minDist param1:(double)param1 param2:(double)param2 NS_SWIFT_NAME(HoughCircles(image:circles:method:dp:minDist:param1:param2:));

/**
 * Finds circles in a grayscale image using the Hough transform.
 *
 * The function finds circles in a grayscale image using a modification of the Hough transform.
 *
 * Example: :
 * Include: snippets/imgproc_HoughLinesCircles.cpp
 *
 * Note:* Usually the function detects the centers of circles well. However, it may fail to find correct
 * radii. You can assist to the function by specifying the radius range ( minRadius and maxRadius ) if
 * you know it. Or, in the case of ``HoughModes/HOUGH_GRADIENT`` method you may set maxRadius to a negative number
 * to return centers only without radius search, and find the correct radius using an additional procedure.
 *
 * It also helps to smooth image a bit unless it's already soft. For example,
 * GaussianBlur() with 7x7 kernel and 1.5x1.5 sigma or similar blurring may help.
 *
 * @param image 8-bit, single-channel, grayscale input image.
 * @param circles Output vector of found circles. Each vector is encoded as  3 or 4 element
 * floating-point vector `$$(x, y, radius)$$` or `$$(x, y, radius, votes)$$` .
 * @param method Detection method, see ``HoughModes``. The available methods are ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``.
 * @param dp Inverse ratio of the accumulator resolution to the image resolution. For example, if
 * dp=1 , the accumulator has the same resolution as the input image. If dp=2 , the accumulator has
 * half as big width and height. For ``HoughModes/HOUGH_GRADIENT_ALT`` the recommended value is dp=1.5,
 * unless some small very circles need to be detected.
 * @param minDist Minimum distance between the centers of the detected circles. If the parameter is
 * too small, multiple neighbor circles may be falsely detected in addition to a true one. If it is
 * too large, some circles may be missed.
 * @param param1 First method-specific parameter. In case of ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``,
 * it is the higher threshold of the two passed to the Canny edge detector (the lower one is twice smaller).
 * Note that ``HoughModes/HOUGH_GRADIENT_ALT`` uses ``Imgproc/Scharr`` algorithm to compute image derivatives, so the threshold value
 * should normally be higher, such as 300 or normally exposed and contrasty images.
 * accumulator threshold for the circle centers at the detection stage. The smaller it is, the more
 * false circles may be detected. Circles, corresponding to the larger accumulator values, will be
 * returned first. In the case of ``HoughModes/HOUGH_GRADIENT_ALT`` algorithm, this is the circle "perfectness" measure.
 * The closer it to 1, the better shaped circles algorithm selects. In most cases 0.9 should be fine.
 * If you want get better detection of small circles, you may decrease it to 0.85, 0.8 or even less.
 * But then also try to limit the search range [minRadius, maxRadius] to avoid many false circles.
 * centers without finding the radius. ``HoughModes/HOUGH_GRADIENT_ALT`` always computes circle radiuses.
 *
 * - SeeAlso fitEllipse, minEnclosingCircle
 */
+ (void)HoughCircles:(Mat*)image circles:(Mat*)circles method:(HoughModes)method dp:(double)dp minDist:(double)minDist param1:(double)param1 NS_SWIFT_NAME(HoughCircles(image:circles:method:dp:minDist:param1:));

/**
 * Finds circles in a grayscale image using the Hough transform.
 *
 * The function finds circles in a grayscale image using a modification of the Hough transform.
 *
 * Example: :
 * Include: snippets/imgproc_HoughLinesCircles.cpp
 *
 * Note:* Usually the function detects the centers of circles well. However, it may fail to find correct
 * radii. You can assist to the function by specifying the radius range ( minRadius and maxRadius ) if
 * you know it. Or, in the case of ``HoughModes/HOUGH_GRADIENT`` method you may set maxRadius to a negative number
 * to return centers only without radius search, and find the correct radius using an additional procedure.
 *
 * It also helps to smooth image a bit unless it's already soft. For example,
 * GaussianBlur() with 7x7 kernel and 1.5x1.5 sigma or similar blurring may help.
 *
 * @param image 8-bit, single-channel, grayscale input image.
 * @param circles Output vector of found circles. Each vector is encoded as  3 or 4 element
 * floating-point vector `$$(x, y, radius)$$` or `$$(x, y, radius, votes)$$` .
 * @param method Detection method, see ``HoughModes``. The available methods are ``HoughModes/HOUGH_GRADIENT`` and ``HoughModes/HOUGH_GRADIENT_ALT``.
 * @param dp Inverse ratio of the accumulator resolution to the image resolution. For example, if
 * dp=1 , the accumulator has the same resolution as the input image. If dp=2 , the accumulator has
 * half as big width and height. For ``HoughModes/HOUGH_GRADIENT_ALT`` the recommended value is dp=1.5,
 * unless some small very circles need to be detected.
 * @param minDist Minimum distance between the centers of the detected circles. If the parameter is
 * too small, multiple neighbor circles may be falsely detected in addition to a true one. If it is
 * too large, some circles may be missed.
 * it is the higher threshold of the two passed to the Canny edge detector (the lower one is twice smaller).
 * Note that ``HoughModes/HOUGH_GRADIENT_ALT`` uses ``Imgproc/Scharr`` algorithm to compute image derivatives, so the threshold value
 * should normally be higher, such as 300 or normally exposed and contrasty images.
 * accumulator threshold for the circle centers at the detection stage. The smaller it is, the more
 * false circles may be detected. Circles, corresponding to the larger accumulator values, will be
 * returned first. In the case of ``HoughModes/HOUGH_GRADIENT_ALT`` algorithm, this is the circle "perfectness" measure.
 * The closer it to 1, the better shaped circles algorithm selects. In most cases 0.9 should be fine.
 * If you want get better detection of small circles, you may decrease it to 0.85, 0.8 or even less.
 * But then also try to limit the search range [minRadius, maxRadius] to avoid many false circles.
 * centers without finding the radius. ``HoughModes/HOUGH_GRADIENT_ALT`` always computes circle radiuses.
 *
 * - SeeAlso fitEllipse, minEnclosingCircle
 */
+ (void)HoughCircles:(Mat*)image circles:(Mat*)circles method:(HoughModes)method dp:(double)dp minDist:(double)minDist NS_SWIFT_NAME(HoughCircles(image:circles:method:dp:minDist:));


//
//  void cv::erode(Mat src, Mat& dst, Mat kernel, Point anchor = Point(-1,-1), int iterations = 1, BorderTypes borderType = BORDER_CONSTANT, Scalar borderValue = morphologyDefaultBorderValue())
//
/**
 * Erodes an image by using a specific structuring element.
 *
 * The function erodes the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the minimum is taken:
 *
 * `$$\texttt{dst} (x,y) =  \min _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Erosion can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for erosion; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``.
 * @param anchor position of the anchor within the element; default value (-1, -1) means that the
 * anchor is at the element center.
 * @param iterations number of times erosion is applied.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 * @param borderValue border value in case of a constant border
 *
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)erode:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations borderType:(BorderTypes)borderType borderValue:(Scalar*)borderValue NS_SWIFT_NAME(erode(src:dst:kernel:anchor:iterations:borderType:borderValue:));

/**
 * Erodes an image by using a specific structuring element.
 *
 * The function erodes the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the minimum is taken:
 *
 * `$$\texttt{dst} (x,y) =  \min _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Erosion can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for erosion; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``.
 * @param anchor position of the anchor within the element; default value (-1, -1) means that the
 * anchor is at the element center.
 * @param iterations number of times erosion is applied.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)erode:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations borderType:(BorderTypes)borderType NS_SWIFT_NAME(erode(src:dst:kernel:anchor:iterations:borderType:));

/**
 * Erodes an image by using a specific structuring element.
 *
 * The function erodes the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the minimum is taken:
 *
 * `$$\texttt{dst} (x,y) =  \min _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Erosion can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for erosion; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``.
 * @param anchor position of the anchor within the element; default value (-1, -1) means that the
 * anchor is at the element center.
 * @param iterations number of times erosion is applied.
 *
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)erode:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations NS_SWIFT_NAME(erode(src:dst:kernel:anchor:iterations:));

/**
 * Erodes an image by using a specific structuring element.
 *
 * The function erodes the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the minimum is taken:
 *
 * `$$\texttt{dst} (x,y) =  \min _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Erosion can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for erosion; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``.
 * @param anchor position of the anchor within the element; default value (-1, -1) means that the
 * anchor is at the element center.
 *
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)erode:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel anchor:(Point2i*)anchor NS_SWIFT_NAME(erode(src:dst:kernel:anchor:));

/**
 * Erodes an image by using a specific structuring element.
 *
 * The function erodes the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the minimum is taken:
 *
 * `$$\texttt{dst} (x,y) =  \min _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Erosion can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for erosion; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``.
 * anchor is at the element center.
 *
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)erode:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel NS_SWIFT_NAME(erode(src:dst:kernel:));


//
//  void cv::dilate(Mat src, Mat& dst, Mat kernel, Point anchor = Point(-1,-1), int iterations = 1, BorderTypes borderType = BORDER_CONSTANT, Scalar borderValue = morphologyDefaultBorderValue())
//
/**
 * Dilates an image by using a specific structuring element.
 *
 * The function dilates the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the maximum is taken:
 * `$$\texttt{dst} (x,y) =  \max _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Dilation can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for dilation; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``
 * @param anchor position of the anchor within the element; default value (-1, -1) means that the
 * anchor is at the element center.
 * @param iterations number of times dilation is applied.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 * @param borderValue border value in case of a constant border
 *
 * - SeeAlso ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)dilate:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations borderType:(BorderTypes)borderType borderValue:(Scalar*)borderValue NS_SWIFT_NAME(dilate(src:dst:kernel:anchor:iterations:borderType:borderValue:));

/**
 * Dilates an image by using a specific structuring element.
 *
 * The function dilates the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the maximum is taken:
 * `$$\texttt{dst} (x,y) =  \max _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Dilation can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for dilation; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``
 * @param anchor position of the anchor within the element; default value (-1, -1) means that the
 * anchor is at the element center.
 * @param iterations number of times dilation is applied.
 * @param borderType pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 *
 * - SeeAlso ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)dilate:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations borderType:(BorderTypes)borderType NS_SWIFT_NAME(dilate(src:dst:kernel:anchor:iterations:borderType:));

/**
 * Dilates an image by using a specific structuring element.
 *
 * The function dilates the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the maximum is taken:
 * `$$\texttt{dst} (x,y) =  \max _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Dilation can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for dilation; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``
 * @param anchor position of the anchor within the element; default value (-1, -1) means that the
 * anchor is at the element center.
 * @param iterations number of times dilation is applied.
 *
 * - SeeAlso ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)dilate:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations NS_SWIFT_NAME(dilate(src:dst:kernel:anchor:iterations:));

/**
 * Dilates an image by using a specific structuring element.
 *
 * The function dilates the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the maximum is taken:
 * `$$\texttt{dst} (x,y) =  \max _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Dilation can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for dilation; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``
 * @param anchor position of the anchor within the element; default value (-1, -1) means that the
 * anchor is at the element center.
 *
 * - SeeAlso ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)dilate:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel anchor:(Point2i*)anchor NS_SWIFT_NAME(dilate(src:dst:kernel:anchor:));

/**
 * Dilates an image by using a specific structuring element.
 *
 * The function dilates the source image using the specified structuring element that determines the
 * shape of a pixel neighborhood over which the maximum is taken:
 * `$$\texttt{dst} (x,y) =  \max _{(x',y'):  \, \texttt{kernel} (x',y') \ne0 } \texttt{src} (x+x',y+y')$$`
 *
 * The function supports the in-place mode. Dilation can be applied several ( iterations ) times. In
 * case of multi-channel images, each channel is processed independently.
 *
 * @param src input image; the number of channels can be arbitrary, but the depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst output image of the same size and type as src.
 * @param kernel structuring element used for dilation; if `kernel=Mat()`, a `3 x 3` rectangular
 * structuring element is used. Kernel can be created using ``Imgproc/getStructuringElement``
 * anchor is at the element center.
 *
 * - SeeAlso ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``morphologyEx:dst:op:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 */
+ (void)dilate:(Mat*)src dst:(Mat*)dst kernel:(Mat*)kernel NS_SWIFT_NAME(dilate(src:dst:kernel:));


//
//  void cv::morphologyEx(Mat src, Mat& dst, MorphTypes op, Mat kernel, Point anchor = Point(-1,-1), int iterations = 1, BorderTypes borderType = BORDER_CONSTANT, Scalar borderValue = morphologyDefaultBorderValue())
//
/**
 * Performs advanced morphological transformations.
 *
 * The function cv::morphologyEx can perform advanced morphological transformations using an erosion and dilation as
 * basic operations.
 *
 * Any of the operations can be done in-place. In case of multi-channel images, each channel is
 * processed independently.
 *
 * @param src Source image. The number of channels can be arbitrary. The depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst Destination image of the same size and type as source image.
 * @param op Type of a morphological operation, see ``MorphTypes``
 * @param kernel Structuring element. It can be created using ``Imgproc/getStructuringElement``.
 * @param anchor Anchor position with the kernel. Negative values mean that the anchor is at the
 * kernel center.
 * @param iterations Number of times erosion and dilation are applied.
 * @param borderType Pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 * @param borderValue Border value in case of a constant border. The default value has a special
 * meaning.
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 * Note:* The number of iterations is the number of times erosion or dilatation operation will be applied.
 * For instance, an opening operation (``MorphTypes/MORPH_OPEN``) with two iterations is equivalent to apply
 * successively: erode -> erode -> dilate -> dilate (and not erode -> dilate -> erode -> dilate).
 */
+ (void)morphologyEx:(Mat*)src dst:(Mat*)dst op:(MorphTypes)op kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations borderType:(BorderTypes)borderType borderValue:(Scalar*)borderValue NS_SWIFT_NAME(morphologyEx(src:dst:op:kernel:anchor:iterations:borderType:borderValue:));

/**
 * Performs advanced morphological transformations.
 *
 * The function cv::morphologyEx can perform advanced morphological transformations using an erosion and dilation as
 * basic operations.
 *
 * Any of the operations can be done in-place. In case of multi-channel images, each channel is
 * processed independently.
 *
 * @param src Source image. The number of channels can be arbitrary. The depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst Destination image of the same size and type as source image.
 * @param op Type of a morphological operation, see ``MorphTypes``
 * @param kernel Structuring element. It can be created using ``Imgproc/getStructuringElement``.
 * @param anchor Anchor position with the kernel. Negative values mean that the anchor is at the
 * kernel center.
 * @param iterations Number of times erosion and dilation are applied.
 * @param borderType Pixel extrapolation method, see ``BorderTypes``. ``BorderTypes/BORDER_WRAP`` is not supported.
 * meaning.
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 * Note:* The number of iterations is the number of times erosion or dilatation operation will be applied.
 * For instance, an opening operation (``MorphTypes/MORPH_OPEN``) with two iterations is equivalent to apply
 * successively: erode -> erode -> dilate -> dilate (and not erode -> dilate -> erode -> dilate).
 */
+ (void)morphologyEx:(Mat*)src dst:(Mat*)dst op:(MorphTypes)op kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations borderType:(BorderTypes)borderType NS_SWIFT_NAME(morphologyEx(src:dst:op:kernel:anchor:iterations:borderType:));

/**
 * Performs advanced morphological transformations.
 *
 * The function cv::morphologyEx can perform advanced morphological transformations using an erosion and dilation as
 * basic operations.
 *
 * Any of the operations can be done in-place. In case of multi-channel images, each channel is
 * processed independently.
 *
 * @param src Source image. The number of channels can be arbitrary. The depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst Destination image of the same size and type as source image.
 * @param op Type of a morphological operation, see ``MorphTypes``
 * @param kernel Structuring element. It can be created using ``Imgproc/getStructuringElement``.
 * @param anchor Anchor position with the kernel. Negative values mean that the anchor is at the
 * kernel center.
 * @param iterations Number of times erosion and dilation are applied.
 * meaning.
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 * Note:* The number of iterations is the number of times erosion or dilatation operation will be applied.
 * For instance, an opening operation (``MorphTypes/MORPH_OPEN``) with two iterations is equivalent to apply
 * successively: erode -> erode -> dilate -> dilate (and not erode -> dilate -> erode -> dilate).
 */
+ (void)morphologyEx:(Mat*)src dst:(Mat*)dst op:(MorphTypes)op kernel:(Mat*)kernel anchor:(Point2i*)anchor iterations:(int)iterations NS_SWIFT_NAME(morphologyEx(src:dst:op:kernel:anchor:iterations:));

/**
 * Performs advanced morphological transformations.
 *
 * The function cv::morphologyEx can perform advanced morphological transformations using an erosion and dilation as
 * basic operations.
 *
 * Any of the operations can be done in-place. In case of multi-channel images, each channel is
 * processed independently.
 *
 * @param src Source image. The number of channels can be arbitrary. The depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst Destination image of the same size and type as source image.
 * @param op Type of a morphological operation, see ``MorphTypes``
 * @param kernel Structuring element. It can be created using ``Imgproc/getStructuringElement``.
 * @param anchor Anchor position with the kernel. Negative values mean that the anchor is at the
 * kernel center.
 * meaning.
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 * Note:* The number of iterations is the number of times erosion or dilatation operation will be applied.
 * For instance, an opening operation (``MorphTypes/MORPH_OPEN``) with two iterations is equivalent to apply
 * successively: erode -> erode -> dilate -> dilate (and not erode -> dilate -> erode -> dilate).
 */
+ (void)morphologyEx:(Mat*)src dst:(Mat*)dst op:(MorphTypes)op kernel:(Mat*)kernel anchor:(Point2i*)anchor NS_SWIFT_NAME(morphologyEx(src:dst:op:kernel:anchor:));

/**
 * Performs advanced morphological transformations.
 *
 * The function cv::morphologyEx can perform advanced morphological transformations using an erosion and dilation as
 * basic operations.
 *
 * Any of the operations can be done in-place. In case of multi-channel images, each channel is
 * processed independently.
 *
 * @param src Source image. The number of channels can be arbitrary. The depth should be one of
 * CV_8U, CV_16U, CV_16S, CV_32F or CV_64F.
 * @param dst Destination image of the same size and type as source image.
 * @param op Type of a morphological operation, see ``MorphTypes``
 * @param kernel Structuring element. It can be created using ``Imgproc/getStructuringElement``.
 * kernel center.
 * meaning.
 * - SeeAlso ``dilate:dst:kernel:anchor:iterations:borderType:borderValue:``, ``erode:dst:kernel:anchor:iterations:borderType:borderValue:``, ``getStructuringElement:ksize:anchor:``
 * Note:* The number of iterations is the number of times erosion or dilatation operation will be applied.
 * For instance, an opening operation (``MorphTypes/MORPH_OPEN``) with two iterations is equivalent to apply
 * successively: erode -> erode -> dilate -> dilate (and not erode -> dilate -> erode -> dilate).
 */
+ (void)morphologyEx:(Mat*)src dst:(Mat*)dst op:(MorphTypes)op kernel:(Mat*)kernel NS_SWIFT_NAME(morphologyEx(src:dst:op:kernel:));


//
//  void cv::resize(Mat src, Mat& dst, Size dsize, double fx = 0, double fy = 0, int interpolation = INTER_LINEAR)
//
/**
 * Resizes an image.
 *
 * The function resize resizes the image src down to or up to the specified size. Note that the
 * initial dst type or size are not taken into account. Instead, the size and type are derived from
 * the `src`,`dsize`,`fx`, and `fy`. If you want to resize src so that it fits the pre-created dst,
 * you may call the function as follows:
 *
 *     // explicitly specify dsize=dst.size(); fx and fy will be computed from that.
 *     resize(src, dst, dst.size(), 0, 0, interpolation);
 *
 * If you want to decimate the image by factor of 2 in each direction, you can call the function this
 * way:
 *
 *     // specify fx and fy and let the function compute the destination image size.
 *     resize(src, dst, Size(), 0.5, 0.5, interpolation);
 *
 * To shrink an image, it will generally look best with ``InterpolationFlags/INTER_AREA`` interpolation, whereas to
 * enlarge an image, it will generally look best with ``InterpolationFlags/INTER_CUBIC`` (slow) or ``InterpolationFlags/INTER_LINEAR``
 * (faster but still looks OK).
 *
 * @param src input image.
 * @param dst output image; it has the size dsize (when it is non-zero) or the size computed from
 * src.size(), fx, and fy; the type of dst is the same as of src.
 * @param dsize output image size; if it equals zero (`None` in Python), it is computed as:
 *  `$$\texttt{dsize = Size(round(fx*src.cols), round(fy*src.rows))}$$`
 *  Either dsize or both fx and fy must be non-zero.
 * @param fx scale factor along the horizontal axis; when it equals 0, it is computed as
 * `$$\texttt{(double)dsize.width/src.cols}$$`
 * @param fy scale factor along the vertical axis; when it equals 0, it is computed as
 * `$$\texttt{(double)dsize.height/src.rows}$$`
 * @param interpolation interpolation method, see ``InterpolationFlags``
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``
 */
+ (void)resize:(Mat*)src dst:(Mat*)dst dsize:(Size2i*)dsize fx:(double)fx fy:(double)fy interpolation:(int)interpolation NS_SWIFT_NAME(resize(src:dst:dsize:fx:fy:interpolation:));

/**
 * Resizes an image.
 *
 * The function resize resizes the image src down to or up to the specified size. Note that the
 * initial dst type or size are not taken into account. Instead, the size and type are derived from
 * the `src`,`dsize`,`fx`, and `fy`. If you want to resize src so that it fits the pre-created dst,
 * you may call the function as follows:
 *
 *     // explicitly specify dsize=dst.size(); fx and fy will be computed from that.
 *     resize(src, dst, dst.size(), 0, 0, interpolation);
 *
 * If you want to decimate the image by factor of 2 in each direction, you can call the function this
 * way:
 *
 *     // specify fx and fy and let the function compute the destination image size.
 *     resize(src, dst, Size(), 0.5, 0.5, interpolation);
 *
 * To shrink an image, it will generally look best with ``InterpolationFlags/INTER_AREA`` interpolation, whereas to
 * enlarge an image, it will generally look best with ``InterpolationFlags/INTER_CUBIC`` (slow) or ``InterpolationFlags/INTER_LINEAR``
 * (faster but still looks OK).
 *
 * @param src input image.
 * @param dst output image; it has the size dsize (when it is non-zero) or the size computed from
 * src.size(), fx, and fy; the type of dst is the same as of src.
 * @param dsize output image size; if it equals zero (`None` in Python), it is computed as:
 *  `$$\texttt{dsize = Size(round(fx*src.cols), round(fy*src.rows))}$$`
 *  Either dsize or both fx and fy must be non-zero.
 * @param fx scale factor along the horizontal axis; when it equals 0, it is computed as
 * `$$\texttt{(double)dsize.width/src.cols}$$`
 * @param fy scale factor along the vertical axis; when it equals 0, it is computed as
 * `$$\texttt{(double)dsize.height/src.rows}$$`
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``
 */
+ (void)resize:(Mat*)src dst:(Mat*)dst dsize:(Size2i*)dsize fx:(double)fx fy:(double)fy NS_SWIFT_NAME(resize(src:dst:dsize:fx:fy:));

/**
 * Resizes an image.
 *
 * The function resize resizes the image src down to or up to the specified size. Note that the
 * initial dst type or size are not taken into account. Instead, the size and type are derived from
 * the `src`,`dsize`,`fx`, and `fy`. If you want to resize src so that it fits the pre-created dst,
 * you may call the function as follows:
 *
 *     // explicitly specify dsize=dst.size(); fx and fy will be computed from that.
 *     resize(src, dst, dst.size(), 0, 0, interpolation);
 *
 * If you want to decimate the image by factor of 2 in each direction, you can call the function this
 * way:
 *
 *     // specify fx and fy and let the function compute the destination image size.
 *     resize(src, dst, Size(), 0.5, 0.5, interpolation);
 *
 * To shrink an image, it will generally look best with ``InterpolationFlags/INTER_AREA`` interpolation, whereas to
 * enlarge an image, it will generally look best with ``InterpolationFlags/INTER_CUBIC`` (slow) or ``InterpolationFlags/INTER_LINEAR``
 * (faster but still looks OK).
 *
 * @param src input image.
 * @param dst output image; it has the size dsize (when it is non-zero) or the size computed from
 * src.size(), fx, and fy; the type of dst is the same as of src.
 * @param dsize output image size; if it equals zero (`None` in Python), it is computed as:
 *  `$$\texttt{dsize = Size(round(fx*src.cols), round(fy*src.rows))}$$`
 *  Either dsize or both fx and fy must be non-zero.
 * @param fx scale factor along the horizontal axis; when it equals 0, it is computed as
 * `$$\texttt{(double)dsize.width/src.cols}$$`
 * `$$\texttt{(double)dsize.height/src.rows}$$`
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``
 */
+ (void)resize:(Mat*)src dst:(Mat*)dst dsize:(Size2i*)dsize fx:(double)fx NS_SWIFT_NAME(resize(src:dst:dsize:fx:));

/**
 * Resizes an image.
 *
 * The function resize resizes the image src down to or up to the specified size. Note that the
 * initial dst type or size are not taken into account. Instead, the size and type are derived from
 * the `src`,`dsize`,`fx`, and `fy`. If you want to resize src so that it fits the pre-created dst,
 * you may call the function as follows:
 *
 *     // explicitly specify dsize=dst.size(); fx and fy will be computed from that.
 *     resize(src, dst, dst.size(), 0, 0, interpolation);
 *
 * If you want to decimate the image by factor of 2 in each direction, you can call the function this
 * way:
 *
 *     // specify fx and fy and let the function compute the destination image size.
 *     resize(src, dst, Size(), 0.5, 0.5, interpolation);
 *
 * To shrink an image, it will generally look best with ``InterpolationFlags/INTER_AREA`` interpolation, whereas to
 * enlarge an image, it will generally look best with ``InterpolationFlags/INTER_CUBIC`` (slow) or ``InterpolationFlags/INTER_LINEAR``
 * (faster but still looks OK).
 *
 * @param src input image.
 * @param dst output image; it has the size dsize (when it is non-zero) or the size computed from
 * src.size(), fx, and fy; the type of dst is the same as of src.
 * @param dsize output image size; if it equals zero (`None` in Python), it is computed as:
 *  `$$\texttt{dsize = Size(round(fx*src.cols), round(fy*src.rows))}$$`
 *  Either dsize or both fx and fy must be non-zero.
 * `$$\texttt{(double)dsize.width/src.cols}$$`
 * `$$\texttt{(double)dsize.height/src.rows}$$`
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``
 */
+ (void)resize:(Mat*)src dst:(Mat*)dst dsize:(Size2i*)dsize NS_SWIFT_NAME(resize(src:dst:dsize:));


//
//  void cv::warpAffine(Mat src, Mat& dst, Mat M, Size dsize, int flags = INTER_LINEAR, BorderTypes borderMode = BORDER_CONSTANT, Scalar borderValue = Scalar(), AlgorithmHint hint = cv::ALGO_HINT_DEFAULT)
//
/**
 * Applies an affine transformation to an image.
 *
 * The function warpAffine transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} ( \texttt{M} _{11} x +  \texttt{M} _{12} y +  \texttt{M} _{13}, \texttt{M} _{21} x +  \texttt{M} _{22} y +  \texttt{M} _{23})$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted
 * with #invertAffineTransform and then put in the formula above instead of M. The function cannot
 * operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$2\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * @param flags combination of interpolation methods (see ``InterpolationFlags``) and the optional
 * flag ``InterpolationFlags/WARP_INVERSE_MAP`` that means that M is the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * @param borderMode pixel extrapolation method (see ``BorderTypes``); when
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image corresponding to
 * the "outliers" in the source image are not modified by the function.
 * @param borderValue value used in case of a constant border; by default, it is 0.
 * @param hint Implementation modification flags. Set ``AlgorithmHint/ALGO_HINT_APPROX`` to use FP16 precision (if available)
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, transform
 */
+ (void)warpAffine:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize flags:(int)flags borderMode:(BorderTypes)borderMode borderValue:(Scalar*)borderValue hint:(AlgorithmHint)hint NS_SWIFT_NAME(warpAffine(src:dst:M:dsize:flags:borderMode:borderValue:hint:));

/**
 * Applies an affine transformation to an image.
 *
 * The function warpAffine transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} ( \texttt{M} _{11} x +  \texttt{M} _{12} y +  \texttt{M} _{13}, \texttt{M} _{21} x +  \texttt{M} _{22} y +  \texttt{M} _{23})$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted
 * with #invertAffineTransform and then put in the formula above instead of M. The function cannot
 * operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$2\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * @param flags combination of interpolation methods (see ``InterpolationFlags``) and the optional
 * flag ``InterpolationFlags/WARP_INVERSE_MAP`` that means that M is the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * @param borderMode pixel extrapolation method (see ``BorderTypes``); when
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image corresponding to
 * the "outliers" in the source image are not modified by the function.
 * @param borderValue value used in case of a constant border; by default, it is 0.
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, transform
 */
+ (void)warpAffine:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize flags:(int)flags borderMode:(BorderTypes)borderMode borderValue:(Scalar*)borderValue NS_SWIFT_NAME(warpAffine(src:dst:M:dsize:flags:borderMode:borderValue:));

/**
 * Applies an affine transformation to an image.
 *
 * The function warpAffine transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} ( \texttt{M} _{11} x +  \texttt{M} _{12} y +  \texttt{M} _{13}, \texttt{M} _{21} x +  \texttt{M} _{22} y +  \texttt{M} _{23})$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted
 * with #invertAffineTransform and then put in the formula above instead of M. The function cannot
 * operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$2\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * @param flags combination of interpolation methods (see ``InterpolationFlags``) and the optional
 * flag ``InterpolationFlags/WARP_INVERSE_MAP`` that means that M is the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * @param borderMode pixel extrapolation method (see ``BorderTypes``); when
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image corresponding to
 * the "outliers" in the source image are not modified by the function.
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, transform
 */
+ (void)warpAffine:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize flags:(int)flags borderMode:(BorderTypes)borderMode NS_SWIFT_NAME(warpAffine(src:dst:M:dsize:flags:borderMode:));

/**
 * Applies an affine transformation to an image.
 *
 * The function warpAffine transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} ( \texttt{M} _{11} x +  \texttt{M} _{12} y +  \texttt{M} _{13}, \texttt{M} _{21} x +  \texttt{M} _{22} y +  \texttt{M} _{23})$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted
 * with #invertAffineTransform and then put in the formula above instead of M. The function cannot
 * operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$2\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * @param flags combination of interpolation methods (see ``InterpolationFlags``) and the optional
 * flag ``InterpolationFlags/WARP_INVERSE_MAP`` that means that M is the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image corresponding to
 * the "outliers" in the source image are not modified by the function.
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, transform
 */
+ (void)warpAffine:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize flags:(int)flags NS_SWIFT_NAME(warpAffine(src:dst:M:dsize:flags:));

/**
 * Applies an affine transformation to an image.
 *
 * The function warpAffine transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} ( \texttt{M} _{11} x +  \texttt{M} _{12} y +  \texttt{M} _{13}, \texttt{M} _{21} x +  \texttt{M} _{22} y +  \texttt{M} _{23})$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted
 * with #invertAffineTransform and then put in the formula above instead of M. The function cannot
 * operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$2\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * flag ``InterpolationFlags/WARP_INVERSE_MAP`` that means that M is the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image corresponding to
 * the "outliers" in the source image are not modified by the function.
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, transform
 */
+ (void)warpAffine:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize NS_SWIFT_NAME(warpAffine(src:dst:M:dsize:));


//
//  void cv::warpPerspective(Mat src, Mat& dst, Mat M, Size dsize, int flags = INTER_LINEAR, BorderTypes borderMode = BORDER_CONSTANT, Scalar borderValue = Scalar(), AlgorithmHint hint = cv::ALGO_HINT_DEFAULT)
//
/**
 * Applies a perspective transformation to an image.
 *
 * The function warpPerspective transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} \left ( \frac{M_{11} x + M_{12} y + M_{13}}{M_{31} x + M_{32} y + M_{33}} ,
 *      \frac{M_{21} x + M_{22} y + M_{23}}{M_{31} x + M_{32} y + M_{33}} \right )$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted with invert
 * and then put in the formula above instead of M. The function cannot operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$3\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * @param flags combination of interpolation methods (``InterpolationFlags/INTER_LINEAR`` or ``InterpolationFlags/INTER_NEAREST``) and the
 * optional flag ``InterpolationFlags/WARP_INVERSE_MAP``, that sets M as the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * @param borderMode pixel extrapolation method (``BorderTypes/BORDER_CONSTANT`` or ``BorderTypes/BORDER_REPLICATE``).
 * @param borderValue value used in case of a constant border; by default, it equals 0.
 * @param hint Implementation modification flags. Set ``AlgorithmHint/ALGO_HINT_APPROX`` to use FP16 precision (if available)
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, perspectiveTransform
 */
+ (void)warpPerspective:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize flags:(int)flags borderMode:(BorderTypes)borderMode borderValue:(Scalar*)borderValue hint:(AlgorithmHint)hint NS_SWIFT_NAME(warpPerspective(src:dst:M:dsize:flags:borderMode:borderValue:hint:));

/**
 * Applies a perspective transformation to an image.
 *
 * The function warpPerspective transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} \left ( \frac{M_{11} x + M_{12} y + M_{13}}{M_{31} x + M_{32} y + M_{33}} ,
 *      \frac{M_{21} x + M_{22} y + M_{23}}{M_{31} x + M_{32} y + M_{33}} \right )$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted with invert
 * and then put in the formula above instead of M. The function cannot operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$3\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * @param flags combination of interpolation methods (``InterpolationFlags/INTER_LINEAR`` or ``InterpolationFlags/INTER_NEAREST``) and the
 * optional flag ``InterpolationFlags/WARP_INVERSE_MAP``, that sets M as the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * @param borderMode pixel extrapolation method (``BorderTypes/BORDER_CONSTANT`` or ``BorderTypes/BORDER_REPLICATE``).
 * @param borderValue value used in case of a constant border; by default, it equals 0.
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, perspectiveTransform
 */
+ (void)warpPerspective:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize flags:(int)flags borderMode:(BorderTypes)borderMode borderValue:(Scalar*)borderValue NS_SWIFT_NAME(warpPerspective(src:dst:M:dsize:flags:borderMode:borderValue:));

/**
 * Applies a perspective transformation to an image.
 *
 * The function warpPerspective transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} \left ( \frac{M_{11} x + M_{12} y + M_{13}}{M_{31} x + M_{32} y + M_{33}} ,
 *      \frac{M_{21} x + M_{22} y + M_{23}}{M_{31} x + M_{32} y + M_{33}} \right )$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted with invert
 * and then put in the formula above instead of M. The function cannot operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$3\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * @param flags combination of interpolation methods (``InterpolationFlags/INTER_LINEAR`` or ``InterpolationFlags/INTER_NEAREST``) and the
 * optional flag ``InterpolationFlags/WARP_INVERSE_MAP``, that sets M as the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * @param borderMode pixel extrapolation method (``BorderTypes/BORDER_CONSTANT`` or ``BorderTypes/BORDER_REPLICATE``).
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, perspectiveTransform
 */
+ (void)warpPerspective:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize flags:(int)flags borderMode:(BorderTypes)borderMode NS_SWIFT_NAME(warpPerspective(src:dst:M:dsize:flags:borderMode:));

/**
 * Applies a perspective transformation to an image.
 *
 * The function warpPerspective transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} \left ( \frac{M_{11} x + M_{12} y + M_{13}}{M_{31} x + M_{32} y + M_{33}} ,
 *      \frac{M_{21} x + M_{22} y + M_{23}}{M_{31} x + M_{32} y + M_{33}} \right )$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted with invert
 * and then put in the formula above instead of M. The function cannot operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$3\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * @param flags combination of interpolation methods (``InterpolationFlags/INTER_LINEAR`` or ``InterpolationFlags/INTER_NEAREST``) and the
 * optional flag ``InterpolationFlags/WARP_INVERSE_MAP``, that sets M as the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, perspectiveTransform
 */
+ (void)warpPerspective:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize flags:(int)flags NS_SWIFT_NAME(warpPerspective(src:dst:M:dsize:flags:));

/**
 * Applies a perspective transformation to an image.
 *
 * The function warpPerspective transforms the source image using the specified matrix:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} \left ( \frac{M_{11} x + M_{12} y + M_{13}}{M_{31} x + M_{32} y + M_{33}} ,
 *      \frac{M_{21} x + M_{22} y + M_{23}}{M_{31} x + M_{32} y + M_{33}} \right )$$`
 *
 * when the flag ``InterpolationFlags/WARP_INVERSE_MAP`` is set. Otherwise, the transformation is first inverted with invert
 * and then put in the formula above instead of M. The function cannot operate in-place.
 *
 * @param src input image.
 * @param dst output image that has the size dsize and the same type as src .
 * @param M `$$3\times 3$$` transformation matrix.
 * @param dsize size of the output image.
 * optional flag ``InterpolationFlags/WARP_INVERSE_MAP``, that sets M as the inverse transformation (
 * `$$\texttt{dst}\rightarrow\texttt{src}$$` ).
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``resize:dst:dsize:fx:fy:interpolation:``, ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``getRectSubPix:patchSize:center:patch:patchType:``, perspectiveTransform
 */
+ (void)warpPerspective:(Mat*)src dst:(Mat*)dst M:(Mat*)M dsize:(Size2i*)dsize NS_SWIFT_NAME(warpPerspective(src:dst:M:dsize:));


//
//  void cv::remap(Mat src, Mat& dst, Mat map1, Mat map2, int interpolation, BorderTypes borderMode = BORDER_CONSTANT, Scalar borderValue = Scalar(), AlgorithmHint hint = cv::ALGO_HINT_DEFAULT)
//
/**
 * Applies a generic geometrical transformation to an image.
 *
 * The function remap transforms the source image using the specified map:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} (map_x(x,y),map_y(x,y))$$`
 *
 * with the WARP_RELATIVE_MAP flag :
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} (x+map_x(x,y),y+map_y(x,y))$$`
 *
 * where values of pixels with non-integer coordinates are computed using one of available
 * interpolation methods. `$$map_x$$` and `$$map_y$$` can be encoded as separate floating-point maps
 * in `$$map_1$$` and `$$map_2$$` respectively, or interleaved floating-point maps of `$$(x,y)$$` in
 * `$$map_1$$`, or fixed-point maps created by using ``Imgproc/convertMaps``. Fixed-point maps
 * use a more compact representation, which can reduce memory bandwidth and benefit
 * repeated remap calls that reuse the same map. Performance gains vary by hardware
 * and are typically modest; measure before converting. In the converted case,
 * `$$map_1$$` contains pairs (cvFloor(x),
 * cvFloor(y)) and `$$map_2$$` contains indices in a table of interpolation coefficients.
 *
 * This function cannot operate in-place.
 *
 * @param src Source image.
 * @param dst Destination image. It has the same size as map1 and the same type as src .
 * @param map1 The first map of either (x,y) points or just x values having the type CV_16SC2 ,
 * CV_32FC1, or CV_32FC2. See ``Imgproc/convertMaps`` for details on converting a floating point
 * representation to fixed-point.
 * @param map2 The second map of y values having the type CV_16UC1, CV_32FC1, or none (empty map
 * if map1 is (x,y) points), respectively.
 * @param interpolation Interpolation method (see ``InterpolationFlags``). The methods ``InterpolationFlags/INTER_AREA``
 * ``InterpolationFlags/INTER_LINEAR_EXACT`` and ``InterpolationFlags/INTER_NEAREST_EXACT`` are not supported by this function.
 * The extra flag WARP_RELATIVE_MAP can be ORed to the interpolation method
 * (e.g. INTER_LINEAR | WARP_RELATIVE_MAP)
 * @param borderMode Pixel extrapolation method (see ``BorderTypes``). When
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image that
 * corresponds to the "outliers" in the source image are not modified by the function.
 * @param borderValue Value used in case of a constant border. By default, it is 0.
 * @param hint Implementation modification flags. Set ``AlgorithmHint/ALGO_HINT_APPROX`` to use FP16 precision (if available)
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 * Note:*
 * Due to current implementation limitations the size of an input and output images should be less than 32767x32767.
 */
+ (void)remap:(Mat*)src dst:(Mat*)dst map1:(Mat*)map1 map2:(Mat*)map2 interpolation:(int)interpolation borderMode:(BorderTypes)borderMode borderValue:(Scalar*)borderValue hint:(AlgorithmHint)hint NS_SWIFT_NAME(remap(src:dst:map1:map2:interpolation:borderMode:borderValue:hint:));

/**
 * Applies a generic geometrical transformation to an image.
 *
 * The function remap transforms the source image using the specified map:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} (map_x(x,y),map_y(x,y))$$`
 *
 * with the WARP_RELATIVE_MAP flag :
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} (x+map_x(x,y),y+map_y(x,y))$$`
 *
 * where values of pixels with non-integer coordinates are computed using one of available
 * interpolation methods. `$$map_x$$` and `$$map_y$$` can be encoded as separate floating-point maps
 * in `$$map_1$$` and `$$map_2$$` respectively, or interleaved floating-point maps of `$$(x,y)$$` in
 * `$$map_1$$`, or fixed-point maps created by using ``Imgproc/convertMaps``. Fixed-point maps
 * use a more compact representation, which can reduce memory bandwidth and benefit
 * repeated remap calls that reuse the same map. Performance gains vary by hardware
 * and are typically modest; measure before converting. In the converted case,
 * `$$map_1$$` contains pairs (cvFloor(x),
 * cvFloor(y)) and `$$map_2$$` contains indices in a table of interpolation coefficients.
 *
 * This function cannot operate in-place.
 *
 * @param src Source image.
 * @param dst Destination image. It has the same size as map1 and the same type as src .
 * @param map1 The first map of either (x,y) points or just x values having the type CV_16SC2 ,
 * CV_32FC1, or CV_32FC2. See ``Imgproc/convertMaps`` for details on converting a floating point
 * representation to fixed-point.
 * @param map2 The second map of y values having the type CV_16UC1, CV_32FC1, or none (empty map
 * if map1 is (x,y) points), respectively.
 * @param interpolation Interpolation method (see ``InterpolationFlags``). The methods ``InterpolationFlags/INTER_AREA``
 * ``InterpolationFlags/INTER_LINEAR_EXACT`` and ``InterpolationFlags/INTER_NEAREST_EXACT`` are not supported by this function.
 * The extra flag WARP_RELATIVE_MAP can be ORed to the interpolation method
 * (e.g. INTER_LINEAR | WARP_RELATIVE_MAP)
 * @param borderMode Pixel extrapolation method (see ``BorderTypes``). When
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image that
 * corresponds to the "outliers" in the source image are not modified by the function.
 * @param borderValue Value used in case of a constant border. By default, it is 0.
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 * Note:*
 * Due to current implementation limitations the size of an input and output images should be less than 32767x32767.
 */
+ (void)remap:(Mat*)src dst:(Mat*)dst map1:(Mat*)map1 map2:(Mat*)map2 interpolation:(int)interpolation borderMode:(BorderTypes)borderMode borderValue:(Scalar*)borderValue NS_SWIFT_NAME(remap(src:dst:map1:map2:interpolation:borderMode:borderValue:));

/**
 * Applies a generic geometrical transformation to an image.
 *
 * The function remap transforms the source image using the specified map:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} (map_x(x,y),map_y(x,y))$$`
 *
 * with the WARP_RELATIVE_MAP flag :
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} (x+map_x(x,y),y+map_y(x,y))$$`
 *
 * where values of pixels with non-integer coordinates are computed using one of available
 * interpolation methods. `$$map_x$$` and `$$map_y$$` can be encoded as separate floating-point maps
 * in `$$map_1$$` and `$$map_2$$` respectively, or interleaved floating-point maps of `$$(x,y)$$` in
 * `$$map_1$$`, or fixed-point maps created by using ``Imgproc/convertMaps``. Fixed-point maps
 * use a more compact representation, which can reduce memory bandwidth and benefit
 * repeated remap calls that reuse the same map. Performance gains vary by hardware
 * and are typically modest; measure before converting. In the converted case,
 * `$$map_1$$` contains pairs (cvFloor(x),
 * cvFloor(y)) and `$$map_2$$` contains indices in a table of interpolation coefficients.
 *
 * This function cannot operate in-place.
 *
 * @param src Source image.
 * @param dst Destination image. It has the same size as map1 and the same type as src .
 * @param map1 The first map of either (x,y) points or just x values having the type CV_16SC2 ,
 * CV_32FC1, or CV_32FC2. See ``Imgproc/convertMaps`` for details on converting a floating point
 * representation to fixed-point.
 * @param map2 The second map of y values having the type CV_16UC1, CV_32FC1, or none (empty map
 * if map1 is (x,y) points), respectively.
 * @param interpolation Interpolation method (see ``InterpolationFlags``). The methods ``InterpolationFlags/INTER_AREA``
 * ``InterpolationFlags/INTER_LINEAR_EXACT`` and ``InterpolationFlags/INTER_NEAREST_EXACT`` are not supported by this function.
 * The extra flag WARP_RELATIVE_MAP can be ORed to the interpolation method
 * (e.g. INTER_LINEAR | WARP_RELATIVE_MAP)
 * @param borderMode Pixel extrapolation method (see ``BorderTypes``). When
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image that
 * corresponds to the "outliers" in the source image are not modified by the function.
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 * Note:*
 * Due to current implementation limitations the size of an input and output images should be less than 32767x32767.
 */
+ (void)remap:(Mat*)src dst:(Mat*)dst map1:(Mat*)map1 map2:(Mat*)map2 interpolation:(int)interpolation borderMode:(BorderTypes)borderMode NS_SWIFT_NAME(remap(src:dst:map1:map2:interpolation:borderMode:));

/**
 * Applies a generic geometrical transformation to an image.
 *
 * The function remap transforms the source image using the specified map:
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} (map_x(x,y),map_y(x,y))$$`
 *
 * with the WARP_RELATIVE_MAP flag :
 *
 * `$$\texttt{dst} (x,y) =  \texttt{src} (x+map_x(x,y),y+map_y(x,y))$$`
 *
 * where values of pixels with non-integer coordinates are computed using one of available
 * interpolation methods. `$$map_x$$` and `$$map_y$$` can be encoded as separate floating-point maps
 * in `$$map_1$$` and `$$map_2$$` respectively, or interleaved floating-point maps of `$$(x,y)$$` in
 * `$$map_1$$`, or fixed-point maps created by using ``Imgproc/convertMaps``. Fixed-point maps
 * use a more compact representation, which can reduce memory bandwidth and benefit
 * repeated remap calls that reuse the same map. Performance gains vary by hardware
 * and are typically modest; measure before converting. In the converted case,
 * `$$map_1$$` contains pairs (cvFloor(x),
 * cvFloor(y)) and `$$map_2$$` contains indices in a table of interpolation coefficients.
 *
 * This function cannot operate in-place.
 *
 * @param src Source image.
 * @param dst Destination image. It has the same size as map1 and the same type as src .
 * @param map1 The first map of either (x,y) points or just x values having the type CV_16SC2 ,
 * CV_32FC1, or CV_32FC2. See ``Imgproc/convertMaps`` for details on converting a floating point
 * representation to fixed-point.
 * @param map2 The second map of y values having the type CV_16UC1, CV_32FC1, or none (empty map
 * if map1 is (x,y) points), respectively.
 * @param interpolation Interpolation method (see ``InterpolationFlags``). The methods ``InterpolationFlags/INTER_AREA``
 * ``InterpolationFlags/INTER_LINEAR_EXACT`` and ``InterpolationFlags/INTER_NEAREST_EXACT`` are not supported by this function.
 * The extra flag WARP_RELATIVE_MAP can be ORed to the interpolation method
 * (e.g. INTER_LINEAR | WARP_RELATIVE_MAP)
 * borderMode=#BORDER_TRANSPARENT, it means that the pixels in the destination image that
 * corresponds to the "outliers" in the source image are not modified by the function.
 * for linear calculation for faster speed. See ``AlgorithmHint``.
 * Note:*
 * Due to current implementation limitations the size of an input and output images should be less than 32767x32767.
 */
+ (void)remap:(Mat*)src dst:(Mat*)dst map1:(Mat*)map1 map2:(Mat*)map2 interpolation:(int)interpolation NS_SWIFT_NAME(remap(src:dst:map1:map2:interpolation:));


//
//  void cv::convertMaps(Mat map1, Mat map2, Mat& dstmap1, Mat& dstmap2, int dstmap1type, bool nninterpolation = false)
//
/**
 * Converts image transformation maps from one representation to another.
 *
 * The function converts a pair of maps for remap from one representation to another. The following
 * options ( (map1.type(), map2.type()) `$$\rightarrow$$` (dstmap1.type(), dstmap2.type()) ) are
 * supported:
 *
 * - `$$\texttt{(CV\_32FC1, CV\_32FC1)} \rightarrow \texttt{(CV\_16SC2, CV\_16UC1)}$$`. This is the
 * most frequently used conversion operation, in which the original floating-point maps (see ``Imgproc/remap``)
 * are converted to a more compact and much faster fixed-point representation. The first output array
 * contains the rounded coordinates and the second array (created only when nninterpolation=false )
 * contains indices in the interpolation tables.
 *
 * - `$$\texttt{(CV\_32FC2)} \rightarrow \texttt{(CV\_16SC2, CV\_16UC1)}$$`. The same as above but
 * the original maps are stored in one 2-channel matrix.
 *
 * - Reverse conversion. Obviously, the reconstructed floating-point maps will not be exactly the same
 * as the originals.
 *
 * @param map1 The first input map of type CV_16SC2, CV_32FC1, or CV_32FC2 .
 * @param map2 The second input map of type CV_16UC1, CV_32FC1, or none (empty matrix),
 * respectively.
 * @param dstmap1 The first output map that has the type dstmap1type and the same size as src .
 * @param dstmap2 The second output map.
 * @param dstmap1type Type of the first output map that should be CV_16SC2, CV_32FC1, or
 * CV_32FC2 .
 * @param nninterpolation Flag indicating whether the fixed-point maps are used for the
 * nearest-neighbor or for a more complex interpolation.
 *
 * - SeeAlso ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``undistort:dst:cameraMatrix:distCoeffs:newCameraMatrix:``, ``initUndistortRectifyMap:distCoeffs:R:newCameraMatrix:size:m1type:map1:map2:``
 */
+ (void)convertMaps:(Mat*)map1 map2:(Mat*)map2 dstmap1:(Mat*)dstmap1 dstmap2:(Mat*)dstmap2 dstmap1type:(int)dstmap1type nninterpolation:(BOOL)nninterpolation NS_SWIFT_NAME(convertMaps(map1:map2:dstmap1:dstmap2:dstmap1type:nninterpolation:));

/**
 * Converts image transformation maps from one representation to another.
 *
 * The function converts a pair of maps for remap from one representation to another. The following
 * options ( (map1.type(), map2.type()) `$$\rightarrow$$` (dstmap1.type(), dstmap2.type()) ) are
 * supported:
 *
 * - `$$\texttt{(CV\_32FC1, CV\_32FC1)} \rightarrow \texttt{(CV\_16SC2, CV\_16UC1)}$$`. This is the
 * most frequently used conversion operation, in which the original floating-point maps (see ``Imgproc/remap``)
 * are converted to a more compact and much faster fixed-point representation. The first output array
 * contains the rounded coordinates and the second array (created only when nninterpolation=false )
 * contains indices in the interpolation tables.
 *
 * - `$$\texttt{(CV\_32FC2)} \rightarrow \texttt{(CV\_16SC2, CV\_16UC1)}$$`. The same as above but
 * the original maps are stored in one 2-channel matrix.
 *
 * - Reverse conversion. Obviously, the reconstructed floating-point maps will not be exactly the same
 * as the originals.
 *
 * @param map1 The first input map of type CV_16SC2, CV_32FC1, or CV_32FC2 .
 * @param map2 The second input map of type CV_16UC1, CV_32FC1, or none (empty matrix),
 * respectively.
 * @param dstmap1 The first output map that has the type dstmap1type and the same size as src .
 * @param dstmap2 The second output map.
 * @param dstmap1type Type of the first output map that should be CV_16SC2, CV_32FC1, or
 * CV_32FC2 .
 * nearest-neighbor or for a more complex interpolation.
 *
 * - SeeAlso ``remap:dst:map1:map2:interpolation:borderMode:borderValue:hint:``, ``undistort:dst:cameraMatrix:distCoeffs:newCameraMatrix:``, ``initUndistortRectifyMap:distCoeffs:R:newCameraMatrix:size:m1type:map1:map2:``
 */
+ (void)convertMaps:(Mat*)map1 map2:(Mat*)map2 dstmap1:(Mat*)dstmap1 dstmap2:(Mat*)dstmap2 dstmap1type:(int)dstmap1type NS_SWIFT_NAME(convertMaps(map1:map2:dstmap1:dstmap2:dstmap1type:));


//
//  void cv::undistort(Mat src, Mat& dst, Mat cameraMatrix, Mat distCoeffs, Mat newCameraMatrix = Mat())
//
/**
 * Transforms an image to compensate for lens distortion.
 *
 * The function transforms an image to compensate radial and tangential lens distortion.
 *
 * The function is simply a combination of ``Imgproc/initUndistortRectifyMap`` (with unity R ) and ``Imgproc/remap``
 * (with bilinear interpolation). See the former function for details of the transformation being
 * performed.
 *
 * Those pixels in the destination image, for which there is no correspondent pixels in the source
 * image, are filled with zeros (black color).
 *
 * A particular subset of the source image that will be visible in the corrected image can be regulated
 * by newCameraMatrix. You can use #getOptimalNewCameraMatrix to compute the appropriate
 * newCameraMatrix depending on your requirements.
 *
 * The camera matrix and the distortion parameters can be determined using #calibrateCamera. If
 * the resolution of images is different from the resolution used at the calibration stage, `$$f_x,
 * f_y, c_x$$` and `$$c_y$$` need to be scaled accordingly, while the distortion coefficients remain
 * the same.
 *
 * @param src Input (distorted) image.
 * @param dst Output (corrected) image that has the same size and type as src .
 * @param cameraMatrix Input camera matrix `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } A = \vecthreethree{f_x}{0}{c_x}{0}{f_y}{c_y}{0}{0}{1}$$` .
 * @param distCoeffs Input vector of distortion coefficients
 * `$$(k_1, k_2, p_1, p_2[, k_3[, k_4, k_5, k_6[, s_1, s_2, s_3, s_4[, \tau_x, \tau_y]]]])$$`
 * of 4, 5, 8, 12 or 14 elements. If the vector is NULL/empty, the zero distortion coefficients are assumed.
 * @param newCameraMatrix Camera matrix of the distorted image. By default, it is the same as
 * cameraMatrix but you may additionally scale and shift the result by using a different matrix.
 */
+ (void)undistort:(Mat*)src dst:(Mat*)dst cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs newCameraMatrix:(Mat*)newCameraMatrix NS_SWIFT_NAME(undistort(src:dst:cameraMatrix:distCoeffs:newCameraMatrix:));

/**
 * Transforms an image to compensate for lens distortion.
 *
 * The function transforms an image to compensate radial and tangential lens distortion.
 *
 * The function is simply a combination of ``Imgproc/initUndistortRectifyMap`` (with unity R ) and ``Imgproc/remap``
 * (with bilinear interpolation). See the former function for details of the transformation being
 * performed.
 *
 * Those pixels in the destination image, for which there is no correspondent pixels in the source
 * image, are filled with zeros (black color).
 *
 * A particular subset of the source image that will be visible in the corrected image can be regulated
 * by newCameraMatrix. You can use #getOptimalNewCameraMatrix to compute the appropriate
 * newCameraMatrix depending on your requirements.
 *
 * The camera matrix and the distortion parameters can be determined using #calibrateCamera. If
 * the resolution of images is different from the resolution used at the calibration stage, `$$f_x,
 * f_y, c_x$$` and `$$c_y$$` need to be scaled accordingly, while the distortion coefficients remain
 * the same.
 *
 * @param src Input (distorted) image.
 * @param dst Output (corrected) image that has the same size and type as src .
 * @param cameraMatrix Input camera matrix `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } A = \vecthreethree{f_x}{0}{c_x}{0}{f_y}{c_y}{0}{0}{1}$$` .
 * @param distCoeffs Input vector of distortion coefficients
 * `$$(k_1, k_2, p_1, p_2[, k_3[, k_4, k_5, k_6[, s_1, s_2, s_3, s_4[, \tau_x, \tau_y]]]])$$`
 * of 4, 5, 8, 12 or 14 elements. If the vector is NULL/empty, the zero distortion coefficients are assumed.
 * cameraMatrix but you may additionally scale and shift the result by using a different matrix.
 */
+ (void)undistort:(Mat*)src dst:(Mat*)dst cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs NS_SWIFT_NAME(undistort(src:dst:cameraMatrix:distCoeffs:));


//
//  void cv::initUndistortRectifyMap(Mat cameraMatrix, Mat distCoeffs, Mat R, Mat newCameraMatrix, Size size, int m1type, Mat& map1, Mat& map2)
//
/**
 * Computes the undistortion and rectification transformation map.
 *
 * The function computes the joint undistortion and rectification transformation and represents the
 * result in the form of maps for ``Imgproc/remap``. The undistorted image looks like original, as if it is
 * captured with a camera using the camera matrix =newCameraMatrix and zero distortion. In case of a
 * monocular camera, newCameraMatrix is usually equal to cameraMatrix, or it can be computed by
 * #getOptimalNewCameraMatrix for a better control over scaling. In case of a stereo camera,
 * newCameraMatrix is normally set to P1 or P2 computed by #stereoRectify .
 *
 * Also, this new camera is oriented differently in the coordinate space, according to R. That, for
 * example, helps to align two heads of a stereo camera so that the epipolar lines on both images
 * become horizontal and have the same y- coordinate (in case of a horizontally aligned stereo camera).
 *
 * The function actually builds the maps for the inverse mapping algorithm that is used by ``Imgproc/remap``. That
 * is, for each pixel `$$(u, v)$$` in the destination (corrected and rectified) image, the function
 * computes the corresponding coordinates in the source image (that is, in the original image from
 * camera). The following process is applied:
 * `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } 
 * \begin{array}{l}
 * x  \leftarrow (u - {c'}_x)/{f'}_x  \\
 * y  \leftarrow (v - {c'}_y)/{f'}_y  \\
 * {[X\,Y\,W]} ^T  \leftarrow R^{-1}*[x \, y \, 1]^T  \\
 * x'  \leftarrow X/W  \\
 * y'  \leftarrow Y/W  \\
 * r^2  \leftarrow x'^2 + y'^2 \\
 * x''  \leftarrow x' \frac{1 + k_1 r^2 + k_2 r^4 + k_3 r^6}{1 + k_4 r^2 + k_5 r^4 + k_6 r^6}
 * + 2p_1 x' y' + p_2(r^2 + 2 x'^2)  + s_1 r^2 + s_2 r^4\\
 * y''  \leftarrow y' \frac{1 + k_1 r^2 + k_2 r^4 + k_3 r^6}{1 + k_4 r^2 + k_5 r^4 + k_6 r^6}
 * + p_1 (r^2 + 2 y'^2) + 2 p_2 x' y' + s_3 r^2 + s_4 r^4 \\
 * s\vecthree{x'''}{y'''}{1} =
 * \vecthreethree{R_{33}(\tau_x, \tau_y)}{0}{-R_{13}((\tau_x, \tau_y)}
 * {0}{R_{33}(\tau_x, \tau_y)}{-R_{23}(\tau_x, \tau_y)}
 * {0}{0}{1} R(\tau_x, \tau_y) \vecthree{x''}{y''}{1}\\
 * map_x(u,v)  \leftarrow x''' f_x + c_x  \\
 * map_y(u,v)  \leftarrow y''' f_y + c_y
 * \end{array}
 * $$`
 * where `$$(k_1, k_2, p_1, p_2[, k_3[, k_4, k_5, k_6[, s_1, s_2, s_3, s_4[, \tau_x, \tau_y]]]])$$`
 * are the distortion coefficients.
 *
 * In case of a stereo camera, this function is called twice: once for each camera head, after
 * #stereoRectify, which in its turn is called after #stereoCalibrate. But if the stereo camera
 * was not calibrated, it is still possible to compute the rectification transformations directly from
 * the fundamental matrix using #stereoRectifyUncalibrated. For each camera, the function computes
 * homography H as the rectification transformation in a pixel domain, not a rotation matrix R in 3D
 * space. R can be computed from H as
 * `$$\texttt{R} = \texttt{cameraMatrix} ^{-1} \cdot \texttt{H} \cdot \texttt{cameraMatrix}$$`
 * where cameraMatrix can be chosen arbitrarily.
 *
 * @param cameraMatrix Input camera matrix `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } A=\vecthreethree{f_x}{0}{c_x}{0}{f_y}{c_y}{0}{0}{1}$$` .
 * @param distCoeffs Input vector of distortion coefficients
 * `$$(k_1, k_2, p_1, p_2[, k_3[, k_4, k_5, k_6[, s_1, s_2, s_3, s_4[, \tau_x, \tau_y]]]])$$`
 * of 4, 5, 8, 12 or 14 elements. If the vector is NULL/empty, the zero distortion coefficients are assumed.
 * @param R Optional rectification transformation in the object space (3x3 matrix). R1 or R2 ,
 * computed by #stereoRectify can be passed here. If the matrix is empty, the identity transformation
 * is assumed. In *initUndistortRectifyMap* R assumed to be an identity matrix.
 * @param newCameraMatrix New camera matrix `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } A'=\vecthreethree{f_x'}{0}{c_x'}{0}{f_y'}{c_y'}{0}{0}{1}$$`.
 * @param size Undistorted image size.
 * @param m1type Type of the first output map that can be CV_32FC1, CV_32FC2 or CV_16SC2, see ``Imgproc/convertMaps``
 * @param map1 The first output map.
 * @param map2 The second output map.
 */
+ (void)initUndistortRectifyMap:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs R:(Mat*)R newCameraMatrix:(Mat*)newCameraMatrix size:(Size2i*)size m1type:(int)m1type map1:(Mat*)map1 map2:(Mat*)map2 NS_SWIFT_NAME(initUndistortRectifyMap(cameraMatrix:distCoeffs:R:newCameraMatrix:size:m1type:map1:map2:));


//
//  void cv::initInverseRectificationMap(Mat cameraMatrix, Mat distCoeffs, Mat R, Mat newCameraMatrix, Size size, int m1type, Mat& map1, Mat& map2)
//
/**
 * Computes the projection and inverse-rectification transformation map. In essense, this is the inverse of
 * ``Imgproc/initUndistortRectifyMap`` to accomodate stereo-rectification of projectors ('inverse-cameras') in projector-camera pairs.
 *
 * The function computes the joint projection and inverse rectification transformation and represents the
 * result in the form of maps for ``Imgproc/remap``. The projected image looks like a distorted version of the original which,
 * once projected by a projector, should visually match the original. In case of a monocular camera, newCameraMatrix
 * is usually equal to cameraMatrix, or it can be computed by
 * #getOptimalNewCameraMatrix for a better control over scaling. In case of a projector-camera pair,
 * newCameraMatrix is normally set to P1 or P2 computed by #stereoRectify .
 *
 * The projector is oriented differently in the coordinate space, according to R. In case of projector-camera pairs,
 * this helps align the projector (in the same manner as ``Imgproc/initUndistortRectifyMap`` for the camera) to create a stereo-rectified pair. This
 * allows epipolar lines on both images to become horizontal and have the same y-coordinate (in case of a horizontally aligned projector-camera pair).
 *
 * The function builds the maps for the inverse mapping algorithm that is used by ``Imgproc/remap``. That
 * is, for each pixel `$$(u, v)$$` in the destination (projected and inverse-rectified) image, the function
 * computes the corresponding coordinates in the source image (that is, in the original digital image). The following process is applied:
 *
 * `$$
 * \begin{array}{l}
 * \text{newCameraMatrix}\\
 * x  \leftarrow (u - {c'}_x)/{f'}_x  \\
 * y  \leftarrow (v - {c'}_y)/{f'}_y  \\
 * \\\text{Undistortion}
 * \\\scriptsize{\textit{though equation shown is for radial undistortion, function implements cv::undistortPoints()}}\\
 * r^2  \leftarrow x^2 + y^2 \\
 * \theta \leftarrow \frac{1 + k_1 r^2 + k_2 r^4 + k_3 r^6}{1 + k_4 r^2 + k_5 r^4 + k_6 r^6}\\
 * x' \leftarrow \frac{x}{\theta} \\
 * y'  \leftarrow \frac{y}{\theta} \\
 * \\\text{Rectification}\\
 * {[X\,Y\,W]} ^T  \leftarrow R*[x' \, y' \, 1]^T  \\
 * x''  \leftarrow X/W  \\
 * y''  \leftarrow Y/W  \\
 * \\\text{cameraMatrix}\\
 * map_x(u,v)  \leftarrow x'' f_x + c_x  \\
 * map_y(u,v)  \leftarrow y'' f_y + c_y
 * \end{array}
 * $$`
 * where `$$(k_1, k_2, p_1, p_2[, k_3[, k_4, k_5, k_6[, s_1, s_2, s_3, s_4[, \tau_x, \tau_y]]]])$$`
 * are the distortion coefficients vector distCoeffs.
 *
 * In case of a stereo-rectified projector-camera pair, this function is called for the projector while ``Imgproc/initUndistortRectifyMap`` is called for the camera head.
 * This is done after #stereoRectify, which in turn is called after #stereoCalibrate. If the projector-camera pair
 * is not calibrated, it is still possible to compute the rectification transformations directly from
 * the fundamental matrix using #stereoRectifyUncalibrated. For the projector and camera, the function computes
 * homography H as the rectification transformation in a pixel domain, not a rotation matrix R in 3D
 * space. R can be computed from H as
 * `$$\texttt{R} = \texttt{cameraMatrix} ^{-1} \cdot \texttt{H} \cdot \texttt{cameraMatrix}$$`
 * where cameraMatrix can be chosen arbitrarily.
 *
 * @param cameraMatrix Input camera matrix `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } A=\vecthreethree{f_x}{0}{c_x}{0}{f_y}{c_y}{0}{0}{1}$$` .
 * @param distCoeffs Input vector of distortion coefficients
 * `$$(k_1, k_2, p_1, p_2[, k_3[, k_4, k_5, k_6[, s_1, s_2, s_3, s_4[, \tau_x, \tau_y]]]])$$`
 * of 4, 5, 8, 12 or 14 elements. If the vector is NULL/empty, the zero distortion coefficients are assumed.
 * @param R Optional rectification transformation in the object space (3x3 matrix). R1 or R2,
 * computed by #stereoRectify can be passed here. If the matrix is empty, the identity transformation
 * is assumed.
 * @param newCameraMatrix New camera matrix `$$\newcommand{\vecthreethree}[9]{ \begin{bmatrix} #1 & #2 & #3\\\\ #4 & #5 & #6\\\\ #7 & #8 & #9 \end{bmatrix} } A'=\vecthreethree{f_x'}{0}{c_x'}{0}{f_y'}{c_y'}{0}{0}{1}$$`.
 * @param size Distorted image size.
 * @param m1type Type of the first output map. Can be CV_32FC1, CV_32FC2 or CV_16SC2, see ``Imgproc/convertMaps``
 * @param map1 The first output map for ``Imgproc/remap``.
 * @param map2 The second output map for ``Imgproc/remap``.
 */
+ (void)initInverseRectificationMap:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs R:(Mat*)R newCameraMatrix:(Mat*)newCameraMatrix size:(Size2i*)size m1type:(int)m1type map1:(Mat*)map1 map2:(Mat*)map2 NS_SWIFT_NAME(initInverseRectificationMap(cameraMatrix:distCoeffs:R:newCameraMatrix:size:m1type:map1:map2:));


//
//  void cv::fisheye::initUndistortRectifyMap(Mat K, Mat D, Mat R, Mat P, Size size, int m1type, Mat& map1, Mat& map2)
//
/**
 * Computes undistortion and rectification maps for image transform by cv::remap(). If D is empty zero
 * distortion is used, if R or P is empty identity matrixes are used.
 *
 * @param K Camera intrinsic matrix `$$cameramatrix{K}$$`.
 * @param D Input vector of distortion coefficients `$$\distcoeffsfisheye$$`.
 * @param R Rectification transformation in the object space: 3x3 1-channel, or vector: 3x1/1x3
 * 1-channel or 1x1 3-channel
 * @param P New camera intrinsic matrix (3x3) or new projection matrix (3x4)
 * @param size Undistorted image size.
 * @param m1type Type of the first output map that can be CV_32FC1 or CV_16SC2 . See convertMaps()
 * for details.
 * @param map1 The first output map.
 * @param map2 The second output map.
 */
+ (void)fisheye_initUndistortRectifyMap:(Mat*)K D:(Mat*)D R:(Mat*)R P:(Mat*)P size:(Size2i*)size m1type:(int)m1type map1:(Mat*)map1 map2:(Mat*)map2 NS_SWIFT_NAME(fisheye_initUndistortRectifyMap(K:D:R:P:size:m1type:map1:map2:));


//
//  void cv::fisheye::undistortImage(Mat distorted, Mat& undistorted, Mat K, Mat D, Mat Knew = cv::Mat(), Size new_size = Size())
//
/**
 * Transforms an image to compensate for fisheye lens distortion.
 *
 * @param distorted image with fisheye lens distortion.
 * @param undistorted Output image with compensated fisheye lens distortion.
 * @param K Camera intrinsic matrix `$$cameramatrix{K}$$`.
 * @param D Input vector of distortion coefficients `$$\distcoeffsfisheye$$`.
 * @param Knew Camera intrinsic matrix of the distorted image. By default, it is the identity matrix but you
 * may additionally scale and shift the result by using a different matrix.
 * @param new_size the new size
 *
 * The function transforms an image to compensate radial and tangential lens distortion.
 *
 * The function is simply a combination of #cv::fisheye::initUndistortRectifyMap (with unity R ) and remap
 * (with bilinear interpolation). See the former function for details of the transformation being
 * performed.
 *
 * See below the results of undistortImage.
 *    -   a\) result of undistort of perspective camera model (all possible coefficients (k_1, k_2, k_3,
 *         k_4, k_5, k_6) of distortion were optimized under calibration)
 *     -   b\) result of #cv::fisheye::undistortImage of fisheye camera model (all possible coefficients (k_1, k_2,
 *         k_3, k_4) of fisheye distortion were optimized under calibration)
 *     -   c\) original image was captured with fisheye lens
 *
 * Pictures a) and b) almost the same. But if we consider points of image located far from the center
 * of image, we can notice that on image a) these points are distorted.
 *
 * ![image](fisheye_undistorted)
 */
+ (void)fisheye_undistortImage:(Mat*)distorted undistorted:(Mat*)undistorted K:(Mat*)K D:(Mat*)D Knew:(Mat*)Knew new_size:(Size2i*)new_size NS_SWIFT_NAME(fisheye_undistortImage(distorted:undistorted:K:D:Knew:new_size:));

/**
 * Transforms an image to compensate for fisheye lens distortion.
 *
 * @param distorted image with fisheye lens distortion.
 * @param undistorted Output image with compensated fisheye lens distortion.
 * @param K Camera intrinsic matrix `$$cameramatrix{K}$$`.
 * @param D Input vector of distortion coefficients `$$\distcoeffsfisheye$$`.
 * @param Knew Camera intrinsic matrix of the distorted image. By default, it is the identity matrix but you
 * may additionally scale and shift the result by using a different matrix.
 *
 * The function transforms an image to compensate radial and tangential lens distortion.
 *
 * The function is simply a combination of #cv::fisheye::initUndistortRectifyMap (with unity R ) and remap
 * (with bilinear interpolation). See the former function for details of the transformation being
 * performed.
 *
 * See below the results of undistortImage.
 *    -   a\) result of undistort of perspective camera model (all possible coefficients (k_1, k_2, k_3,
 *         k_4, k_5, k_6) of distortion were optimized under calibration)
 *     -   b\) result of #cv::fisheye::undistortImage of fisheye camera model (all possible coefficients (k_1, k_2,
 *         k_3, k_4) of fisheye distortion were optimized under calibration)
 *     -   c\) original image was captured with fisheye lens
 *
 * Pictures a) and b) almost the same. But if we consider points of image located far from the center
 * of image, we can notice that on image a) these points are distorted.
 *
 * ![image](fisheye_undistorted)
 */
+ (void)fisheye_undistortImage:(Mat*)distorted undistorted:(Mat*)undistorted K:(Mat*)K D:(Mat*)D Knew:(Mat*)Knew NS_SWIFT_NAME(fisheye_undistortImage(distorted:undistorted:K:D:Knew:));

/**
 * Transforms an image to compensate for fisheye lens distortion.
 *
 * @param distorted image with fisheye lens distortion.
 * @param undistorted Output image with compensated fisheye lens distortion.
 * @param K Camera intrinsic matrix `$$cameramatrix{K}$$`.
 * @param D Input vector of distortion coefficients `$$\distcoeffsfisheye$$`.
 * may additionally scale and shift the result by using a different matrix.
 *
 * The function transforms an image to compensate radial and tangential lens distortion.
 *
 * The function is simply a combination of #cv::fisheye::initUndistortRectifyMap (with unity R ) and remap
 * (with bilinear interpolation). See the former function for details of the transformation being
 * performed.
 *
 * See below the results of undistortImage.
 *    -   a\) result of undistort of perspective camera model (all possible coefficients (k_1, k_2, k_3,
 *         k_4, k_5, k_6) of distortion were optimized under calibration)
 *     -   b\) result of #cv::fisheye::undistortImage of fisheye camera model (all possible coefficients (k_1, k_2,
 *         k_3, k_4) of fisheye distortion were optimized under calibration)
 *     -   c\) original image was captured with fisheye lens
 *
 * Pictures a) and b) almost the same. But if we consider points of image located far from the center
 * of image, we can notice that on image a) these points are distorted.
 *
 * ![image](fisheye_undistorted)
 */
+ (void)fisheye_undistortImage:(Mat*)distorted undistorted:(Mat*)undistorted K:(Mat*)K D:(Mat*)D NS_SWIFT_NAME(fisheye_undistortImage(distorted:undistorted:K:D:));


//
//  void cv::getRectSubPix(Mat image, Size patchSize, Point2f center, Mat& patch, int patchType = -1)
//
/**
 * Retrieves a pixel rectangle from an image with sub-pixel accuracy.
 *
 * The function getRectSubPix extracts pixels from src:
 *
 * `$$patch(x, y) = src(x +  \texttt{center.x} - ( \texttt{dst.cols} -1)*0.5, y +  \texttt{center.y} - ( \texttt{dst.rows} -1)*0.5)$$`
 *
 * where the values of the pixels at non-integer coordinates are retrieved using bilinear
 * interpolation. Every channel of multi-channel images is processed independently. Also
 * the image should be a single channel or three channel image. While the center of the
 * rectangle must be inside the image, parts of the rectangle may be outside.
 *
 * @param image Source image.
 * @param patchSize Size of the extracted patch.
 * @param center Floating point coordinates of the center of the extracted rectangle within the
 * source image. The center must be inside the image.
 * @param patch Extracted patch that has the size patchSize and the same number of channels as src .
 * @param patchType Depth of the extracted pixels. By default, they have the same depth as src .
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``
 */
+ (void)getRectSubPix:(Mat*)image patchSize:(Size2i*)patchSize center:(Point2f*)center patch:(Mat*)patch patchType:(int)patchType NS_SWIFT_NAME(getRectSubPix(image:patchSize:center:patch:patchType:));

/**
 * Retrieves a pixel rectangle from an image with sub-pixel accuracy.
 *
 * The function getRectSubPix extracts pixels from src:
 *
 * `$$patch(x, y) = src(x +  \texttt{center.x} - ( \texttt{dst.cols} -1)*0.5, y +  \texttt{center.y} - ( \texttt{dst.rows} -1)*0.5)$$`
 *
 * where the values of the pixels at non-integer coordinates are retrieved using bilinear
 * interpolation. Every channel of multi-channel images is processed independently. Also
 * the image should be a single channel or three channel image. While the center of the
 * rectangle must be inside the image, parts of the rectangle may be outside.
 *
 * @param image Source image.
 * @param patchSize Size of the extracted patch.
 * @param center Floating point coordinates of the center of the extracted rectangle within the
 * source image. The center must be inside the image.
 * @param patch Extracted patch that has the size patchSize and the same number of channels as src .
 *
 * - SeeAlso ``warpAffine:dst:M:dsize:flags:borderMode:borderValue:hint:``, ``warpPerspective:dst:M:dsize:flags:borderMode:borderValue:hint:``
 */
+ (void)getRectSubPix:(Mat*)image patchSize:(Size2i*)patchSize center:(Point2f*)center patch:(Mat*)patch NS_SWIFT_NAME(getRectSubPix(image:patchSize:center:patch:));


//
//  void cv::warpPolar(Mat src, Mat& dst, Size dsize, Point2f center, double maxRadius, int flags)
//
/**
 * Remaps an image to polar or semilog-polar coordinates space
 *
 *  polar_remaps_reference_image
 * ![Polar remaps reference](polar_remap_doc)
 *
 * Transform the source image using the following transformation:
 * `$$
 * dst(\rho , \phi ) = src(x,y)
 * $$`
 *
 * where
 * `$$
 * \begin{array}{l}
 * \vec{I} = (x - center.x, \;y - center.y) \\
 * \phi = Kangle \cdot \texttt{angle} (\vec{I}) \\
 * \rho = \left\{\begin{matrix}
 * Klin \cdot \texttt{magnitude} (\vec{I}) & default \\
 * Klog \cdot log_e(\texttt{magnitude} (\vec{I})) & if \; semilog \\
 * \end{matrix}\right.
 * \end{array}
 * $$`
 *
 * and
 * `$$
 * \begin{array}{l}
 * Kangle = dsize.height / 2\Pi \\
 * Klin = dsize.width / maxRadius \\
 * Klog = dsize.width / log_e(maxRadius) \\
 * \end{array}
 * $$`
 *
 *
 * \par Linear vs semilog mapping
 *
 * Polar mapping can be linear or semi-log. Add one of ``WarpPolarMode`` to `flags` to specify the polar mapping mode.
 *
 * Linear is the default mode.
 *
 * The semilog mapping emulates the human "foveal" vision that permit very high acuity on the line of sight (central vision)
 * in contrast to peripheral vision where acuity is minor.
 *
 * \par Option on `dsize`:
 *
 * - if both values in `dsize <=0 ` (default),
 * the destination image will have (almost) same area of source bounding circle:
 * `$$\begin{array}{l}
 * dsize.area  \leftarrow (maxRadius^2 \cdot \Pi) \\
 * dsize.width = \texttt{cvRound}(maxRadius) \\
 * dsize.height = \texttt{cvRound}(maxRadius \cdot \Pi) \\
 * \end{array}$$`
 *
 *
 * - if only `dsize.height <= 0`,
 * the destination image area will be proportional to the bounding circle area but scaled by `Kx * Kx`:
 * `$$\begin{array}{l}
 * dsize.height = \texttt{cvRound}(dsize.width \cdot \Pi) \\
 * \end{array}
 * $$`
 *
 * - if both values in `dsize > 0 `,
 * the destination image will have the given size therefore the area of the bounding circle will be scaled to `dsize`.
 *
 *
 * \par Reverse mapping
 *
 * You can get reverse mapping adding ``InterpolationFlags/WARP_INVERSE_MAP`` to `flags`
 * \snippet polar_transforms.cpp InverseMap
 *
 * In addition, to calculate the original coordinate from a polar mapped coordinate `$$(rho, phi)->(x, y)$$`:
 * \snippet polar_transforms.cpp InverseCoordinate
 *
 * @param src Source image.
 * @param dst Destination image. It will have same type as src.
 * @param dsize The destination image size (see description for valid options).
 * @param center The transformation center.
 * @param maxRadius The radius of the bounding circle to transform. It determines the inverse magnitude scale parameter too.
 * @param flags A combination of interpolation methods, ``InterpolationFlags`` + ``WarpPolarMode``.
 *             - Add ``WarpPolarMode/WARP_POLAR_LINEAR`` to select linear polar mapping (default)
 *             - Add ``WarpPolarMode/WARP_POLAR_LOG`` to select semilog polar mapping
 *             - Add ``InterpolationFlags/WARP_INVERSE_MAP`` for reverse mapping.
 * Note:*
 * -  The function can not operate in-place.
 * -  To calculate magnitude and angle in degrees ``Core/cartToPolar`` is used internally thus angles are measured from 0 to 360 with accuracy about 0.3 degrees.
 * -  This function uses ``Imgproc/remap``. Due to current implementation limitations the size of an input and output images should be less than 32767x32767.
 *
 * - SeeAlso cv::remap
 */
+ (void)warpPolar:(Mat*)src dst:(Mat*)dst dsize:(Size2i*)dsize center:(Point2f*)center maxRadius:(double)maxRadius flags:(int)flags NS_SWIFT_NAME(warpPolar(src:dst:dsize:center:maxRadius:flags:));


//
//  void cv::integral(Mat src, Mat& sum, Mat& sqsum, Mat& tilted, int sdepth = -1, int sqdepth = -1)
//
/**
 * Calculates the integral of an image.
 *
 * The function calculates one or more integral images for the source image as follows:
 *
 * `$$\texttt{sum} (X,Y) =  \sum _{x<X,y<Y}  \texttt{image} (x,y)$$`
 *
 * `$$\texttt{sqsum} (X,Y) =  \sum _{x<X,y<Y}  \texttt{image} (x,y)^2$$`
 *
 * `$$\texttt{tilted} (X,Y) =  \sum _{y<Y,abs(x-X+1) \leq Y-y-1}  \texttt{image} (x,y)$$`
 *
 * Using these integral images, you can calculate sum, mean, and standard deviation over a specific
 * up-right or rotated rectangular region of the image in a constant time, for example:
 *
 * `$$\sum _{x_1 \leq x < x_2,  \, y_1  \leq y < y_2}  \texttt{image} (x,y) =  \texttt{sum} (x_2,y_2)- \texttt{sum} (x_1,y_2)- \texttt{sum} (x_2,y_1)+ \texttt{sum} (x_1,y_1)$$`
 *
 * It makes possible to do a fast blurring or fast block correlation with a variable window size, for
 * example. In case of multi-channel images, sums for each channel are accumulated independently.
 *
 * As a practical example, the next figure shows the calculation of the integral of a straight
 * rectangle Rect(4,4,3,2) and of a tilted rectangle Rect(5,1,2,3) . The selected pixels in the
 * original image are shown, as well as the relative pixels in the integral images sum and tilted .
 *
 * ![integral calculation example](integral)
 *
 * @param src input image as `$$W \times H$$`, 8-bit or floating-point (32f or 64f).
 * @param sum integral image as `$$(W+1)\times (H+1)$$` , 32-bit integer or floating-point (32f or 64f).
 * @param sqsum integral image for squared pixel values; it is `$$(W+1)\times (H+1)$$`, double-precision
 * floating-point (64f) array.
 * @param tilted integral for the image rotated by 45 degrees; it is `$$(W+1)\times (H+1)$$` array with
 * the same data type as sum.
 * @param sdepth desired depth of the integral and the tilted integral images, CV_32S, CV_32F, or
 * CV_64F.
 * @param sqdepth desired depth of the integral image of squared pixel values, CV_32F or CV_64F.
 */
+ (void)integral3:(Mat*)src sum:(Mat*)sum sqsum:(Mat*)sqsum tilted:(Mat*)tilted sdepth:(int)sdepth sqdepth:(int)sqdepth NS_SWIFT_NAME(integral(src:sum:sqsum:tilted:sdepth:sqdepth:));

/**
 * Calculates the integral of an image.
 *
 * The function calculates one or more integral images for the source image as follows:
 *
 * `$$\texttt{sum} (X,Y) =  \sum _{x<X,y<Y}  \texttt{image} (x,y)$$`
 *
 * `$$\texttt{sqsum} (X,Y) =  \sum _{x<X,y<Y}  \texttt{image} (x,y)^2$$`
 *
 * `$$\texttt{tilted} (X,Y) =  \sum _{y<Y,abs(x-X+1) \leq Y-y-1}  \texttt{image} (x,y)$$`
 *
 * Using these integral images, you can calculate sum, mean, and standard deviation over a specific
 * up-right or rotated rectangular region of the image in a constant time, for example:
 *
 * `$$\sum _{x_1 \leq x < x_2,  \, y_1  \leq y < y_2}  \texttt{image} (x,y) =  \texttt{sum} (x_2,y_2)- \texttt{sum} (x_1,y_2)- \texttt{sum} (x_2,y_1)+ \texttt{sum} (x_1,y_1)$$`
 *
 * It makes possible to do a fast blurring or fast block correlation with a variable window size, for
 * example. In case of multi-channel images, sums for each channel are accumulated independently.
 *
 * As a practical example, the next figure shows the calculation of the integral of a straight
 * rectangle Rect(4,4,3,2) and of a tilted rectangle Rect(5,1,2,3) . The selected pixels in the
 * original image are shown, as well as the relative pixels in the integral images sum and tilted .
 *
 * ![integral calculation example](integral)
 *
 * @param src input image as `$$W \times H$$`, 8-bit or floating-point (32f or 64f).
 * @param sum integral image as `$$(W+1)\times (H+1)$$` , 32-bit integer or floating-point (32f or 64f).
 * @param sqsum integral image for squared pixel values; it is `$$(W+1)\times (H+1)$$`, double-precision
 * floating-point (64f) array.
 * @param tilted integral for the image rotated by 45 degrees; it is `$$(W+1)\times (H+1)$$` array with
 * the same data type as sum.
 * @param sdepth desired depth of the integral and the tilted integral images, CV_32S, CV_32F, or
 * CV_64F.
 */
+ (void)integral3:(Mat*)src sum:(Mat*)sum sqsum:(Mat*)sqsum tilted:(Mat*)tilted sdepth:(int)sdepth NS_SWIFT_NAME(integral(src:sum:sqsum:tilted:sdepth:));

/**
 * Calculates the integral of an image.
 *
 * The function calculates one or more integral images for the source image as follows:
 *
 * `$$\texttt{sum} (X,Y) =  \sum _{x<X,y<Y}  \texttt{image} (x,y)$$`
 *
 * `$$\texttt{sqsum} (X,Y) =  \sum _{x<X,y<Y}  \texttt{image} (x,y)^2$$`
 *
 * `$$\texttt{tilted} (X,Y) =  \sum _{y<Y,abs(x-X+1) \leq Y-y-1}  \texttt{image} (x,y)$$`
 *
 * Using these integral images, you can calculate sum, mean, and standard deviation over a specific
 * up-right or rotated rectangular region of the image in a constant time, for example:
 *
 * `$$\sum _{x_1 \leq x < x_2,  \, y_1  \leq y < y_2}  \texttt{image} (x,y) =  \texttt{sum} (x_2,y_2)- \texttt{sum} (x_1,y_2)- \texttt{sum} (x_2,y_1)+ \texttt{sum} (x_1,y_1)$$`
 *
 * It makes possible to do a fast blurring or fast block correlation with a variable window size, for
 * example. In case of multi-channel images, sums for each channel are accumulated independently.
 *
 * As a practical example, the next figure shows the calculation of the integral of a straight
 * rectangle Rect(4,4,3,2) and of a tilted rectangle Rect(5,1,2,3) . The selected pixels in the
 * original image are shown, as well as the relative pixels in the integral images sum and tilted .
 *
 * ![integral calculation example](integral)
 *
 * @param src input image as `$$W \times H$$`, 8-bit or floating-point (32f or 64f).
 * @param sum integral image as `$$(W+1)\times (H+1)$$` , 32-bit integer or floating-point (32f or 64f).
 * @param sqsum integral image for squared pixel values; it is `$$(W+1)\times (H+1)$$`, double-precision
 * floating-point (64f) array.
 * @param tilted integral for the image rotated by 45 degrees; it is `$$(W+1)\times (H+1)$$` array with
 * the same data type as sum.
 * CV_64F.
 */
+ (void)integral3:(Mat*)src sum:(Mat*)sum sqsum:(Mat*)sqsum tilted:(Mat*)tilted NS_SWIFT_NAME(integral(src:sum:sqsum:tilted:));


//
//  void cv::integral(Mat src, Mat& sum, int sdepth = -1)
//
+ (void)integral:(Mat*)src sum:(Mat*)sum sdepth:(int)sdepth NS_SWIFT_NAME(integral(src:sum:sdepth:));

+ (void)integral:(Mat*)src sum:(Mat*)sum NS_SWIFT_NAME(integral(src:sum:));


//
//  void cv::integral(Mat src, Mat& sum, Mat& sqsum, int sdepth = -1, int sqdepth = -1)
//
+ (void)integral2:(Mat*)src sum:(Mat*)sum sqsum:(Mat*)sqsum sdepth:(int)sdepth sqdepth:(int)sqdepth NS_SWIFT_NAME(integral(src:sum:sqsum:sdepth:sqdepth:));

+ (void)integral2:(Mat*)src sum:(Mat*)sum sqsum:(Mat*)sqsum sdepth:(int)sdepth NS_SWIFT_NAME(integral(src:sum:sqsum:sdepth:));

+ (void)integral2:(Mat*)src sum:(Mat*)sum sqsum:(Mat*)sqsum NS_SWIFT_NAME(integral(src:sum:sqsum:));


//
//  void cv::accumulate(Mat src, Mat& dst, Mat mask = Mat())
//
/**
 * Adds an image to the accumulator image.
 *
 * The function adds src or some of its elements to dst :
 *
 * `$$\texttt{dst} (x,y)  \leftarrow \texttt{dst} (x,y) +  \texttt{src} (x,y)  \quad \text{if} \quad \texttt{mask} (x,y)  \ne 0$$`
 *
 * The function supports multi-channel images. Each channel is processed independently.
 *
 * The function cv::accumulate can be used, for example, to collect statistics of a scene background
 * viewed by a still camera and for the further foreground-background segmentation.
 *
 * @param src Input image of type CV_8UC(n), CV_16UC(n), CV_32FC(n) or CV_64FC(n), where n is a positive integer.
 * @param dst %Accumulator image with the same number of channels as input image, and a depth of CV_32F or CV_64F.
 * @param mask Optional operation mask.
 *
 * - SeeAlso ``accumulateSquare:dst:mask:``, ``accumulateProduct:src2:dst:mask:``, ``accumulateWeighted:dst:alpha:mask:``
 */
+ (void)accumulate:(Mat*)src dst:(Mat*)dst mask:(Mat*)mask NS_SWIFT_NAME(accumulate(src:dst:mask:));

/**
 * Adds an image to the accumulator image.
 *
 * The function adds src or some of its elements to dst :
 *
 * `$$\texttt{dst} (x,y)  \leftarrow \texttt{dst} (x,y) +  \texttt{src} (x,y)  \quad \text{if} \quad \texttt{mask} (x,y)  \ne 0$$`
 *
 * The function supports multi-channel images. Each channel is processed independently.
 *
 * The function cv::accumulate can be used, for example, to collect statistics of a scene background
 * viewed by a still camera and for the further foreground-background segmentation.
 *
 * @param src Input image of type CV_8UC(n), CV_16UC(n), CV_32FC(n) or CV_64FC(n), where n is a positive integer.
 * @param dst %Accumulator image with the same number of channels as input image, and a depth of CV_32F or CV_64F.
 *
 * - SeeAlso ``accumulateSquare:dst:mask:``, ``accumulateProduct:src2:dst:mask:``, ``accumulateWeighted:dst:alpha:mask:``
 */
+ (void)accumulate:(Mat*)src dst:(Mat*)dst NS_SWIFT_NAME(accumulate(src:dst:));


//
//  void cv::accumulateSquare(Mat src, Mat& dst, Mat mask = Mat())
//
/**
 * Adds the square of a source image to the accumulator image.
 *
 * The function adds the input image src or its selected region, raised to a power of 2, to the
 * accumulator dst :
 *
 * `$$\texttt{dst} (x,y)  \leftarrow \texttt{dst} (x,y) +  \texttt{src} (x,y)^2  \quad \text{if} \quad \texttt{mask} (x,y)  \ne 0$$`
 *
 * The function supports multi-channel images. Each channel is processed independently.
 *
 * @param src Input image as 1- or 3-channel, 8-bit or 32-bit floating point.
 * @param dst %Accumulator image with the same number of channels as input image, 32-bit or 64-bit
 * floating-point.
 * @param mask Optional operation mask.
 *
 * - SeeAlso ``accumulateSquare:dst:mask:``, ``accumulateProduct:src2:dst:mask:``, ``accumulateWeighted:dst:alpha:mask:``
 */
+ (void)accumulateSquare:(Mat*)src dst:(Mat*)dst mask:(Mat*)mask NS_SWIFT_NAME(accumulateSquare(src:dst:mask:));

/**
 * Adds the square of a source image to the accumulator image.
 *
 * The function adds the input image src or its selected region, raised to a power of 2, to the
 * accumulator dst :
 *
 * `$$\texttt{dst} (x,y)  \leftarrow \texttt{dst} (x,y) +  \texttt{src} (x,y)^2  \quad \text{if} \quad \texttt{mask} (x,y)  \ne 0$$`
 *
 * The function supports multi-channel images. Each channel is processed independently.
 *
 * @param src Input image as 1- or 3-channel, 8-bit or 32-bit floating point.
 * @param dst %Accumulator image with the same number of channels as input image, 32-bit or 64-bit
 * floating-point.
 *
 * - SeeAlso ``accumulateSquare:dst:mask:``, ``accumulateProduct:src2:dst:mask:``, ``accumulateWeighted:dst:alpha:mask:``
 */
+ (void)accumulateSquare:(Mat*)src dst:(Mat*)dst NS_SWIFT_NAME(accumulateSquare(src:dst:));


//
//  void cv::accumulateProduct(Mat src1, Mat src2, Mat& dst, Mat mask = Mat())
//
/**
 * Adds the per-element product of two input images to the accumulator image.
 *
 * The function adds the product of two images or their selected regions to the accumulator dst :
 *
 * `$$\texttt{dst} (x,y)  \leftarrow \texttt{dst} (x,y) +  \texttt{src1} (x,y)  \cdot \texttt{src2} (x,y)  \quad \text{if} \quad \texttt{mask} (x,y)  \ne 0$$`
 *
 * The function supports multi-channel images. Each channel is processed independently.
 *
 * @param src1 First input image, 1- or 3-channel, 8-bit or 32-bit floating point.
 * @param src2 Second input image of the same type and the same size as src1 .
 * @param dst %Accumulator image with the same number of channels as input images, 32-bit or 64-bit
 * floating-point.
 * @param mask Optional operation mask.
 *
 * - SeeAlso ``accumulate:dst:mask:``, ``accumulateSquare:dst:mask:``, ``accumulateWeighted:dst:alpha:mask:``
 */
+ (void)accumulateProduct:(Mat*)src1 src2:(Mat*)src2 dst:(Mat*)dst mask:(Mat*)mask NS_SWIFT_NAME(accumulateProduct(src1:src2:dst:mask:));

/**
 * Adds the per-element product of two input images to the accumulator image.
 *
 * The function adds the product of two images or their selected regions to the accumulator dst :
 *
 * `$$\texttt{dst} (x,y)  \leftarrow \texttt{dst} (x,y) +  \texttt{src1} (x,y)  \cdot \texttt{src2} (x,y)  \quad \text{if} \quad \texttt{mask} (x,y)  \ne 0$$`
 *
 * The function supports multi-channel images. Each channel is processed independently.
 *
 * @param src1 First input image, 1- or 3-channel, 8-bit or 32-bit floating point.
 * @param src2 Second input image of the same type and the same size as src1 .
 * @param dst %Accumulator image with the same number of channels as input images, 32-bit or 64-bit
 * floating-point.
 *
 * - SeeAlso ``accumulate:dst:mask:``, ``accumulateSquare:dst:mask:``, ``accumulateWeighted:dst:alpha:mask:``
 */
+ (void)accumulateProduct:(Mat*)src1 src2:(Mat*)src2 dst:(Mat*)dst NS_SWIFT_NAME(accumulateProduct(src1:src2:dst:));


//
//  void cv::accumulateWeighted(Mat src, Mat& dst, double alpha, Mat mask = Mat())
//
/**
 * Updates a running average.
 *
 * The function calculates the weighted sum of the input image src and the accumulator dst so that dst
 * becomes a running average of a frame sequence:
 *
 * `$$\texttt{dst} (x,y)  \leftarrow (1- \texttt{alpha} )  \cdot \texttt{dst} (x,y) +  \texttt{alpha} \cdot \texttt{src} (x,y)  \quad \text{if} \quad \texttt{mask} (x,y)  \ne 0$$`
 *
 * That is, alpha regulates the update speed (how fast the accumulator "forgets" about earlier images).
 * The function supports multi-channel images. Each channel is processed independently.
 *
 * @param src Input image as 1- or 3-channel, 8-bit or 32-bit floating point.
 * @param dst %Accumulator image with the same number of channels as input image, 32-bit or 64-bit
 * floating-point.
 * @param alpha Weight of the input image.
 * @param mask Optional operation mask.
 *
 * - SeeAlso ``accumulate:dst:mask:``, ``accumulateSquare:dst:mask:``, ``accumulateProduct:src2:dst:mask:``
 */
+ (void)accumulateWeighted:(Mat*)src dst:(Mat*)dst alpha:(double)alpha mask:(Mat*)mask NS_SWIFT_NAME(accumulateWeighted(src:dst:alpha:mask:));

/**
 * Updates a running average.
 *
 * The function calculates the weighted sum of the input image src and the accumulator dst so that dst
 * becomes a running average of a frame sequence:
 *
 * `$$\texttt{dst} (x,y)  \leftarrow (1- \texttt{alpha} )  \cdot \texttt{dst} (x,y) +  \texttt{alpha} \cdot \texttt{src} (x,y)  \quad \text{if} \quad \texttt{mask} (x,y)  \ne 0$$`
 *
 * That is, alpha regulates the update speed (how fast the accumulator "forgets" about earlier images).
 * The function supports multi-channel images. Each channel is processed independently.
 *
 * @param src Input image as 1- or 3-channel, 8-bit or 32-bit floating point.
 * @param dst %Accumulator image with the same number of channels as input image, 32-bit or 64-bit
 * floating-point.
 * @param alpha Weight of the input image.
 *
 * - SeeAlso ``accumulate:dst:mask:``, ``accumulateSquare:dst:mask:``, ``accumulateProduct:src2:dst:mask:``
 */
+ (void)accumulateWeighted:(Mat*)src dst:(Mat*)dst alpha:(double)alpha NS_SWIFT_NAME(accumulateWeighted(src:dst:alpha:));


//
//  Point2d cv::phaseCorrelate(Mat src1, Mat src2, Mat window = Mat(), double* response = 0)
//
/**
 * The function is used to detect translational shifts that occur between two images.
 *
 * The operation takes advantage of the Fourier shift theorem for detecting the translational shift in
 * the frequency domain. It can be used for fast image registration as well as motion estimation. For
 * more information please see <https://en.wikipedia.org/wiki/Phase_correlation>
 *
 * Calculates the cross-power spectrum of two supplied source arrays. The arrays are padded if needed
 * with getOptimalDFTSize.
 *
 * The function performs the following equations:
 * - First it applies a Hanning window to each image to remove possible edge effects, if it's provided
 * by user. See *Ref:* createHanningWindow and <https://en.wikipedia.org/wiki/Hann_function>. This window may
 * be cached until the array size changes to speed up processing time.
 * - Next it computes the forward DFTs of each source array:
 * `$$\mathbf{G}_a = \mathcal{F}\{src_1\}, \; \mathbf{G}_b = \mathcal{F}\{src_2\}$$`
 * where `$$\mathcal{F}$$` is the forward DFT.
 * - It then computes the cross-power spectrum of each frequency domain array:
 * `$$R = \frac{ \mathbf{G}_a \mathbf{G}_b^*}{|\mathbf{G}_a \mathbf{G}_b^*|}$$`
 * - Next the cross-correlation is converted back into the time domain via the inverse DFT:
 * `$$r = \mathcal{F}^{-1}\{R\}$$`
 * - Finally, it computes the peak location and computes a 5x5 weighted centroid around the peak to
 * achieve sub-pixel accuracy.
 * `$$(\Delta x, \Delta y) = \texttt{weightedCentroid} \{\arg \max_{(x, y)}\{r\}\}$$`
 * - If non-zero, the response parameter is computed as the sum of the elements of r within the 5x5
 * centroid around the peak location. It is normalized to a maximum of 1 (meaning there is a single
 * peak) and will be smaller when there are multiple peaks.
 *
 * @param src1 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param src2 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param window Floating point array with windowing coefficients to reduce edge effects (optional).
 * @param response Signal power within the 5x5 centroid around the peak, between 0 and 1 (optional).
 * @return detected phase shift (sub-pixel) between the two arrays.
 *
 * - SeeAlso dft, getOptimalDFTSize, idft, mulSpectrums createHanningWindow
 */
+ (Point2d*)phaseCorrelate:(Mat*)src1 src2:(Mat*)src2 window:(Mat*)window response:(double*)response NS_SWIFT_NAME(phaseCorrelate(src1:src2:window:response:));

/**
 * The function is used to detect translational shifts that occur between two images.
 *
 * The operation takes advantage of the Fourier shift theorem for detecting the translational shift in
 * the frequency domain. It can be used for fast image registration as well as motion estimation. For
 * more information please see <https://en.wikipedia.org/wiki/Phase_correlation>
 *
 * Calculates the cross-power spectrum of two supplied source arrays. The arrays are padded if needed
 * with getOptimalDFTSize.
 *
 * The function performs the following equations:
 * - First it applies a Hanning window to each image to remove possible edge effects, if it's provided
 * by user. See *Ref:* createHanningWindow and <https://en.wikipedia.org/wiki/Hann_function>. This window may
 * be cached until the array size changes to speed up processing time.
 * - Next it computes the forward DFTs of each source array:
 * `$$\mathbf{G}_a = \mathcal{F}\{src_1\}, \; \mathbf{G}_b = \mathcal{F}\{src_2\}$$`
 * where `$$\mathcal{F}$$` is the forward DFT.
 * - It then computes the cross-power spectrum of each frequency domain array:
 * `$$R = \frac{ \mathbf{G}_a \mathbf{G}_b^*}{|\mathbf{G}_a \mathbf{G}_b^*|}$$`
 * - Next the cross-correlation is converted back into the time domain via the inverse DFT:
 * `$$r = \mathcal{F}^{-1}\{R\}$$`
 * - Finally, it computes the peak location and computes a 5x5 weighted centroid around the peak to
 * achieve sub-pixel accuracy.
 * `$$(\Delta x, \Delta y) = \texttt{weightedCentroid} \{\arg \max_{(x, y)}\{r\}\}$$`
 * - If non-zero, the response parameter is computed as the sum of the elements of r within the 5x5
 * centroid around the peak location. It is normalized to a maximum of 1 (meaning there is a single
 * peak) and will be smaller when there are multiple peaks.
 *
 * @param src1 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param src2 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param window Floating point array with windowing coefficients to reduce edge effects (optional).
 * @return detected phase shift (sub-pixel) between the two arrays.
 *
 * - SeeAlso dft, getOptimalDFTSize, idft, mulSpectrums createHanningWindow
 */
+ (Point2d*)phaseCorrelate:(Mat*)src1 src2:(Mat*)src2 window:(Mat*)window NS_SWIFT_NAME(phaseCorrelate(src1:src2:window:));

/**
 * The function is used to detect translational shifts that occur between two images.
 *
 * The operation takes advantage of the Fourier shift theorem for detecting the translational shift in
 * the frequency domain. It can be used for fast image registration as well as motion estimation. For
 * more information please see <https://en.wikipedia.org/wiki/Phase_correlation>
 *
 * Calculates the cross-power spectrum of two supplied source arrays. The arrays are padded if needed
 * with getOptimalDFTSize.
 *
 * The function performs the following equations:
 * - First it applies a Hanning window to each image to remove possible edge effects, if it's provided
 * by user. See *Ref:* createHanningWindow and <https://en.wikipedia.org/wiki/Hann_function>. This window may
 * be cached until the array size changes to speed up processing time.
 * - Next it computes the forward DFTs of each source array:
 * `$$\mathbf{G}_a = \mathcal{F}\{src_1\}, \; \mathbf{G}_b = \mathcal{F}\{src_2\}$$`
 * where `$$\mathcal{F}$$` is the forward DFT.
 * - It then computes the cross-power spectrum of each frequency domain array:
 * `$$R = \frac{ \mathbf{G}_a \mathbf{G}_b^*}{|\mathbf{G}_a \mathbf{G}_b^*|}$$`
 * - Next the cross-correlation is converted back into the time domain via the inverse DFT:
 * `$$r = \mathcal{F}^{-1}\{R\}$$`
 * - Finally, it computes the peak location and computes a 5x5 weighted centroid around the peak to
 * achieve sub-pixel accuracy.
 * `$$(\Delta x, \Delta y) = \texttt{weightedCentroid} \{\arg \max_{(x, y)}\{r\}\}$$`
 * - If non-zero, the response parameter is computed as the sum of the elements of r within the 5x5
 * centroid around the peak location. It is normalized to a maximum of 1 (meaning there is a single
 * peak) and will be smaller when there are multiple peaks.
 *
 * @param src1 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param src2 Source floating point array (CV_32FC1 or CV_64FC1)
 * @return detected phase shift (sub-pixel) between the two arrays.
 *
 * - SeeAlso dft, getOptimalDFTSize, idft, mulSpectrums createHanningWindow
 */
+ (Point2d*)phaseCorrelate:(Mat*)src1 src2:(Mat*)src2 NS_SWIFT_NAME(phaseCorrelate(src1:src2:));


//
//  Point2d cv::phaseCorrelateIterative(Mat src1, Mat src2, int L2size = 7, int maxIters = 10)
//
/**
 * Detects translational shifts between two images.
 *
 * This function extends the standard *Ref:* phaseCorrelate method by improving sub-pixel accuracy
 * through iterative shift refinement in the phase-correlation space, as described in
 * Cite:* hrazdira2020iterative.
 *
 * @param src1 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param src2 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param L2size The size of the correlation neighborhood used by the iterative shift refinement algorithm.
 * @param maxIters The maximum number of iterations the iterative refinement algorithm will run.
 * @return detected sub-pixel shift between the two arrays.
 *
 * - SeeAlso ``phaseCorrelate:src2:window:response:``, dft, idft, ``createHanningWindow:winSize:type:``
 */
+ (Point2d*)phaseCorrelateIterative:(Mat*)src1 src2:(Mat*)src2 L2size:(int)L2size maxIters:(int)maxIters NS_SWIFT_NAME(phaseCorrelateIterative(src1:src2:L2size:maxIters:));

/**
 * Detects translational shifts between two images.
 *
 * This function extends the standard *Ref:* phaseCorrelate method by improving sub-pixel accuracy
 * through iterative shift refinement in the phase-correlation space, as described in
 * Cite:* hrazdira2020iterative.
 *
 * @param src1 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param src2 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param L2size The size of the correlation neighborhood used by the iterative shift refinement algorithm.
 * @return detected sub-pixel shift between the two arrays.
 *
 * - SeeAlso ``phaseCorrelate:src2:window:response:``, dft, idft, ``createHanningWindow:winSize:type:``
 */
+ (Point2d*)phaseCorrelateIterative:(Mat*)src1 src2:(Mat*)src2 L2size:(int)L2size NS_SWIFT_NAME(phaseCorrelateIterative(src1:src2:L2size:));

/**
 * Detects translational shifts between two images.
 *
 * This function extends the standard *Ref:* phaseCorrelate method by improving sub-pixel accuracy
 * through iterative shift refinement in the phase-correlation space, as described in
 * Cite:* hrazdira2020iterative.
 *
 * @param src1 Source floating point array (CV_32FC1 or CV_64FC1)
 * @param src2 Source floating point array (CV_32FC1 or CV_64FC1)
 * @return detected sub-pixel shift between the two arrays.
 *
 * - SeeAlso ``phaseCorrelate:src2:window:response:``, dft, idft, ``createHanningWindow:winSize:type:``
 */
+ (Point2d*)phaseCorrelateIterative:(Mat*)src1 src2:(Mat*)src2 NS_SWIFT_NAME(phaseCorrelateIterative(src1:src2:));


//
//  void cv::createHanningWindow(Mat& dst, Size winSize, int type)
//
/**
 * This function computes a Hanning window coefficients in two dimensions.
 *
 * See (https://en.wikipedia.org/wiki/Hann_function) and (https://en.wikipedia.org/wiki/Window_function)
 * for more information.
 *
 * An example is shown below:
 *
 *     // create hanning window of size 100x100 and type CV_32F
 *     Mat hann;
 *     createHanningWindow(hann, Size(100, 100), CV_32F);
 *
 * @param dst Destination array to place Hann coefficients in
 * @param winSize The window size specifications (both width and height must be > 1)
 * @param type Created array type
 */
+ (void)createHanningWindow:(Mat*)dst winSize:(Size2i*)winSize type:(int)type NS_SWIFT_NAME(createHanningWindow(dst:winSize:type:));


//
//  double cv::threshold(Mat src, Mat& dst, double thresh, double maxval, ThresholdTypes type)
//
/**
 * Applies a fixed-level threshold to each array element.
 *
 * The function applies fixed-level thresholding to a multiple-channel array. The function is typically
 * used to get a bi-level (binary) image out of a grayscale image ( ``Core/compare`` could be also used for
 * this purpose) or for removing a noise, that is, filtering out pixels with too small or too large
 * values. There are several types of thresholding supported by the function. They are determined by
 * type parameter.
 *
 * Also, the special values ``ThresholdTypes/THRESH_OTSU`` or ``ThresholdTypes/THRESH_TRIANGLE`` may be combined with one of the
 * above values. In these cases, the function determines the optimal threshold value using the Otsu's
 * or Triangle algorithm and uses it instead of the specified thresh.
 *
 * Note:* Currently, the Otsu's method is implemented only for CV_8UC1 and CV_16UC1 images,
 * and the Triangle's method is implemented only for CV_8UC1 images.
 *
 * @param src input array (multiple-channel, CV_8U, CV_16S, CV_16U, CV_32F or CV_64F).
 * @param dst output array of the same size  and type and the same number of channels as src.
 * @param thresh threshold value.
 * @param maxval maximum value to use with the ``ThresholdTypes/THRESH_BINARY`` and ``ThresholdTypes/THRESH_BINARY_INV`` thresholding
 * types.
 * @param type thresholding type (see ``ThresholdTypes``).
 * @return the computed threshold value if Otsu's or Triangle methods used.
 *
 * - SeeAlso ``thresholdWithMask:dst:mask:thresh:maxval:type:``, ``adaptiveThreshold:dst:maxValue:adaptiveMethod:thresholdType:blockSize:C:``, ``findContours:contours:hierarchy:mode:method:offset:``, compare, min, max
 */
+ (double)threshold:(Mat*)src dst:(Mat*)dst thresh:(double)thresh maxval:(double)maxval type:(ThresholdTypes)type NS_SWIFT_NAME(threshold(src:dst:thresh:maxval:type:));


//
//  double cv::thresholdWithMask(Mat src, Mat& dst, Mat mask, double thresh, double maxval, int type)
//
/**
 * Same as ``Imgproc/threshold``, but with an optional mask
 *
 * Note:* If the mask is empty, *thresholdWithMask* is equivalent to ``Imgproc/threshold``.
 * If the mask is not empty, dst *must* be of the same size and type as src, so that
 * outliers pixels are left as-is
 *
 * @param src input array (multiple-channel, 8-bit or 32-bit floating point).
 * @param dst output array of the same size  and type and the same number of channels as src.
 * @param mask optional mask (same size as src, 8-bit).
 * @param thresh threshold value.
 * @param maxval maximum value to use with the ``ThresholdTypes/THRESH_BINARY`` and ``ThresholdTypes/THRESH_BINARY_INV`` thresholding
 * types.
 * @param type thresholding type (see ``ThresholdTypes``).
 * @return the computed threshold value if Otsu's or Triangle methods used.
 *
 * - SeeAlso ``threshold:dst:thresh:maxval:type:``, ``adaptiveThreshold:dst:maxValue:adaptiveMethod:thresholdType:blockSize:C:``, ``findContours:contours:hierarchy:mode:method:offset:``, compare, min, max
 */
+ (double)thresholdWithMask:(Mat*)src dst:(Mat*)dst mask:(Mat*)mask thresh:(double)thresh maxval:(double)maxval type:(int)type NS_SWIFT_NAME(thresholdWithMask(src:dst:mask:thresh:maxval:type:));


//
//  void cv::adaptiveThreshold(Mat src, Mat& dst, double maxValue, AdaptiveThresholdTypes adaptiveMethod, ThresholdTypes thresholdType, int blockSize, double C)
//
/**
 * Applies an adaptive threshold to an array.
 *
 * The function transforms a grayscale image to a binary image according to the formulae:
 * -   **THRESH_BINARY**
 *     `$$\newcommand{\fork}[4]{ \left\{ \begin{array}{l l} #1 & \text{#2}\\\\ #3 & \text{#4}\\\\ \end{array} \right.} dst(x,y) =  \fork{\texttt{maxValue}}{if \(src(x,y) > T(x,y)\)}{0}{otherwise}$$`
 * -   **THRESH_BINARY_INV**
 *     `$$\newcommand{\fork}[4]{ \left\{ \begin{array}{l l} #1 & \text{#2}\\\\ #3 & \text{#4}\\\\ \end{array} \right.} dst(x,y) =  \fork{0}{if \(src(x,y) > T(x,y)\)}{\texttt{maxValue}}{otherwise}$$`
 * where `$$T(x,y)$$` is a threshold calculated individually for each pixel (see adaptiveMethod parameter).
 *
 * The function can process the image in-place.
 *
 * @param src Source 8-bit single-channel image.
 * @param dst Destination image of the same size and the same type as src.
 * @param maxValue Non-zero value assigned to the pixels for which the condition is satisfied
 * @param adaptiveMethod Adaptive thresholding algorithm to use, see ``AdaptiveThresholdTypes``.
 * The ``BorderTypes/BORDER_REPLICATE`` | ``BorderTypes/BORDER_ISOLATED`` is used to process boundaries.
 * @param thresholdType Thresholding type that must be either ``ThresholdTypes/THRESH_BINARY`` or ``ThresholdTypes/THRESH_BINARY_INV``,
 * see ``ThresholdTypes``.
 * @param blockSize Size of a pixel neighborhood that is used to calculate a threshold value for the
 * pixel: 3, 5, 7, and so on.
 * @param C Constant subtracted from the mean or weighted mean (see the details below). Normally, it
 * is positive but may be zero or negative as well.
 *
 * - SeeAlso ``threshold:dst:thresh:maxval:type:``, ``blur:dst:ksize:anchor:borderType:``, ``GaussianBlur:dst:ksize:sigmaX:sigmaY:borderType:hint:``
 */
+ (void)adaptiveThreshold:(Mat*)src dst:(Mat*)dst maxValue:(double)maxValue adaptiveMethod:(AdaptiveThresholdTypes)adaptiveMethod thresholdType:(ThresholdTypes)thresholdType blockSize:(int)blockSize C:(double)C NS_SWIFT_NAME(adaptiveThreshold(src:dst:maxValue:adaptiveMethod:thresholdType:blockSize:C:));


//
//  void cv::pyrDown(Mat src, Mat& dst, Size dstsize = Size(), BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Blurs an image and downsamples it.
 *
 * By default, size of the output image is computed as `Size((src.cols+1)/2, (src.rows+1)/2)`, but in
 * any case, the following conditions should be satisfied:
 *
 * `$$\begin{array}{l} | \texttt{dstsize.width} *2-src.cols| \leq 2 \\ | \texttt{dstsize.height} *2-src.rows| \leq 2 \end{array}$$`
 *
 * The function performs the downsampling step of the Gaussian pyramid construction. First, it
 * convolves the source image with the kernel:
 *
 * `$$\frac{1}{256} \begin{bmatrix} 1 & 4 & 6 & 4 & 1  \\ 4 & 16 & 24 & 16 & 4  \\ 6 & 24 & 36 & 24 & 6  \\ 4 & 16 & 24 & 16 & 4  \\ 1 & 4 & 6 & 4 & 1 \end{bmatrix}$$`
 *
 * Then, it downsamples the image by rejecting even rows and columns.
 *
 * @param src input image.
 * @param dst output image; it has the specified size and the same type as src.
 * @param dstsize size of the output image.
 * @param borderType Pixel extrapolation method, see ``BorderTypes`` (``BorderTypes/BORDER_CONSTANT`` isn't supported)
 */
+ (void)pyrDown:(Mat*)src dst:(Mat*)dst dstsize:(Size2i*)dstsize borderType:(BorderTypes)borderType NS_SWIFT_NAME(pyrDown(src:dst:dstsize:borderType:));

/**
 * Blurs an image and downsamples it.
 *
 * By default, size of the output image is computed as `Size((src.cols+1)/2, (src.rows+1)/2)`, but in
 * any case, the following conditions should be satisfied:
 *
 * `$$\begin{array}{l} | \texttt{dstsize.width} *2-src.cols| \leq 2 \\ | \texttt{dstsize.height} *2-src.rows| \leq 2 \end{array}$$`
 *
 * The function performs the downsampling step of the Gaussian pyramid construction. First, it
 * convolves the source image with the kernel:
 *
 * `$$\frac{1}{256} \begin{bmatrix} 1 & 4 & 6 & 4 & 1  \\ 4 & 16 & 24 & 16 & 4  \\ 6 & 24 & 36 & 24 & 6  \\ 4 & 16 & 24 & 16 & 4  \\ 1 & 4 & 6 & 4 & 1 \end{bmatrix}$$`
 *
 * Then, it downsamples the image by rejecting even rows and columns.
 *
 * @param src input image.
 * @param dst output image; it has the specified size and the same type as src.
 * @param dstsize size of the output image.
 */
+ (void)pyrDown:(Mat*)src dst:(Mat*)dst dstsize:(Size2i*)dstsize NS_SWIFT_NAME(pyrDown(src:dst:dstsize:));

/**
 * Blurs an image and downsamples it.
 *
 * By default, size of the output image is computed as `Size((src.cols+1)/2, (src.rows+1)/2)`, but in
 * any case, the following conditions should be satisfied:
 *
 * `$$\begin{array}{l} | \texttt{dstsize.width} *2-src.cols| \leq 2 \\ | \texttt{dstsize.height} *2-src.rows| \leq 2 \end{array}$$`
 *
 * The function performs the downsampling step of the Gaussian pyramid construction. First, it
 * convolves the source image with the kernel:
 *
 * `$$\frac{1}{256} \begin{bmatrix} 1 & 4 & 6 & 4 & 1  \\ 4 & 16 & 24 & 16 & 4  \\ 6 & 24 & 36 & 24 & 6  \\ 4 & 16 & 24 & 16 & 4  \\ 1 & 4 & 6 & 4 & 1 \end{bmatrix}$$`
 *
 * Then, it downsamples the image by rejecting even rows and columns.
 *
 * @param src input image.
 * @param dst output image; it has the specified size and the same type as src.
 */
+ (void)pyrDown:(Mat*)src dst:(Mat*)dst NS_SWIFT_NAME(pyrDown(src:dst:));


//
//  void cv::pyrUp(Mat src, Mat& dst, Size dstsize = Size(), BorderTypes borderType = BORDER_DEFAULT)
//
/**
 * Upsamples an image and then blurs it.
 *
 * By default, size of the output image is computed as `Size(src.cols\*2, (src.rows\*2)`, but in any
 * case, the following conditions should be satisfied:
 *
 * `$$\begin{array}{l} | \texttt{dstsize.width} -src.cols*2| \leq  ( \texttt{dstsize.width}   \mod  2)  \\ | \texttt{dstsize.height} -src.rows*2| \leq  ( \texttt{dstsize.height}   \mod  2) \end{array}$$`
 *
 * The function performs the upsampling step of the Gaussian pyramid construction, though it can
 * actually be used to construct the Laplacian pyramid. First, it upsamples the source image by
 * injecting even zero rows and columns and then convolves the result with the same kernel as in
 * pyrDown multiplied by 4.
 *
 * @param src input image.
 * @param dst output image. It has the specified size and the same type as src .
 * @param dstsize size of the output image.
 * @param borderType Pixel extrapolation method, see ``BorderTypes`` (only ``BorderTypes/BORDER_DEFAULT`` is supported)
 */
+ (void)pyrUp:(Mat*)src dst:(Mat*)dst dstsize:(Size2i*)dstsize borderType:(BorderTypes)borderType NS_SWIFT_NAME(pyrUp(src:dst:dstsize:borderType:));

/**
 * Upsamples an image and then blurs it.
 *
 * By default, size of the output image is computed as `Size(src.cols\*2, (src.rows\*2)`, but in any
 * case, the following conditions should be satisfied:
 *
 * `$$\begin{array}{l} | \texttt{dstsize.width} -src.cols*2| \leq  ( \texttt{dstsize.width}   \mod  2)  \\ | \texttt{dstsize.height} -src.rows*2| \leq  ( \texttt{dstsize.height}   \mod  2) \end{array}$$`
 *
 * The function performs the upsampling step of the Gaussian pyramid construction, though it can
 * actually be used to construct the Laplacian pyramid. First, it upsamples the source image by
 * injecting even zero rows and columns and then convolves the result with the same kernel as in
 * pyrDown multiplied by 4.
 *
 * @param src input image.
 * @param dst output image. It has the specified size and the same type as src .
 * @param dstsize size of the output image.
 */
+ (void)pyrUp:(Mat*)src dst:(Mat*)dst dstsize:(Size2i*)dstsize NS_SWIFT_NAME(pyrUp(src:dst:dstsize:));

/**
 * Upsamples an image and then blurs it.
 *
 * By default, size of the output image is computed as `Size(src.cols\*2, (src.rows\*2)`, but in any
 * case, the following conditions should be satisfied:
 *
 * `$$\begin{array}{l} | \texttt{dstsize.width} -src.cols*2| \leq  ( \texttt{dstsize.width}   \mod  2)  \\ | \texttt{dstsize.height} -src.rows*2| \leq  ( \texttt{dstsize.height}   \mod  2) \end{array}$$`
 *
 * The function performs the upsampling step of the Gaussian pyramid construction, though it can
 * actually be used to construct the Laplacian pyramid. First, it upsamples the source image by
 * injecting even zero rows and columns and then convolves the result with the same kernel as in
 * pyrDown multiplied by 4.
 *
 * @param src input image.
 * @param dst output image. It has the specified size and the same type as src .
 */
+ (void)pyrUp:(Mat*)src dst:(Mat*)dst NS_SWIFT_NAME(pyrUp(src:dst:));


//
//  void cv::calcHist(vector_Mat images, vector_int channels, Mat mask, Mat& hist, vector_int histSize, vector_float ranges, bool accumulate = false)
//
/**
 *
 *
 * this variant supports only uniform histograms.
 *
 * ranges argument is either empty vector or a flattened vector of histSize.size()*2 elements
 * (histSize.size() element pairs). The first and second elements of each pair specify the lower and
 * upper boundaries.
 */
+ (void)calcHist:(NSArray<Mat*>*)images channels:(IntVector*)channels mask:(Mat*)mask hist:(Mat*)hist histSize:(IntVector*)histSize ranges:(FloatVector*)ranges accumulate:(BOOL)accumulate NS_SWIFT_NAME(calcHist(images:channels:mask:hist:histSize:ranges:accumulate:));

/**
 *
 *
 * this variant supports only uniform histograms.
 *
 * ranges argument is either empty vector or a flattened vector of histSize.size()*2 elements
 * (histSize.size() element pairs). The first and second elements of each pair specify the lower and
 * upper boundaries.
 */
+ (void)calcHist:(NSArray<Mat*>*)images channels:(IntVector*)channels mask:(Mat*)mask hist:(Mat*)hist histSize:(IntVector*)histSize ranges:(FloatVector*)ranges NS_SWIFT_NAME(calcHist(images:channels:mask:hist:histSize:ranges:));


//
//  void cv::calcBackProject(vector_Mat images, vector_int channels, Mat hist, Mat& dst, vector_float ranges, double scale)
//
+ (void)calcBackProject:(NSArray<Mat*>*)images channels:(IntVector*)channels hist:(Mat*)hist dst:(Mat*)dst ranges:(FloatVector*)ranges scale:(double)scale NS_SWIFT_NAME(calcBackProject(images:channels:hist:dst:ranges:scale:));


//
//  double cv::compareHist(Mat H1, Mat H2, HistCompMethods method)
//
/**
 * Compares two histograms.
 *
 * The function cv::compareHist compares two dense or two sparse histograms using the specified method.
 *
 * The function returns `$$d(H_1, H_2)$$` .
 *
 * While the function works well with 1-, 2-, 3-dimensional dense histograms, it may not be suitable
 * for high-dimensional sparse histograms. In such histograms, because of aliasing and sampling
 * problems, the coordinates of non-zero histogram bins can slightly shift. To compare such histograms
 * or more general sparse configurations of weighted points, consider using the ``Imgproc/EMD`` function.
 *
 * @param H1 First compared histogram.
 * @param H2 Second compared histogram of the same size as H1 .
 * @param method Comparison method, see ``HistCompMethods``
 */
+ (double)compareHist:(Mat*)H1 H2:(Mat*)H2 method:(HistCompMethods)method NS_SWIFT_NAME(compareHist(H1:H2:method:));


//
//  void cv::equalizeHist(Mat src, Mat& dst)
//
/**
 * Equalizes the histogram of a grayscale image.
 *
 * The function equalizes the histogram of the input image using the following algorithm:
 *
 * - Calculate the histogram `$$H$$` for src .
 * - Normalize the histogram so that the sum of histogram bins is 255.
 * - Compute the integral of the histogram:
 * `$$H'_i =  \sum _{0  \le j < i} H(j)$$`
 * - Transform the image using `$$H'$$` as a look-up table: `$$\texttt{dst}(x,y) = H'(\texttt{src}(x,y))$$`
 *
 * The algorithm normalizes the brightness and increases the contrast of the image.
 *
 * @param src Source 8-bit single channel image.
 * @param dst Destination image of the same size and type as src .
 */
+ (void)equalizeHist:(Mat*)src dst:(Mat*)dst NS_SWIFT_NAME(equalizeHist(src:dst:));


//
//  Ptr_CLAHE cv::createCLAHE(double clipLimit = 40.0, Size tileGridSize = Size(8, 8))
//
/**
 * Creates a smart pointer to a cv::CLAHE class and initializes it.
 *
 * @param clipLimit Threshold for contrast limiting.
 * @param tileGridSize Size of grid for histogram equalization. Input image will be divided into
 * equally sized rectangular tiles. tileGridSize defines the number of tiles in row and column.
 */
+ (CLAHE*)createCLAHE:(double)clipLimit tileGridSize:(Size2i*)tileGridSize NS_SWIFT_NAME(createCLAHE(clipLimit:tileGridSize:));

/**
 * Creates a smart pointer to a cv::CLAHE class and initializes it.
 *
 * @param clipLimit Threshold for contrast limiting.
 * equally sized rectangular tiles. tileGridSize defines the number of tiles in row and column.
 */
+ (CLAHE*)createCLAHE:(double)clipLimit NS_SWIFT_NAME(createCLAHE(clipLimit:));

/**
 * Creates a smart pointer to a cv::CLAHE class and initializes it.
 *
 * equally sized rectangular tiles. tileGridSize defines the number of tiles in row and column.
 */
+ (CLAHE*)createCLAHE NS_SWIFT_NAME(createCLAHE());


//
//  float cv::wrapperEMD(Mat signature1, Mat signature2, DistanceTypes distType, Mat cost = Mat(),  _hidden_ & lowerBound = cv::Ptr<float>(), Mat& flow = Mat())
//
/**
 * Computes the "minimal work" distance between two weighted point configurations.
 *
 * The function computes the earth mover distance and/or a lower boundary of the distance between the
 * two weighted point configurations. One of the applications described in *Cite:* RubnerSept98,
 * Cite:* Rubner2000 is multi-dimensional histogram comparison for image retrieval. EMD is a transportation
 * problem that is solved using some modification of a simplex algorithm, thus the complexity is
 * exponential in the worst case, though, on average it is much faster. In the case of a real metric
 * the lower boundary can be calculated even faster (using linear-time algorithm) and it can be used
 * to determine roughly whether the two signatures are far enough so that they cannot relate to the
 * same object.
 *
 * @param signature1 First signature, a `$$\texttt{size1}\times \texttt{dims}+1$$` floating-point matrix.
 * Each row stores the point weight followed by the point coordinates. The matrix is allowed to have
 * a single column (weights only) if the user-defined cost matrix is used. The weights must be
 * non-negative and have at least one non-zero value.
 * @param signature2 Second signature of the same format as signature1 , though the number of rows
 * may be different. The total weights may be different. In this case an extra "dummy" point is added
 * to either signature1 or signature2. The weights must be non-negative and have at least one non-zero
 * value.
 * @param distType Used metric. See ``DistanceTypes``.
 * @param cost User-defined `$$\texttt{size1}\times \texttt{size2}$$` cost matrix. Also, if a cost matrix
 * is used, lower boundary lowerBound cannot be calculated because it needs a metric function.
 * @param lowerBound Optional input/output parameter: lower boundary of a distance between the two
 * signatures that is a distance between mass centers. The lower boundary may not be calculated if
 * the user-defined cost matrix is used, the total weights of point configurations are not equal, or
 * if the signatures consist of weights only (the signature matrices have a single column). You
 * *must** initialize \*lowerBound . If the calculated distance between mass centers is greater or
 * equal to \*lowerBound (it means that the signatures are far enough), the function does not
 * calculate EMD. In any case \*lowerBound is set to the calculated distance between mass centers on
 * return. Thus, if you want to calculate both distance between mass centers and EMD, \*lowerBound
 * should be set to 0.
 * @param flow Resultant `$$\texttt{size1} \times \texttt{size2}$$` flow matrix: `$$\texttt{flow}_{i,j}$$` is
 * a flow from `$$i$$` -th point of signature1 to `$$j$$` -th point of signature2 .
 */
+ (float)EMD:(Mat*)signature1 signature2:(Mat*)signature2 distType:(DistanceTypes)distType cost:(Mat*)cost flow:(Mat*)flow NS_SWIFT_NAME(wrapperEMD(signature1:signature2:distType:cost:flow:));

/**
 * Computes the "minimal work" distance between two weighted point configurations.
 *
 * The function computes the earth mover distance and/or a lower boundary of the distance between the
 * two weighted point configurations. One of the applications described in *Cite:* RubnerSept98,
 * Cite:* Rubner2000 is multi-dimensional histogram comparison for image retrieval. EMD is a transportation
 * problem that is solved using some modification of a simplex algorithm, thus the complexity is
 * exponential in the worst case, though, on average it is much faster. In the case of a real metric
 * the lower boundary can be calculated even faster (using linear-time algorithm) and it can be used
 * to determine roughly whether the two signatures are far enough so that they cannot relate to the
 * same object.
 *
 * @param signature1 First signature, a `$$\texttt{size1}\times \texttt{dims}+1$$` floating-point matrix.
 * Each row stores the point weight followed by the point coordinates. The matrix is allowed to have
 * a single column (weights only) if the user-defined cost matrix is used. The weights must be
 * non-negative and have at least one non-zero value.
 * @param signature2 Second signature of the same format as signature1 , though the number of rows
 * may be different. The total weights may be different. In this case an extra "dummy" point is added
 * to either signature1 or signature2. The weights must be non-negative and have at least one non-zero
 * value.
 * @param distType Used metric. See ``DistanceTypes``.
 * @param cost User-defined `$$\texttt{size1}\times \texttt{size2}$$` cost matrix. Also, if a cost matrix
 * is used, lower boundary lowerBound cannot be calculated because it needs a metric function.
 * @param lowerBound Optional input/output parameter: lower boundary of a distance between the two
 * signatures that is a distance between mass centers. The lower boundary may not be calculated if
 * the user-defined cost matrix is used, the total weights of point configurations are not equal, or
 * if the signatures consist of weights only (the signature matrices have a single column). You
 * *must** initialize \*lowerBound . If the calculated distance between mass centers is greater or
 * equal to \*lowerBound (it means that the signatures are far enough), the function does not
 * calculate EMD. In any case \*lowerBound is set to the calculated distance between mass centers on
 * return. Thus, if you want to calculate both distance between mass centers and EMD, \*lowerBound
 * should be set to 0.
 * a flow from `$$i$$` -th point of signature1 to `$$j$$` -th point of signature2 .
 */
+ (float)EMD:(Mat*)signature1 signature2:(Mat*)signature2 distType:(DistanceTypes)distType cost:(Mat*)cost NS_SWIFT_NAME(wrapperEMD(signature1:signature2:distType:cost:));

/**
 * Computes the "minimal work" distance between two weighted point configurations.
 *
 * The function computes the earth mover distance and/or a lower boundary of the distance between the
 * two weighted point configurations. One of the applications described in *Cite:* RubnerSept98,
 * Cite:* Rubner2000 is multi-dimensional histogram comparison for image retrieval. EMD is a transportation
 * problem that is solved using some modification of a simplex algorithm, thus the complexity is
 * exponential in the worst case, though, on average it is much faster. In the case of a real metric
 * the lower boundary can be calculated even faster (using linear-time algorithm) and it can be used
 * to determine roughly whether the two signatures are far enough so that they cannot relate to the
 * same object.
 *
 * @param signature1 First signature, a `$$\texttt{size1}\times \texttt{dims}+1$$` floating-point matrix.
 * Each row stores the point weight followed by the point coordinates. The matrix is allowed to have
 * a single column (weights only) if the user-defined cost matrix is used. The weights must be
 * non-negative and have at least one non-zero value.
 * @param signature2 Second signature of the same format as signature1 , though the number of rows
 * may be different. The total weights may be different. In this case an extra "dummy" point is added
 * to either signature1 or signature2. The weights must be non-negative and have at least one non-zero
 * value.
 * @param distType Used metric. See ``DistanceTypes``.
 * is used, lower boundary lowerBound cannot be calculated because it needs a metric function.
 * signatures that is a distance between mass centers. The lower boundary may not be calculated if
 * the user-defined cost matrix is used, the total weights of point configurations are not equal, or
 * if the signatures consist of weights only (the signature matrices have a single column). You
 * *must** initialize \*lowerBound . If the calculated distance between mass centers is greater or
 * equal to \*lowerBound (it means that the signatures are far enough), the function does not
 * calculate EMD. In any case \*lowerBound is set to the calculated distance between mass centers on
 * return. Thus, if you want to calculate both distance between mass centers and EMD, \*lowerBound
 * should be set to 0.
 * a flow from `$$i$$` -th point of signature1 to `$$j$$` -th point of signature2 .
 */
+ (float)EMD:(Mat*)signature1 signature2:(Mat*)signature2 distType:(DistanceTypes)distType NS_SWIFT_NAME(wrapperEMD(signature1:signature2:distType:));


//
//  void cv::watershed(Mat image, Mat& markers)
//
/**
 * Performs a marker-based image segmentation using the watershed algorithm.
 *
 * The function implements one of the variants of watershed, non-parametric marker-based segmentation
 * algorithm, described in *Cite:* Meyer92 .
 *
 * Before passing the image to the function, you have to roughly outline the desired regions in the
 * image markers with positive (\>0) indices. So, every region is represented as one or more connected
 * components with the pixel values 1, 2, 3, and so on. Such markers can be retrieved from a binary
 * mask using ``Imgproc/findContours`` and ``Imgproc/drawContours`` (see the watershed.cpp demo). The markers are "seeds" of
 * the future image regions. All the other pixels in markers , whose relation to the outlined regions
 * is not known and should be defined by the algorithm, should be set to 0's. In the function output,
 * each pixel in markers is set to a value of the "seed" components or to -1 at boundaries between the
 * regions.
 *
 * Note:* Any two neighbor connected components are not necessarily separated by a watershed boundary
 * (-1's pixels); for example, they can touch each other in the initial marker image passed to the
 * function.
 *
 * @param image Input 8-bit 3-channel image.
 * @param markers Input/output 32-bit single-channel image (map) of markers. It should have the same
 * size as image .
 *
 * - SeeAlso ``findContours:contours:hierarchy:mode:method:offset:``
 */
+ (void)watershed:(Mat*)image markers:(Mat*)markers NS_SWIFT_NAME(watershed(image:markers:));


//
//  void cv::pyrMeanShiftFiltering(Mat src, Mat& dst, double sp, double sr, int maxLevel = 1, TermCriteria termcrit = TermCriteria(TermCriteria::MAX_ITER+TermCriteria::EPS,5,1))
//
/**
 * Performs initial step of meanshift segmentation of an image.
 *
 * The function implements the filtering stage of meanshift segmentation, that is, the output of the
 * function is the filtered "posterized" image with color gradients and fine-grain texture flattened.
 * At every pixel (X,Y) of the input image (or down-sized input image, see below) the function executes
 * meanshift iterations, that is, the pixel (X,Y) neighborhood in the joint space-color hyperspace is
 * considered:
 *
 * `$$(x,y): X- \texttt{sp} \le x  \le X+ \texttt{sp} , Y- \texttt{sp} \le y  \le Y+ \texttt{sp} , ||(R,G,B)-(r,g,b)||   \le \texttt{sr}$$`
 *
 * where (R,G,B) and (r,g,b) are the vectors of color components at (X,Y) and (x,y), respectively
 * (though, the algorithm does not depend on the color space used, so any 3-component color space can
 * be used instead). Over the neighborhood the average spatial value (X',Y') and average color vector
 * (R',G',B') are found and they act as the neighborhood center on the next iteration:
 *
 * `$$(X,Y)~(X',Y'), (R,G,B)~(R',G',B').$$`
 *
 * After the iterations over, the color components of the initial pixel (that is, the pixel from where
 * the iterations started) are set to the final value (average color at the last iteration):
 *
 * `$$I(X,Y) <- (R*,G*,B*)$$`
 *
 * When maxLevel \> 0, the gaussian pyramid of maxLevel+1 levels is built, and the above procedure is
 * run on the smallest layer first. After that, the results are propagated to the larger layer and the
 * iterations are run again only on those pixels where the layer colors differ by more than sr from the
 * lower-resolution layer of the pyramid. That makes boundaries of color regions sharper. Note that the
 * results will be actually different from the ones obtained by running the meanshift procedure on the
 * whole original image (i.e. when maxLevel==0).
 *
 * @param src The source 8-bit, 3-channel image.
 * @param dst The destination image of the same format and the same size as the source.
 * @param sp The spatial window radius.
 * @param sr The color window radius.
 * @param maxLevel Maximum level of the pyramid for the segmentation.
 * @param termcrit Termination criteria: when to stop meanshift iterations.
 */
+ (void)pyrMeanShiftFiltering:(Mat*)src dst:(Mat*)dst sp:(double)sp sr:(double)sr maxLevel:(int)maxLevel termcrit:(TermCriteria*)termcrit NS_SWIFT_NAME(pyrMeanShiftFiltering(src:dst:sp:sr:maxLevel:termcrit:));

/**
 * Performs initial step of meanshift segmentation of an image.
 *
 * The function implements the filtering stage of meanshift segmentation, that is, the output of the
 * function is the filtered "posterized" image with color gradients and fine-grain texture flattened.
 * At every pixel (X,Y) of the input image (or down-sized input image, see below) the function executes
 * meanshift iterations, that is, the pixel (X,Y) neighborhood in the joint space-color hyperspace is
 * considered:
 *
 * `$$(x,y): X- \texttt{sp} \le x  \le X+ \texttt{sp} , Y- \texttt{sp} \le y  \le Y+ \texttt{sp} , ||(R,G,B)-(r,g,b)||   \le \texttt{sr}$$`
 *
 * where (R,G,B) and (r,g,b) are the vectors of color components at (X,Y) and (x,y), respectively
 * (though, the algorithm does not depend on the color space used, so any 3-component color space can
 * be used instead). Over the neighborhood the average spatial value (X',Y') and average color vector
 * (R',G',B') are found and they act as the neighborhood center on the next iteration:
 *
 * `$$(X,Y)~(X',Y'), (R,G,B)~(R',G',B').$$`
 *
 * After the iterations over, the color components of the initial pixel (that is, the pixel from where
 * the iterations started) are set to the final value (average color at the last iteration):
 *
 * `$$I(X,Y) <- (R*,G*,B*)$$`
 *
 * When maxLevel \> 0, the gaussian pyramid of maxLevel+1 levels is built, and the above procedure is
 * run on the smallest layer first. After that, the results are propagated to the larger layer and the
 * iterations are run again only on those pixels where the layer colors differ by more than sr from the
 * lower-resolution layer of the pyramid. That makes boundaries of color regions sharper. Note that the
 * results will be actually different from the ones obtained by running the meanshift procedure on the
 * whole original image (i.e. when maxLevel==0).
 *
 * @param src The source 8-bit, 3-channel image.
 * @param dst The destination image of the same format and the same size as the source.
 * @param sp The spatial window radius.
 * @param sr The color window radius.
 * @param maxLevel Maximum level of the pyramid for the segmentation.
 */
+ (void)pyrMeanShiftFiltering:(Mat*)src dst:(Mat*)dst sp:(double)sp sr:(double)sr maxLevel:(int)maxLevel NS_SWIFT_NAME(pyrMeanShiftFiltering(src:dst:sp:sr:maxLevel:));

/**
 * Performs initial step of meanshift segmentation of an image.
 *
 * The function implements the filtering stage of meanshift segmentation, that is, the output of the
 * function is the filtered "posterized" image with color gradients and fine-grain texture flattened.
 * At every pixel (X,Y) of the input image (or down-sized input image, see below) the function executes
 * meanshift iterations, that is, the pixel (X,Y) neighborhood in the joint space-color hyperspace is
 * considered:
 *
 * `$$(x,y): X- \texttt{sp} \le x  \le X+ \texttt{sp} , Y- \texttt{sp} \le y  \le Y+ \texttt{sp} , ||(R,G,B)-(r,g,b)||   \le \texttt{sr}$$`
 *
 * where (R,G,B) and (r,g,b) are the vectors of color components at (X,Y) and (x,y), respectively
 * (though, the algorithm does not depend on the color space used, so any 3-component color space can
 * be used instead). Over the neighborhood the average spatial value (X',Y') and average color vector
 * (R',G',B') are found and they act as the neighborhood center on the next iteration:
 *
 * `$$(X,Y)~(X',Y'), (R,G,B)~(R',G',B').$$`
 *
 * After the iterations over, the color components of the initial pixel (that is, the pixel from where
 * the iterations started) are set to the final value (average color at the last iteration):
 *
 * `$$I(X,Y) <- (R*,G*,B*)$$`
 *
 * When maxLevel \> 0, the gaussian pyramid of maxLevel+1 levels is built, and the above procedure is
 * run on the smallest layer first. After that, the results are propagated to the larger layer and the
 * iterations are run again only on those pixels where the layer colors differ by more than sr from the
 * lower-resolution layer of the pyramid. That makes boundaries of color regions sharper. Note that the
 * results will be actually different from the ones obtained by running the meanshift procedure on the
 * whole original image (i.e. when maxLevel==0).
 *
 * @param src The source 8-bit, 3-channel image.
 * @param dst The destination image of the same format and the same size as the source.
 * @param sp The spatial window radius.
 * @param sr The color window radius.
 */
+ (void)pyrMeanShiftFiltering:(Mat*)src dst:(Mat*)dst sp:(double)sp sr:(double)sr NS_SWIFT_NAME(pyrMeanShiftFiltering(src:dst:sp:sr:));


//
//  void cv::grabCut(Mat img, Mat& mask, Rect rect, Mat& bgdModel, Mat& fgdModel, int iterCount, int mode = GC_EVAL)
//
/**
 * Runs the GrabCut algorithm.
 *
 * The function implements the [GrabCut image segmentation algorithm](https://en.wikipedia.org/wiki/GrabCut).
 *
 * @param img Input 8-bit 3-channel image.
 * @param mask Input/output 8-bit single-channel mask. The mask is initialized by the function when
 * mode is set to ``GrabCutModes/GC_INIT_WITH_RECT``. Its elements may have one of the ``GrabCutClasses``.
 * @param rect ROI containing a segmented object. The pixels outside of the ROI are marked as
 * "obvious background". The parameter is only used when mode==#GC_INIT_WITH_RECT .
 * @param bgdModel Temporary array for the background model. Do not modify it while you are
 * processing the same image.
 * @param fgdModel Temporary arrays for the foreground model. Do not modify it while you are
 * processing the same image.
 * @param iterCount Number of iterations the algorithm should make before returning the result. Note
 * that the result can be refined with further calls with mode==#GC_INIT_WITH_MASK or
 * mode==GC_EVAL .
 * @param mode Operation mode that could be one of the ``GrabCutModes``
 */
+ (void)grabCut:(Mat*)img mask:(Mat*)mask rect:(Rect2i*)rect bgdModel:(Mat*)bgdModel fgdModel:(Mat*)fgdModel iterCount:(int)iterCount mode:(int)mode NS_SWIFT_NAME(grabCut(img:mask:rect:bgdModel:fgdModel:iterCount:mode:));

/**
 * Runs the GrabCut algorithm.
 *
 * The function implements the [GrabCut image segmentation algorithm](https://en.wikipedia.org/wiki/GrabCut).
 *
 * @param img Input 8-bit 3-channel image.
 * @param mask Input/output 8-bit single-channel mask. The mask is initialized by the function when
 * mode is set to ``GrabCutModes/GC_INIT_WITH_RECT``. Its elements may have one of the ``GrabCutClasses``.
 * @param rect ROI containing a segmented object. The pixels outside of the ROI are marked as
 * "obvious background". The parameter is only used when mode==#GC_INIT_WITH_RECT .
 * @param bgdModel Temporary array for the background model. Do not modify it while you are
 * processing the same image.
 * @param fgdModel Temporary arrays for the foreground model. Do not modify it while you are
 * processing the same image.
 * @param iterCount Number of iterations the algorithm should make before returning the result. Note
 * that the result can be refined with further calls with mode==#GC_INIT_WITH_MASK or
 * mode==GC_EVAL .
 */
+ (void)grabCut:(Mat*)img mask:(Mat*)mask rect:(Rect2i*)rect bgdModel:(Mat*)bgdModel fgdModel:(Mat*)fgdModel iterCount:(int)iterCount NS_SWIFT_NAME(grabCut(img:mask:rect:bgdModel:fgdModel:iterCount:));


//
//  void cv::distanceTransform(Mat src, Mat& dst, Mat& labels, DistanceTypes distanceType, DistanceTransformMasks maskSize, DistanceTransformLabelTypes labelType = DIST_LABEL_CCOMP)
//
/**
 * Calculates the distance to the closest zero pixel for each pixel of the source image.
 *
 * The function cv::distanceTransform calculates the approximate or precise distance from every binary
 * image pixel to the nearest zero pixel. For zero image pixels, the distance will obviously be zero.
 *
 * When maskSize == ``DistanceTransformMasks/DIST_MASK_PRECISE`` and distanceType == ``DistanceTypes/DIST_L2`` , the function runs the
 * algorithm described in *Cite:* Felzenszwalb04 . This algorithm is parallelized with the TBB library.
 *
 * In other cases, the algorithm *Cite:* Borgefors86 is used. This means that for a pixel the function
 * finds the shortest path to the nearest zero pixel consisting of basic shifts: horizontal, vertical,
 * diagonal, or knight's move (the latest is available for a `$$5\times 5$$` mask). The overall
 * distance is calculated as a sum of these basic distances. Since the distance function should be
 * symmetric, all of the horizontal and vertical shifts must have the same cost (denoted as a ), all
 * the diagonal shifts must have the same cost (denoted as `b`), and all knight's moves must have the
 * same cost (denoted as `c`). For the ``DistanceTypes/DIST_C`` and ``DistanceTypes/DIST_L1`` types, the distance is calculated
 * precisely, whereas for ``DistanceTypes/DIST_L2`` (Euclidean distance) the distance can be calculated only with a
 * relative error (a `$$5\times 5$$` mask gives more accurate results). For `a`,`b`, and `c`, OpenCV
 * uses the values suggested in the original paper:
 * - DIST_L1: `a = 1, b = 2`
 * - DIST_L2:
 *     - `3 x 3`: `a=0.955, b=1.3693`
 *     - `5 x 5`: `a=1, b=1.4, c=2.1969`
 * - DIST_C: `a = 1, b = 1`
 *
 * Typically, for a fast, coarse distance estimation ``DistanceTypes/DIST_L2``, a `$$3\times 3$$` mask is used. For a
 * more accurate distance estimation ``DistanceTypes/DIST_L2``, a `$$5\times 5$$` mask or the precise algorithm is used.
 * Note that both the precise and the approximate algorithms are linear on the number of pixels.
 *
 * This variant of the function does not only compute the minimum distance for each pixel `$$(x, y)$$`
 * but also identifies the nearest connected component consisting of zero pixels
 * (labelType==#DIST_LABEL_CCOMP) or the nearest zero pixel (labelType==#DIST_LABEL_PIXEL). Index of the
 * component/pixel is stored in `labels(x, y)`. When labelType==#DIST_LABEL_CCOMP, the function
 * automatically finds connected components of zero pixels in the input image and marks them with
 * distinct labels. When labelType==#DIST_LABEL_PIXEL, the function scans through the input image and
 * marks all the zero pixels with distinct labels.
 *
 * In this mode, the complexity is still linear. That is, the function provides a very fast way to
 * compute the Voronoi diagram for a binary image. Currently, the second variant can use only the
 * approximate distance transform algorithm, i.e. maskSize=#DIST_MASK_PRECISE is not supported
 * yet.
 *
 * @param src 8-bit, single-channel (binary) source image.
 * @param dst Output image with calculated distances. It is a 8-bit or 32-bit floating-point,
 * single-channel image of the same size as src.
 * @param labels Output 2D array of labels (the discrete Voronoi diagram). It has the type
 * CV_32SC1 and the same size as src.
 * @param distanceType Type of distance, see ``DistanceTypes``
 * @param maskSize Size of the distance transform mask, see ``DistanceTransformMasks``.
 * ``DistanceTransformMasks/DIST_MASK_PRECISE`` is not supported by this variant. In case of the ``DistanceTypes/DIST_L1`` or ``DistanceTypes/DIST_C`` distance type,
 * the parameter is forced to 3 because a `$$3\times 3$$` mask gives the same result as `$$5\times
 * 5$$` or any larger aperture.
 * @param labelType Type of the label array to build, see ``DistanceTransformLabelTypes``.
 */
+ (void)distanceTransformWithLabels:(Mat*)src dst:(Mat*)dst labels:(Mat*)labels distanceType:(DistanceTypes)distanceType maskSize:(DistanceTransformMasks)maskSize labelType:(DistanceTransformLabelTypes)labelType NS_SWIFT_NAME(distanceTransform(src:dst:labels:distanceType:maskSize:labelType:));

/**
 * Calculates the distance to the closest zero pixel for each pixel of the source image.
 *
 * The function cv::distanceTransform calculates the approximate or precise distance from every binary
 * image pixel to the nearest zero pixel. For zero image pixels, the distance will obviously be zero.
 *
 * When maskSize == ``DistanceTransformMasks/DIST_MASK_PRECISE`` and distanceType == ``DistanceTypes/DIST_L2`` , the function runs the
 * algorithm described in *Cite:* Felzenszwalb04 . This algorithm is parallelized with the TBB library.
 *
 * In other cases, the algorithm *Cite:* Borgefors86 is used. This means that for a pixel the function
 * finds the shortest path to the nearest zero pixel consisting of basic shifts: horizontal, vertical,
 * diagonal, or knight's move (the latest is available for a `$$5\times 5$$` mask). The overall
 * distance is calculated as a sum of these basic distances. Since the distance function should be
 * symmetric, all of the horizontal and vertical shifts must have the same cost (denoted as a ), all
 * the diagonal shifts must have the same cost (denoted as `b`), and all knight's moves must have the
 * same cost (denoted as `c`). For the ``DistanceTypes/DIST_C`` and ``DistanceTypes/DIST_L1`` types, the distance is calculated
 * precisely, whereas for ``DistanceTypes/DIST_L2`` (Euclidean distance) the distance can be calculated only with a
 * relative error (a `$$5\times 5$$` mask gives more accurate results). For `a`,`b`, and `c`, OpenCV
 * uses the values suggested in the original paper:
 * - DIST_L1: `a = 1, b = 2`
 * - DIST_L2:
 *     - `3 x 3`: `a=0.955, b=1.3693`
 *     - `5 x 5`: `a=1, b=1.4, c=2.1969`
 * - DIST_C: `a = 1, b = 1`
 *
 * Typically, for a fast, coarse distance estimation ``DistanceTypes/DIST_L2``, a `$$3\times 3$$` mask is used. For a
 * more accurate distance estimation ``DistanceTypes/DIST_L2``, a `$$5\times 5$$` mask or the precise algorithm is used.
 * Note that both the precise and the approximate algorithms are linear on the number of pixels.
 *
 * This variant of the function does not only compute the minimum distance for each pixel `$$(x, y)$$`
 * but also identifies the nearest connected component consisting of zero pixels
 * (labelType==#DIST_LABEL_CCOMP) or the nearest zero pixel (labelType==#DIST_LABEL_PIXEL). Index of the
 * component/pixel is stored in `labels(x, y)`. When labelType==#DIST_LABEL_CCOMP, the function
 * automatically finds connected components of zero pixels in the input image and marks them with
 * distinct labels. When labelType==#DIST_LABEL_PIXEL, the function scans through the input image and
 * marks all the zero pixels with distinct labels.
 *
 * In this mode, the complexity is still linear. That is, the function provides a very fast way to
 * compute the Voronoi diagram for a binary image. Currently, the second variant can use only the
 * approximate distance transform algorithm, i.e. maskSize=#DIST_MASK_PRECISE is not supported
 * yet.
 *
 * @param src 8-bit, single-channel (binary) source image.
 * @param dst Output image with calculated distances. It is a 8-bit or 32-bit floating-point,
 * single-channel image of the same size as src.
 * @param labels Output 2D array of labels (the discrete Voronoi diagram). It has the type
 * CV_32SC1 and the same size as src.
 * @param distanceType Type of distance, see ``DistanceTypes``
 * @param maskSize Size of the distance transform mask, see ``DistanceTransformMasks``.
 * ``DistanceTransformMasks/DIST_MASK_PRECISE`` is not supported by this variant. In case of the ``DistanceTypes/DIST_L1`` or ``DistanceTypes/DIST_C`` distance type,
 * the parameter is forced to 3 because a `$$3\times 3$$` mask gives the same result as `$$5\times
 * 5$$` or any larger aperture.
 */
+ (void)distanceTransformWithLabels:(Mat*)src dst:(Mat*)dst labels:(Mat*)labels distanceType:(DistanceTypes)distanceType maskSize:(DistanceTransformMasks)maskSize NS_SWIFT_NAME(distanceTransform(src:dst:labels:distanceType:maskSize:));


//
//  void cv::distanceTransform(Mat src, Mat& dst, DistanceTypes distanceType, DistanceTransformMasks maskSize, int dstType = CV_32F)
//
/**
 *
 * @param src 8-bit, single-channel (binary) source image.
 * @param dst Output image with calculated distances. It is a 8-bit or 32-bit floating-point,
 * single-channel image of the same size as src .
 * @param distanceType Type of distance, see ``DistanceTypes``
 * @param maskSize Size of the distance transform mask, see ``DistanceTransformMasks``. In case of the
 * ``DistanceTypes/DIST_L1`` or ``DistanceTypes/DIST_C`` distance type, the parameter is forced to 3 because a `$$3\times 3$$` mask gives
 * the same result as `$$5\times 5$$` or any larger aperture.
 * @param dstType Type of output image. It can be CV_8U or CV_32F. Type CV_8U can be used only for
 * the first variant of the function and distanceType == ``DistanceTypes/DIST_L1``.
 */
+ (void)distanceTransform:(Mat*)src dst:(Mat*)dst distanceType:(DistanceTypes)distanceType maskSize:(DistanceTransformMasks)maskSize dstType:(int)dstType NS_SWIFT_NAME(distanceTransform(src:dst:distanceType:maskSize:dstType:));

/**
 *
 * @param src 8-bit, single-channel (binary) source image.
 * @param dst Output image with calculated distances. It is a 8-bit or 32-bit floating-point,
 * single-channel image of the same size as src .
 * @param distanceType Type of distance, see ``DistanceTypes``
 * @param maskSize Size of the distance transform mask, see ``DistanceTransformMasks``. In case of the
 * ``DistanceTypes/DIST_L1`` or ``DistanceTypes/DIST_C`` distance type, the parameter is forced to 3 because a `$$3\times 3$$` mask gives
 * the same result as `$$5\times 5$$` or any larger aperture.
 * the first variant of the function and distanceType == ``DistanceTypes/DIST_L1``.
 */
+ (void)distanceTransform:(Mat*)src dst:(Mat*)dst distanceType:(DistanceTypes)distanceType maskSize:(DistanceTransformMasks)maskSize NS_SWIFT_NAME(distanceTransform(src:dst:distanceType:maskSize:));


//
//  int cv::floodFill(Mat& image, Mat& mask, Point seedPoint, Scalar newVal, Rect* rect = 0, Scalar loDiff = Scalar(), Scalar upDiff = Scalar(), int flags = 4)
//
/**
 * Fills a connected component with the given color.
 *
 * The function cv::floodFill fills a connected component starting from the seed point with the specified
 * color. The connectivity is determined by the color/brightness closeness of the neighbor pixels. The
 * pixel at `$$(x,y)$$` is considered to belong to the repainted domain if:
 *
 * - in case of a grayscale image and floating range
 * `$$\texttt{src} (x',y')- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} (x',y')+ \texttt{upDiff}$$`
 *
 *
 * - in case of a grayscale image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)+ \texttt{upDiff}$$`
 *
 *
 * - in case of a color image and floating range
 * `$$\texttt{src} (x',y')_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} (x',y')_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} (x',y')_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} (x',y')_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} (x',y')_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} (x',y')_b+ \texttt{upDiff} _b$$`
 *
 *
 * - in case of a color image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b+ \texttt{upDiff} _b$$`
 *
 *
 * where `$$src(x',y')$$` is the value of one of pixel neighbors that is already known to belong to the
 * component. That is, to be added to the connected component, a color/brightness of the pixel should
 * be close enough to:
 * - Color/brightness of one of its neighbors that already belong to the connected component in case
 * of a floating range.
 * - Color/brightness of the seed point in case of a fixed range.
 *
 * Use these functions to either mark a connected component with the specified color in-place, or build
 * a mask and then extract the contour, or copy the region to another image, and so on.
 *
 * @param image Input/output 1- or 3-channel, 8-bit, or floating-point image. It is modified by the
 * function unless the ``FloodFillFlags/FLOODFILL_MASK_ONLY`` flag is set in the second variant of the function. See
 * the details below.
 * @param mask Operation mask that should be a single-channel 8-bit image, 2 pixels wider and 2 pixels
 * taller than image. If an empty Mat is passed it will be created automatically. Since this is both an
 * input and output parameter, you must take responsibility of initializing it.
 * Flood-filling cannot go across non-zero pixels in the input mask. For example,
 * an edge detector output can be used as a mask to stop filling at edges. On output, pixels in the
 * mask corresponding to filled pixels in the image are set to 1 or to the specified value in flags
 * as described below. Additionally, the function fills the border of the mask with ones to simplify
 * internal processing. It is therefore possible to use the same mask in multiple calls to the function
 * to make sure the filled areas do not overlap.
 * @param seedPoint Starting point.
 * @param newVal New value of the repainted domain pixels.
 * @param loDiff Maximal lower brightness/color difference between the currently observed pixel and
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * @param upDiff Maximal upper brightness/color difference between the currently observed pixel and
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * @param rect Optional output parameter set by the function to the minimum bounding rectangle of the
 * repainted domain.
 * @param flags Operation flags. The first 8 bits contain a connectivity value. The default value of
 * 4 means that only the four nearest neighbor pixels (those that share an edge) are considered. A
 * connectivity value of 8 means that the eight nearest neighbor pixels (those that share a corner)
 * will be considered. The next 8 bits (8-16) contain a value between 1 and 255 with which to fill
 * the mask (the default value is 1). For example, 4 | ( 255 \<\< 8 ) will consider 4 nearest
 * neighbours and fill the mask with a value of 255. The following additional options occupy higher
 * bits and therefore may be further combined with the connectivity and mask fill values using
 * bit-wise or (|), see ``FloodFillFlags``.
 *
 * Note:* Since the mask is larger than the filled image, a pixel `$$(x, y)$$` in image corresponds to the
 * pixel `$$(x+1, y+1)$$` in the mask .
 *
 * - SeeAlso ``findContours:contours:hierarchy:mode:method:offset:``
 */
+ (int)floodFill:(Mat*)image mask:(Mat*)mask seedPoint:(Point2i*)seedPoint newVal:(Scalar*)newVal rect:(Rect2i*)rect loDiff:(Scalar*)loDiff upDiff:(Scalar*)upDiff flags:(int)flags NS_SWIFT_NAME(floodFill(image:mask:seedPoint:newVal:rect:loDiff:upDiff:flags:));

/**
 * Fills a connected component with the given color.
 *
 * The function cv::floodFill fills a connected component starting from the seed point with the specified
 * color. The connectivity is determined by the color/brightness closeness of the neighbor pixels. The
 * pixel at `$$(x,y)$$` is considered to belong to the repainted domain if:
 *
 * - in case of a grayscale image and floating range
 * `$$\texttt{src} (x',y')- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} (x',y')+ \texttt{upDiff}$$`
 *
 *
 * - in case of a grayscale image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)+ \texttt{upDiff}$$`
 *
 *
 * - in case of a color image and floating range
 * `$$\texttt{src} (x',y')_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} (x',y')_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} (x',y')_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} (x',y')_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} (x',y')_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} (x',y')_b+ \texttt{upDiff} _b$$`
 *
 *
 * - in case of a color image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b+ \texttt{upDiff} _b$$`
 *
 *
 * where `$$src(x',y')$$` is the value of one of pixel neighbors that is already known to belong to the
 * component. That is, to be added to the connected component, a color/brightness of the pixel should
 * be close enough to:
 * - Color/brightness of one of its neighbors that already belong to the connected component in case
 * of a floating range.
 * - Color/brightness of the seed point in case of a fixed range.
 *
 * Use these functions to either mark a connected component with the specified color in-place, or build
 * a mask and then extract the contour, or copy the region to another image, and so on.
 *
 * @param image Input/output 1- or 3-channel, 8-bit, or floating-point image. It is modified by the
 * function unless the ``FloodFillFlags/FLOODFILL_MASK_ONLY`` flag is set in the second variant of the function. See
 * the details below.
 * @param mask Operation mask that should be a single-channel 8-bit image, 2 pixels wider and 2 pixels
 * taller than image. If an empty Mat is passed it will be created automatically. Since this is both an
 * input and output parameter, you must take responsibility of initializing it.
 * Flood-filling cannot go across non-zero pixels in the input mask. For example,
 * an edge detector output can be used as a mask to stop filling at edges. On output, pixels in the
 * mask corresponding to filled pixels in the image are set to 1 or to the specified value in flags
 * as described below. Additionally, the function fills the border of the mask with ones to simplify
 * internal processing. It is therefore possible to use the same mask in multiple calls to the function
 * to make sure the filled areas do not overlap.
 * @param seedPoint Starting point.
 * @param newVal New value of the repainted domain pixels.
 * @param loDiff Maximal lower brightness/color difference between the currently observed pixel and
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * @param upDiff Maximal upper brightness/color difference between the currently observed pixel and
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * @param rect Optional output parameter set by the function to the minimum bounding rectangle of the
 * repainted domain.
 * 4 means that only the four nearest neighbor pixels (those that share an edge) are considered. A
 * connectivity value of 8 means that the eight nearest neighbor pixels (those that share a corner)
 * will be considered. The next 8 bits (8-16) contain a value between 1 and 255 with which to fill
 * the mask (the default value is 1). For example, 4 | ( 255 \<\< 8 ) will consider 4 nearest
 * neighbours and fill the mask with a value of 255. The following additional options occupy higher
 * bits and therefore may be further combined with the connectivity and mask fill values using
 * bit-wise or (|), see ``FloodFillFlags``.
 *
 * Note:* Since the mask is larger than the filled image, a pixel `$$(x, y)$$` in image corresponds to the
 * pixel `$$(x+1, y+1)$$` in the mask .
 *
 * - SeeAlso ``findContours:contours:hierarchy:mode:method:offset:``
 */
+ (int)floodFill:(Mat*)image mask:(Mat*)mask seedPoint:(Point2i*)seedPoint newVal:(Scalar*)newVal rect:(Rect2i*)rect loDiff:(Scalar*)loDiff upDiff:(Scalar*)upDiff NS_SWIFT_NAME(floodFill(image:mask:seedPoint:newVal:rect:loDiff:upDiff:));

/**
 * Fills a connected component with the given color.
 *
 * The function cv::floodFill fills a connected component starting from the seed point with the specified
 * color. The connectivity is determined by the color/brightness closeness of the neighbor pixels. The
 * pixel at `$$(x,y)$$` is considered to belong to the repainted domain if:
 *
 * - in case of a grayscale image and floating range
 * `$$\texttt{src} (x',y')- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} (x',y')+ \texttt{upDiff}$$`
 *
 *
 * - in case of a grayscale image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)+ \texttt{upDiff}$$`
 *
 *
 * - in case of a color image and floating range
 * `$$\texttt{src} (x',y')_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} (x',y')_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} (x',y')_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} (x',y')_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} (x',y')_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} (x',y')_b+ \texttt{upDiff} _b$$`
 *
 *
 * - in case of a color image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b+ \texttt{upDiff} _b$$`
 *
 *
 * where `$$src(x',y')$$` is the value of one of pixel neighbors that is already known to belong to the
 * component. That is, to be added to the connected component, a color/brightness of the pixel should
 * be close enough to:
 * - Color/brightness of one of its neighbors that already belong to the connected component in case
 * of a floating range.
 * - Color/brightness of the seed point in case of a fixed range.
 *
 * Use these functions to either mark a connected component with the specified color in-place, or build
 * a mask and then extract the contour, or copy the region to another image, and so on.
 *
 * @param image Input/output 1- or 3-channel, 8-bit, or floating-point image. It is modified by the
 * function unless the ``FloodFillFlags/FLOODFILL_MASK_ONLY`` flag is set in the second variant of the function. See
 * the details below.
 * @param mask Operation mask that should be a single-channel 8-bit image, 2 pixels wider and 2 pixels
 * taller than image. If an empty Mat is passed it will be created automatically. Since this is both an
 * input and output parameter, you must take responsibility of initializing it.
 * Flood-filling cannot go across non-zero pixels in the input mask. For example,
 * an edge detector output can be used as a mask to stop filling at edges. On output, pixels in the
 * mask corresponding to filled pixels in the image are set to 1 or to the specified value in flags
 * as described below. Additionally, the function fills the border of the mask with ones to simplify
 * internal processing. It is therefore possible to use the same mask in multiple calls to the function
 * to make sure the filled areas do not overlap.
 * @param seedPoint Starting point.
 * @param newVal New value of the repainted domain pixels.
 * @param loDiff Maximal lower brightness/color difference between the currently observed pixel and
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * @param rect Optional output parameter set by the function to the minimum bounding rectangle of the
 * repainted domain.
 * 4 means that only the four nearest neighbor pixels (those that share an edge) are considered. A
 * connectivity value of 8 means that the eight nearest neighbor pixels (those that share a corner)
 * will be considered. The next 8 bits (8-16) contain a value between 1 and 255 with which to fill
 * the mask (the default value is 1). For example, 4 | ( 255 \<\< 8 ) will consider 4 nearest
 * neighbours and fill the mask with a value of 255. The following additional options occupy higher
 * bits and therefore may be further combined with the connectivity and mask fill values using
 * bit-wise or (|), see ``FloodFillFlags``.
 *
 * Note:* Since the mask is larger than the filled image, a pixel `$$(x, y)$$` in image corresponds to the
 * pixel `$$(x+1, y+1)$$` in the mask .
 *
 * - SeeAlso ``findContours:contours:hierarchy:mode:method:offset:``
 */
+ (int)floodFill:(Mat*)image mask:(Mat*)mask seedPoint:(Point2i*)seedPoint newVal:(Scalar*)newVal rect:(Rect2i*)rect loDiff:(Scalar*)loDiff NS_SWIFT_NAME(floodFill(image:mask:seedPoint:newVal:rect:loDiff:));

/**
 * Fills a connected component with the given color.
 *
 * The function cv::floodFill fills a connected component starting from the seed point with the specified
 * color. The connectivity is determined by the color/brightness closeness of the neighbor pixels. The
 * pixel at `$$(x,y)$$` is considered to belong to the repainted domain if:
 *
 * - in case of a grayscale image and floating range
 * `$$\texttt{src} (x',y')- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} (x',y')+ \texttt{upDiff}$$`
 *
 *
 * - in case of a grayscale image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)+ \texttt{upDiff}$$`
 *
 *
 * - in case of a color image and floating range
 * `$$\texttt{src} (x',y')_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} (x',y')_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} (x',y')_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} (x',y')_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} (x',y')_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} (x',y')_b+ \texttt{upDiff} _b$$`
 *
 *
 * - in case of a color image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b+ \texttt{upDiff} _b$$`
 *
 *
 * where `$$src(x',y')$$` is the value of one of pixel neighbors that is already known to belong to the
 * component. That is, to be added to the connected component, a color/brightness of the pixel should
 * be close enough to:
 * - Color/brightness of one of its neighbors that already belong to the connected component in case
 * of a floating range.
 * - Color/brightness of the seed point in case of a fixed range.
 *
 * Use these functions to either mark a connected component with the specified color in-place, or build
 * a mask and then extract the contour, or copy the region to another image, and so on.
 *
 * @param image Input/output 1- or 3-channel, 8-bit, or floating-point image. It is modified by the
 * function unless the ``FloodFillFlags/FLOODFILL_MASK_ONLY`` flag is set in the second variant of the function. See
 * the details below.
 * @param mask Operation mask that should be a single-channel 8-bit image, 2 pixels wider and 2 pixels
 * taller than image. If an empty Mat is passed it will be created automatically. Since this is both an
 * input and output parameter, you must take responsibility of initializing it.
 * Flood-filling cannot go across non-zero pixels in the input mask. For example,
 * an edge detector output can be used as a mask to stop filling at edges. On output, pixels in the
 * mask corresponding to filled pixels in the image are set to 1 or to the specified value in flags
 * as described below. Additionally, the function fills the border of the mask with ones to simplify
 * internal processing. It is therefore possible to use the same mask in multiple calls to the function
 * to make sure the filled areas do not overlap.
 * @param seedPoint Starting point.
 * @param newVal New value of the repainted domain pixels.
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * @param rect Optional output parameter set by the function to the minimum bounding rectangle of the
 * repainted domain.
 * 4 means that only the four nearest neighbor pixels (those that share an edge) are considered. A
 * connectivity value of 8 means that the eight nearest neighbor pixels (those that share a corner)
 * will be considered. The next 8 bits (8-16) contain a value between 1 and 255 with which to fill
 * the mask (the default value is 1). For example, 4 | ( 255 \<\< 8 ) will consider 4 nearest
 * neighbours and fill the mask with a value of 255. The following additional options occupy higher
 * bits and therefore may be further combined with the connectivity and mask fill values using
 * bit-wise or (|), see ``FloodFillFlags``.
 *
 * Note:* Since the mask is larger than the filled image, a pixel `$$(x, y)$$` in image corresponds to the
 * pixel `$$(x+1, y+1)$$` in the mask .
 *
 * - SeeAlso ``findContours:contours:hierarchy:mode:method:offset:``
 */
+ (int)floodFill:(Mat*)image mask:(Mat*)mask seedPoint:(Point2i*)seedPoint newVal:(Scalar*)newVal rect:(Rect2i*)rect NS_SWIFT_NAME(floodFill(image:mask:seedPoint:newVal:rect:));

/**
 * Fills a connected component with the given color.
 *
 * The function cv::floodFill fills a connected component starting from the seed point with the specified
 * color. The connectivity is determined by the color/brightness closeness of the neighbor pixels. The
 * pixel at `$$(x,y)$$` is considered to belong to the repainted domain if:
 *
 * - in case of a grayscale image and floating range
 * `$$\texttt{src} (x',y')- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} (x',y')+ \texttt{upDiff}$$`
 *
 *
 * - in case of a grayscale image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)- \texttt{loDiff} \leq \texttt{src} (x,y)  \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)+ \texttt{upDiff}$$`
 *
 *
 * - in case of a color image and floating range
 * `$$\texttt{src} (x',y')_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} (x',y')_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} (x',y')_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} (x',y')_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} (x',y')_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} (x',y')_b+ \texttt{upDiff} _b$$`
 *
 *
 * - in case of a color image and fixed range
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r- \texttt{loDiff} _r \leq \texttt{src} (x,y)_r \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_r+ \texttt{upDiff} _r,$$`
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g- \texttt{loDiff} _g \leq \texttt{src} (x,y)_g \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_g+ \texttt{upDiff} _g$$`
 * and
 * `$$\texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b- \texttt{loDiff} _b \leq \texttt{src} (x,y)_b \leq \texttt{src} ( \texttt{seedPoint} .x, \texttt{seedPoint} .y)_b+ \texttt{upDiff} _b$$`
 *
 *
 * where `$$src(x',y')$$` is the value of one of pixel neighbors that is already known to belong to the
 * component. That is, to be added to the connected component, a color/brightness of the pixel should
 * be close enough to:
 * - Color/brightness of one of its neighbors that already belong to the connected component in case
 * of a floating range.
 * - Color/brightness of the seed point in case of a fixed range.
 *
 * Use these functions to either mark a connected component with the specified color in-place, or build
 * a mask and then extract the contour, or copy the region to another image, and so on.
 *
 * @param image Input/output 1- or 3-channel, 8-bit, or floating-point image. It is modified by the
 * function unless the ``FloodFillFlags/FLOODFILL_MASK_ONLY`` flag is set in the second variant of the function. See
 * the details below.
 * @param mask Operation mask that should be a single-channel 8-bit image, 2 pixels wider and 2 pixels
 * taller than image. If an empty Mat is passed it will be created automatically. Since this is both an
 * input and output parameter, you must take responsibility of initializing it.
 * Flood-filling cannot go across non-zero pixels in the input mask. For example,
 * an edge detector output can be used as a mask to stop filling at edges. On output, pixels in the
 * mask corresponding to filled pixels in the image are set to 1 or to the specified value in flags
 * as described below. Additionally, the function fills the border of the mask with ones to simplify
 * internal processing. It is therefore possible to use the same mask in multiple calls to the function
 * to make sure the filled areas do not overlap.
 * @param seedPoint Starting point.
 * @param newVal New value of the repainted domain pixels.
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * one of its neighbors belonging to the component, or a seed pixel being added to the component.
 * repainted domain.
 * 4 means that only the four nearest neighbor pixels (those that share an edge) are considered. A
 * connectivity value of 8 means that the eight nearest neighbor pixels (those that share a corner)
 * will be considered. The next 8 bits (8-16) contain a value between 1 and 255 with which to fill
 * the mask (the default value is 1). For example, 4 | ( 255 \<\< 8 ) will consider 4 nearest
 * neighbours and fill the mask with a value of 255. The following additional options occupy higher
 * bits and therefore may be further combined with the connectivity and mask fill values using
 * bit-wise or (|), see ``FloodFillFlags``.
 *
 * Note:* Since the mask is larger than the filled image, a pixel `$$(x, y)$$` in image corresponds to the
 * pixel `$$(x+1, y+1)$$` in the mask .
 *
 * - SeeAlso ``findContours:contours:hierarchy:mode:method:offset:``
 */
+ (int)floodFill:(Mat*)image mask:(Mat*)mask seedPoint:(Point2i*)seedPoint newVal:(Scalar*)newVal NS_SWIFT_NAME(floodFill(image:mask:seedPoint:newVal:));


//
//  void cv::blendLinear(Mat src1, Mat src2, Mat weights1, Mat weights2, Mat& dst)
//
/**
 *
 *
 * variant without `mask` parameter
 */
+ (void)blendLinear:(Mat*)src1 src2:(Mat*)src2 weights1:(Mat*)weights1 weights2:(Mat*)weights2 dst:(Mat*)dst NS_SWIFT_NAME(blendLinear(src1:src2:weights1:weights2:dst:));


//
//  void cv::alphaComposite(Mat overlay, Mat background, Mat& dst, int op = ALPHA_COMPOSITE_OVER, bool premultiplied = false)
//
/**
 * Composites two images according to their alpha channels, using a Porter-Duff operator.
 *
 * The default operator, ``AlphaCompositeOperations/ALPHA_COMPOSITE_OVER``, draws overlay on top of background and blends the two
 * according to overlay's alpha channel, so that partially-transparent pixels mix smoothly into the
 * background with no fringing at the edges. This is what is usually wanted when pasting an RGBA
 * sprite, an antialiased glyph or a segmentation mask onto a picture. The other operators of
 * ``AlphaCompositeOperations`` select the rest of the Porter-Duff set, for instance
 * ``AlphaCompositeOperations/ALPHA_COMPOSITE_ATOP`` to clip the overlay to the background's shape, or ``AlphaCompositeOperations/ALPHA_COMPOSITE_DEST_OUT``
 * to punch a hole in the background.
 *
 * Only the compositing operator is configurable. The blend mode is always *normal*: the overlay's
 * color is taken as-is and is never mixed with the background's color the way the separable blend
 * modes of the same specification (multiply, screen, overlay, darken, and so on) do. Blend modes are
 * a separate axis and are not implemented here.
 *
 * All operators are evaluated in premultiplied alpha space, where each one reduces to a pair of
 * per-pixel weights `$$F_a$$`, `$$F_b$$` listed in #AlphaCompositeOperations:
 * `$$C_o = C_s F_a + C_b F_b, \qquad \alpha_o = \alpha_s F_a + \alpha_b F_b$$`
 * with `$$C_s, \alpha_s$$` taken from overlay and `$$C_b, \alpha_b$$` from background. Inputs that
 * carry straight (unassociated) alpha are premultiplied on entry and the result is un-premultiplied
 * on exit. Both steps reuse ``Imgproc/cvtColor`` with ``ColorConversionCodes/COLOR_RGBA2mRGBA`` and ``ColorConversionCodes/COLOR_mRGBA2RGBA``, so alphaComposite
 * follows exactly the same alpha conventions as those conversions.
 *
 * @param overlay 8-bit 4-channel image (RGBA or BGRA; channel order does not matter as long as it
 * matches background) acting as the source of the operator; must be the same size as background.
 * @param background 8-bit 3-channel or 4-channel image acting as the destination of the operator. A
 * 4-channel background contributes its own alpha to the blend, using the same straight/premultiplied
 * convention as overlay, and dst has 4 channels holding the composited alpha `$$\alpha_o$$`. A
 * 3-channel background is taken to be fully opaque (`$$\alpha_b = 1$$`) and dst has 3 channels;
 * since such a dst cannot store `$$\alpha_o$$`, the alpha is dropped and the premultiplied color is
 * written, which is what Cairo does when the target surface has no alpha channel. Operators whose
 * result is not opaque (``AlphaCompositeOperations/ALPHA_COMPOSITE_CLEAR``, ``AlphaCompositeOperations/ALPHA_COMPOSITE_OUT``, ``AlphaCompositeOperations/ALPHA_COMPOSITE_XOR`` and
 * others) therefore darken toward black on a 3-channel background; pass a 4-channel background to
 * keep the alpha.
 * @param dst output image, created with the same size and type as background. It may be the same
 * array as background.
 * @param op compositing operator, one of ``AlphaCompositeOperations``.
 * @param premultiplied false (the default) if overlay's alpha (and background's, when it has one) is
 * straight/unassociated, as produced by e.g. `imread(..., IMREAD_UNCHANGED)`; true if it is already
 * premultiplied, which skips the internal conversion.
 *
 * - SeeAlso ``cvtColor:dst:code:dstCn:hint:``, COLOR_RGBA2mRGBA, COLOR_mRGBA2RGBA, ``blendLinear:src2:weights1:weights2:dst:``, addWeighted
 */
+ (void)alphaComposite:(Mat*)overlay background:(Mat*)background dst:(Mat*)dst op:(int)op premultiplied:(BOOL)premultiplied NS_SWIFT_NAME(alphaComposite(overlay:background:dst:op:premultiplied:));

/**
 * Composites two images according to their alpha channels, using a Porter-Duff operator.
 *
 * The default operator, ``AlphaCompositeOperations/ALPHA_COMPOSITE_OVER``, draws overlay on top of background and blends the two
 * according to overlay's alpha channel, so that partially-transparent pixels mix smoothly into the
 * background with no fringing at the edges. This is what is usually wanted when pasting an RGBA
 * sprite, an antialiased glyph or a segmentation mask onto a picture. The other operators of
 * ``AlphaCompositeOperations`` select the rest of the Porter-Duff set, for instance
 * ``AlphaCompositeOperations/ALPHA_COMPOSITE_ATOP`` to clip the overlay to the background's shape, or ``AlphaCompositeOperations/ALPHA_COMPOSITE_DEST_OUT``
 * to punch a hole in the background.
 *
 * Only the compositing operator is configurable. The blend mode is always *normal*: the overlay's
 * color is taken as-is and is never mixed with the background's color the way the separable blend
 * modes of the same specification (multiply, screen, overlay, darken, and so on) do. Blend modes are
 * a separate axis and are not implemented here.
 *
 * All operators are evaluated in premultiplied alpha space, where each one reduces to a pair of
 * per-pixel weights `$$F_a$$`, `$$F_b$$` listed in #AlphaCompositeOperations:
 * `$$C_o = C_s F_a + C_b F_b, \qquad \alpha_o = \alpha_s F_a + \alpha_b F_b$$`
 * with `$$C_s, \alpha_s$$` taken from overlay and `$$C_b, \alpha_b$$` from background. Inputs that
 * carry straight (unassociated) alpha are premultiplied on entry and the result is un-premultiplied
 * on exit. Both steps reuse ``Imgproc/cvtColor`` with ``ColorConversionCodes/COLOR_RGBA2mRGBA`` and ``ColorConversionCodes/COLOR_mRGBA2RGBA``, so alphaComposite
 * follows exactly the same alpha conventions as those conversions.
 *
 * @param overlay 8-bit 4-channel image (RGBA or BGRA; channel order does not matter as long as it
 * matches background) acting as the source of the operator; must be the same size as background.
 * @param background 8-bit 3-channel or 4-channel image acting as the destination of the operator. A
 * 4-channel background contributes its own alpha to the blend, using the same straight/premultiplied
 * convention as overlay, and dst has 4 channels holding the composited alpha `$$\alpha_o$$`. A
 * 3-channel background is taken to be fully opaque (`$$\alpha_b = 1$$`) and dst has 3 channels;
 * since such a dst cannot store `$$\alpha_o$$`, the alpha is dropped and the premultiplied color is
 * written, which is what Cairo does when the target surface has no alpha channel. Operators whose
 * result is not opaque (``AlphaCompositeOperations/ALPHA_COMPOSITE_CLEAR``, ``AlphaCompositeOperations/ALPHA_COMPOSITE_OUT``, ``AlphaCompositeOperations/ALPHA_COMPOSITE_XOR`` and
 * others) therefore darken toward black on a 3-channel background; pass a 4-channel background to
 * keep the alpha.
 * @param dst output image, created with the same size and type as background. It may be the same
 * array as background.
 * @param op compositing operator, one of ``AlphaCompositeOperations``.
 * straight/unassociated, as produced by e.g. `imread(..., IMREAD_UNCHANGED)`; true if it is already
 * premultiplied, which skips the internal conversion.
 *
 * - SeeAlso ``cvtColor:dst:code:dstCn:hint:``, COLOR_RGBA2mRGBA, COLOR_mRGBA2RGBA, ``blendLinear:src2:weights1:weights2:dst:``, addWeighted
 */
+ (void)alphaComposite:(Mat*)overlay background:(Mat*)background dst:(Mat*)dst op:(int)op NS_SWIFT_NAME(alphaComposite(overlay:background:dst:op:));

/**
 * Composites two images according to their alpha channels, using a Porter-Duff operator.
 *
 * The default operator, ``AlphaCompositeOperations/ALPHA_COMPOSITE_OVER``, draws overlay on top of background and blends the two
 * according to overlay's alpha channel, so that partially-transparent pixels mix smoothly into the
 * background with no fringing at the edges. This is what is usually wanted when pasting an RGBA
 * sprite, an antialiased glyph or a segmentation mask onto a picture. The other operators of
 * ``AlphaCompositeOperations`` select the rest of the Porter-Duff set, for instance
 * ``AlphaCompositeOperations/ALPHA_COMPOSITE_ATOP`` to clip the overlay to the background's shape, or ``AlphaCompositeOperations/ALPHA_COMPOSITE_DEST_OUT``
 * to punch a hole in the background.
 *
 * Only the compositing operator is configurable. The blend mode is always *normal*: the overlay's
 * color is taken as-is and is never mixed with the background's color the way the separable blend
 * modes of the same specification (multiply, screen, overlay, darken, and so on) do. Blend modes are
 * a separate axis and are not implemented here.
 *
 * All operators are evaluated in premultiplied alpha space, where each one reduces to a pair of
 * per-pixel weights `$$F_a$$`, `$$F_b$$` listed in #AlphaCompositeOperations:
 * `$$C_o = C_s F_a + C_b F_b, \qquad \alpha_o = \alpha_s F_a + \alpha_b F_b$$`
 * with `$$C_s, \alpha_s$$` taken from overlay and `$$C_b, \alpha_b$$` from background. Inputs that
 * carry straight (unassociated) alpha are premultiplied on entry and the result is un-premultiplied
 * on exit. Both steps reuse ``Imgproc/cvtColor`` with ``ColorConversionCodes/COLOR_RGBA2mRGBA`` and ``ColorConversionCodes/COLOR_mRGBA2RGBA``, so alphaComposite
 * follows exactly the same alpha conventions as those conversions.
 *
 * @param overlay 8-bit 4-channel image (RGBA or BGRA; channel order does not matter as long as it
 * matches background) acting as the source of the operator; must be the same size as background.
 * @param background 8-bit 3-channel or 4-channel image acting as the destination of the operator. A
 * 4-channel background contributes its own alpha to the blend, using the same straight/premultiplied
 * convention as overlay, and dst has 4 channels holding the composited alpha `$$\alpha_o$$`. A
 * 3-channel background is taken to be fully opaque (`$$\alpha_b = 1$$`) and dst has 3 channels;
 * since such a dst cannot store `$$\alpha_o$$`, the alpha is dropped and the premultiplied color is
 * written, which is what Cairo does when the target surface has no alpha channel. Operators whose
 * result is not opaque (``AlphaCompositeOperations/ALPHA_COMPOSITE_CLEAR``, ``AlphaCompositeOperations/ALPHA_COMPOSITE_OUT``, ``AlphaCompositeOperations/ALPHA_COMPOSITE_XOR`` and
 * others) therefore darken toward black on a 3-channel background; pass a 4-channel background to
 * keep the alpha.
 * @param dst output image, created with the same size and type as background. It may be the same
 * array as background.
 * straight/unassociated, as produced by e.g. `imread(..., IMREAD_UNCHANGED)`; true if it is already
 * premultiplied, which skips the internal conversion.
 *
 * - SeeAlso ``cvtColor:dst:code:dstCn:hint:``, COLOR_RGBA2mRGBA, COLOR_mRGBA2RGBA, ``blendLinear:src2:weights1:weights2:dst:``, addWeighted
 */
+ (void)alphaComposite:(Mat*)overlay background:(Mat*)background dst:(Mat*)dst NS_SWIFT_NAME(alphaComposite(overlay:background:dst:));


//
//  void cv::cvtColor(Mat src, Mat& dst, ColorConversionCodes code, int dstCn = 0, AlgorithmHint hint = cv::ALGO_HINT_DEFAULT)
//
/**
 * Converts an image from one color space to another.
 *
 * The function converts an input image from one color space to another. In case of a transformation
 * to-from RGB color space, the order of the channels should be specified explicitly (RGB or BGR). Note
 * that the default color format in OpenCV is often referred to as RGB but it is actually BGR (the
 * bytes are reversed). So the first byte in a standard (24-bit) color image will be an 8-bit Blue
 * component, the second byte will be Green, and the third byte will be Red. The fourth, fifth, and
 * sixth bytes would then be the second pixel (Blue, then Green, then Red), and so on.
 *
 * The conventional ranges for R, G, and B channel values are:
 * -   0 to 255 for CV_8U images
 * -   0 to 65535 for CV_16U images
 * -   0 to 1 for CV_32F images
 *
 * In case of linear transformations, the range does not matter. But in case of a non-linear
 * transformation, an input RGB image should be normalized to the proper value range to get the correct
 * results, for example, for RGB `$$\rightarrow$$` L\*u\*v\* transformation. For example, if you have a
 * 32-bit floating-point image directly converted from an 8-bit image without any scaling, then it will
 * have the 0..255 value range instead of 0..1 assumed by the function. So, before calling *cvtColor* ,
 * you need first to scale the image down:
 *
 *     img *= 1./255;
 *     cvtColor(img, img, COLOR_BGR2Luv);
 *
 * If you use *cvtColor* with 8-bit images, the conversion will have some information lost. For many
 * applications, this will not be noticeable but it is recommended to use 32-bit images in applications
 * that need the full range of colors or that convert an image before an operation and then convert
 * back.
 *
 * If conversion adds the alpha channel, its value will set to the maximum of corresponding channel
 * range: 255 for CV_8U, 65535 for CV_16U, 1 for CV_32F.
 *
 * @param src input image: 8-bit unsigned, 16-bit unsigned ( CV_16UC... ), or single-precision
 * floating-point.
 * @param dst output image of the same size and depth as src.
 * @param code color space conversion code (see ``ColorConversionCodes``).
 * @param dstCn number of channels in the destination image; if the parameter is 0, the number of the
 * channels is derived automatically from src and code.
 * @param hint Implementation modification flags. See ``AlgorithmHint``
 *
 * Note:* The source image (src) must be of an appropriate type for the desired color conversion. see ColorConversionCodes
 * - SeeAlso *Ref:* imgproc_color_conversions
 */
+ (void)cvtColor:(Mat*)src dst:(Mat*)dst code:(ColorConversionCodes)code dstCn:(int)dstCn hint:(AlgorithmHint)hint NS_SWIFT_NAME(cvtColor(src:dst:code:dstCn:hint:));

/**
 * Converts an image from one color space to another.
 *
 * The function converts an input image from one color space to another. In case of a transformation
 * to-from RGB color space, the order of the channels should be specified explicitly (RGB or BGR). Note
 * that the default color format in OpenCV is often referred to as RGB but it is actually BGR (the
 * bytes are reversed). So the first byte in a standard (24-bit) color image will be an 8-bit Blue
 * component, the second byte will be Green, and the third byte will be Red. The fourth, fifth, and
 * sixth bytes would then be the second pixel (Blue, then Green, then Red), and so on.
 *
 * The conventional ranges for R, G, and B channel values are:
 * -   0 to 255 for CV_8U images
 * -   0 to 65535 for CV_16U images
 * -   0 to 1 for CV_32F images
 *
 * In case of linear transformations, the range does not matter. But in case of a non-linear
 * transformation, an input RGB image should be normalized to the proper value range to get the correct
 * results, for example, for RGB `$$\rightarrow$$` L\*u\*v\* transformation. For example, if you have a
 * 32-bit floating-point image directly converted from an 8-bit image without any scaling, then it will
 * have the 0..255 value range instead of 0..1 assumed by the function. So, before calling *cvtColor* ,
 * you need first to scale the image down:
 *
 *     img *= 1./255;
 *     cvtColor(img, img, COLOR_BGR2Luv);
 *
 * If you use *cvtColor* with 8-bit images, the conversion will have some information lost. For many
 * applications, this will not be noticeable but it is recommended to use 32-bit images in applications
 * that need the full range of colors or that convert an image before an operation and then convert
 * back.
 *
 * If conversion adds the alpha channel, its value will set to the maximum of corresponding channel
 * range: 255 for CV_8U, 65535 for CV_16U, 1 for CV_32F.
 *
 * @param src input image: 8-bit unsigned, 16-bit unsigned ( CV_16UC... ), or single-precision
 * floating-point.
 * @param dst output image of the same size and depth as src.
 * @param code color space conversion code (see ``ColorConversionCodes``).
 * @param dstCn number of channels in the destination image; if the parameter is 0, the number of the
 * channels is derived automatically from src and code.
 *
 * Note:* The source image (src) must be of an appropriate type for the desired color conversion. see ColorConversionCodes
 * - SeeAlso *Ref:* imgproc_color_conversions
 */
+ (void)cvtColor:(Mat*)src dst:(Mat*)dst code:(ColorConversionCodes)code dstCn:(int)dstCn NS_SWIFT_NAME(cvtColor(src:dst:code:dstCn:));

/**
 * Converts an image from one color space to another.
 *
 * The function converts an input image from one color space to another. In case of a transformation
 * to-from RGB color space, the order of the channels should be specified explicitly (RGB or BGR). Note
 * that the default color format in OpenCV is often referred to as RGB but it is actually BGR (the
 * bytes are reversed). So the first byte in a standard (24-bit) color image will be an 8-bit Blue
 * component, the second byte will be Green, and the third byte will be Red. The fourth, fifth, and
 * sixth bytes would then be the second pixel (Blue, then Green, then Red), and so on.
 *
 * The conventional ranges for R, G, and B channel values are:
 * -   0 to 255 for CV_8U images
 * -   0 to 65535 for CV_16U images
 * -   0 to 1 for CV_32F images
 *
 * In case of linear transformations, the range does not matter. But in case of a non-linear
 * transformation, an input RGB image should be normalized to the proper value range to get the correct
 * results, for example, for RGB `$$\rightarrow$$` L\*u\*v\* transformation. For example, if you have a
 * 32-bit floating-point image directly converted from an 8-bit image without any scaling, then it will
 * have the 0..255 value range instead of 0..1 assumed by the function. So, before calling *cvtColor* ,
 * you need first to scale the image down:
 *
 *     img *= 1./255;
 *     cvtColor(img, img, COLOR_BGR2Luv);
 *
 * If you use *cvtColor* with 8-bit images, the conversion will have some information lost. For many
 * applications, this will not be noticeable but it is recommended to use 32-bit images in applications
 * that need the full range of colors or that convert an image before an operation and then convert
 * back.
 *
 * If conversion adds the alpha channel, its value will set to the maximum of corresponding channel
 * range: 255 for CV_8U, 65535 for CV_16U, 1 for CV_32F.
 *
 * @param src input image: 8-bit unsigned, 16-bit unsigned ( CV_16UC... ), or single-precision
 * floating-point.
 * @param dst output image of the same size and depth as src.
 * @param code color space conversion code (see ``ColorConversionCodes``).
 * channels is derived automatically from src and code.
 *
 * Note:* The source image (src) must be of an appropriate type for the desired color conversion. see ColorConversionCodes
 * - SeeAlso *Ref:* imgproc_color_conversions
 */
+ (void)cvtColor:(Mat*)src dst:(Mat*)dst code:(ColorConversionCodes)code NS_SWIFT_NAME(cvtColor(src:dst:code:));


//
//  void cv::cvtColorTwoPlane(Mat src1, Mat src2, Mat& dst, int code, AlgorithmHint hint = cv::ALGO_HINT_DEFAULT)
//
/**
 * Converts an image from one color space to another where the source image is
 * stored in two planes.
 *
 * This function only supports YUV420 to RGB conversion as of now.
 *
 * @param src1 8-bit image (#CV_8U) of the Y plane.
 * @param src2 image containing interleaved U/V plane.
 * @param dst output image.
 * @param code Specifies the type of conversion. It can take any of the following values:
 * - ``ColorConversionCodes/COLOR_YUV2BGR_NV12``
 * - ``ColorConversionCodes/COLOR_YUV2RGB_NV12``
 * - ``ColorConversionCodes/COLOR_YUV2BGRA_NV12``
 * - ``ColorConversionCodes/COLOR_YUV2RGBA_NV12``
 * - ``ColorConversionCodes/COLOR_YUV2BGR_NV21``
 * - ``ColorConversionCodes/COLOR_YUV2RGB_NV21``
 * - ``ColorConversionCodes/COLOR_YUV2BGRA_NV21``
 * - ``ColorConversionCodes/COLOR_YUV2RGBA_NV21``
 * @param hint Implementation modification flags. See ``AlgorithmHint``
 */
+ (void)cvtColorTwoPlane:(Mat*)src1 src2:(Mat*)src2 dst:(Mat*)dst code:(int)code hint:(AlgorithmHint)hint NS_SWIFT_NAME(cvtColorTwoPlane(src1:src2:dst:code:hint:));

/**
 * Converts an image from one color space to another where the source image is
 * stored in two planes.
 *
 * This function only supports YUV420 to RGB conversion as of now.
 *
 * @param src1 8-bit image (#CV_8U) of the Y plane.
 * @param src2 image containing interleaved U/V plane.
 * @param dst output image.
 * @param code Specifies the type of conversion. It can take any of the following values:
 * - ``ColorConversionCodes/COLOR_YUV2BGR_NV12``
 * - ``ColorConversionCodes/COLOR_YUV2RGB_NV12``
 * - ``ColorConversionCodes/COLOR_YUV2BGRA_NV12``
 * - ``ColorConversionCodes/COLOR_YUV2RGBA_NV12``
 * - ``ColorConversionCodes/COLOR_YUV2BGR_NV21``
 * - ``ColorConversionCodes/COLOR_YUV2RGB_NV21``
 * - ``ColorConversionCodes/COLOR_YUV2BGRA_NV21``
 * - ``ColorConversionCodes/COLOR_YUV2RGBA_NV21``
 */
+ (void)cvtColorTwoPlane:(Mat*)src1 src2:(Mat*)src2 dst:(Mat*)dst code:(int)code NS_SWIFT_NAME(cvtColorTwoPlane(src1:src2:dst:code:));


//
//  void cv::demosaicing(Mat src, Mat& dst, int code, int dstCn = 0)
//
/**
 * main function for all demosaicing processes
 *
 * @param src input image: 8-bit unsigned or 16-bit unsigned.
 * @param dst output image of the same size and depth as src.
 * @param code Color space conversion code (see the description below).
 * @param dstCn number of channels in the destination image; if the parameter is 0, the number of the
 * channels is derived automatically from src and code.
 *
 * The function can do the following transformations:
 *
 * -   Demosaicing using bilinear interpolation
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2BGR`` , ``ColorConversionCodes/COLOR_BayerGB2BGR`` , ``ColorConversionCodes/COLOR_BayerRG2BGR`` , ``ColorConversionCodes/COLOR_BayerGR2BGR``
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2GRAY`` , ``ColorConversionCodes/COLOR_BayerGB2GRAY`` , ``ColorConversionCodes/COLOR_BayerRG2GRAY`` , ``ColorConversionCodes/COLOR_BayerGR2GRAY``
 *
 * -   Demosaicing using Variable Number of Gradients.
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2BGR_VNG`` , ``ColorConversionCodes/COLOR_BayerGB2BGR_VNG`` , ``ColorConversionCodes/COLOR_BayerRG2BGR_VNG`` , ``ColorConversionCodes/COLOR_BayerGR2BGR_VNG``
 *
 * -   Edge-Aware Demosaicing.
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2BGR_EA`` , ``ColorConversionCodes/COLOR_BayerGB2BGR_EA`` , ``ColorConversionCodes/COLOR_BayerRG2BGR_EA`` , ``ColorConversionCodes/COLOR_BayerGR2BGR_EA``
 *
 * -   Demosaicing with alpha channel
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2BGRA`` , ``ColorConversionCodes/COLOR_BayerGB2BGRA`` , ``ColorConversionCodes/COLOR_BayerRG2BGRA`` , ``ColorConversionCodes/COLOR_BayerGR2BGRA``
 *
 * Note:* The source image (src) must be of an appropriate type for the desired color conversion. see ColorConversionCodes
 * - SeeAlso ``cvtColor:dst:code:dstCn:hint:``
 */
+ (void)demosaicing:(Mat*)src dst:(Mat*)dst code:(int)code dstCn:(int)dstCn NS_SWIFT_NAME(demosaicing(src:dst:code:dstCn:));

/**
 * main function for all demosaicing processes
 *
 * @param src input image: 8-bit unsigned or 16-bit unsigned.
 * @param dst output image of the same size and depth as src.
 * @param code Color space conversion code (see the description below).
 * channels is derived automatically from src and code.
 *
 * The function can do the following transformations:
 *
 * -   Demosaicing using bilinear interpolation
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2BGR`` , ``ColorConversionCodes/COLOR_BayerGB2BGR`` , ``ColorConversionCodes/COLOR_BayerRG2BGR`` , ``ColorConversionCodes/COLOR_BayerGR2BGR``
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2GRAY`` , ``ColorConversionCodes/COLOR_BayerGB2GRAY`` , ``ColorConversionCodes/COLOR_BayerRG2GRAY`` , ``ColorConversionCodes/COLOR_BayerGR2GRAY``
 *
 * -   Demosaicing using Variable Number of Gradients.
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2BGR_VNG`` , ``ColorConversionCodes/COLOR_BayerGB2BGR_VNG`` , ``ColorConversionCodes/COLOR_BayerRG2BGR_VNG`` , ``ColorConversionCodes/COLOR_BayerGR2BGR_VNG``
 *
 * -   Edge-Aware Demosaicing.
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2BGR_EA`` , ``ColorConversionCodes/COLOR_BayerGB2BGR_EA`` , ``ColorConversionCodes/COLOR_BayerRG2BGR_EA`` , ``ColorConversionCodes/COLOR_BayerGR2BGR_EA``
 *
 * -   Demosaicing with alpha channel
 *
 *     ``ColorConversionCodes/COLOR_BayerBG2BGRA`` , ``ColorConversionCodes/COLOR_BayerGB2BGRA`` , ``ColorConversionCodes/COLOR_BayerRG2BGRA`` , ``ColorConversionCodes/COLOR_BayerGR2BGRA``
 *
 * Note:* The source image (src) must be of an appropriate type for the desired color conversion. see ColorConversionCodes
 * - SeeAlso ``cvtColor:dst:code:dstCn:hint:``
 */
+ (void)demosaicing:(Mat*)src dst:(Mat*)dst code:(int)code NS_SWIFT_NAME(demosaicing(src:dst:code:));


//
//  void cv::matchTemplate(Mat image, Mat templ, Mat& result, TemplateMatchModes method, Mat mask = Mat())
//
/**
 * Compares a template against overlapped image regions.
 *
 * The function slides through image , compares the overlapped patches of size `$$w \times h$$` against
 * templ using the specified method and stores the comparison results in result . ``TemplateMatchModes``
 * describes the formulae for the available comparison methods ( `$$I$$` denotes image, `$$T$$`
 * template, `$$R$$` result, `$$M$$` the optional mask ). The summation is done over template and/or
 * the image patch: `$$x' = 0...w-1, y' = 0...h-1$$`
 *
 * After the function finishes the comparison, the best matches can be found as global minimums (when
 * ``TemplateMatchModes/TM_SQDIFF`` was used) or maximums (when ``TemplateMatchModes/TM_CCORR`` or ``TemplateMatchModes/TM_CCOEFF`` was used) using the
 * ``Core/minMaxLoc`` function. In case of a color image, template summation in the numerator and each sum in
 * the denominator is done over all of the channels and separate mean values are used for each channel.
 * That is, the function can take a color template and a color image. The result will still be a
 * single-channel image, which is easier to analyze.
 *
 * @param image Image where the search is running. It must be 8-bit or 32-bit floating-point.
 * @param templ Searched template. It must be not greater than the source image and have the same
 * data type.
 * @param result Map of comparison results. It must be single-channel 32-bit floating-point. If image
 * is `$$W \times H$$` and templ is `$$w \times h$$` , then result is `$$(W-w+1) \times (H-h+1)$$` .
 * @param method Parameter specifying the comparison method, see ``TemplateMatchModes``
 * @param mask Optional mask. It must have the same size as templ. It must either have the same number
 *             of channels as template or only one channel, which is then used for all template and
 *             image channels. If the data type is #CV_8U, the mask is interpreted as a binary mask,
 *             meaning only elements where mask is nonzero are used and are kept unchanged independent
 *             of the actual mask value (weight equals 1). For data type #CV_32F, the mask values are
 *             used as weights. The exact formulas are documented in ``TemplateMatchModes``.
 */
+ (void)matchTemplate:(Mat*)image templ:(Mat*)templ result:(Mat*)result method:(TemplateMatchModes)method mask:(Mat*)mask NS_SWIFT_NAME(matchTemplate(image:templ:result:method:mask:));

/**
 * Compares a template against overlapped image regions.
 *
 * The function slides through image , compares the overlapped patches of size `$$w \times h$$` against
 * templ using the specified method and stores the comparison results in result . ``TemplateMatchModes``
 * describes the formulae for the available comparison methods ( `$$I$$` denotes image, `$$T$$`
 * template, `$$R$$` result, `$$M$$` the optional mask ). The summation is done over template and/or
 * the image patch: `$$x' = 0...w-1, y' = 0...h-1$$`
 *
 * After the function finishes the comparison, the best matches can be found as global minimums (when
 * ``TemplateMatchModes/TM_SQDIFF`` was used) or maximums (when ``TemplateMatchModes/TM_CCORR`` or ``TemplateMatchModes/TM_CCOEFF`` was used) using the
 * ``Core/minMaxLoc`` function. In case of a color image, template summation in the numerator and each sum in
 * the denominator is done over all of the channels and separate mean values are used for each channel.
 * That is, the function can take a color template and a color image. The result will still be a
 * single-channel image, which is easier to analyze.
 *
 * @param image Image where the search is running. It must be 8-bit or 32-bit floating-point.
 * @param templ Searched template. It must be not greater than the source image and have the same
 * data type.
 * @param result Map of comparison results. It must be single-channel 32-bit floating-point. If image
 * is `$$W \times H$$` and templ is `$$w \times h$$` , then result is `$$(W-w+1) \times (H-h+1)$$` .
 * @param method Parameter specifying the comparison method, see ``TemplateMatchModes``
 *             of channels as template or only one channel, which is then used for all template and
 *             image channels. If the data type is #CV_8U, the mask is interpreted as a binary mask,
 *             meaning only elements where mask is nonzero are used and are kept unchanged independent
 *             of the actual mask value (weight equals 1). For data type #CV_32F, the mask values are
 *             used as weights. The exact formulas are documented in ``TemplateMatchModes``.
 */
+ (void)matchTemplate:(Mat*)image templ:(Mat*)templ result:(Mat*)result method:(TemplateMatchModes)method NS_SWIFT_NAME(matchTemplate(image:templ:result:method:));


//
//  int cv::connectedComponents(Mat image, Mat& labels, int connectivity, int ltype, int ccltype)
//
/**
 * computes the connected components labeled image of boolean image
 *
 * image with 4 or 8 way connectivity - returns N, the total number of labels [0, N-1] where 0
 * represents the background label. ltype specifies the output label image type, an important
 * consideration based on the total number of labels or alternatively the total number of pixels in
 * the source image. ccltype specifies the connected components labeling algorithm to use, currently
 * Bolelli (Spaghetti) *Cite:* Bolelli2019, Grana (BBDT) *Cite:* Grana2010 and Wu's (SAUF) *Cite:* Wu2009 algorithms
 * are supported, see the ``ConnectedComponentsAlgorithmsTypes`` for details. Note that SAUF algorithm forces
 * a row major ordering of labels while Spaghetti and BBDT do not.
 * This function uses parallel version of the algorithms if at least one allowed
 * parallel framework is enabled and if the rows of the image are at least twice the number returned by ``Core/getNumberOfCPUs``.
 *
 * @param image the 8-bit single-channel image to be labeled
 * @param labels destination labeled image
 * @param connectivity 8 or 4 for 8-way or 4-way connectivity respectively
 * @param ltype output image label type. Currently CV_32S and CV_16U are supported.
 * @param ccltype connected components algorithm type (see the ``ConnectedComponentsAlgorithmsTypes``).
 */
+ (int)connectedComponentsWithAlgorithm:(Mat*)image labels:(Mat*)labels connectivity:(int)connectivity ltype:(int)ltype ccltype:(int)ccltype NS_SWIFT_NAME(connectedComponents(image:labels:connectivity:ltype:ccltype:));


//
//  int cv::connectedComponents(Mat image, Mat& labels, int connectivity = 8, int ltype = CV_32S)
//
/**
 *
 *
 * @param image the 8-bit single-channel image to be labeled
 * @param labels destination labeled image
 * @param connectivity 8 or 4 for 8-way or 4-way connectivity respectively
 * @param ltype output image label type. Currently CV_32S and CV_16U are supported.
 */
+ (int)connectedComponents:(Mat*)image labels:(Mat*)labels connectivity:(int)connectivity ltype:(int)ltype NS_SWIFT_NAME(connectedComponents(image:labels:connectivity:ltype:));

/**
 *
 *
 * @param image the 8-bit single-channel image to be labeled
 * @param labels destination labeled image
 * @param connectivity 8 or 4 for 8-way or 4-way connectivity respectively
 */
+ (int)connectedComponents:(Mat*)image labels:(Mat*)labels connectivity:(int)connectivity NS_SWIFT_NAME(connectedComponents(image:labels:connectivity:));

/**
 *
 *
 * @param image the 8-bit single-channel image to be labeled
 * @param labels destination labeled image
 */
+ (int)connectedComponents:(Mat*)image labels:(Mat*)labels NS_SWIFT_NAME(connectedComponents(image:labels:));


//
//  int cv::connectedComponentsWithStats(Mat image, Mat& labels, Mat& stats, Mat& centroids, int connectivity, int ltype, ConnectedComponentsAlgorithmsTypes ccltype)
//
/**
 * computes the connected components labeled image of boolean image and also produces a statistics output for each label
 *
 * image with 4 or 8 way connectivity - returns N, the total number of labels [0, N-1] where 0
 * represents the background label. ltype specifies the output label image type, an important
 * consideration based on the total number of labels or alternatively the total number of pixels in
 * the source image. ccltype specifies the connected components labeling algorithm to use, currently
 * Bolelli (Spaghetti) *Cite:* Bolelli2019, Grana (BBDT) *Cite:* Grana2010 and Wu's (SAUF) *Cite:* Wu2009 algorithms
 * are supported, see the ``ConnectedComponentsAlgorithmsTypes`` for details. Note that SAUF algorithm forces
 * a row major ordering of labels while Spaghetti and BBDT do not.
 * This function uses parallel version of the algorithms (statistics included) if at least one allowed
 * parallel framework is enabled and if the rows of the image are at least twice the number returned by ``Core/getNumberOfCPUs``.
 *
 * @param image the 8-bit single-channel image to be labeled
 * @param labels destination labeled image
 * @param stats statistics output for each label, including the background label.
 * Statistics are accessed via stats(label, COLUMN) where COLUMN is one of
 * ``ConnectedComponentsTypes``, selecting the statistic. The data type is CV_32S.
 * @param centroids centroid output for each label, including the background label. Centroids are
 * accessed via centroids(label, 0) for x and centroids(label, 1) for y. The data type CV_64F.
 * @param connectivity 8 or 4 for 8-way or 4-way connectivity respectively
 * @param ltype output image label type. Currently CV_32S and CV_16U are supported.
 * @param ccltype connected components algorithm type (see ``ConnectedComponentsAlgorithmsTypes``).
 */
+ (int)connectedComponentsWithStatsWithAlgorithm:(Mat*)image labels:(Mat*)labels stats:(Mat*)stats centroids:(Mat*)centroids connectivity:(int)connectivity ltype:(int)ltype ccltype:(ConnectedComponentsAlgorithmsTypes)ccltype NS_SWIFT_NAME(connectedComponentsWithStats(image:labels:stats:centroids:connectivity:ltype:ccltype:));


//
//  int cv::connectedComponentsWithStats(Mat image, Mat& labels, Mat& stats, Mat& centroids, int connectivity = 8, int ltype = CV_32S)
//
/**
 *
 * @param image the 8-bit single-channel image to be labeled
 * @param labels destination labeled image
 * @param stats statistics output for each label, including the background label.
 * Statistics are accessed via stats(label, COLUMN) where COLUMN is one of
 * ``ConnectedComponentsTypes``, selecting the statistic. The data type is CV_32S.
 * @param centroids centroid output for each label, including the background label. Centroids are
 * accessed via centroids(label, 0) for x and centroids(label, 1) for y. The data type CV_64F.
 * @param connectivity 8 or 4 for 8-way or 4-way connectivity respectively
 * @param ltype output image label type. Currently CV_32S and CV_16U are supported.
 */
+ (int)connectedComponentsWithStats:(Mat*)image labels:(Mat*)labels stats:(Mat*)stats centroids:(Mat*)centroids connectivity:(int)connectivity ltype:(int)ltype NS_SWIFT_NAME(connectedComponentsWithStats(image:labels:stats:centroids:connectivity:ltype:));

/**
 *
 * @param image the 8-bit single-channel image to be labeled
 * @param labels destination labeled image
 * @param stats statistics output for each label, including the background label.
 * Statistics are accessed via stats(label, COLUMN) where COLUMN is one of
 * ``ConnectedComponentsTypes``, selecting the statistic. The data type is CV_32S.
 * @param centroids centroid output for each label, including the background label. Centroids are
 * accessed via centroids(label, 0) for x and centroids(label, 1) for y. The data type CV_64F.
 * @param connectivity 8 or 4 for 8-way or 4-way connectivity respectively
 */
+ (int)connectedComponentsWithStats:(Mat*)image labels:(Mat*)labels stats:(Mat*)stats centroids:(Mat*)centroids connectivity:(int)connectivity NS_SWIFT_NAME(connectedComponentsWithStats(image:labels:stats:centroids:connectivity:));

/**
 *
 * @param image the 8-bit single-channel image to be labeled
 * @param labels destination labeled image
 * @param stats statistics output for each label, including the background label.
 * Statistics are accessed via stats(label, COLUMN) where COLUMN is one of
 * ``ConnectedComponentsTypes``, selecting the statistic. The data type is CV_32S.
 * @param centroids centroid output for each label, including the background label. Centroids are
 * accessed via centroids(label, 0) for x and centroids(label, 1) for y. The data type CV_64F.
 */
+ (int)connectedComponentsWithStats:(Mat*)image labels:(Mat*)labels stats:(Mat*)stats centroids:(Mat*)centroids NS_SWIFT_NAME(connectedComponentsWithStats(image:labels:stats:centroids:));


//
//  void cv::findContours(Mat image, vector_vector_Point& contours, Mat& hierarchy, RetrievalModes mode, ContourApproximationModes method, Point offset = Point())
//
/**
 * Finds contours in a binary image.
 *
 * The function retrieves contours from the binary image. The contours
 * are a useful tool for shape analysis and object detection and recognition. See squares.cpp in the
 * OpenCV sample directory.
 *
 * Note:* Since OpenCV 4.14, when mode is ``RetrievalModes/RETR_LIST`` and no hierarchy is requested, this function
 * automatically uses the TRUCO parallel algorithm *Cite:* TRUCO2026, a scalable lock-free method for
 * contour extraction. In all other cases, the sequential *Cite:* Suzuki85 algorithm is used.
 *
 * Note:* Since opencv 3.2 source image is not modified by this function.
 *
 * @param image Source, an 8-bit single-channel image. Non-zero pixels are treated as 1's. Zero
 * pixels remain 0's, so the image is treated as binary . You can use ``Core/compare``, ``Core/inRange``, ``Imgproc/threshold`` ,
 * ``Imgproc/adaptiveThreshold``, ``Imgproc/Canny``, and others to create a binary image out of a grayscale or color one.
 * If mode equals to ``RetrievalModes/RETR_CCOMP`` or ``RetrievalModes/RETR_FLOODFILL``, the input can also be a 32-bit integer image of labels (CV_32SC1).
 * @param contours Detected contours. Each contour is stored as a vector of points (e.g.
 * std::vector<std::vector<cv::Point> >).
 * @param hierarchy Optional output vector (e.g. std::vector<cv::Vec4i>), containing information about the image topology. It has
 * as many elements as the number of contours. For each i-th contour contours[i], the elements
 * hierarchy[i][0] , hierarchy[i][1] , hierarchy[i][2] , and hierarchy[i][3] are set to 0-based indices
 * in contours of the next and previous contours at the same hierarchical level, the first child
 * contour and the parent contour, respectively. If for the contour i there are no next, previous,
 * parent, or nested contours, the corresponding elements of hierarchy[i] will be negative.
 * Note:* In Python, hierarchy is nested inside a top level array. Use hierarchy[0][i] to access hierarchical elements of i-th contour.
 * @param mode Contour retrieval mode, see ``RetrievalModes``
 * @param method Contour approximation method, see ``ContourApproximationModes``
 * @param offset Optional offset by which every contour point is shifted. This is useful if the
 * contours are extracted from the image ROI and then they should be analyzed in the whole image
 * context.
 */
+ (void)findContours:(Mat*)image contours:(NSMutableArray<NSMutableArray<Point2i*>*>*)contours hierarchy:(Mat*)hierarchy mode:(RetrievalModes)mode method:(ContourApproximationModes)method offset:(Point2i*)offset NS_SWIFT_NAME(findContours(image:contours:hierarchy:mode:method:offset:));

/**
 * Finds contours in a binary image.
 *
 * The function retrieves contours from the binary image. The contours
 * are a useful tool for shape analysis and object detection and recognition. See squares.cpp in the
 * OpenCV sample directory.
 *
 * Note:* Since OpenCV 4.14, when mode is ``RetrievalModes/RETR_LIST`` and no hierarchy is requested, this function
 * automatically uses the TRUCO parallel algorithm *Cite:* TRUCO2026, a scalable lock-free method for
 * contour extraction. In all other cases, the sequential *Cite:* Suzuki85 algorithm is used.
 *
 * Note:* Since opencv 3.2 source image is not modified by this function.
 *
 * @param image Source, an 8-bit single-channel image. Non-zero pixels are treated as 1's. Zero
 * pixels remain 0's, so the image is treated as binary . You can use ``Core/compare``, ``Core/inRange``, ``Imgproc/threshold`` ,
 * ``Imgproc/adaptiveThreshold``, ``Imgproc/Canny``, and others to create a binary image out of a grayscale or color one.
 * If mode equals to ``RetrievalModes/RETR_CCOMP`` or ``RetrievalModes/RETR_FLOODFILL``, the input can also be a 32-bit integer image of labels (CV_32SC1).
 * @param contours Detected contours. Each contour is stored as a vector of points (e.g.
 * std::vector<std::vector<cv::Point> >).
 * @param hierarchy Optional output vector (e.g. std::vector<cv::Vec4i>), containing information about the image topology. It has
 * as many elements as the number of contours. For each i-th contour contours[i], the elements
 * hierarchy[i][0] , hierarchy[i][1] , hierarchy[i][2] , and hierarchy[i][3] are set to 0-based indices
 * in contours of the next and previous contours at the same hierarchical level, the first child
 * contour and the parent contour, respectively. If for the contour i there are no next, previous,
 * parent, or nested contours, the corresponding elements of hierarchy[i] will be negative.
 * Note:* In Python, hierarchy is nested inside a top level array. Use hierarchy[0][i] to access hierarchical elements of i-th contour.
 * @param mode Contour retrieval mode, see ``RetrievalModes``
 * @param method Contour approximation method, see ``ContourApproximationModes``
 * contours are extracted from the image ROI and then they should be analyzed in the whole image
 * context.
 */
+ (void)findContours:(Mat*)image contours:(NSMutableArray<NSMutableArray<Point2i*>*>*)contours hierarchy:(Mat*)hierarchy mode:(RetrievalModes)mode method:(ContourApproximationModes)method NS_SWIFT_NAME(findContours(image:contours:hierarchy:mode:method:));


//
//  void cv::findContoursLinkRuns(Mat image, vector_Mat& contours, Mat& hierarchy)
//
+ (void)findContoursLinkRuns:(Mat*)image contours:(NSMutableArray<Mat*>*)contours hierarchy:(Mat*)hierarchy NS_SWIFT_NAME(findContoursLinkRuns(image:contours:hierarchy:));


//
//  void cv::findContoursLinkRuns(Mat image, vector_Mat& contours)
//
+ (void)findContoursLinkRuns:(Mat*)image contours:(NSMutableArray<Mat*>*)contours NS_SWIFT_NAME(findContoursLinkRuns(image:contours:));


//
//  Ptr_GeneralizedHoughBallard cv::createGeneralizedHoughBallard()
//
/**
 * Creates a smart pointer to a cv::GeneralizedHoughBallard class and initializes it.
 */
+ (GeneralizedHoughBallard*)createGeneralizedHoughBallard NS_SWIFT_NAME(createGeneralizedHoughBallard());


//
//  Ptr_GeneralizedHoughGuil cv::createGeneralizedHoughGuil()
//
/**
 * Creates a smart pointer to a cv::GeneralizedHoughGuil class and initializes it.
 */
+ (GeneralizedHoughGuil*)createGeneralizedHoughGuil NS_SWIFT_NAME(createGeneralizedHoughGuil());


//
//  void cv::applyColorMap(Mat src, Mat& dst, ColormapTypes colormap)
//
/**
 * Applies a GNU Octave/MATLAB equivalent colormap on a given image.
 *
 * @param src The source image, grayscale or colored of type CV_8UC1 or CV_8UC3. If CV_8UC3, then the CV_8UC1 image is generated internally using cv::COLOR_BGR2GRAY.
 * @param dst The result is the colormapped source image. Note: Mat::create is called on dst.
 * @param colormap The colormap to apply, see ``ColormapTypes``
 */
+ (void)applyColorMap:(Mat*)src dst:(Mat*)dst colormap:(ColormapTypes)colormap NS_SWIFT_NAME(applyColorMap(src:dst:colormap:));


//
//  void cv::applyColorMap(Mat src, Mat& dst, Mat userColor)
//
/**
 * Applies a user colormap on a given image.
 *
 * @param src The source image, grayscale or colored of type CV_8UC1 or CV_8UC3. If CV_8UC3, then the CV_8UC1 image is generated internally using cv::COLOR_BGR2GRAY.
 * @param dst The result is the colormapped source image of the same number of channels as userColor. Note: Mat::create is called on dst.
 * @param userColor The colormap to apply of type CV_8UC1 or CV_8UC3 and size 256
 */
+ (void)applyColorMap:(Mat*)src dst:(Mat*)dst userColor:(Mat*)userColor NS_SWIFT_NAME(applyColorMap(src:dst:userColor:));


//
//  void cv::line(Mat& img, Point pt1, Point pt2, Scalar color, int thickness = 1, LineTypes lineType = LINE_8, int shift = 0)
//
/**
 * Draws a line segment connecting two points.
 *
 * The function line draws the line segment between pt1 and pt2 points in the image. The line is
 * clipped by the image boundaries. For non-antialiased lines with integer coordinates, the 8-connected
 * or 4-connected Bresenham algorithm is used. Thick lines are drawn with rounding endings. Antialiased
 * lines are drawn using Gaussian filtering.
 *
 * @param img Image.
 * @param pt1 First point of the line segment.
 * @param pt2 Second point of the line segment.
 * @param color Line color.
 * @param thickness Line thickness.
 * @param lineType Type of the line. See ``LineTypes``.
 * @param shift Number of fractional bits in the point coordinates.
 */
+ (void)line:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType shift:(int)shift NS_SWIFT_NAME(line(img:pt1:pt2:color:thickness:lineType:shift:));

/**
 * Draws a line segment connecting two points.
 *
 * The function line draws the line segment between pt1 and pt2 points in the image. The line is
 * clipped by the image boundaries. For non-antialiased lines with integer coordinates, the 8-connected
 * or 4-connected Bresenham algorithm is used. Thick lines are drawn with rounding endings. Antialiased
 * lines are drawn using Gaussian filtering.
 *
 * @param img Image.
 * @param pt1 First point of the line segment.
 * @param pt2 Second point of the line segment.
 * @param color Line color.
 * @param thickness Line thickness.
 * @param lineType Type of the line. See ``LineTypes``.
 */
+ (void)line:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(line(img:pt1:pt2:color:thickness:lineType:));

/**
 * Draws a line segment connecting two points.
 *
 * The function line draws the line segment between pt1 and pt2 points in the image. The line is
 * clipped by the image boundaries. For non-antialiased lines with integer coordinates, the 8-connected
 * or 4-connected Bresenham algorithm is used. Thick lines are drawn with rounding endings. Antialiased
 * lines are drawn using Gaussian filtering.
 *
 * @param img Image.
 * @param pt1 First point of the line segment.
 * @param pt2 Second point of the line segment.
 * @param color Line color.
 * @param thickness Line thickness.
 */
+ (void)line:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(line(img:pt1:pt2:color:thickness:));

/**
 * Draws a line segment connecting two points.
 *
 * The function line draws the line segment between pt1 and pt2 points in the image. The line is
 * clipped by the image boundaries. For non-antialiased lines with integer coordinates, the 8-connected
 * or 4-connected Bresenham algorithm is used. Thick lines are drawn with rounding endings. Antialiased
 * lines are drawn using Gaussian filtering.
 *
 * @param img Image.
 * @param pt1 First point of the line segment.
 * @param pt2 Second point of the line segment.
 * @param color Line color.
 */
+ (void)line:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color NS_SWIFT_NAME(line(img:pt1:pt2:color:));


//
//  void cv::arrowedLine(Mat& img, Point pt1, Point pt2, Scalar color, int thickness = 1, LineTypes line_type = 8, int shift = 0, double tipLength = 0.1)
//
/**
 * Draws an arrow segment pointing from the first point to the second one.
 *
 * The function cv::arrowedLine draws an arrow between pt1 and pt2 points in the image. See also ``Imgproc/line``.
 *
 * @param img Image.
 * @param pt1 The point the arrow starts from.
 * @param pt2 The point the arrow points to.
 * @param color Line color.
 * @param thickness Line thickness.
 * @param line_type Type of the line. See ``LineTypes``
 * @param shift Number of fractional bits in the point coordinates.
 * @param tipLength The length of the arrow tip in relation to the arrow length
 */
+ (void)arrowedLine:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness line_type:(LineTypes)line_type shift:(int)shift tipLength:(double)tipLength NS_SWIFT_NAME(arrowedLine(img:pt1:pt2:color:thickness:line_type:shift:tipLength:));

/**
 * Draws an arrow segment pointing from the first point to the second one.
 *
 * The function cv::arrowedLine draws an arrow between pt1 and pt2 points in the image. See also ``Imgproc/line``.
 *
 * @param img Image.
 * @param pt1 The point the arrow starts from.
 * @param pt2 The point the arrow points to.
 * @param color Line color.
 * @param thickness Line thickness.
 * @param line_type Type of the line. See ``LineTypes``
 * @param shift Number of fractional bits in the point coordinates.
 */
+ (void)arrowedLine:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness line_type:(LineTypes)line_type shift:(int)shift NS_SWIFT_NAME(arrowedLine(img:pt1:pt2:color:thickness:line_type:shift:));

/**
 * Draws an arrow segment pointing from the first point to the second one.
 *
 * The function cv::arrowedLine draws an arrow between pt1 and pt2 points in the image. See also ``Imgproc/line``.
 *
 * @param img Image.
 * @param pt1 The point the arrow starts from.
 * @param pt2 The point the arrow points to.
 * @param color Line color.
 * @param thickness Line thickness.
 * @param line_type Type of the line. See ``LineTypes``
 */
+ (void)arrowedLine:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness line_type:(LineTypes)line_type NS_SWIFT_NAME(arrowedLine(img:pt1:pt2:color:thickness:line_type:));

/**
 * Draws an arrow segment pointing from the first point to the second one.
 *
 * The function cv::arrowedLine draws an arrow between pt1 and pt2 points in the image. See also ``Imgproc/line``.
 *
 * @param img Image.
 * @param pt1 The point the arrow starts from.
 * @param pt2 The point the arrow points to.
 * @param color Line color.
 * @param thickness Line thickness.
 */
+ (void)arrowedLine:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(arrowedLine(img:pt1:pt2:color:thickness:));

/**
 * Draws an arrow segment pointing from the first point to the second one.
 *
 * The function cv::arrowedLine draws an arrow between pt1 and pt2 points in the image. See also ``Imgproc/line``.
 *
 * @param img Image.
 * @param pt1 The point the arrow starts from.
 * @param pt2 The point the arrow points to.
 * @param color Line color.
 */
+ (void)arrowedLine:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color NS_SWIFT_NAME(arrowedLine(img:pt1:pt2:color:));


//
//  void cv::drawFrameAxes(Mat& image, Mat cameraMatrix, Mat distCoeffs, Mat rvec, Mat tvec, float length, int thickness = 3)
//
/**
 * Draw axes of the world/object coordinate system from pose estimation. - SeeAlso solvePnP
 *
 * @param image Input/output image. It must have 1 or 3 channels. The number of channels is not altered.
 * @param cameraMatrix Input 3x3 floating-point matrix of camera intrinsic parameters.
 * `$$\cameramatrix{A}$$`
 * @param distCoeffs Input vector of distortion coefficients
 * `$$\distcoeffs$$`. If the vector is empty, the zero distortion coefficients are assumed.
 * @param rvec Rotation vector (see *Ref:* Rodrigues ) that, together with tvec, brings points from
 * the model coordinate system to the camera coordinate system.
 * @param tvec Translation vector.
 * @param length Length of the painted axes in the same unit than tvec (usually in meters).
 * @param thickness Line thickness of the painted axes.
 *
 * This function draws the axes of the world/object coordinate system w.r.t. to the camera frame.
 * OX is drawn in red, OY in green and OZ in blue.
 */
+ (void)drawFrameAxes:(Mat*)image cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvec:(Mat*)rvec tvec:(Mat*)tvec length:(float)length thickness:(int)thickness NS_SWIFT_NAME(drawFrameAxes(image:cameraMatrix:distCoeffs:rvec:tvec:length:thickness:));

/**
 * Draw axes of the world/object coordinate system from pose estimation. - SeeAlso solvePnP
 *
 * @param image Input/output image. It must have 1 or 3 channels. The number of channels is not altered.
 * @param cameraMatrix Input 3x3 floating-point matrix of camera intrinsic parameters.
 * `$$\cameramatrix{A}$$`
 * @param distCoeffs Input vector of distortion coefficients
 * `$$\distcoeffs$$`. If the vector is empty, the zero distortion coefficients are assumed.
 * @param rvec Rotation vector (see *Ref:* Rodrigues ) that, together with tvec, brings points from
 * the model coordinate system to the camera coordinate system.
 * @param tvec Translation vector.
 * @param length Length of the painted axes in the same unit than tvec (usually in meters).
 *
 * This function draws the axes of the world/object coordinate system w.r.t. to the camera frame.
 * OX is drawn in red, OY in green and OZ in blue.
 */
+ (void)drawFrameAxes:(Mat*)image cameraMatrix:(Mat*)cameraMatrix distCoeffs:(Mat*)distCoeffs rvec:(Mat*)rvec tvec:(Mat*)tvec length:(float)length NS_SWIFT_NAME(drawFrameAxes(image:cameraMatrix:distCoeffs:rvec:tvec:length:));


//
//  void cv::rectangle(Mat& img, Point pt1, Point pt2, Scalar color, int thickness = 1, LineTypes lineType = LINE_8, int shift = 0)
//
/**
 * Draws a simple, thick, or filled up-right rectangle.
 *
 * The function cv::rectangle draws a rectangle outline or a filled rectangle whose two opposite corners
 * are pt1 and pt2.
 *
 * @param img Image.
 * @param pt1 Vertex of the rectangle.
 * @param pt2 Vertex of the rectangle opposite to pt1 .
 * @param color Rectangle color or brightness (grayscale image).
 * @param thickness Thickness of lines that make up the rectangle. Negative values, like ``LineTypes/FILLED``,
 * mean that the function has to draw a filled rectangle.
 * @param lineType Type of the line. See ``LineTypes``
 * @param shift Number of fractional bits in the point coordinates.
 */
+ (void)rectangle:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType shift:(int)shift NS_SWIFT_NAME(rectangle(img:pt1:pt2:color:thickness:lineType:shift:));

/**
 * Draws a simple, thick, or filled up-right rectangle.
 *
 * The function cv::rectangle draws a rectangle outline or a filled rectangle whose two opposite corners
 * are pt1 and pt2.
 *
 * @param img Image.
 * @param pt1 Vertex of the rectangle.
 * @param pt2 Vertex of the rectangle opposite to pt1 .
 * @param color Rectangle color or brightness (grayscale image).
 * @param thickness Thickness of lines that make up the rectangle. Negative values, like ``LineTypes/FILLED``,
 * mean that the function has to draw a filled rectangle.
 * @param lineType Type of the line. See ``LineTypes``
 */
+ (void)rectangle:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(rectangle(img:pt1:pt2:color:thickness:lineType:));

/**
 * Draws a simple, thick, or filled up-right rectangle.
 *
 * The function cv::rectangle draws a rectangle outline or a filled rectangle whose two opposite corners
 * are pt1 and pt2.
 *
 * @param img Image.
 * @param pt1 Vertex of the rectangle.
 * @param pt2 Vertex of the rectangle opposite to pt1 .
 * @param color Rectangle color or brightness (grayscale image).
 * @param thickness Thickness of lines that make up the rectangle. Negative values, like ``LineTypes/FILLED``,
 * mean that the function has to draw a filled rectangle.
 */
+ (void)rectangle:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(rectangle(img:pt1:pt2:color:thickness:));

/**
 * Draws a simple, thick, or filled up-right rectangle.
 *
 * The function cv::rectangle draws a rectangle outline or a filled rectangle whose two opposite corners
 * are pt1 and pt2.
 *
 * @param img Image.
 * @param pt1 Vertex of the rectangle.
 * @param pt2 Vertex of the rectangle opposite to pt1 .
 * @param color Rectangle color or brightness (grayscale image).
 * mean that the function has to draw a filled rectangle.
 */
+ (void)rectangle:(Mat*)img pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 color:(Scalar*)color NS_SWIFT_NAME(rectangle(img:pt1:pt2:color:));


//
//  void cv::rectangle(Mat& img, Rect rec, Scalar color, int thickness = 1, LineTypes lineType = LINE_8, int shift = 0)
//
/**
 *
 *
 * use `rec` parameter as alternative specification of the drawn rectangle: `r.tl() and
 * r.br()-Point(1,1)` are opposite corners
 */
+ (void)rectangle:(Mat*)img rec:(Rect2i*)rec color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType shift:(int)shift NS_SWIFT_NAME(rectangle(img:rec:color:thickness:lineType:shift:));

/**
 *
 *
 * use `rec` parameter as alternative specification of the drawn rectangle: `r.tl() and
 * r.br()-Point(1,1)` are opposite corners
 */
+ (void)rectangle:(Mat*)img rec:(Rect2i*)rec color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(rectangle(img:rec:color:thickness:lineType:));

/**
 *
 *
 * use `rec` parameter as alternative specification of the drawn rectangle: `r.tl() and
 * r.br()-Point(1,1)` are opposite corners
 */
+ (void)rectangle:(Mat*)img rec:(Rect2i*)rec color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(rectangle(img:rec:color:thickness:));

/**
 *
 *
 * use `rec` parameter as alternative specification of the drawn rectangle: `r.tl() and
 * r.br()-Point(1,1)` are opposite corners
 */
+ (void)rectangle:(Mat*)img rec:(Rect2i*)rec color:(Scalar*)color NS_SWIFT_NAME(rectangle(img:rec:color:));


//
//  void cv::circle(Mat& img, Point center, int radius, Scalar color, int thickness = 1, LineTypes lineType = LINE_8, int shift = 0)
//
/**
 * Draws a circle.
 *
 * The function cv::circle draws a simple or filled circle with a given center and radius.
 * @param img Image where the circle is drawn.
 * @param center Center of the circle.
 * @param radius Radius of the circle.
 * @param color Circle color.
 * @param thickness Thickness of the circle outline, if positive. Negative values, like ``LineTypes/FILLED``,
 * mean that a filled circle is to be drawn.
 * @param lineType Type of the circle boundary. See ``LineTypes``
 * @param shift Number of fractional bits in the coordinates of the center and in the radius value.
 */
+ (void)circle:(Mat*)img center:(Point2i*)center radius:(int)radius color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType shift:(int)shift NS_SWIFT_NAME(circle(img:center:radius:color:thickness:lineType:shift:));

/**
 * Draws a circle.
 *
 * The function cv::circle draws a simple or filled circle with a given center and radius.
 * @param img Image where the circle is drawn.
 * @param center Center of the circle.
 * @param radius Radius of the circle.
 * @param color Circle color.
 * @param thickness Thickness of the circle outline, if positive. Negative values, like ``LineTypes/FILLED``,
 * mean that a filled circle is to be drawn.
 * @param lineType Type of the circle boundary. See ``LineTypes``
 */
+ (void)circle:(Mat*)img center:(Point2i*)center radius:(int)radius color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(circle(img:center:radius:color:thickness:lineType:));

/**
 * Draws a circle.
 *
 * The function cv::circle draws a simple or filled circle with a given center and radius.
 * @param img Image where the circle is drawn.
 * @param center Center of the circle.
 * @param radius Radius of the circle.
 * @param color Circle color.
 * @param thickness Thickness of the circle outline, if positive. Negative values, like ``LineTypes/FILLED``,
 * mean that a filled circle is to be drawn.
 */
+ (void)circle:(Mat*)img center:(Point2i*)center radius:(int)radius color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(circle(img:center:radius:color:thickness:));

/**
 * Draws a circle.
 *
 * The function cv::circle draws a simple or filled circle with a given center and radius.
 * @param img Image where the circle is drawn.
 * @param center Center of the circle.
 * @param radius Radius of the circle.
 * @param color Circle color.
 * mean that a filled circle is to be drawn.
 */
+ (void)circle:(Mat*)img center:(Point2i*)center radius:(int)radius color:(Scalar*)color NS_SWIFT_NAME(circle(img:center:radius:color:));


//
//  void cv::ellipse(Mat& img, Point center, Size axes, double angle, double startAngle, double endAngle, Scalar color, int thickness = 1, LineTypes lineType = LINE_8, int shift = 0)
//
/**
 * Draws a simple or thick elliptic arc or fills an ellipse sector.
 *
 * The function cv::ellipse with more parameters draws an ellipse outline, a filled ellipse, an elliptic
 * arc, or a filled ellipse sector. The drawing code uses general parametric form.
 * A piecewise-linear curve is used to approximate the elliptic arc
 * boundary. If you need more control of the ellipse rendering, you can retrieve the curve using
 * ``Imgproc/ellipse2Poly`` and then render it with ``Imgproc/polylines`` or fill it with ``Imgproc/fillPoly``. If you use the first
 * variant of the function and want to draw the whole ellipse, not an arc, pass `startAngle=0` and
 * `endAngle=360`. If `startAngle` is greater than `endAngle`, they are swapped. The figure below explains
 * the meaning of the parameters to draw the blue arc.
 *
 * ![Parameters of Elliptic Arc](ellipse)
 *
 * @param img Image.
 * @param center Center of the ellipse.
 * @param axes Half of the size of the ellipse main axes.
 * @param angle Ellipse rotation angle in degrees.
 * @param startAngle Starting angle of the elliptic arc in degrees.
 * @param endAngle Ending angle of the elliptic arc in degrees.
 * @param color Ellipse color.
 * @param thickness Thickness of the ellipse arc outline, if positive. Otherwise, this indicates that
 * a filled ellipse sector is to be drawn.
 * @param lineType Type of the ellipse boundary. See ``LineTypes``
 * @param shift Number of fractional bits in the coordinates of the center and values of axes.
 */
+ (void)ellipse:(Mat*)img center:(Point2i*)center axes:(Size2i*)axes angle:(double)angle startAngle:(double)startAngle endAngle:(double)endAngle color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType shift:(int)shift NS_SWIFT_NAME(ellipse(img:center:axes:angle:startAngle:endAngle:color:thickness:lineType:shift:));

/**
 * Draws a simple or thick elliptic arc or fills an ellipse sector.
 *
 * The function cv::ellipse with more parameters draws an ellipse outline, a filled ellipse, an elliptic
 * arc, or a filled ellipse sector. The drawing code uses general parametric form.
 * A piecewise-linear curve is used to approximate the elliptic arc
 * boundary. If you need more control of the ellipse rendering, you can retrieve the curve using
 * ``Imgproc/ellipse2Poly`` and then render it with ``Imgproc/polylines`` or fill it with ``Imgproc/fillPoly``. If you use the first
 * variant of the function and want to draw the whole ellipse, not an arc, pass `startAngle=0` and
 * `endAngle=360`. If `startAngle` is greater than `endAngle`, they are swapped. The figure below explains
 * the meaning of the parameters to draw the blue arc.
 *
 * ![Parameters of Elliptic Arc](ellipse)
 *
 * @param img Image.
 * @param center Center of the ellipse.
 * @param axes Half of the size of the ellipse main axes.
 * @param angle Ellipse rotation angle in degrees.
 * @param startAngle Starting angle of the elliptic arc in degrees.
 * @param endAngle Ending angle of the elliptic arc in degrees.
 * @param color Ellipse color.
 * @param thickness Thickness of the ellipse arc outline, if positive. Otherwise, this indicates that
 * a filled ellipse sector is to be drawn.
 * @param lineType Type of the ellipse boundary. See ``LineTypes``
 */
+ (void)ellipse:(Mat*)img center:(Point2i*)center axes:(Size2i*)axes angle:(double)angle startAngle:(double)startAngle endAngle:(double)endAngle color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(ellipse(img:center:axes:angle:startAngle:endAngle:color:thickness:lineType:));

/**
 * Draws a simple or thick elliptic arc or fills an ellipse sector.
 *
 * The function cv::ellipse with more parameters draws an ellipse outline, a filled ellipse, an elliptic
 * arc, or a filled ellipse sector. The drawing code uses general parametric form.
 * A piecewise-linear curve is used to approximate the elliptic arc
 * boundary. If you need more control of the ellipse rendering, you can retrieve the curve using
 * ``Imgproc/ellipse2Poly`` and then render it with ``Imgproc/polylines`` or fill it with ``Imgproc/fillPoly``. If you use the first
 * variant of the function and want to draw the whole ellipse, not an arc, pass `startAngle=0` and
 * `endAngle=360`. If `startAngle` is greater than `endAngle`, they are swapped. The figure below explains
 * the meaning of the parameters to draw the blue arc.
 *
 * ![Parameters of Elliptic Arc](ellipse)
 *
 * @param img Image.
 * @param center Center of the ellipse.
 * @param axes Half of the size of the ellipse main axes.
 * @param angle Ellipse rotation angle in degrees.
 * @param startAngle Starting angle of the elliptic arc in degrees.
 * @param endAngle Ending angle of the elliptic arc in degrees.
 * @param color Ellipse color.
 * @param thickness Thickness of the ellipse arc outline, if positive. Otherwise, this indicates that
 * a filled ellipse sector is to be drawn.
 */
+ (void)ellipse:(Mat*)img center:(Point2i*)center axes:(Size2i*)axes angle:(double)angle startAngle:(double)startAngle endAngle:(double)endAngle color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(ellipse(img:center:axes:angle:startAngle:endAngle:color:thickness:));

/**
 * Draws a simple or thick elliptic arc or fills an ellipse sector.
 *
 * The function cv::ellipse with more parameters draws an ellipse outline, a filled ellipse, an elliptic
 * arc, or a filled ellipse sector. The drawing code uses general parametric form.
 * A piecewise-linear curve is used to approximate the elliptic arc
 * boundary. If you need more control of the ellipse rendering, you can retrieve the curve using
 * ``Imgproc/ellipse2Poly`` and then render it with ``Imgproc/polylines`` or fill it with ``Imgproc/fillPoly``. If you use the first
 * variant of the function and want to draw the whole ellipse, not an arc, pass `startAngle=0` and
 * `endAngle=360`. If `startAngle` is greater than `endAngle`, they are swapped. The figure below explains
 * the meaning of the parameters to draw the blue arc.
 *
 * ![Parameters of Elliptic Arc](ellipse)
 *
 * @param img Image.
 * @param center Center of the ellipse.
 * @param axes Half of the size of the ellipse main axes.
 * @param angle Ellipse rotation angle in degrees.
 * @param startAngle Starting angle of the elliptic arc in degrees.
 * @param endAngle Ending angle of the elliptic arc in degrees.
 * @param color Ellipse color.
 * a filled ellipse sector is to be drawn.
 */
+ (void)ellipse:(Mat*)img center:(Point2i*)center axes:(Size2i*)axes angle:(double)angle startAngle:(double)startAngle endAngle:(double)endAngle color:(Scalar*)color NS_SWIFT_NAME(ellipse(img:center:axes:angle:startAngle:endAngle:color:));


//
//  void cv::ellipse(Mat& img, RotatedRect box, Scalar color, int thickness = 1, LineTypes lineType = LINE_8)
//
/**
 *
 * @param img Image.
 * @param box Alternative ellipse representation via RotatedRect. This means that the function draws
 * an ellipse inscribed in the rotated rectangle.
 * @param color Ellipse color.
 * @param thickness Thickness of the ellipse arc outline, if positive. Otherwise, this indicates that
 * a filled ellipse sector is to be drawn.
 * @param lineType Type of the ellipse boundary. See ``LineTypes``
 */
+ (void)ellipse:(Mat*)img box:(RotatedRect*)box color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(ellipse(img:box:color:thickness:lineType:));

/**
 *
 * @param img Image.
 * @param box Alternative ellipse representation via RotatedRect. This means that the function draws
 * an ellipse inscribed in the rotated rectangle.
 * @param color Ellipse color.
 * @param thickness Thickness of the ellipse arc outline, if positive. Otherwise, this indicates that
 * a filled ellipse sector is to be drawn.
 */
+ (void)ellipse:(Mat*)img box:(RotatedRect*)box color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(ellipse(img:box:color:thickness:));

/**
 *
 * @param img Image.
 * @param box Alternative ellipse representation via RotatedRect. This means that the function draws
 * an ellipse inscribed in the rotated rectangle.
 * @param color Ellipse color.
 * a filled ellipse sector is to be drawn.
 */
+ (void)ellipse:(Mat*)img box:(RotatedRect*)box color:(Scalar*)color NS_SWIFT_NAME(ellipse(img:box:color:));


//
//  void cv::drawMarker(Mat& img, Point position, Scalar color, MarkerTypes markerType = MARKER_CROSS, int markerSize = 20, int thickness = 1, LineTypes line_type = 8)
//
/**
 * Draws a marker on a predefined position in an image.
 *
 * The function cv::drawMarker draws a marker on a given position in the image. For the moment several
 * marker types are supported, see ``MarkerTypes`` for more information.
 *
 * @param img Image.
 * @param position The point where the crosshair is positioned.
 * @param color Line color.
 * @param markerType The specific type of marker you want to use, see ``MarkerTypes``
 * @param thickness Line thickness.
 * @param line_type Type of the line, See ``LineTypes``
 * @param markerSize The length of the marker axis [default = 20 pixels]
 */
+ (void)drawMarker:(Mat*)img position:(Point2i*)position color:(Scalar*)color markerType:(MarkerTypes)markerType markerSize:(int)markerSize thickness:(int)thickness line_type:(LineTypes)line_type NS_SWIFT_NAME(drawMarker(img:position:color:markerType:markerSize:thickness:line_type:));

/**
 * Draws a marker on a predefined position in an image.
 *
 * The function cv::drawMarker draws a marker on a given position in the image. For the moment several
 * marker types are supported, see ``MarkerTypes`` for more information.
 *
 * @param img Image.
 * @param position The point where the crosshair is positioned.
 * @param color Line color.
 * @param markerType The specific type of marker you want to use, see ``MarkerTypes``
 * @param thickness Line thickness.
 * @param markerSize The length of the marker axis [default = 20 pixels]
 */
+ (void)drawMarker:(Mat*)img position:(Point2i*)position color:(Scalar*)color markerType:(MarkerTypes)markerType markerSize:(int)markerSize thickness:(int)thickness NS_SWIFT_NAME(drawMarker(img:position:color:markerType:markerSize:thickness:));

/**
 * Draws a marker on a predefined position in an image.
 *
 * The function cv::drawMarker draws a marker on a given position in the image. For the moment several
 * marker types are supported, see ``MarkerTypes`` for more information.
 *
 * @param img Image.
 * @param position The point where the crosshair is positioned.
 * @param color Line color.
 * @param markerType The specific type of marker you want to use, see ``MarkerTypes``
 * @param markerSize The length of the marker axis [default = 20 pixels]
 */
+ (void)drawMarker:(Mat*)img position:(Point2i*)position color:(Scalar*)color markerType:(MarkerTypes)markerType markerSize:(int)markerSize NS_SWIFT_NAME(drawMarker(img:position:color:markerType:markerSize:));

/**
 * Draws a marker on a predefined position in an image.
 *
 * The function cv::drawMarker draws a marker on a given position in the image. For the moment several
 * marker types are supported, see ``MarkerTypes`` for more information.
 *
 * @param img Image.
 * @param position The point where the crosshair is positioned.
 * @param color Line color.
 * @param markerType The specific type of marker you want to use, see ``MarkerTypes``
 */
+ (void)drawMarker:(Mat*)img position:(Point2i*)position color:(Scalar*)color markerType:(MarkerTypes)markerType NS_SWIFT_NAME(drawMarker(img:position:color:markerType:));

/**
 * Draws a marker on a predefined position in an image.
 *
 * The function cv::drawMarker draws a marker on a given position in the image. For the moment several
 * marker types are supported, see ``MarkerTypes`` for more information.
 *
 * @param img Image.
 * @param position The point where the crosshair is positioned.
 * @param color Line color.
 */
+ (void)drawMarker:(Mat*)img position:(Point2i*)position color:(Scalar*)color NS_SWIFT_NAME(drawMarker(img:position:color:));


//
//  void cv::fillConvexPoly(Mat& img, vector_Point points, Scalar color, LineTypes lineType = LINE_8, int shift = 0)
//
/**
 * Fills a convex polygon.
 *
 * The function cv::fillConvexPoly draws a filled convex polygon. This function is much faster than the
 * function ``Imgproc/fillPoly`` . It can fill not only convex polygons but any monotonic polygon without
 * self-intersections, that is, a polygon whose contour intersects every horizontal line (scan line)
 * twice at the most (though, its top-most and/or the bottom edge could be horizontal).
 *
 * @param img Image.
 * @param points Polygon vertices.
 * @param color Polygon color.
 * @param lineType Type of the polygon boundaries. See ``LineTypes``
 * @param shift Number of fractional bits in the vertex coordinates.
 */
+ (void)fillConvexPoly:(Mat*)img points:(NSArray<Point2i*>*)points color:(Scalar*)color lineType:(LineTypes)lineType shift:(int)shift NS_SWIFT_NAME(fillConvexPoly(img:points:color:lineType:shift:));

/**
 * Fills a convex polygon.
 *
 * The function cv::fillConvexPoly draws a filled convex polygon. This function is much faster than the
 * function ``Imgproc/fillPoly`` . It can fill not only convex polygons but any monotonic polygon without
 * self-intersections, that is, a polygon whose contour intersects every horizontal line (scan line)
 * twice at the most (though, its top-most and/or the bottom edge could be horizontal).
 *
 * @param img Image.
 * @param points Polygon vertices.
 * @param color Polygon color.
 * @param lineType Type of the polygon boundaries. See ``LineTypes``
 */
+ (void)fillConvexPoly:(Mat*)img points:(NSArray<Point2i*>*)points color:(Scalar*)color lineType:(LineTypes)lineType NS_SWIFT_NAME(fillConvexPoly(img:points:color:lineType:));

/**
 * Fills a convex polygon.
 *
 * The function cv::fillConvexPoly draws a filled convex polygon. This function is much faster than the
 * function ``Imgproc/fillPoly`` . It can fill not only convex polygons but any monotonic polygon without
 * self-intersections, that is, a polygon whose contour intersects every horizontal line (scan line)
 * twice at the most (though, its top-most and/or the bottom edge could be horizontal).
 *
 * @param img Image.
 * @param points Polygon vertices.
 * @param color Polygon color.
 */
+ (void)fillConvexPoly:(Mat*)img points:(NSArray<Point2i*>*)points color:(Scalar*)color NS_SWIFT_NAME(fillConvexPoly(img:points:color:));


//
//  void cv::fillPoly(Mat& img, vector_vector_Point pts, Scalar color, LineTypes lineType = LINE_8, int shift = 0, Point offset = Point())
//
/**
 * Fills the area bounded by one or more polygons.
 *
 * The function cv::fillPoly fills an area bounded by several polygonal contours. The function can fill
 * complex areas, for example, areas with holes, contours with self-intersections (some of their
 * parts), and so forth.
 *
 * @param img Image.
 * @param pts Array of polygons where each polygon is represented as an array of points.
 * @param color Polygon color.
 * @param lineType Type of the polygon boundaries. See ``LineTypes``
 * @param shift Number of fractional bits in the vertex coordinates.
 * @param offset Optional offset of all points of the contours.
 */
+ (void)fillPoly:(Mat*)img pts:(NSArray<NSArray<Point2i*>*>*)pts color:(Scalar*)color lineType:(LineTypes)lineType shift:(int)shift offset:(Point2i*)offset NS_SWIFT_NAME(fillPoly(img:pts:color:lineType:shift:offset:));

/**
 * Fills the area bounded by one or more polygons.
 *
 * The function cv::fillPoly fills an area bounded by several polygonal contours. The function can fill
 * complex areas, for example, areas with holes, contours with self-intersections (some of their
 * parts), and so forth.
 *
 * @param img Image.
 * @param pts Array of polygons where each polygon is represented as an array of points.
 * @param color Polygon color.
 * @param lineType Type of the polygon boundaries. See ``LineTypes``
 * @param shift Number of fractional bits in the vertex coordinates.
 */
+ (void)fillPoly:(Mat*)img pts:(NSArray<NSArray<Point2i*>*>*)pts color:(Scalar*)color lineType:(LineTypes)lineType shift:(int)shift NS_SWIFT_NAME(fillPoly(img:pts:color:lineType:shift:));

/**
 * Fills the area bounded by one or more polygons.
 *
 * The function cv::fillPoly fills an area bounded by several polygonal contours. The function can fill
 * complex areas, for example, areas with holes, contours with self-intersections (some of their
 * parts), and so forth.
 *
 * @param img Image.
 * @param pts Array of polygons where each polygon is represented as an array of points.
 * @param color Polygon color.
 * @param lineType Type of the polygon boundaries. See ``LineTypes``
 */
+ (void)fillPoly:(Mat*)img pts:(NSArray<NSArray<Point2i*>*>*)pts color:(Scalar*)color lineType:(LineTypes)lineType NS_SWIFT_NAME(fillPoly(img:pts:color:lineType:));

/**
 * Fills the area bounded by one or more polygons.
 *
 * The function cv::fillPoly fills an area bounded by several polygonal contours. The function can fill
 * complex areas, for example, areas with holes, contours with self-intersections (some of their
 * parts), and so forth.
 *
 * @param img Image.
 * @param pts Array of polygons where each polygon is represented as an array of points.
 * @param color Polygon color.
 */
+ (void)fillPoly:(Mat*)img pts:(NSArray<NSArray<Point2i*>*>*)pts color:(Scalar*)color NS_SWIFT_NAME(fillPoly(img:pts:color:));


//
//  void cv::polylines(Mat& img, vector_vector_Point pts, bool isClosed, Scalar color, int thickness = 1, LineTypes lineType = LINE_8, int shift = 0)
//
/**
 * Draws several polygonal curves.
 *
 * @param img Image.
 * @param pts Array of polygonal curves.
 * @param isClosed Flag indicating whether the drawn polylines are closed or not. If they are closed,
 * the function draws a line from the last vertex of each curve to its first vertex.
 * @param color Polyline color.
 * @param thickness Thickness of the polyline edges.
 * @param lineType Type of the line segments. See ``LineTypes``
 * @param shift Number of fractional bits in the vertex coordinates.
 *
 * The function cv::polylines draws one or more polygonal curves.
 */
+ (void)polylines:(Mat*)img pts:(NSArray<NSArray<Point2i*>*>*)pts isClosed:(BOOL)isClosed color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType shift:(int)shift NS_SWIFT_NAME(polylines(img:pts:isClosed:color:thickness:lineType:shift:));

/**
 * Draws several polygonal curves.
 *
 * @param img Image.
 * @param pts Array of polygonal curves.
 * @param isClosed Flag indicating whether the drawn polylines are closed or not. If they are closed,
 * the function draws a line from the last vertex of each curve to its first vertex.
 * @param color Polyline color.
 * @param thickness Thickness of the polyline edges.
 * @param lineType Type of the line segments. See ``LineTypes``
 *
 * The function cv::polylines draws one or more polygonal curves.
 */
+ (void)polylines:(Mat*)img pts:(NSArray<NSArray<Point2i*>*>*)pts isClosed:(BOOL)isClosed color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(polylines(img:pts:isClosed:color:thickness:lineType:));

/**
 * Draws several polygonal curves.
 *
 * @param img Image.
 * @param pts Array of polygonal curves.
 * @param isClosed Flag indicating whether the drawn polylines are closed or not. If they are closed,
 * the function draws a line from the last vertex of each curve to its first vertex.
 * @param color Polyline color.
 * @param thickness Thickness of the polyline edges.
 *
 * The function cv::polylines draws one or more polygonal curves.
 */
+ (void)polylines:(Mat*)img pts:(NSArray<NSArray<Point2i*>*>*)pts isClosed:(BOOL)isClosed color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(polylines(img:pts:isClosed:color:thickness:));

/**
 * Draws several polygonal curves.
 *
 * @param img Image.
 * @param pts Array of polygonal curves.
 * @param isClosed Flag indicating whether the drawn polylines are closed or not. If they are closed,
 * the function draws a line from the last vertex of each curve to its first vertex.
 * @param color Polyline color.
 *
 * The function cv::polylines draws one or more polygonal curves.
 */
+ (void)polylines:(Mat*)img pts:(NSArray<NSArray<Point2i*>*>*)pts isClosed:(BOOL)isClosed color:(Scalar*)color NS_SWIFT_NAME(polylines(img:pts:isClosed:color:));


//
//  void cv::drawContours(Mat& image, vector_vector_Point contours, int contourIdx, Scalar color, int thickness = 1, LineTypes lineType = LINE_8, Mat hierarchy = Mat(), int maxLevel = INT_MAX, Point offset = Point())
//
/**
 * Draws contours outlines or filled contours.
 *
 * The function draws contour outlines in the image if `$$\texttt{thickness} \ge 0$$` or fills the area
 * bounded by the contours if `$$\texttt{thickness}<0$$` . The example below shows how to retrieve
 * connected components from the binary image and label them: :
 * Include: snippets/imgproc_drawContours.cpp
 *
 * @param image Destination image.
 * @param contours All the input contours. Each contour is stored as a point vector.
 * @param contourIdx Parameter indicating a contour to draw. If it is negative, all the contours are drawn.
 * @param color Color of the contours.
 * @param thickness Thickness of lines the contours are drawn with. If it is negative (for example,
 * thickness=#FILLED ), the contour interiors are drawn.
 * @param lineType Line connectivity. See ``LineTypes``
 * @param hierarchy Optional information about hierarchy. It is only needed if you want to draw only
 * some of the contours (see maxLevel ).
 * @param maxLevel Maximal level for drawn contours. If it is 0, only the specified contour is drawn.
 * If it is 1, the function draws the contour(s) and all the nested contours. If it is 2, the function
 * draws the contours, all the nested contours, all the nested-to-nested contours, and so on. This
 * parameter is only taken into account when there is hierarchy available.
 * @param offset Optional contour shift parameter. Shift all the drawn contours by the specified
 * `$$\texttt{offset}=(dx,dy)$$` .
 * Note:* When thickness=#FILLED, the function is designed to handle connected components with holes correctly
 * even when no hierarchy data is provided. This is done by analyzing all the outlines together
 * using even-odd rule. This may give incorrect results if you have a joint collection of separately retrieved
 * contours. In order to solve this problem, you need to call *drawContours* separately for each sub-group
 * of contours, or iterate over the collection using contourIdx parameter.
 */
+ (void)drawContours:(Mat*)image contours:(NSArray<NSArray<Point2i*>*>*)contours contourIdx:(int)contourIdx color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType hierarchy:(Mat*)hierarchy maxLevel:(int)maxLevel offset:(Point2i*)offset NS_SWIFT_NAME(drawContours(image:contours:contourIdx:color:thickness:lineType:hierarchy:maxLevel:offset:));

/**
 * Draws contours outlines or filled contours.
 *
 * The function draws contour outlines in the image if `$$\texttt{thickness} \ge 0$$` or fills the area
 * bounded by the contours if `$$\texttt{thickness}<0$$` . The example below shows how to retrieve
 * connected components from the binary image and label them: :
 * Include: snippets/imgproc_drawContours.cpp
 *
 * @param image Destination image.
 * @param contours All the input contours. Each contour is stored as a point vector.
 * @param contourIdx Parameter indicating a contour to draw. If it is negative, all the contours are drawn.
 * @param color Color of the contours.
 * @param thickness Thickness of lines the contours are drawn with. If it is negative (for example,
 * thickness=#FILLED ), the contour interiors are drawn.
 * @param lineType Line connectivity. See ``LineTypes``
 * @param hierarchy Optional information about hierarchy. It is only needed if you want to draw only
 * some of the contours (see maxLevel ).
 * @param maxLevel Maximal level for drawn contours. If it is 0, only the specified contour is drawn.
 * If it is 1, the function draws the contour(s) and all the nested contours. If it is 2, the function
 * draws the contours, all the nested contours, all the nested-to-nested contours, and so on. This
 * parameter is only taken into account when there is hierarchy available.
 * `$$\texttt{offset}=(dx,dy)$$` .
 * Note:* When thickness=#FILLED, the function is designed to handle connected components with holes correctly
 * even when no hierarchy data is provided. This is done by analyzing all the outlines together
 * using even-odd rule. This may give incorrect results if you have a joint collection of separately retrieved
 * contours. In order to solve this problem, you need to call *drawContours* separately for each sub-group
 * of contours, or iterate over the collection using contourIdx parameter.
 */
+ (void)drawContours:(Mat*)image contours:(NSArray<NSArray<Point2i*>*>*)contours contourIdx:(int)contourIdx color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType hierarchy:(Mat*)hierarchy maxLevel:(int)maxLevel NS_SWIFT_NAME(drawContours(image:contours:contourIdx:color:thickness:lineType:hierarchy:maxLevel:));

/**
 * Draws contours outlines or filled contours.
 *
 * The function draws contour outlines in the image if `$$\texttt{thickness} \ge 0$$` or fills the area
 * bounded by the contours if `$$\texttt{thickness}<0$$` . The example below shows how to retrieve
 * connected components from the binary image and label them: :
 * Include: snippets/imgproc_drawContours.cpp
 *
 * @param image Destination image.
 * @param contours All the input contours. Each contour is stored as a point vector.
 * @param contourIdx Parameter indicating a contour to draw. If it is negative, all the contours are drawn.
 * @param color Color of the contours.
 * @param thickness Thickness of lines the contours are drawn with. If it is negative (for example,
 * thickness=#FILLED ), the contour interiors are drawn.
 * @param lineType Line connectivity. See ``LineTypes``
 * @param hierarchy Optional information about hierarchy. It is only needed if you want to draw only
 * some of the contours (see maxLevel ).
 * If it is 1, the function draws the contour(s) and all the nested contours. If it is 2, the function
 * draws the contours, all the nested contours, all the nested-to-nested contours, and so on. This
 * parameter is only taken into account when there is hierarchy available.
 * `$$\texttt{offset}=(dx,dy)$$` .
 * Note:* When thickness=#FILLED, the function is designed to handle connected components with holes correctly
 * even when no hierarchy data is provided. This is done by analyzing all the outlines together
 * using even-odd rule. This may give incorrect results if you have a joint collection of separately retrieved
 * contours. In order to solve this problem, you need to call *drawContours* separately for each sub-group
 * of contours, or iterate over the collection using contourIdx parameter.
 */
+ (void)drawContours:(Mat*)image contours:(NSArray<NSArray<Point2i*>*>*)contours contourIdx:(int)contourIdx color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType hierarchy:(Mat*)hierarchy NS_SWIFT_NAME(drawContours(image:contours:contourIdx:color:thickness:lineType:hierarchy:));

/**
 * Draws contours outlines or filled contours.
 *
 * The function draws contour outlines in the image if `$$\texttt{thickness} \ge 0$$` or fills the area
 * bounded by the contours if `$$\texttt{thickness}<0$$` . The example below shows how to retrieve
 * connected components from the binary image and label them: :
 * Include: snippets/imgproc_drawContours.cpp
 *
 * @param image Destination image.
 * @param contours All the input contours. Each contour is stored as a point vector.
 * @param contourIdx Parameter indicating a contour to draw. If it is negative, all the contours are drawn.
 * @param color Color of the contours.
 * @param thickness Thickness of lines the contours are drawn with. If it is negative (for example,
 * thickness=#FILLED ), the contour interiors are drawn.
 * @param lineType Line connectivity. See ``LineTypes``
 * some of the contours (see maxLevel ).
 * If it is 1, the function draws the contour(s) and all the nested contours. If it is 2, the function
 * draws the contours, all the nested contours, all the nested-to-nested contours, and so on. This
 * parameter is only taken into account when there is hierarchy available.
 * `$$\texttt{offset}=(dx,dy)$$` .
 * Note:* When thickness=#FILLED, the function is designed to handle connected components with holes correctly
 * even when no hierarchy data is provided. This is done by analyzing all the outlines together
 * using even-odd rule. This may give incorrect results if you have a joint collection of separately retrieved
 * contours. In order to solve this problem, you need to call *drawContours* separately for each sub-group
 * of contours, or iterate over the collection using contourIdx parameter.
 */
+ (void)drawContours:(Mat*)image contours:(NSArray<NSArray<Point2i*>*>*)contours contourIdx:(int)contourIdx color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(drawContours(image:contours:contourIdx:color:thickness:lineType:));

/**
 * Draws contours outlines or filled contours.
 *
 * The function draws contour outlines in the image if `$$\texttt{thickness} \ge 0$$` or fills the area
 * bounded by the contours if `$$\texttt{thickness}<0$$` . The example below shows how to retrieve
 * connected components from the binary image and label them: :
 * Include: snippets/imgproc_drawContours.cpp
 *
 * @param image Destination image.
 * @param contours All the input contours. Each contour is stored as a point vector.
 * @param contourIdx Parameter indicating a contour to draw. If it is negative, all the contours are drawn.
 * @param color Color of the contours.
 * @param thickness Thickness of lines the contours are drawn with. If it is negative (for example,
 * thickness=#FILLED ), the contour interiors are drawn.
 * some of the contours (see maxLevel ).
 * If it is 1, the function draws the contour(s) and all the nested contours. If it is 2, the function
 * draws the contours, all the nested contours, all the nested-to-nested contours, and so on. This
 * parameter is only taken into account when there is hierarchy available.
 * `$$\texttt{offset}=(dx,dy)$$` .
 * Note:* When thickness=#FILLED, the function is designed to handle connected components with holes correctly
 * even when no hierarchy data is provided. This is done by analyzing all the outlines together
 * using even-odd rule. This may give incorrect results if you have a joint collection of separately retrieved
 * contours. In order to solve this problem, you need to call *drawContours* separately for each sub-group
 * of contours, or iterate over the collection using contourIdx parameter.
 */
+ (void)drawContours:(Mat*)image contours:(NSArray<NSArray<Point2i*>*>*)contours contourIdx:(int)contourIdx color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(drawContours(image:contours:contourIdx:color:thickness:));

/**
 * Draws contours outlines or filled contours.
 *
 * The function draws contour outlines in the image if `$$\texttt{thickness} \ge 0$$` or fills the area
 * bounded by the contours if `$$\texttt{thickness}<0$$` . The example below shows how to retrieve
 * connected components from the binary image and label them: :
 * Include: snippets/imgproc_drawContours.cpp
 *
 * @param image Destination image.
 * @param contours All the input contours. Each contour is stored as a point vector.
 * @param contourIdx Parameter indicating a contour to draw. If it is negative, all the contours are drawn.
 * @param color Color of the contours.
 * thickness=#FILLED ), the contour interiors are drawn.
 * some of the contours (see maxLevel ).
 * If it is 1, the function draws the contour(s) and all the nested contours. If it is 2, the function
 * draws the contours, all the nested contours, all the nested-to-nested contours, and so on. This
 * parameter is only taken into account when there is hierarchy available.
 * `$$\texttt{offset}=(dx,dy)$$` .
 * Note:* When thickness=#FILLED, the function is designed to handle connected components with holes correctly
 * even when no hierarchy data is provided. This is done by analyzing all the outlines together
 * using even-odd rule. This may give incorrect results if you have a joint collection of separately retrieved
 * contours. In order to solve this problem, you need to call *drawContours* separately for each sub-group
 * of contours, or iterate over the collection using contourIdx parameter.
 */
+ (void)drawContours:(Mat*)image contours:(NSArray<NSArray<Point2i*>*>*)contours contourIdx:(int)contourIdx color:(Scalar*)color NS_SWIFT_NAME(drawContours(image:contours:contourIdx:color:));


//
//  bool cv::clipLine(Rect imgRect, Point& pt1, Point& pt2)
//
/**
 *
 * @param imgRect Image rectangle.
 * @param pt1 First line point.
 * @param pt2 Second line point.
 */
+ (BOOL)clipLine:(Rect2i*)imgRect pt1:(Point2i*)pt1 pt2:(Point2i*)pt2 NS_SWIFT_NAME(clipLine(imgRect:pt1:pt2:));


//
//  void cv::ellipse2Poly(Point center, Size axes, int angle, int arcStart, int arcEnd, int delta, vector_Point& pts)
//
/**
 * Approximates an elliptic arc with a polyline.
 *
 * The function ellipse2Poly computes the vertices of a polyline that approximates the specified
 * elliptic arc. It is used by ``Imgproc/ellipse``. If `arcStart` is greater than `arcEnd`, they are swapped.
 *
 * @param center Center of the arc.
 * @param axes Half of the size of the ellipse main axes. See ``Imgproc/ellipse`` for details.
 * @param angle Rotation angle of the ellipse in degrees. See ``Imgproc/ellipse`` for details.
 * @param arcStart Starting angle of the elliptic arc in degrees.
 * @param arcEnd Ending angle of the elliptic arc in degrees.
 * @param delta Angle between the subsequent polyline vertices. It defines the approximation
 * accuracy.
 * @param pts Output vector of polyline vertices.
 */
+ (void)ellipse2Poly:(Point2i*)center axes:(Size2i*)axes angle:(int)angle arcStart:(int)arcStart arcEnd:(int)arcEnd delta:(int)delta pts:(NSMutableArray<Point2i*>*)pts NS_SWIFT_NAME(ellipse2Poly(center:axes:angle:arcStart:arcEnd:delta:pts:));


//
//  void cv::putText(Mat& img, String text, Point org, HersheyFonts fontFace, double fontScale, Scalar color, int thickness = 1, LineTypes lineType = LINE_8, bool bottomLeftOrigin = false)
//
/**
 * Draws a text string.
 *
 * The function cv::putText renders the specified text string in the image. Symbols that cannot be rendered
 * using the specified font are replaced by question marks. See ``Imgproc/getTextSize`` for a text rendering code
 * example.
 *
 * The `fontScale` parameter is a scale factor that is multiplied by the base font size:
 * - When scale > 1, the text is magnified.
 * - When 0 < scale < 1, the text is minimized.
 * - When scale < 0, the text is mirrored or reversed.
 *
 * @param img Image.
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the text string in the image.
 * @param fontFace Font type, see ``HersheyFonts``.
 * @param fontScale Font scale factor that is multiplied by the font-specific base size.
 * @param color Text color.
 * @param thickness Thickness of the lines used to draw a text.
 * @param lineType Line type. See ``LineTypes``
 * @param bottomLeftOrigin When true, the image data origin is at the bottom-left corner. Otherwise,
 * it is at the top-left corner.
 */
+ (void)putText:(Mat*)img text:(NSString*)text org:(Point2i*)org fontFace:(HersheyFonts)fontFace fontScale:(double)fontScale color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType bottomLeftOrigin:(BOOL)bottomLeftOrigin NS_SWIFT_NAME(putText(img:text:org:fontFace:fontScale:color:thickness:lineType:bottomLeftOrigin:));

/**
 * Draws a text string.
 *
 * The function cv::putText renders the specified text string in the image. Symbols that cannot be rendered
 * using the specified font are replaced by question marks. See ``Imgproc/getTextSize`` for a text rendering code
 * example.
 *
 * The `fontScale` parameter is a scale factor that is multiplied by the base font size:
 * - When scale > 1, the text is magnified.
 * - When 0 < scale < 1, the text is minimized.
 * - When scale < 0, the text is mirrored or reversed.
 *
 * @param img Image.
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the text string in the image.
 * @param fontFace Font type, see ``HersheyFonts``.
 * @param fontScale Font scale factor that is multiplied by the font-specific base size.
 * @param color Text color.
 * @param thickness Thickness of the lines used to draw a text.
 * @param lineType Line type. See ``LineTypes``
 * it is at the top-left corner.
 */
+ (void)putText:(Mat*)img text:(NSString*)text org:(Point2i*)org fontFace:(HersheyFonts)fontFace fontScale:(double)fontScale color:(Scalar*)color thickness:(int)thickness lineType:(LineTypes)lineType NS_SWIFT_NAME(putText(img:text:org:fontFace:fontScale:color:thickness:lineType:));

/**
 * Draws a text string.
 *
 * The function cv::putText renders the specified text string in the image. Symbols that cannot be rendered
 * using the specified font are replaced by question marks. See ``Imgproc/getTextSize`` for a text rendering code
 * example.
 *
 * The `fontScale` parameter is a scale factor that is multiplied by the base font size:
 * - When scale > 1, the text is magnified.
 * - When 0 < scale < 1, the text is minimized.
 * - When scale < 0, the text is mirrored or reversed.
 *
 * @param img Image.
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the text string in the image.
 * @param fontFace Font type, see ``HersheyFonts``.
 * @param fontScale Font scale factor that is multiplied by the font-specific base size.
 * @param color Text color.
 * @param thickness Thickness of the lines used to draw a text.
 * it is at the top-left corner.
 */
+ (void)putText:(Mat*)img text:(NSString*)text org:(Point2i*)org fontFace:(HersheyFonts)fontFace fontScale:(double)fontScale color:(Scalar*)color thickness:(int)thickness NS_SWIFT_NAME(putText(img:text:org:fontFace:fontScale:color:thickness:));

/**
 * Draws a text string.
 *
 * The function cv::putText renders the specified text string in the image. Symbols that cannot be rendered
 * using the specified font are replaced by question marks. See ``Imgproc/getTextSize`` for a text rendering code
 * example.
 *
 * The `fontScale` parameter is a scale factor that is multiplied by the base font size:
 * - When scale > 1, the text is magnified.
 * - When 0 < scale < 1, the text is minimized.
 * - When scale < 0, the text is mirrored or reversed.
 *
 * @param img Image.
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the text string in the image.
 * @param fontFace Font type, see ``HersheyFonts``.
 * @param fontScale Font scale factor that is multiplied by the font-specific base size.
 * @param color Text color.
 * it is at the top-left corner.
 */
+ (void)putText:(Mat*)img text:(NSString*)text org:(Point2i*)org fontFace:(HersheyFonts)fontFace fontScale:(double)fontScale color:(Scalar*)color NS_SWIFT_NAME(putText(img:text:org:fontFace:fontScale:color:));


//
//  Size cv::getTextSize(String text, HersheyFonts fontFace, double fontScale, int thickness, int* baseLine)
//
/**
 * Calculates the width and height of a text string.
 *
 * The function cv::getTextSize calculates and returns the size of a box that contains the specified text.
 * That is, the following code renders some text, the tight box surrounding it, and the baseline: :
 *
 *     String text = "Funny text inside the box";
 *     int fontFace = FONT_HERSHEY_SCRIPT_SIMPLEX;
 *     double fontScale = 2;
 *     int thickness = 3;
 *
 *     Mat img(600, 800, CV_8UC3, Scalar::all(0));
 *
 *     int baseline=0;
 *     Size textSize = getTextSize(text, fontFace,
 *                                 fontScale, thickness, &baseline);
 *     baseline += thickness;
 *
 *     // center the text
 *     Point textOrg((img.cols - textSize.width)/2,
 *                   (img.rows + textSize.height)/2);
 *
 *     // draw the box
 *     rectangle(img, textOrg + Point(0, baseline),
 *               textOrg + Point(textSize.width, -textSize.height),
 *               Scalar(0,0,255));
 *     // ... and the baseline first
 *     line(img, textOrg + Point(0, thickness),
 *          textOrg + Point(textSize.width, thickness),
 *          Scalar(0, 0, 255));
 *
 *     // then put the text itself
 *     putText(img, text, textOrg, fontFace, fontScale,
 *             Scalar::all(255), thickness, 8);
 *
 *
 * @param text Input text string.
 * @param fontFace Font to use, see ``HersheyFonts``.
 * @param fontScale Font scale factor that is multiplied by the font-specific base size.
 * @param thickness Thickness of lines used to render the text. See ``Imgproc/putText`` for details.
 * @param baseLine y-coordinate of the baseline relative to the bottom-most text
 * point.
 * @return The size of a box that contains the specified text.
 *
 * - SeeAlso ``putText:text:org:fontFace:fontScale:color:thickness:lineType:bottomLeftOrigin:``
 */
+ (Size2i*)getTextSize:(NSString*)text fontFace:(HersheyFonts)fontFace fontScale:(double)fontScale thickness:(int)thickness baseLine:(int*)baseLine NS_SWIFT_NAME(getTextSize(text:fontFace:fontScale:thickness:baseLine:));


//
//  double cv::getFontScaleFromHeight(int fontFace, int pixelHeight, int thickness = 1)
//
/**
 * Calculates the font-specific size to use to achieve a given height in pixels.
 *
 * @param fontFace Font to use, see cv::HersheyFonts.
 * @param pixelHeight Pixel height to compute the fontScale for
 * @param thickness Thickness of lines used to render the text.See putText for details.
 * @return The fontSize to use for cv::putText
 *
 * - SeeAlso cv::putText
 */
+ (double)getFontScaleFromHeight:(int)fontFace pixelHeight:(int)pixelHeight thickness:(int)thickness NS_SWIFT_NAME(getFontScaleFromHeight(fontFace:pixelHeight:thickness:));

/**
 * Calculates the font-specific size to use to achieve a given height in pixels.
 *
 * @param fontFace Font to use, see cv::HersheyFonts.
 * @param pixelHeight Pixel height to compute the fontScale for
 * @return The fontSize to use for cv::putText
 *
 * - SeeAlso cv::putText
 */
+ (double)getFontScaleFromHeight:(int)fontFace pixelHeight:(int)pixelHeight NS_SWIFT_NAME(getFontScaleFromHeight(fontFace:pixelHeight:));


//
//  Point cv::putText(Mat& img, String text, Point org, Scalar color, FontFace fface, int size, int weight = 0, PutTextFlags flags = PUT_TEXT_ALIGN_LEFT, Range wrap = Range())
//
/**
 * Draws a text string using specified font.
 *
 * The function cv::putText renders the specified text string in the image. Symbols that cannot be rendered
 * using the specified font are replaced by question marks. See ``Imgproc/getTextSize`` for a text rendering code
 * example. The function returns the coordinates in pixels from where the text can be continued.
 *
 * @param img Image.
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the first character of the printed text
 *            (see PUT_TEXT_ALIGN_... though)
 * @param color Text color.
 * @param fface The font to use for the text
 * @param size Font size in pixels (by default) or pts
 * @param weight Font weight, 100..1000,
 *        where 100 is "thin" font, 400 is "regular",
 *        600 is "semibold", 800 is "bold" and beyond that is "black".
 *        The parameter is ignored if the font is not a variable font or if it does not provide variation along 'wght' axis.
 *        If the weight is 0, then the weight, currently set via setInstance(), is used.
 * @param flags Various flags, see PUT_TEXT_...
 * @param wrap The optional text wrapping range:
 *        In the case of left-to-right (LTR) text if the printed character would cross wrap.end boundary,
 *        the "cursor" is set to wrap.start.
 *        In the case of right-to-left (RTL) text it's vice versa.
 *        If the parameters is not set,
 *        [org.x, img.cols] is used for LTR text and
 *        [0, org.x] is for RTL one.
 */
+ (Point2i*)putText:(Mat*)img text:(NSString*)text org:(Point2i*)org color:(Scalar*)color fface:(FontFace*)fface size:(int)size weight:(int)weight flags:(PutTextFlags)flags wrap:(Range*)wrap NS_SWIFT_NAME(putText(img:text:org:color:fface:size:weight:flags:wrap:));

/**
 * Draws a text string using specified font.
 *
 * The function cv::putText renders the specified text string in the image. Symbols that cannot be rendered
 * using the specified font are replaced by question marks. See ``Imgproc/getTextSize`` for a text rendering code
 * example. The function returns the coordinates in pixels from where the text can be continued.
 *
 * @param img Image.
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the first character of the printed text
 *            (see PUT_TEXT_ALIGN_... though)
 * @param color Text color.
 * @param fface The font to use for the text
 * @param size Font size in pixels (by default) or pts
 * @param weight Font weight, 100..1000,
 *        where 100 is "thin" font, 400 is "regular",
 *        600 is "semibold", 800 is "bold" and beyond that is "black".
 *        The parameter is ignored if the font is not a variable font or if it does not provide variation along 'wght' axis.
 *        If the weight is 0, then the weight, currently set via setInstance(), is used.
 * @param flags Various flags, see PUT_TEXT_...
 *        In the case of left-to-right (LTR) text if the printed character would cross wrap.end boundary,
 *        the "cursor" is set to wrap.start.
 *        In the case of right-to-left (RTL) text it's vice versa.
 *        If the parameters is not set,
 *        [org.x, img.cols] is used for LTR text and
 *        [0, org.x] is for RTL one.
 */
+ (Point2i*)putText:(Mat*)img text:(NSString*)text org:(Point2i*)org color:(Scalar*)color fface:(FontFace*)fface size:(int)size weight:(int)weight flags:(PutTextFlags)flags NS_SWIFT_NAME(putText(img:text:org:color:fface:size:weight:flags:));

/**
 * Draws a text string using specified font.
 *
 * The function cv::putText renders the specified text string in the image. Symbols that cannot be rendered
 * using the specified font are replaced by question marks. See ``Imgproc/getTextSize`` for a text rendering code
 * example. The function returns the coordinates in pixels from where the text can be continued.
 *
 * @param img Image.
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the first character of the printed text
 *            (see PUT_TEXT_ALIGN_... though)
 * @param color Text color.
 * @param fface The font to use for the text
 * @param size Font size in pixels (by default) or pts
 * @param weight Font weight, 100..1000,
 *        where 100 is "thin" font, 400 is "regular",
 *        600 is "semibold", 800 is "bold" and beyond that is "black".
 *        The parameter is ignored if the font is not a variable font or if it does not provide variation along 'wght' axis.
 *        If the weight is 0, then the weight, currently set via setInstance(), is used.
 *        In the case of left-to-right (LTR) text if the printed character would cross wrap.end boundary,
 *        the "cursor" is set to wrap.start.
 *        In the case of right-to-left (RTL) text it's vice versa.
 *        If the parameters is not set,
 *        [org.x, img.cols] is used for LTR text and
 *        [0, org.x] is for RTL one.
 */
+ (Point2i*)putText:(Mat*)img text:(NSString*)text org:(Point2i*)org color:(Scalar*)color fface:(FontFace*)fface size:(int)size weight:(int)weight NS_SWIFT_NAME(putText(img:text:org:color:fface:size:weight:));

/**
 * Draws a text string using specified font.
 *
 * The function cv::putText renders the specified text string in the image. Symbols that cannot be rendered
 * using the specified font are replaced by question marks. See ``Imgproc/getTextSize`` for a text rendering code
 * example. The function returns the coordinates in pixels from where the text can be continued.
 *
 * @param img Image.
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the first character of the printed text
 *            (see PUT_TEXT_ALIGN_... though)
 * @param color Text color.
 * @param fface The font to use for the text
 * @param size Font size in pixels (by default) or pts
 *        where 100 is "thin" font, 400 is "regular",
 *        600 is "semibold", 800 is "bold" and beyond that is "black".
 *        The parameter is ignored if the font is not a variable font or if it does not provide variation along 'wght' axis.
 *        If the weight is 0, then the weight, currently set via setInstance(), is used.
 *        In the case of left-to-right (LTR) text if the printed character would cross wrap.end boundary,
 *        the "cursor" is set to wrap.start.
 *        In the case of right-to-left (RTL) text it's vice versa.
 *        If the parameters is not set,
 *        [org.x, img.cols] is used for LTR text and
 *        [0, org.x] is for RTL one.
 */
+ (Point2i*)putText:(Mat*)img text:(NSString*)text org:(Point2i*)org color:(Scalar*)color fface:(FontFace*)fface size:(int)size NS_SWIFT_NAME(putText(img:text:org:color:fface:size:));


//
//  Rect cv::getTextSize(Size imgsize, String text, Point org, FontFace fface, int size, int weight = 0, PutTextFlags flags = PUT_TEXT_ALIGN_LEFT, Range wrap = Range())
//
/**
 * Calculates the bounding rect for the text
 *
 * The function cv::getTextSize calculates and returns the size of a box that contains the specified text.
 * That is, the following code renders some text, the tight box surrounding it, and the baseline: :
 *
 * @param imgsize Size of the target image, can be empty
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the first character of the printed text
 *            (see PUT_TEXT_ALIGN_... though)
 * @param fface The font to use for the text
 * @param size Font size in pixels (by default) or pts
 * @param weight Font weight, 100..1000,
 *         where 100 is "thin" font, 400 is "regular",
 *         600 is "semibold", 800 is "bold" and beyond that is "black".
 *         The default weight means "400" for variable-weight fonts or
 *         whatever "default" weight the used font provides.
 * @param flags Various flags, see PUT_TEXT_...
 * @param wrap The optional text wrapping range; see ``Imgproc/putText``.
 */
+ (Rect2i*)getTextSize:(Size2i*)imgsize text:(NSString*)text org:(Point2i*)org fface:(FontFace*)fface size:(int)size weight:(int)weight flags:(PutTextFlags)flags wrap:(Range*)wrap NS_SWIFT_NAME(getTextSize(imgsize:text:org:fface:size:weight:flags:wrap:));

/**
 * Calculates the bounding rect for the text
 *
 * The function cv::getTextSize calculates and returns the size of a box that contains the specified text.
 * That is, the following code renders some text, the tight box surrounding it, and the baseline: :
 *
 * @param imgsize Size of the target image, can be empty
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the first character of the printed text
 *            (see PUT_TEXT_ALIGN_... though)
 * @param fface The font to use for the text
 * @param size Font size in pixels (by default) or pts
 * @param weight Font weight, 100..1000,
 *         where 100 is "thin" font, 400 is "regular",
 *         600 is "semibold", 800 is "bold" and beyond that is "black".
 *         The default weight means "400" for variable-weight fonts or
 *         whatever "default" weight the used font provides.
 * @param flags Various flags, see PUT_TEXT_...
 */
+ (Rect2i*)getTextSize:(Size2i*)imgsize text:(NSString*)text org:(Point2i*)org fface:(FontFace*)fface size:(int)size weight:(int)weight flags:(PutTextFlags)flags NS_SWIFT_NAME(getTextSize(imgsize:text:org:fface:size:weight:flags:));

/**
 * Calculates the bounding rect for the text
 *
 * The function cv::getTextSize calculates and returns the size of a box that contains the specified text.
 * That is, the following code renders some text, the tight box surrounding it, and the baseline: :
 *
 * @param imgsize Size of the target image, can be empty
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the first character of the printed text
 *            (see PUT_TEXT_ALIGN_... though)
 * @param fface The font to use for the text
 * @param size Font size in pixels (by default) or pts
 * @param weight Font weight, 100..1000,
 *         where 100 is "thin" font, 400 is "regular",
 *         600 is "semibold", 800 is "bold" and beyond that is "black".
 *         The default weight means "400" for variable-weight fonts or
 *         whatever "default" weight the used font provides.
 */
+ (Rect2i*)getTextSize:(Size2i*)imgsize text:(NSString*)text org:(Point2i*)org fface:(FontFace*)fface size:(int)size weight:(int)weight NS_SWIFT_NAME(getTextSize(imgsize:text:org:fface:size:weight:));

/**
 * Calculates the bounding rect for the text
 *
 * The function cv::getTextSize calculates and returns the size of a box that contains the specified text.
 * That is, the following code renders some text, the tight box surrounding it, and the baseline: :
 *
 * @param imgsize Size of the target image, can be empty
 * @param text Text string to be drawn.
 * @param org Bottom-left corner of the first character of the printed text
 *            (see PUT_TEXT_ALIGN_... though)
 * @param fface The font to use for the text
 * @param size Font size in pixels (by default) or pts
 *         where 100 is "thin" font, 400 is "regular",
 *         600 is "semibold", 800 is "bold" and beyond that is "black".
 *         The default weight means "400" for variable-weight fonts or
 *         whatever "default" weight the used font provides.
 */
+ (Rect2i*)getTextSize:(Size2i*)imgsize text:(NSString*)text org:(Point2i*)org fface:(FontFace*)fface size:(int)size NS_SWIFT_NAME(getTextSize(imgsize:text:org:fface:size:));


//
//  void cv::HoughLinesWithAccumulator(Mat image, Mat& lines, double rho, double theta, int threshold, double srn = 0, double stn = 0, double min_theta = 0, double max_theta = CV_PI, bool use_edgeval = false)
//
/**
 * Finds lines in a binary image using the standard Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughLines:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:use_edgeval:``
 */
+ (void)HoughLinesWithAccumulator:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn stn:(double)stn min_theta:(double)min_theta max_theta:(double)max_theta use_edgeval:(BOOL)use_edgeval NS_SWIFT_NAME(HoughLinesWithAccumulator(image:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:use_edgeval:));

/**
 * Finds lines in a binary image using the standard Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughLines:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:use_edgeval:``
 */
+ (void)HoughLinesWithAccumulator:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn stn:(double)stn min_theta:(double)min_theta max_theta:(double)max_theta NS_SWIFT_NAME(HoughLinesWithAccumulator(image:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:));

/**
 * Finds lines in a binary image using the standard Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughLines:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:use_edgeval:``
 */
+ (void)HoughLinesWithAccumulator:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn stn:(double)stn min_theta:(double)min_theta NS_SWIFT_NAME(HoughLinesWithAccumulator(image:lines:rho:theta:threshold:srn:stn:min_theta:));

/**
 * Finds lines in a binary image using the standard Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughLines:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:use_edgeval:``
 */
+ (void)HoughLinesWithAccumulator:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn stn:(double)stn NS_SWIFT_NAME(HoughLinesWithAccumulator(image:lines:rho:theta:threshold:srn:stn:));

/**
 * Finds lines in a binary image using the standard Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughLines:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:use_edgeval:``
 */
+ (void)HoughLinesWithAccumulator:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold srn:(double)srn NS_SWIFT_NAME(HoughLinesWithAccumulator(image:lines:rho:theta:threshold:srn:));

/**
 * Finds lines in a binary image using the standard Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughLines:lines:rho:theta:threshold:srn:stn:min_theta:max_theta:use_edgeval:``
 */
+ (void)HoughLinesWithAccumulator:(Mat*)image lines:(Mat*)lines rho:(double)rho theta:(double)theta threshold:(int)threshold NS_SWIFT_NAME(HoughLinesWithAccumulator(image:lines:rho:theta:threshold:));


//
//  void cv::HoughCirclesWithAccumulator(Mat image, Mat& circles, int method, double dp, double minDist, double param1 = 100, double param2 = 100, int minRadius = 0, int maxRadius = 0)
//
/**
 * Finds circles in a grayscale image using the Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughCircles:circles:method:dp:minDist:param1:param2:minRadius:maxRadius:``
 */
+ (void)HoughCirclesWithAccumulator:(Mat*)image circles:(Mat*)circles method:(int)method dp:(double)dp minDist:(double)minDist param1:(double)param1 param2:(double)param2 minRadius:(int)minRadius maxRadius:(int)maxRadius NS_SWIFT_NAME(HoughCirclesWithAccumulator(image:circles:method:dp:minDist:param1:param2:minRadius:maxRadius:));

/**
 * Finds circles in a grayscale image using the Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughCircles:circles:method:dp:minDist:param1:param2:minRadius:maxRadius:``
 */
+ (void)HoughCirclesWithAccumulator:(Mat*)image circles:(Mat*)circles method:(int)method dp:(double)dp minDist:(double)minDist param1:(double)param1 param2:(double)param2 minRadius:(int)minRadius NS_SWIFT_NAME(HoughCirclesWithAccumulator(image:circles:method:dp:minDist:param1:param2:minRadius:));

/**
 * Finds circles in a grayscale image using the Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughCircles:circles:method:dp:minDist:param1:param2:minRadius:maxRadius:``
 */
+ (void)HoughCirclesWithAccumulator:(Mat*)image circles:(Mat*)circles method:(int)method dp:(double)dp minDist:(double)minDist param1:(double)param1 param2:(double)param2 NS_SWIFT_NAME(HoughCirclesWithAccumulator(image:circles:method:dp:minDist:param1:param2:));

/**
 * Finds circles in a grayscale image using the Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughCircles:circles:method:dp:minDist:param1:param2:minRadius:maxRadius:``
 */
+ (void)HoughCirclesWithAccumulator:(Mat*)image circles:(Mat*)circles method:(int)method dp:(double)dp minDist:(double)minDist param1:(double)param1 NS_SWIFT_NAME(HoughCirclesWithAccumulator(image:circles:method:dp:minDist:param1:));

/**
 * Finds circles in a grayscale image using the Hough transform and get accumulator.
 *
 * *Note:* This function is for bindings use only. Use original function in C++ code
 *
 * - SeeAlso ``HoughCircles:circles:method:dp:minDist:param1:param2:minRadius:maxRadius:``
 */
+ (void)HoughCirclesWithAccumulator:(Mat*)image circles:(Mat*)circles method:(int)method dp:(double)dp minDist:(double)minDist NS_SWIFT_NAME(HoughCirclesWithAccumulator(image:circles:method:dp:minDist:));



@end

NS_ASSUME_NONNULL_END


