//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/core.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


@class IntVector;



NS_ASSUME_NONNULL_BEGIN

// C++: class ReduceParams
/**
 * The reduction that the n-dimensional #reduce performs.
 *
 * Everything the call needs besides the input and the output arrays, in one struct, so that further
 * options can be added without changing the signature.
 *
 * @see reduce
 *
 * Member of `Core`
 */
CV_EXPORTS @interface ReduceParams : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::ReduceParams> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::ReduceParams>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::ReduceParams>)nativePtr;
#endif


#pragma mark - Methods


//
//   cv::ReduceParams::ReduceParams(int rtype = REDUCE_SUM, vector_int axes = std::vector<int>(), bool keepdims = true, int dtype = -1)
//
- (instancetype)initWithRtype:(int)rtype axes:(IntVector*)axes keepdims:(BOOL)keepdims dtype:(int)dtype;

- (instancetype)initWithRtype:(int)rtype axes:(IntVector*)axes keepdims:(BOOL)keepdims;

- (instancetype)initWithRtype:(int)rtype axes:(IntVector*)axes;

- (instancetype)initWithRtype:(int)rtype;

- (instancetype)init;


    //
    // C++: int cv::ReduceParams::rtype
    //

@property int rtype;

    //
    // C++: vector_int cv::ReduceParams::axes
    //

@property IntVector* axes;

    //
    // C++: bool cv::ReduceParams::keepdims
    //

@property BOOL keepdims;

    //
    // C++: int cv::ReduceParams::dtype
    //

@property int dtype;


@end

NS_ASSUME_NONNULL_END


