//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/dnn.hpp"
#import "opencv2/dnn/dnn.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>


@class Mat;



NS_ASSUME_NONNULL_BEGIN

// C++: class LayerInfo
/**
 * Backend-independent description of a graph operation (node).
 *
 * %LayerInfo carries everything needed to reason about an operation *without* executing it:
 * its parameters (#blobs and type-specific fields of derived classes), graph wiring
 * (#inputs / #outputs as Arg indices) and shape/type/layout inference. The new DNN graph
 * engine stores a topologically sorted sequence of %LayerInfo nodes (see Graph::prog());
 * executable, backend-specific instances (Layer subclasses) are constructed from an
 * %LayerInfo during Net::finalizeNet().
 *
 * Each operation type registers a `static Ptr<LayerInfo> create(const LayerParams&)` factory
 * via *Ref:* CV_DNN_REGISTER_OP_CLASS.
 *
 * Member of `Dnn`
 */
CV_EXPORTS @interface LayerInfo : NSObject


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::dnn::LayerInfo> nativePtr;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::dnn::LayerInfo>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::dnn::LayerInfo>)nativePtr;
#endif


#pragma mark - Methods


//
//  int cv::dnn::LayerInfo::outputNameToIndex(String outputName)
//
- (int)outputNameToIndex:(NSString*)outputName NS_SWIFT_NAME(outputNameToIndex(outputName:));


    //
    // C++: vector_Mat cv::dnn::LayerInfo::blobs
    //

@property Mat* blobs;

    //
    // C++: String cv::dnn::LayerInfo::name
    //

@property (readonly) NSString* name;

    //
    // C++: String cv::dnn::LayerInfo::type
    //

@property (readonly) NSString* type;


@end

NS_ASSUME_NONNULL_END


