/*M///////////////////////////////////////////////////////////////////////////////////////
//
//  IMPORTANT: READ BEFORE DOWNLOADING, COPYING, INSTALLING OR USING.
//
//  By downloading, copying, installing or using the software you agree to this license.
//  If you do not agree to this license, do not download, install,
//  copy or use the software.
//
//
//                          License Agreement
//                For Open Source Computer Vision Library
//
// Copyright (C) 2000-2008, Intel Corporation, all rights reserved.
// Copyright (C) 2009, Willow Garage Inc., all rights reserved.
// Copyright (C) 2013, OpenCV Foundation, all rights reserved.
// Copyright (C) 2014, Itseez Inc., all rights reserved.
// Third party copyrights are property of their respective owners.
//
// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
//   * Redistribution's of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//   * Redistribution's in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
//   * The name of the copyright holders may not be used to endorse or promote products
//     derived from this software without specific prior written permission.
//
// This software is provided by the copyright holders and contributors "as is" and
// any express or implied warranties, including, but not limited to, the implied
// warranties of merchantability and fitness for a particular purpose are disclaimed.
// In no event shall the Intel Corporation or contributors be liable for any direct,
// indirect, incidental, special, exemplary, or consequential damages
// (including, but not limited to, procurement of substitute goods or services;
// loss of use, data, or profits; or business interruption) however caused
// and on any theory of liability, whether in contract, strict liability,
// or tort (including negligence or otherwise) arising in any way out of
// the use of this software, even if advised of the possibility of such damage.
//
//M*/

#ifndef OPENCV_CORE_SATURATE_HPP
#define OPENCV_CORE_SATURATE_HPP

#include "opencv2/core/cvdef.h"
#include <climits>
#include "opencv2/core/fast_math.hpp"

namespace cv
{

//! @addtogroup core_utils
//! @{

/////////////// saturate_cast (used in image & signal processing) ///////////////////

/** @brief Template function for accurate conversion from one primitive type to another.

 The function saturate_cast resembles the standard C++ cast operations, such as static_cast\<T\>()
 and others. It perform an efficient and accurate conversion from one primitive type to another
 (see the introduction chapter). saturate in the name means that when the input value v is out of the
 range of the target type, the result is not formed just by taking low bits of the input, but instead
 the value is clipped. For example:
 @code
 uchar a = saturate_cast<uchar>(-100); // a = 0 (UCHAR_MIN)
 short b = saturate_cast<short>(33333.33333); // b = 32767 (SHRT_MAX)
 @endcode
 Such clipping is done when the target type is unsigned char , signed char , unsigned short or
 signed short . For 32- and 64-bit integer sources, no clipping is done when the target type is
 a 32- or 64-bit integer of the same or larger range: the value is converted using static_cast.

 When the parameter is a floating-point value and the target type is an integer (8-, 16-, 32- or 64-bit),
 the floating-point value is first rounded to the nearest integer (using the round-half-to-even rule,
 see cvRound and cvRound64) and then clipped to the target type range. In particular,
 saturate_cast<int>(1e10) == INT_MAX, saturate_cast<uchar>(1e10f) == 255,
 saturate_cast<uint64>(-1.) == 0. NaN is not handled, the result is unspecified (see cvRound).

 @param v Function parameter.
 @sa add, subtract, multiply, divide, Mat::convertTo
 */
template<typename _Tp> inline _Tp saturate_cast(uchar v)    { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(schar v)    { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(ushort v)   { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(short v)    { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(unsigned v) { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(int v)      { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(float v)    { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(double v)   { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(int64 v)    { return _Tp(v); }
/** @overload */
template<typename _Tp> inline _Tp saturate_cast(uint64 v)   { return _Tp(v); }

template<> inline uchar saturate_cast<uchar>(schar v)        { return (uchar)std::max((int)v, 0); }
template<> inline uchar saturate_cast<uchar>(ushort v)       { return (uchar)std::min((unsigned)v, (unsigned)UCHAR_MAX); }
template<> inline uchar saturate_cast<uchar>(int v)          { return (uchar)((unsigned)v <= UCHAR_MAX ? v : v > 0 ? UCHAR_MAX : 0); }
template<> inline uchar saturate_cast<uchar>(short v)        { return saturate_cast<uchar>((int)v); }
template<> inline uchar saturate_cast<uchar>(unsigned v)     { return (uchar)std::min(v, (unsigned)UCHAR_MAX); }
template<> inline uchar saturate_cast<uchar>(float v)        { int iv = cvRound(v); return saturate_cast<uchar>(iv); }
template<> inline uchar saturate_cast<uchar>(double v)       { int iv = cvRound(v); return saturate_cast<uchar>(iv); }
template<> inline uchar saturate_cast<uchar>(int64 v)        { return (uchar)((uint64)v <= (uint64)UCHAR_MAX ? v : v > 0 ? UCHAR_MAX : 0); }
template<> inline uchar saturate_cast<uchar>(uint64 v)       { return (uchar)std::min(v, (uint64)UCHAR_MAX); }

template<> inline schar saturate_cast<schar>(uchar v)        { return (schar)std::min((int)v, SCHAR_MAX); }
template<> inline schar saturate_cast<schar>(ushort v)       { return (schar)std::min((unsigned)v, (unsigned)SCHAR_MAX); }
// the range checks are done in unsigned arithmetic to avoid signed overflow (UB) for v close to INT_MAX/INT64_MAX
template<> inline schar saturate_cast<schar>(int v)          { return (schar)((unsigned)v + 128u <= (unsigned)UCHAR_MAX ? v : v > 0 ? SCHAR_MAX : SCHAR_MIN); }
template<> inline schar saturate_cast<schar>(short v)        { return saturate_cast<schar>((int)v); }
template<> inline schar saturate_cast<schar>(unsigned v)     { return (schar)std::min(v, (unsigned)SCHAR_MAX); }
template<> inline schar saturate_cast<schar>(float v)        { int iv = cvRound(v); return saturate_cast<schar>(iv); }
template<> inline schar saturate_cast<schar>(double v)       { int iv = cvRound(v); return saturate_cast<schar>(iv); }
template<> inline schar saturate_cast<schar>(int64 v)        { return (schar)((uint64)v + 128u <= (uint64)UCHAR_MAX ? v : v > 0 ? SCHAR_MAX : SCHAR_MIN); }
template<> inline schar saturate_cast<schar>(uint64 v)       { return (schar)std::min(v, (uint64)SCHAR_MAX); }

template<> inline ushort saturate_cast<ushort>(schar v)      { return (ushort)std::max((int)v, 0); }
template<> inline ushort saturate_cast<ushort>(short v)      { return (ushort)std::max((int)v, 0); }
template<> inline ushort saturate_cast<ushort>(int v)        { return (ushort)((unsigned)v <= (unsigned)USHRT_MAX ? v : v > 0 ? USHRT_MAX : 0); }
template<> inline ushort saturate_cast<ushort>(unsigned v)   { return (ushort)std::min(v, (unsigned)USHRT_MAX); }
template<> inline ushort saturate_cast<ushort>(float v)      { int iv = cvRound(v); return saturate_cast<ushort>(iv); }
template<> inline ushort saturate_cast<ushort>(double v)     { int iv = cvRound(v); return saturate_cast<ushort>(iv); }
template<> inline ushort saturate_cast<ushort>(int64 v)      { return (ushort)((uint64)v <= (uint64)USHRT_MAX ? v : v > 0 ? USHRT_MAX : 0); }
template<> inline ushort saturate_cast<ushort>(uint64 v)     { return (ushort)std::min(v, (uint64)USHRT_MAX); }

template<> inline short saturate_cast<short>(ushort v)       { return (short)std::min((int)v, SHRT_MAX); }
template<> inline short saturate_cast<short>(int v)          { return (short)((unsigned)v + 32768u <= (unsigned)USHRT_MAX ? v : v > 0 ? SHRT_MAX : SHRT_MIN); }
template<> inline short saturate_cast<short>(unsigned v)     { return (short)std::min(v, (unsigned)SHRT_MAX); }
template<> inline short saturate_cast<short>(float v)        { int iv = cvRound(v); return saturate_cast<short>(iv); }
template<> inline short saturate_cast<short>(double v)       { int iv = cvRound(v); return saturate_cast<short>(iv); }
template<> inline short saturate_cast<short>(int64 v)        { return (short)((uint64)v + 32768u <= (uint64)USHRT_MAX ? v : v > 0 ? SHRT_MAX : SHRT_MIN); }
template<> inline short saturate_cast<short>(uint64 v)       { return (short)std::min(v, (uint64)SHRT_MAX); }

template<> inline int saturate_cast<int>(unsigned v)         { return (int)std::min(v, (unsigned)INT_MAX); }
template<> inline int saturate_cast<int>(int64 v)            { return (int)((uint64)v + 2147483648u <= (uint64)UINT_MAX ? v : v > 0 ? INT_MAX : INT_MIN); }
template<> inline int saturate_cast<int>(uint64 v)           { return (int)std::min(v, (uint64)INT_MAX); }
template<> inline int saturate_cast<int>(float v)            { return cvRound(v); }
template<> inline int saturate_cast<int>(double v)           { return cvRound(v); }

template<> inline unsigned saturate_cast<unsigned>(schar v)  { return (unsigned)std::max(v, (schar)0); }
template<> inline unsigned saturate_cast<unsigned>(short v)  { return (unsigned)std::max(v, (short)0); }
template<> inline unsigned saturate_cast<unsigned>(int v)    { return (unsigned)std::max(v, (int)0); }
template<> inline unsigned saturate_cast<unsigned>(int64 v)  { return (unsigned)((uint64)v <= (uint64)UINT_MAX ? v : v > 0 ? UINT_MAX : 0); }
template<> inline unsigned saturate_cast<unsigned>(uint64 v) { return (unsigned)std::min(v, (uint64)UINT_MAX); }
template<> inline unsigned saturate_cast<unsigned>(float v)  { int64 iv = cvRound64(v); return iv < 0 ? 0u : iv > (int64)UINT_MAX ? UINT_MAX : (unsigned)iv; }
template<> inline unsigned saturate_cast<unsigned>(double v) { int64 iv = cvRound64(v); return iv < 0 ? 0u : iv > (int64)UINT_MAX ? UINT_MAX : (unsigned)iv; }

template<> inline uint64 saturate_cast<uint64>(schar v)      { return (uint64)std::max(v, (schar)0); }
template<> inline uint64 saturate_cast<uint64>(short v)      { return (uint64)std::max(v, (short)0); }
template<> inline uint64 saturate_cast<uint64>(int v)        { return (uint64)std::max(v, (int)0); }
template<> inline uint64 saturate_cast<uint64>(int64 v)      { return (uint64)std::max(v, (int64)0); }

template<> inline int64 saturate_cast<int64>(uint64 v)       { return (int64)std::min(v, (uint64)LLONG_MAX); }
template<> inline int64 saturate_cast<int64>(float v)        { return cvRound64(v); }
template<> inline int64 saturate_cast<int64>(double v)       { return cvRound64(v); }
// values >= 2^63 are integers already (float/double have at most 53 significant bits),
// so the direct conversion is exact and there is nothing to round
template<> inline uint64 saturate_cast<uint64>(float v)      { return v <= 0.f ? (uint64)0 : v < 9223372036854775808.f ? (uint64)cvRound64(v) : v < 18446744073709551616.f ? (uint64)v : (uint64)ULLONG_MAX; }
template<> inline uint64 saturate_cast<uint64>(double v)     { return v <= 0.  ? (uint64)0 : v < 9223372036854775808.0 ? (uint64)cvRound64(v) : v < 18446744073709551616.0 ? (uint64)v : (uint64)ULLONG_MAX; }


/** @overload */
template<typename _Tp> inline _Tp saturate_cast(hfloat v) { return saturate_cast<_Tp>((float)v); }
template<typename _Tp> inline _Tp saturate_cast(bfloat v) { return saturate_cast<_Tp>((float)v); }
template<typename _Tp> inline _Tp saturate_cast(bool v) { return saturate_cast<_Tp>(v ? 1 : 0); }

// in theory, we could use a LUT for 8u/8s->16f conversion,
// but with hardware support for FP32->FP16 conversion the current approach is preferable
template<> inline hfloat saturate_cast<hfloat>(uchar v)   { return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(schar v)   { return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(ushort v)  { return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(short v)   { return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(unsigned v){ return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(int v)     { return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(uint64 v)  { return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(int64 v)   { return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(float v)   { return hfloat(v); }
template<> inline hfloat saturate_cast<hfloat>(double v)  { return hfloat((float)v); }
template<> inline hfloat saturate_cast<hfloat>(hfloat v)  { return v; }
template<> inline hfloat saturate_cast<hfloat>(bfloat v)  { return hfloat((float)v); }

template<> inline bfloat saturate_cast<bfloat>(uchar v)   { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(schar v)   { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(ushort v)  { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(short v)   { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(unsigned v){ return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(int v)     { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(uint64 v)  { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(int64 v)   { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(float v)   { return bfloat(v); }
template<> inline bfloat saturate_cast<bfloat>(double v)  { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(hfloat v) { return bfloat((float)v); }
template<> inline bfloat saturate_cast<bfloat>(bfloat v) { return v; }

template<> inline bool saturate_cast<bool>(uchar v) { return v != 0; }
template<> inline bool saturate_cast<bool>(schar v) { return v != 0; }
template<> inline bool saturate_cast<bool>(ushort v) { return v != 0; }
template<> inline bool saturate_cast<bool>(short v) { return v != 0; }
template<> inline bool saturate_cast<bool>(unsigned v){ return v != 0; }
template<> inline bool saturate_cast<bool>(int v){ return v != 0; }
template<> inline bool saturate_cast<bool>(float v){ return v != 0; }
template<> inline bool saturate_cast<bool>(double v){ return v != 0; }
template<> inline bool saturate_cast<bool>(uint64_t v){ return v != 0; }
template<> inline bool saturate_cast<bool>(int64_t v){ return v != 0; }
template<> inline bool saturate_cast<bool>(hfloat v){ return (float)v != 0; }
template<> inline bool saturate_cast<bool>(bfloat v){ return (float)v != 0; }

// saturate_cast for the FP8 family — routes through float, mirroring hfloat/bfloat above.
#define CV_FP8_SATURATE_CAST(T) \
template<typename _Tp> static inline _Tp saturate_cast(T v) { return saturate_cast<_Tp>((float)v); } \
template<> inline T saturate_cast<T>(uchar v)    { return T((float)v); } \
template<> inline T saturate_cast<T>(schar v)    { return T((float)v); } \
template<> inline T saturate_cast<T>(ushort v)   { return T((float)v); } \
template<> inline T saturate_cast<T>(short v)    { return T((float)v); } \
template<> inline T saturate_cast<T>(unsigned v) { return T((float)v); } \
template<> inline T saturate_cast<T>(int v)      { return T((float)v); } \
template<> inline T saturate_cast<T>(uint64 v)   { return T((float)v); } \
template<> inline T saturate_cast<T>(int64 v)    { return T((float)v); } \
template<> inline T saturate_cast<T>(float v)    { return T(v); } \
template<> inline T saturate_cast<T>(double v)   { return T((float)v); } \
template<> inline T saturate_cast<T>(hfloat v)   { return T((float)v); } \
template<> inline T saturate_cast<T>(bfloat v)   { return T((float)v); } \
template<> inline T saturate_cast<T>(T v)        { return v; } \
template<> inline bool saturate_cast<bool>(T v)  { return (float)v != 0; }

CV_FP8_SATURATE_CAST(fp8_t)
CV_FP8_SATURATE_CAST(fp8a_t)
#undef CV_FP8_SATURATE_CAST

//! @}

} // cv

#endif // OPENCV_CORE_SATURATE_HPP
