//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/features.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>
#import "DescriptorMatcher.h"

@class ByteVector;
@class KeyPoint;
@class Mat;
@class Size2i;



NS_ASSUME_NONNULL_BEGIN

// C++: class LightGlueMatcher
/**
 * LightGlue feature matcher.
 *
 * LightGlue is an attention-based feature matcher, as described in *Cite:* Lindenberger23 . It takes
 * keypoint locations and descriptors from two images and directly predicts match pairs. Unlike
 * traditional matchers that compute descriptor distances, LightGlue produces confidence scores
 * for each potential match pair.
 *
 * The matcher extends DescriptorMatcher and supports match() and knnMatch() with k=1.
 * Context (keypoints and image sizes) must be provided via setPairInfo() or setImagePairInfo()
 * before matching. radiusMatch() is not supported.
 *
 * Member of `Features`
 */
CV_EXPORTS @interface LightGlueMatcher : DescriptorMatcher


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::LightGlueMatcher> nativePtrLightGlueMatcher;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::LightGlueMatcher>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::LightGlueMatcher>)nativePtr;
#endif


#pragma mark - Methods


//
// static Ptr_LightGlueMatcher cv::LightGlueMatcher::create(String modelPath, float scoreThreshold = 0.0f, int backend = 0, int target = 0, int type = LG_ALIKED)
//
/**
 * Creates LightGlueMatcher from a model file path.
 * @param modelPath Path to the ONNX model file.
 * @param scoreThreshold Match confidence threshold.
 * @param backend DNN backend
 * @param target DNN target
 * @param type Model variant: LG_ALIKED (default) or LG_DISK.
 */
+ (LightGlueMatcher*)createFromFile:(NSString*)modelPath scoreThreshold:(float)scoreThreshold backend:(int)backend target:(int)target type:(int)type NS_SWIFT_NAME(create(modelPath:scoreThreshold:backend:target:type:));

/**
 * Creates LightGlueMatcher from a model file path.
 * @param modelPath Path to the ONNX model file.
 * @param scoreThreshold Match confidence threshold.
 * @param backend DNN backend
 * @param target DNN target
 */
+ (LightGlueMatcher*)createFromFile:(NSString*)modelPath scoreThreshold:(float)scoreThreshold backend:(int)backend target:(int)target NS_SWIFT_NAME(create(modelPath:scoreThreshold:backend:target:));

/**
 * Creates LightGlueMatcher from a model file path.
 * @param modelPath Path to the ONNX model file.
 * @param scoreThreshold Match confidence threshold.
 * @param backend DNN backend
 */
+ (LightGlueMatcher*)createFromFile:(NSString*)modelPath scoreThreshold:(float)scoreThreshold backend:(int)backend NS_SWIFT_NAME(create(modelPath:scoreThreshold:backend:));

/**
 * Creates LightGlueMatcher from a model file path.
 * @param modelPath Path to the ONNX model file.
 * @param scoreThreshold Match confidence threshold.
 */
+ (LightGlueMatcher*)createFromFile:(NSString*)modelPath scoreThreshold:(float)scoreThreshold NS_SWIFT_NAME(create(modelPath:scoreThreshold:));

/**
 * Creates LightGlueMatcher from a model file path.
 * @param modelPath Path to the ONNX model file.
 */
+ (LightGlueMatcher*)createFromFile:(NSString*)modelPath NS_SWIFT_NAME(create(modelPath:));


//
// static Ptr_LightGlueMatcher cv::LightGlueMatcher::create(vector_uchar modelData, float scoreThreshold = 0.0f, int backend = 0, int target = 0, int type = LG_ALIKED)
//
/**
 * Creates LightGlueMatcher from in-memory model data.
 * @param modelData Buffer containing the model data.
 * @param scoreThreshold Match confidence threshold.
 * @param backend DNN backend
 * @param target DNN target
 * @param type Model variant: LG_ALIKED (default) or LG_DISK.
 */
+ (LightGlueMatcher*)createFromMemory:(ByteVector*)modelData scoreThreshold:(float)scoreThreshold backend:(int)backend target:(int)target type:(int)type NS_SWIFT_NAME(create(modelData:scoreThreshold:backend:target:type:));

/**
 * Creates LightGlueMatcher from in-memory model data.
 * @param modelData Buffer containing the model data.
 * @param scoreThreshold Match confidence threshold.
 * @param backend DNN backend
 * @param target DNN target
 */
+ (LightGlueMatcher*)createFromMemory:(ByteVector*)modelData scoreThreshold:(float)scoreThreshold backend:(int)backend target:(int)target NS_SWIFT_NAME(create(modelData:scoreThreshold:backend:target:));

/**
 * Creates LightGlueMatcher from in-memory model data.
 * @param modelData Buffer containing the model data.
 * @param scoreThreshold Match confidence threshold.
 * @param backend DNN backend
 */
+ (LightGlueMatcher*)createFromMemory:(ByteVector*)modelData scoreThreshold:(float)scoreThreshold backend:(int)backend NS_SWIFT_NAME(create(modelData:scoreThreshold:backend:));

/**
 * Creates LightGlueMatcher from in-memory model data.
 * @param modelData Buffer containing the model data.
 * @param scoreThreshold Match confidence threshold.
 */
+ (LightGlueMatcher*)createFromMemory:(ByteVector*)modelData scoreThreshold:(float)scoreThreshold NS_SWIFT_NAME(create(modelData:scoreThreshold:));

/**
 * Creates LightGlueMatcher from in-memory model data.
 * @param modelData Buffer containing the model data.
 */
+ (LightGlueMatcher*)createFromMemory:(ByteVector*)modelData NS_SWIFT_NAME(create(modelData:));


//
//  void cv::LightGlueMatcher::setPairInfo(Mat queryKpts, Mat trainKpts, Size queryImageSize = Size(), Size trainImageSize = Size())
//
/**
 * Sets the keypoint and image size context for the next match() call.
 *
 *     This provides the spatial context that LightGlue needs in addition to descriptors.
 *     Must be called before match()/knnMatch(), or use setImagePairInfo().
 *     Pixel coordinates are normalized according to the LightGlueType selected at creation, or as
 *     selected by setKeypointNormalization().
 *     For keypoints already normalized for that model, leave the corresponding image size empty.
 *
 * @param queryKpts Query image keypoints (Nx2 float matrix with x,y coordinates).
 * @param trainKpts Train image keypoints (Nx2 float matrix with x,y coordinates).
 * @param queryImageSize Size of the query image, or Size() for normalized query keypoints.
 * @param trainImageSize Size of the train image, or Size() for normalized train keypoints.
 */
- (void)setPairInfo:(Mat*)queryKpts trainKpts:(Mat*)trainKpts queryImageSize:(Size2i*)queryImageSize trainImageSize:(Size2i*)trainImageSize NS_SWIFT_NAME(setPairInfo(queryKpts:trainKpts:queryImageSize:trainImageSize:));

/**
 * Sets the keypoint and image size context for the next match() call.
 *
 *     This provides the spatial context that LightGlue needs in addition to descriptors.
 *     Must be called before match()/knnMatch(), or use setImagePairInfo().
 *     Pixel coordinates are normalized according to the LightGlueType selected at creation, or as
 *     selected by setKeypointNormalization().
 *     For keypoints already normalized for that model, leave the corresponding image size empty.
 *
 * @param queryKpts Query image keypoints (Nx2 float matrix with x,y coordinates).
 * @param trainKpts Train image keypoints (Nx2 float matrix with x,y coordinates).
 * @param queryImageSize Size of the query image, or Size() for normalized query keypoints.
 */
- (void)setPairInfo:(Mat*)queryKpts trainKpts:(Mat*)trainKpts queryImageSize:(Size2i*)queryImageSize NS_SWIFT_NAME(setPairInfo(queryKpts:trainKpts:queryImageSize:));

/**
 * Sets the keypoint and image size context for the next match() call.
 *
 *     This provides the spatial context that LightGlue needs in addition to descriptors.
 *     Must be called before match()/knnMatch(), or use setImagePairInfo().
 *     Pixel coordinates are normalized according to the LightGlueType selected at creation, or as
 *     selected by setKeypointNormalization().
 *     For keypoints already normalized for that model, leave the corresponding image size empty.
 *
 * @param queryKpts Query image keypoints (Nx2 float matrix with x,y coordinates).
 * @param trainKpts Train image keypoints (Nx2 float matrix with x,y coordinates).
 */
- (void)setPairInfo:(Mat*)queryKpts trainKpts:(Mat*)trainKpts NS_SWIFT_NAME(setPairInfo(queryKpts:trainKpts:));


//
//  void cv::LightGlueMatcher::clearPairInfo()
//
/**
 * Clears stored pair context information.
 */
- (void)clearPairInfo NS_SWIFT_NAME(clearPairInfo());


//
//  void cv::LightGlueMatcher::setKeypointNormalization(int normalization)
//
/**
 * Selects how pixel keypoints passed with an image size are normalized.
 *
 *     The default, LG_NORM_MODEL, keeps the per-axis mapping implied by the LightGlueType given at
 *     creation. LG_NORM_MAX_SIDE applies the mapping of the LightGlue reference implementation, which
 *     shifts by half the image size and divides both axes by half the longer side. Use it for models
 *     exported from the reference forward without their own normalization, e.g. XFeat's LighterGlue.
 *     For square images the two mappings coincide for LG_ALIKED.
 *
 *     The setting does not affect keypoints passed with an empty image size, and it is kept by clone().
 * @param normalization One of LightGlueNormalization.
 */
- (void)setKeypointNormalization:(int)normalization NS_SWIFT_NAME(setKeypointNormalization(normalization:));


//
//  int cv::LightGlueMatcher::getKeypointNormalization()
//
/**
 * Returns the keypoint normalization, one of LightGlueNormalization.
 */
- (int)getKeypointNormalization NS_SWIFT_NAME(getKeypointNormalization());


//
//  void cv::LightGlueMatcher::setImagePairInfo(vector_KeyPoint queryKpts, vector_KeyPoint trainKpts, Size queryImageSize = Size(), Size trainImageSize = Size())
//
/**
 * Convenience overload of setPairInfo() taking keypoints directly.
 *     Uses the same model-specific normalization and image size convention as setPairInfo().
 */
- (void)setImagePairInfo:(NSArray<KeyPoint*>*)queryKpts trainKpts:(NSArray<KeyPoint*>*)trainKpts queryImageSize:(Size2i*)queryImageSize trainImageSize:(Size2i*)trainImageSize NS_SWIFT_NAME(setImagePairInfo(queryKpts:trainKpts:queryImageSize:trainImageSize:));

/**
 * Convenience overload of setPairInfo() taking keypoints directly.
 *     Uses the same model-specific normalization and image size convention as setPairInfo().
 */
- (void)setImagePairInfo:(NSArray<KeyPoint*>*)queryKpts trainKpts:(NSArray<KeyPoint*>*)trainKpts queryImageSize:(Size2i*)queryImageSize NS_SWIFT_NAME(setImagePairInfo(queryKpts:trainKpts:queryImageSize:));

/**
 * Convenience overload of setPairInfo() taking keypoints directly.
 *     Uses the same model-specific normalization and image size convention as setPairInfo().
 */
- (void)setImagePairInfo:(NSArray<KeyPoint*>*)queryKpts trainKpts:(NSArray<KeyPoint*>*)trainKpts NS_SWIFT_NAME(setImagePairInfo(queryKpts:trainKpts:));



@end

NS_ASSUME_NONNULL_END


