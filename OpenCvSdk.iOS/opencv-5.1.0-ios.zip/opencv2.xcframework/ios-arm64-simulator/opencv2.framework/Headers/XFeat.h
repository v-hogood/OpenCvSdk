//
// This file is auto-generated. Please don't modify it!
//
#pragma once

#ifdef __cplusplus
//#import "opencv.hpp"
#import "opencv2/features.hpp"
#else
#define CV_EXPORTS
#endif

#import <Foundation/Foundation.h>
#import "Feature2D.h"

@class ByteVector;
@class Size2i;



NS_ASSUME_NONNULL_BEGIN

// C++: class XFeat
/**
 * XFeat feature detector and descriptor, based on a DNN model.
 *
 * XFeat is a compact learned local-feature extractor. This class wraps an ONNX export through
 * cv::dnn::Net and exposes score-map detections with 64-D float descriptors under the standard
 * cv::Feature2D interface.
 *
 * The class assumes the ONNX model has a single grayscale input tensor N×1×H×W in [0, 1] and
 * returns descriptor and score maps. The descriptor map must have 64 channels, and the keypoint
 * logit map must have either 64 channels (no extra class) or 65 channels, where the last channel
 * is treated as a dustbin/background class used only in softmax normalization. Images are resized
 * with preserved aspect ratio and padded to the configured network input size.
 *
 * Member of `Features`
 */
CV_EXPORTS @interface XFeat : Feature2D


#ifdef __cplusplus
@property(readonly)cv::Ptr<cv::XFeat> nativePtrXFeat;
#endif

#ifdef __cplusplus
- (instancetype)initWithNativePtr:(cv::Ptr<cv::XFeat>)nativePtr;
+ (instancetype)fromNative:(cv::Ptr<cv::XFeat>)nativePtr;
#endif


#pragma mark - Methods


//
// static Ptr_XFeat cv::XFeat::create(String modelPath, int maxKeypoints = -1, float scoreThreshold = 0.5f, Size inputSize = Size(640, 640), int backendId = 0, int targetId = 0)
//
/**
 * Creates an XFeat detector.
 * @param modelPath Path to the XFeat ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score not greater than this value.
 * @param inputSize Input size fed to the network, default Size(640, 640).
 * @param backendId DNN backend identifier (see cv::dnn::Backend); 0 = DNN_BACKEND_DEFAULT.
 * @param targetId  DNN target identifier (see cv::dnn::Target);  0 = DNN_TARGET_CPU.
 */
+ (XFeat*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold inputSize:(Size2i*)inputSize backendId:(int)backendId targetId:(int)targetId NS_SWIFT_NAME(create(modelPath:maxKeypoints:scoreThreshold:inputSize:backendId:targetId:));

/**
 * Creates an XFeat detector.
 * @param modelPath Path to the XFeat ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score not greater than this value.
 * @param inputSize Input size fed to the network, default Size(640, 640).
 * @param backendId DNN backend identifier (see cv::dnn::Backend); 0 = DNN_BACKEND_DEFAULT.
 */
+ (XFeat*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold inputSize:(Size2i*)inputSize backendId:(int)backendId NS_SWIFT_NAME(create(modelPath:maxKeypoints:scoreThreshold:inputSize:backendId:));

/**
 * Creates an XFeat detector.
 * @param modelPath Path to the XFeat ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score not greater than this value.
 * @param inputSize Input size fed to the network, default Size(640, 640).
 */
+ (XFeat*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold inputSize:(Size2i*)inputSize NS_SWIFT_NAME(create(modelPath:maxKeypoints:scoreThreshold:inputSize:));

/**
 * Creates an XFeat detector.
 * @param modelPath Path to the XFeat ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses are kept; -1 keeps all detections.
 * @param scoreThreshold Discard keypoints with network score not greater than this value.
 */
+ (XFeat*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold NS_SWIFT_NAME(create(modelPath:maxKeypoints:scoreThreshold:));

/**
 * Creates an XFeat detector.
 * @param modelPath Path to the XFeat ONNX model.
 * @param maxKeypoints Maximum number of keypoints to return per image. The strongest
 *                         responses are kept; -1 keeps all detections.
 */
+ (XFeat*)create:(NSString*)modelPath maxKeypoints:(int)maxKeypoints NS_SWIFT_NAME(create(modelPath:maxKeypoints:));

/**
 * Creates an XFeat detector.
 * @param modelPath Path to the XFeat ONNX model.
 *                         responses are kept; -1 keeps all detections.
 */
+ (XFeat*)create:(NSString*)modelPath NS_SWIFT_NAME(create(modelPath:));


//
// static Ptr_XFeat cv::XFeat::create(vector_uchar bufferModel, int maxKeypoints = -1, float scoreThreshold = 0.5f, Size inputSize = Size(640, 640), int backendId = 0, int targetId = 0)
//
/**
 * Creates an XFeat detector from an in-memory model buffer.
 */
+ (XFeat*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold inputSize:(Size2i*)inputSize backendId:(int)backendId targetId:(int)targetId NS_SWIFT_NAME(create(bufferModel:maxKeypoints:scoreThreshold:inputSize:backendId:targetId:));

/**
 * Creates an XFeat detector from an in-memory model buffer.
 */
+ (XFeat*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold inputSize:(Size2i*)inputSize backendId:(int)backendId NS_SWIFT_NAME(create(bufferModel:maxKeypoints:scoreThreshold:inputSize:backendId:));

/**
 * Creates an XFeat detector from an in-memory model buffer.
 */
+ (XFeat*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold inputSize:(Size2i*)inputSize NS_SWIFT_NAME(create(bufferModel:maxKeypoints:scoreThreshold:inputSize:));

/**
 * Creates an XFeat detector from an in-memory model buffer.
 */
+ (XFeat*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints scoreThreshold:(float)scoreThreshold NS_SWIFT_NAME(create(bufferModel:maxKeypoints:scoreThreshold:));

/**
 * Creates an XFeat detector from an in-memory model buffer.
 */
+ (XFeat*)createFromMemory:(ByteVector*)bufferModel maxKeypoints:(int)maxKeypoints NS_SWIFT_NAME(create(bufferModel:maxKeypoints:));

/**
 * Creates an XFeat detector from an in-memory model buffer.
 */
+ (XFeat*)createFromMemory:(ByteVector*)bufferModel NS_SWIFT_NAME(create(bufferModel:));


//
//  void cv::XFeat::setMaxKeypoints(int maxKeypoints)
//
- (void)setMaxKeypoints:(int)maxKeypoints NS_SWIFT_NAME(setMaxKeypoints(maxKeypoints:));


//
//  int cv::XFeat::getMaxKeypoints()
//
- (int)getMaxKeypoints NS_SWIFT_NAME(getMaxKeypoints());


//
//  void cv::XFeat::setScoreThreshold(float threshold)
//
- (void)setScoreThreshold:(float)threshold NS_SWIFT_NAME(setScoreThreshold(threshold:));


//
//  float cv::XFeat::getScoreThreshold()
//
- (float)getScoreThreshold NS_SWIFT_NAME(getScoreThreshold());


//
//  void cv::XFeat::setInputSize(Size inputSize)
//
- (void)setInputSize:(Size2i*)inputSize NS_SWIFT_NAME(setInputSize(inputSize:));


//
//  Size cv::XFeat::getInputSize()
//
- (Size2i*)getInputSize NS_SWIFT_NAME(getInputSize());


//
//  String cv::XFeat::getDefaultName()
//
- (NSString*)getDefaultName NS_SWIFT_NAME(getDefaultName());



@end

NS_ASSUME_NONNULL_END


